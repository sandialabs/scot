### Jetty

This plugin works with Jetty to manage the deployed applications, as well viewing information about connectors, and JMX, etc.

