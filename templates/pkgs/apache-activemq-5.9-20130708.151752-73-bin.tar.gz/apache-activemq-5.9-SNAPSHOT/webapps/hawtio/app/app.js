var org_fusesource_fabric_api_CreateContainerChildOptions = {
  "type" : "object",
  "properties" : {
    "name" : {
      "type" : "string"
    },
    "parent" : {
      "type" : "string"
    },
    "providerType" : {
      "type" : "string"
    },
    "ensembleServer" : {
      "type" : "boolean",
      "required" : true
    },
    "preferredAddress" : {
      "type" : "string"
    },
    "resolver" : {
      "type" : "string"
    },
    "minimumPort" : {
      "type" : "integer"
    },
    "maximumPort" : {
      "type" : "integer"
    },
    "systemProperties" : {
      "type" : "object"
    },
    "number" : {
      "type" : "integer"
    },
    "proxyUri" : {
      "type" : "string"
    },
    "zookeeperUrl" : {
      "type" : "string"
    },
    "zookeeperPassword" : {
      "type" : "string"
    },
    "jvmOpts" : {
      "type" : "string"
    },
    "adminAccess" : {
      "type" : "boolean",
      "required" : true
    },
    "metadataMap" : {
      "type" : "object"
    },
    "jmxUser" : {
      "type" : "string"
    },
    "jmxPassword" : {
      "type" : "string"
    }
  }
}
var org_fusesource_fabric_api_CreateJCloudsContainerOptions = {
  "type" : "object",
  "properties" : {
    "name" : {
      "type" : "string"
    },
    "parent" : {
      "type" : "string"
    },
    "providerType" : {
      "type" : "string"
    },
    "ensembleServer" : {
      "type" : "boolean",
      "required" : true
    },
    "preferredAddress" : {
      "type" : "string"
    },
    "resolver" : {
      "type" : "string"
    },
    "minimumPort" : {
      "type" : "integer"
    },
    "maximumPort" : {
      "type" : "integer"
    },
    "systemProperties" : {
      "type" : "object"
    },
    "number" : {
      "type" : "integer"
    },
    "proxyUri" : {
      "type" : "string"
    },
    "zookeeperUrl" : {
      "type" : "string"
    },
    "zookeeperPassword" : {
      "type" : "string"
    },
    "jvmOpts" : {
      "type" : "string"
    },
    "adminAccess" : {
      "type" : "boolean",
      "required" : true
    },
    "metadataMap" : {
      "type" : "object"
    },
    "osFamily" : {
      "type" : "string"
    },
    "osVersion" : {
      "type" : "string"
    },
    "imageId" : {
      "type" : "string"
    },
    "hardwareId" : {
      "type" : "string"
    },
    "locationId" : {
      "type" : "string"
    },
    "group" : {
      "type" : "string"
    },
    "user" : {
      "type" : "string"
    },
    "password" : {
      "type" : "string"
    },
    "contextName" : {
      "type" : "string"
    },
    "providerName" : {
      "type" : "string"
    },
    "apiName" : {
      "type" : "string"
    },
    "endpoint" : {
      "type" : "string"
    },
    "instanceType" : {
      "type" : "string",
      "enum" : [ "Smallest", "Biggest", "Fastest" ]
    },
    "identity" : {
      "type" : "string"
    },
    "credential" : {
      "type" : "string"
    },
    "owner" : {
      "type" : "string"
    },
    "serviceOptions" : {
      "type" : "object"
    },
    "nodeOptions" : {
      "type" : "object"
    },
    "servicePort" : {
      "type" : "integer"
    },
    "publicKeyFile" : {
      "type" : "string"
    },
    "createEnsembleOptions" : {
      "type" : "object",
      "properties" : {
        "zookeeperPassword" : {
          "type" : "string"
        },
        "users" : {
          "type" : "object"
        }
      }
    },
    "path" : {
      "type" : "string"
    }
  }
}
var org_fusesource_fabric_api_CreateSshContainerOptions = {
  "type" : "object",
  "properties" : {
    "name" : {
      "type" : "string"
    },
    "parent" : {
      "type" : "string"
    },
    "providerType" : {
      "type" : "string"
    },
    "ensembleServer" : {
      "type" : "boolean",
      "required" : true
    },
    "preferredAddress" : {
      "type" : "string"
    },
    "resolver" : {
      "type" : "string"
    },
    "minimumPort" : {
      "type" : "integer"
    },
    "maximumPort" : {
      "type" : "integer"
    },
    "systemProperties" : {
      "type" : "object"
    },
    "number" : {
      "type" : "integer"
    },
    "proxyUri" : {
      "type" : "string"
    },
    "zookeeperUrl" : {
      "type" : "string"
    },
    "zookeeperPassword" : {
      "type" : "string"
    },
    "jvmOpts" : {
      "type" : "string"
    },
    "adminAccess" : {
      "type" : "boolean",
      "required" : true
    },
    "metadataMap" : {
      "type" : "object"
    },
    "username" : {
      "type" : "string"
    },
    "password" : {
      "type" : "string"
    },
    "host" : {
      "type" : "string"
    },
    "port" : {
      "type" : "integer"
    },
    "sshRetries" : {
      "type" : "integer"
    },
    "retryDelay" : {
      "type" : "integer"
    },
    "privateKeyFile" : {
      "type" : "string"
    },
    "passPhrase" : {
      "type" : "string"
    },
    "createEnsembleOptions" : {
      "type" : "object",
      "properties" : {
        "zookeeperPassword" : {
          "type" : "string"
        },
        "users" : {
          "type" : "object"
        }
      }
    },
    "path" : {
      "type" : "string"
    }
  }
}
var ActiveMQ;
(function (ActiveMQ) {
    var pluginName = 'activemq';
    var jmxDomain = 'org.apache.activemq';
    angular.module(pluginName, [
        'bootstrap', 
        'ngResource', 
        'ui.bootstrap.dialog', 
        'hawtioCore', 
        'camel', 
        'hawtio-ui'
    ]).config(function ($routeProvider) {
        $routeProvider.when('/activemq/browseQueue', {
            templateUrl: 'app/activemq/html/browseQueue.html'
        }).when('/activemq/subscribers', {
            templateUrl: 'app/activemq/html/subscribers.html'
        }).when('/activemq/createQueue', {
            templateUrl: 'app/activemq/html/createQueue.html'
        }).when('/activemq/createTopic', {
            templateUrl: 'app/activemq/html/createTopic.html'
        }).when('/activemq/deleteQueue', {
            templateUrl: 'app/activemq/html/deleteQueue.html'
        }).when('/activemq/deleteTopic', {
            templateUrl: 'app/activemq/html/deleteTopic.html'
        }).when('/activemq/sendMessage', {
            templateUrl: 'app/camel/html/sendMessage.html'
        }).when('/activemq/durableSubscribers', {
            templateUrl: 'app/activemq/html/durableSubscribers.html'
        });
    }).run(function ($location, workspace, viewRegistry) {
        viewRegistry['activemq'] = 'app/activemq/html/layoutActiveMQTree.html';
        workspace.addTreePostProcessor(postProcessTree);
        var attributes = workspace.attributeColumnDefs;
        attributes[jmxDomain + "/Broker/folder"] = [
            {
                field: 'BrokerName',
                displayName: 'Name',
                width: "**"
            }, 
            {
                field: 'TotalProducerCount',
                displayName: 'Producer #'
            }, 
            {
                field: 'TotalConsumerCount',
                displayName: 'Consumer #'
            }, 
            {
                field: 'StorePercentUsage',
                displayName: 'Store %'
            }, 
            {
                field: 'TempPercentUsage',
                displayName: 'Temp %'
            }, 
            {
                field: 'MemoryPercentUsage',
                displayName: 'Memory %'
            }, 
            {
                field: 'TotalEnqueueCount',
                displayName: 'Enqueue #'
            }, 
            {
                field: 'TotalDequeueCount',
                displayName: 'Dequeue #'
            }
        ];
        attributes[jmxDomain + "/Queue/folder"] = [
            {
                field: 'Name',
                displayName: 'Name',
                width: "***"
            }, 
            {
                field: 'QueueSize',
                displayName: 'Queue Size'
            }, 
            {
                field: 'ProducerCount',
                displayName: 'Producer #'
            }, 
            {
                field: 'ConsumerCount',
                displayName: 'Consumer #'
            }, 
            {
                field: 'EnqueueCount',
                displayName: 'Enqueue #'
            }, 
            {
                field: 'DequeueCount',
                displayName: 'Dequeue #'
            }, 
            {
                field: 'MemoryPercentUsage',
                displayName: 'Memory %'
            }, 
            {
                field: 'DispatchCount',
                displayName: 'Dispatch #',
                visible: false
            }
        ];
        attributes[jmxDomain + "/Topic/folder"] = [
            {
                field: 'Name',
                displayName: 'Name',
                width: "****"
            }, 
            {
                field: 'ProducerCount',
                displayName: 'Producer #'
            }, 
            {
                field: 'ConsumerCount',
                displayName: 'Consumer #'
            }, 
            {
                field: 'EnqueueCount',
                displayName: 'Enqueue #'
            }, 
            {
                field: 'DequeueCount',
                displayName: 'Dequeue #'
            }, 
            {
                field: 'MemoryPercentUsage',
                displayName: 'Memory %'
            }, 
            {
                field: 'DispatchCount',
                displayName: 'Dispatch #',
                visible: false
            }
        ];
        attributes[jmxDomain + "/Consumer/folder"] = [
            {
                field: 'ConnectionId',
                displayName: 'Name',
                width: "**"
            }, 
            {
                field: 'PrefetchSize',
                displayName: 'Prefetch Size'
            }, 
            {
                field: 'Priority',
                displayName: 'Priority'
            }, 
            {
                field: 'DispatchedQueueSize',
                displayName: 'Dispatched Queue #'
            }, 
            {
                field: 'SlowConsumer',
                displayName: 'Slow ?'
            }, 
            {
                field: 'Retroactive',
                displayName: 'Retroactive'
            }, 
            {
                field: 'Selector',
                displayName: 'Selector'
            }
        ];
        attributes[jmxDomain + "/networkConnectors/folder"] = [
            {
                field: 'Name',
                displayName: 'Name',
                width: "**"
            }, 
            {
                field: 'UserName',
                displayName: 'User Name'
            }, 
            {
                field: 'PrefetchSize',
                displayName: 'Prefetch Size'
            }, 
            {
                field: 'ConduitSubscriptions',
                displayName: 'Conduit Subscriptions?'
            }, 
            {
                field: 'Duplex',
                displayName: 'Duplex'
            }, 
            {
                field: 'DynamicOnly',
                displayName: 'Dynamic Only'
            }
        ];
        attributes[jmxDomain + "/PersistenceAdapter/folder"] = [
            {
                field: 'IndexDirectory',
                displayName: 'Index Directory',
                width: "**"
            }, 
            {
                field: 'LogDirectory',
                displayName: 'Log Directory',
                width: "**"
            }
        ];
        workspace.topLevelTabs.push({
            content: "ActiveMQ",
            title: "Manage your ActiveMQ message brokers",
            isValid: function (workspace) {
                return workspace.treeContainsDomainAndProperties("org.apache.activemq");
            },
            href: function () {
                return "#/jmx/attributes?tab=activemq";
            },
            isActive: function () {
                return workspace.isTopTabActive("activemq");
            }
        });
        workspace.subLevelTabs.push({
            content: '<i class="icon-envelope"></i> Browse',
            title: "Browse the messages on the queue",
            isValid: function (workspace) {
                return isQueue(workspace);
            },
            href: function () {
                return "#/activemq/browseQueue";
            }
        });
        workspace.subLevelTabs.push({
            content: '<i class="icon-pencil"></i> Send',
            title: "Send a message to this destination",
            isValid: function (workspace) {
                return isQueue(workspace) || isTopic(workspace);
            },
            href: function () {
                return "#/activemq/sendMessage";
            }
        });
        workspace.subLevelTabs.push({
            content: '<i class="icon-picture"></i> Diagram',
            title: "View a diagram of the producers, destinations and consumers",
            isValid: function (workspace) {
                return isActiveMQFolder(workspace);
            },
            href: function () {
                return "#/activemq/subscribers";
            }
        });
        workspace.subLevelTabs.push({
            content: '<i class="icon-plus"></i> Create',
            title: "Create a new queue",
            isValid: function (workspace) {
                return isQueuesFolder(workspace) || isBroker(workspace);
            },
            href: function () {
                return "#/activemq/createQueue";
            }
        });
        workspace.subLevelTabs.push({
            content: '<i class="icon-plus"></i> Create',
            title: "Create a new topic",
            isValid: function (workspace) {
                return isTopicsFolder(workspace) || isBroker(workspace);
            },
            href: function () {
                return "#/activemq/createTopic";
            }
        });
        workspace.subLevelTabs.push({
            content: '<i class="icon-remove"></i> Delete Topic',
            title: "Delete this topic",
            isValid: function (workspace) {
                return isTopic(workspace);
            },
            href: function () {
                return "#/activemq/deleteTopic";
            }
        });
        workspace.subLevelTabs.push({
            content: '<i class="icon-remove"></i> Delete',
            title: "Delete or purge this queue",
            isValid: function (workspace) {
                return isQueue(workspace);
            },
            href: function () {
                return "#/activemq/deleteQueue";
            }
        });
        workspace.subLevelTabs.push({
            content: '<i class="icon-list"></i> Durable Subscribers',
            title: "Manage durable subscribers",
            isValid: function (workspace) {
                return isBroker(workspace);
            },
            href: function () {
                return "#/activemq/durableSubscribers";
            }
        });
        function postProcessTree(tree) {
            var activemq = tree.get("org.apache.activemq");
            setConsumerType(activemq);
            if(activemq) {
                angular.forEach(activemq.children, function (broker) {
                    angular.forEach(broker.children, function (child) {
                        var grandChildren = child.children;
                        if(grandChildren) {
                            var names = [
                                "Topic", 
                                "Queue"
                            ];
                            angular.forEach(names, function (name) {
                                var idx = grandChildren.findIndex(function (n) {
                                    return n.title === name;
                                });
                                if(idx > 0) {
                                    var old = grandChildren[idx];
                                    grandChildren.splice(idx, 1);
                                    grandChildren.splice(0, 0, old);
                                }
                            });
                        }
                    });
                });
            }
        }
        function setConsumerType(node) {
            if(node) {
                var parent = node.parent;
                var entries = node.entries;
                if(parent && !parent.typeName && entries) {
                    var endpoint = entries["endpoint"];
                    if(endpoint === "Consumer" || endpoint === "Producer") {
                        parent.typeName = endpoint;
                    }
                }
                angular.forEach(node.children, function (child) {
                    return setConsumerType(child);
                });
            }
        }
    });
    hawtioPluginLoader.addModule(pluginName);
    function isQueue(workspace) {
        return workspace.hasDomainAndProperties(jmxDomain, {
            'destinationType': 'Queue'
        }, 4) || workspace.selectionHasDomainAndType(jmxDomain, 'Queue');
    }
    ActiveMQ.isQueue = isQueue;
    function isTopic(workspace) {
        return workspace.hasDomainAndProperties(jmxDomain, {
            'destinationType': 'Topic'
        }, 4) || workspace.selectionHasDomainAndType(jmxDomain, 'Topic');
    }
    ActiveMQ.isTopic = isTopic;
    function isQueuesFolder(workspace) {
        return workspace.selectionHasDomainAndLastFolderName(jmxDomain, 'Queue');
    }
    ActiveMQ.isQueuesFolder = isQueuesFolder;
    function isTopicsFolder(workspace) {
        return workspace.selectionHasDomainAndLastFolderName(jmxDomain, 'Topic');
    }
    ActiveMQ.isTopicsFolder = isTopicsFolder;
    function isBroker(workspace) {
        if(workspace.selectionHasDomainAndType(jmxDomain, 'Broker')) {
            var parent = workspace.selection.parent;
            return !(parent && parent.ancestorHasType('Broker'));
        }
        return false;
    }
    ActiveMQ.isBroker = isBroker;
    function isActiveMQFolder(workspace) {
        return workspace.hasDomainAndProperties(jmxDomain);
    }
    ActiveMQ.isActiveMQFolder = isActiveMQFolder;
})(ActiveMQ || (ActiveMQ = {}));
var ActiveMQ;
(function (ActiveMQ) {
    function BrowseQueueController($scope, workspace, jolokia) {
        $scope.searchText = '';
        $scope.messages = [];
        $scope.headers = {
        };
        $scope.mode = 'text';
        $scope.deleteDialog = false;
        $scope.moveDialog = false;
        $scope.gridOptions = {
            selectedItems: [],
            data: 'messages',
            displayFooter: false,
            showFilter: false,
            showColumnMenu: true,
            enableColumnResize: true,
            enableColumnReordering: true,
            filterOptions: {
                filterText: ''
            },
            selectWithCheckboxOnly: true,
            showSelectionCheckbox: true,
            maintainColumnRatios: false,
            columnDefs: [
                {
                    field: 'JMSMessageID',
                    displayName: 'Message ID',
                    cellTemplate: '<div class="ngCellText"><a ng-click="openMessageDialog(row)">{{row.entity.JMSMessageID}}</a></div>',
                    width: '34%'
                }, 
                {
                    field: 'JMSType',
                    displayName: 'Type',
                    width: '10%'
                }, 
                {
                    field: 'JMSPriority',
                    displayName: 'Priority',
                    width: '7%'
                }, 
                {
                    field: 'JMSTimestamp',
                    displayName: 'Timestamp',
                    width: '19%'
                }, 
                {
                    field: 'JMSExpiration',
                    displayName: 'Expires',
                    width: '10%'
                }, 
                {
                    field: 'JMSReplyTo',
                    displayName: 'Reply To',
                    width: '10%'
                }, 
                {
                    field: 'JMSCorrelationID',
                    displayName: 'Correlation ID',
                    width: '10%'
                }
            ]
        };
        $scope.showMessageDetails = false;
        var ignoreColumns = [
            "PropertiesText", 
            "BodyPreview", 
            "Text"
        ];
        var flattenColumns = [
            "BooleanProperties", 
            "ByteProperties", 
            "ShortProperties", 
            "IntProperties", 
            "LongProperties", 
            "FloatProperties", 
            "DoubleProperties", 
            "StringProperties"
        ];
        $scope.$watch('workspace.selection', function () {
            if(workspace.moveIfViewInvalid()) {
                return;
            }
            setTimeout(loadTable, 50);
        });
        $scope.openMessageDialog = function (message) {
            var idx = Core.pathGet(message, [
                "rowIndex"
            ]);
            $scope.selectRowIndex(idx);
            if($scope.row) {
                $scope.mode = CodeEditor.detectTextFormat($scope.row.Text);
                $scope.showMessageDetails = true;
            }
        };
        $scope.refresh = loadTable;
        $scope.selectRowIndex = function (idx) {
            $scope.rowIndex = idx;
            var selected = $scope.gridOptions.selectedItems;
            selected.splice(0, selected.length);
            if(idx >= 0 && idx < $scope.messages.length) {
                $scope.row = $scope.messages[idx];
                if($scope.row) {
                    selected.push($scope.row);
                }
            } else {
                $scope.row = null;
            }
        };
        $scope.moveMessages = function () {
            var selection = workspace.selection;
            var mbean = selection.objectName;
            if(mbean && selection) {
                var selectedItems = $scope.gridOptions.selectedItems;
                $scope.message = "Moved " + Core.maybePlural(selectedItems.length, "message" + " to " + $scope.queueName);
                var operation = "moveMessageTo(java.lang.String, java.lang.String)";
                angular.forEach(selectedItems, function (item, idx) {
                    var id = item.JMSMessageID;
                    if(id) {
                        var callback = (idx + 1 < selectedItems.length) ? intermediateResult : moveSuccess;
                        jolokia.execute(mbean, operation, id, $scope.queueName, onSuccess(callback));
                    }
                });
            }
        };
        $scope.deleteMessages = function () {
            var selection = workspace.selection;
            var mbean = selection.objectName;
            if(mbean && selection) {
                var selectedItems = $scope.gridOptions.selectedItems;
                $scope.message = "Deleted " + Core.maybePlural(selectedItems.length, "message");
                var operation = "removeMessage(java.lang.String)";
                angular.forEach(selectedItems, function (item, idx) {
                    var id = item.JMSMessageID;
                    if(id) {
                        var callback = (idx + 1 < selectedItems.length) ? intermediateResult : operationSuccess;
                        jolokia.execute(mbean, operation, id, onSuccess(callback));
                    }
                });
            }
        };
        $scope.retryMessages = function () {
            var selection = workspace.selection;
            var mbean = selection.objectName;
            if(mbean && selection) {
                var selectedItems = $scope.gridOptions.selectedItems;
                $scope.message = "Retry " + Core.maybePlural(selectedItems.length, "message");
                var operation = "retryMessage(java.lang.String)";
                angular.forEach(selectedItems, function (item, idx) {
                    var id = item.JMSMessageID;
                    if(id) {
                        var callback = (idx + 1 < selectedItems.length) ? intermediateResult : operationSuccess;
                        jolokia.execute(mbean, operation, id, onSuccess(callback));
                    }
                });
            }
        };
        $scope.queueNames = function () {
            var queuesFolder = ActiveMQ.getSelectionQueuesFolder(workspace);
            return (queuesFolder) ? queuesFolder.children.map(function (n) {
                return n.title;
            }) : [];
        };
        function populateTable(response) {
            var data = response.value;
            if(!angular.isArray(data)) {
                $scope.messages = [];
                angular.forEach(data, function (value, idx) {
                    $scope.messages.push(value);
                });
            } else {
                $scope.messages = data;
            }
            angular.forEach($scope.messages, function (message) {
                message.headerHtml = createHeaderHtml(message);
            });
            Core.$apply($scope);
        }
        function createHeaderHtml(message) {
            var headers = createHeaders(message);
            var buffer = "";
            angular.forEach(headers, function (value, key) {
                buffer += "<tr><td class='property-name'>" + key + "</td>" + "<td class='property-value'>" + value + "</td></tr>";
            });
            return buffer;
        }
        function createHeaders(row) {
            var answer = {
            };
            angular.forEach(row, function (value, key) {
                if(!ignoreColumns.any(key)) {
                    if(flattenColumns.any(key)) {
                        angular.forEach(value, function (v2, k2) {
                            return answer[k2] = v2;
                        });
                    } else {
                        answer[key] = value;
                    }
                }
            });
            return answer;
        }
        function loadTable() {
            var selection = workspace.selection;
            if(selection) {
                var mbean = selection.objectName;
                if(mbean) {
                    $scope.dlq = false;
                    jolokia.getAttribute(mbean, "DLQ", onSuccess(onDlq, {
                        silent: true
                    }));
                    jolokia.request({
                        type: 'exec',
                        mbean: mbean,
                        operation: 'browse()'
                    }, onSuccess(populateTable));
                }
            }
        }
        function onDlq(response) {
            $scope.dlq = response;
            Core.$apply($scope);
        }
        function intermediateResult() {
        }
        function operationSuccess() {
            $scope.messageDialog = false;
            $scope.gridOptions.selectedItems.splice(0);
            notification("success", $scope.message);
            setTimeout(loadTable, 50);
        }
        function moveSuccess() {
            operationSuccess();
            $scope.workspace.loadTree();
        }
    }
    ActiveMQ.BrowseQueueController = BrowseQueueController;
})(ActiveMQ || (ActiveMQ = {}));
var ActiveMQ;
(function (ActiveMQ) {
    function DestinationController($scope, workspace, jolokia) {
        $scope.workspace = workspace;
        $scope.message = "";
        $scope.deleteDialog = false;
        $scope.purgeDialog = false;
        $scope.$watch('workspace.selection', function () {
            workspace.moveIfViewInvalid();
        });
        function operationSuccess() {
            $scope.destinationName = "";
            $scope.workspace.operationCounter += 1;
            $scope.$apply();
            notification("success", $scope.message);
            $scope.workspace.loadTree();
        }
        function deleteSuccess() {
            workspace.removeAndSelectParentNode();
            $scope.workspace.operationCounter += 1;
            $scope.$apply();
            notification("success", $scope.message);
            $scope.workspace.loadTree();
        }
        function getBrokerMBean(jolokia) {
            var mbean = null;
            var selection = workspace.selection;
            if(selection && ActiveMQ.isBroker(workspace) && selection.objectName) {
                return selection.objectName;
            }
            var folderNames = selection.folderNames;
            var parent = selection ? selection.parent : null;
            if(selection && parent && jolokia && folderNames && folderNames.length > 1) {
                mbean = parent.objectName;
                if(!mbean && parent) {
                    mbean = parent.parent.objectName;
                }
                if(!mbean) {
                    mbean = "" + folderNames[0] + ":BrokerName=" + folderNames[1] + ",Type=Broker";
                }
            }
            return mbean;
        }
        $scope.createDestination = function (name, isQueue) {
            var mbean = getBrokerMBean(jolokia);
            if(mbean) {
                var operation;
                if(isQueue) {
                    operation = "addQueue(java.lang.String)";
                    $scope.message = "Created queue " + name;
                } else {
                    operation = "addTopic(java.lang.String)";
                    $scope.message = "Created topic " + name;
                }
                if(mbean) {
                    jolokia.execute(mbean, operation, name, onSuccess(operationSuccess));
                } else {
                    notification("error", "Could not find the Broker MBean!");
                }
            }
        };
        $scope.deleteDestination = function () {
            var mbean = getBrokerMBean(jolokia);
            var selection = workspace.selection;
            var entries = selection.entries;
            if(mbean && selection && jolokia && entries) {
                var domain = selection.domain;
                var name = entries["Destination"] || entries["destinationName"] || selection.title;
                var isQueue = "Topic" !== (entries["Type"] || entries["destinationType"]);
                var operation;
                if(isQueue) {
                    operation = "removeQueue(java.lang.String)";
                    $scope.message = "Deleted queue " + name;
                } else {
                    operation = "removeTopic(java.lang.String)";
                    $scope.message = "Deleted topic " + name;
                }
                jolokia.execute(mbean, operation, name, onSuccess(deleteSuccess));
            }
        };
        $scope.purgeDestination = function () {
            var mbean = workspace.getSelectedMBeanName();
            var selection = workspace.selection;
            var entries = selection.entries;
            if(mbean && selection && jolokia && entries) {
                var name = entries["Destination"] || entries["destinationName"] || selection.title;
                var operation = "purge()";
                $scope.message = "Purged queue " + name;
                jolokia.execute(mbean, operation, onSuccess(operationSuccess));
            }
        };
        $scope.name = function () {
            var selection = workspace.selection;
            if(selection) {
                return selection.title;
            }
            return null;
        };
    }
    ActiveMQ.DestinationController = DestinationController;
})(ActiveMQ || (ActiveMQ = {}));
var ActiveMQ;
(function (ActiveMQ) {
    function DurableSubscriberController($scope, workspace, jolokia) {
        $scope.refresh = loadTable;
        $scope.durableSubscribers = [];
        $scope.tempData = [];
        $scope.gridOptions = {
            selectedItems: [],
            data: 'durableSubscribers',
            displayFooter: false,
            showFilter: false,
            showColumnMenu: true,
            enableColumnResize: true,
            enableColumnReordering: true,
            filterOptions: {
                filterText: ''
            },
            selectWithCheckboxOnly: true,
            showSelectionCheckbox: true,
            maintainColumnRatios: false,
            columnDefs: [
                {
                    field: 'clientId',
                    displayName: 'Client ID',
                    width: '45%'
                }, 
                {
                    field: 'consumerId',
                    displayName: 'Consumer ID',
                    width: '45%'
                }, 
                {
                    field: 'status',
                    displayName: 'Status',
                    width: '10%'
                }
            ]
        };
        $scope.$watch('workspace.selection', function () {
            if(workspace.moveIfViewInvalid()) {
                return;
            }
            setTimeout(loadTable, 50);
        });
        function loadTable() {
            var mbean = getBrokerMBean(jolokia);
            if(mbean) {
                $scope.durableSubscribers = [];
                jolokia.request({
                    type: "read",
                    mbean: mbean,
                    attribute: [
                        "DurableTopicSubscribers"
                    ]
                }, onSuccess(function (response) {
                    return populateTable(response, "DurableTopicSubscribers", "Active");
                }));
                jolokia.request({
                    type: "read",
                    mbean: mbean,
                    attribute: [
                        "InactiveDurableTopicSubscribers"
                    ]
                }, onSuccess(function (response) {
                    return populateTable(response, "InactiveDurableTopicSubscribers", "Offline");
                }));
            }
        }
        function populateTable(response, attr, status) {
            var data = response.value;
            $scope.durableSubscribers.push.apply($scope.durableSubscribers, data[attr].map(function (o) {
                var objectName = o["objectName"];
                var entries = Core.objectNameProperties(objectName);
                entries["_id"] = objectName;
                entries["status"] = status;
                return entries;
            }));
            Core.$apply($scope);
        }
        function getBrokerMBean(jolokia) {
            var mbean = null;
            var selection = workspace.selection;
            if(selection && ActiveMQ.isBroker(workspace) && selection.objectName) {
                return selection.objectName;
            }
            var folderNames = selection.folderNames;
            var parent = selection ? selection.parent : null;
            if(selection && parent && jolokia && folderNames && folderNames.length > 1) {
                mbean = parent.objectName;
                if(!mbean && parent) {
                    mbean = parent.parent.objectName;
                }
                if(!mbean) {
                    mbean = "" + folderNames[0] + ":BrokerName=" + folderNames[1] + ",Type=Broker";
                }
            }
            return mbean;
        }
    }
    ActiveMQ.DurableSubscriberController = DurableSubscriberController;
})(ActiveMQ || (ActiveMQ = {}));
var ActiveMQ;
(function (ActiveMQ) {
    function SubscriberGraphController($scope, $element, workspace, jolokia) {
        $scope.nodes = [];
        $scope.links = [];
        $scope.queues = {
        };
        $scope.topics = {
        };
        $scope.subscriptions = {
        };
        $scope.producers = {
        };
        $scope.networks = {
        };
        $scope.parentHeight = 0;
        $scope.parentWidth = 0;
        function matchesSelection(destinationName) {
            var selectionDetinationName = $scope.selectionDetinationName;
            return !selectionDetinationName || destinationName === selectionDetinationName;
        }
        function getOrCreate(container, key, defaultObject) {
            var value = container[key];
            var id;
            if(!value) {
                container[key] = defaultObject;
                id = $scope.nodes.length;
                defaultObject["id"] = id;
                $scope.nodes.push(defaultObject);
            } else {
                id = value["id"];
            }
            return id;
        }
        var populateSubscribers = function (response) {
            var data = response.value;
            for(var key in data) {
                var subscription = data[key];
                var destinationNameText = subscription["DestinationName"];
                if(destinationNameText) {
                    var subscriptionId = null;
                    var destinationNames = destinationNameText.split(",");
                    destinationNames.forEach(function (destinationName) {
                        var id = null;
                        var isQueue = !subscription["DestinationTopic"];
                        if(isQueue === $scope.isQueue && matchesSelection(destinationName)) {
                            if(isQueue) {
                                id = getOrCreate($scope.queues, destinationName, {
                                    label: destinationName,
                                    imageUrl: url("/app/activemq/img/queue.png")
                                });
                            } else {
                                id = getOrCreate($scope.topics, destinationName, {
                                    label: destinationName,
                                    imageUrl: url("/app/activemq/img/topic.png")
                                });
                            }
                            if(!subscriptionId) {
                                var subscriptionKey = subscription["ConnectionId"] + ":" + subscription["SubcriptionId"];
                                subscription["label"] = subscriptionKey;
                                subscription["imageUrl"] = url("/app/activemq/img/listener.gif");
                                subscriptionId = getOrCreate($scope.subscriptions, subscriptionKey, subscription);
                            }
                            $scope.links.push({
                                source: id,
                                target: subscriptionId
                            });
                        }
                    });
                }
            }
        };
        var populateProducers = function (response) {
            var data = response.value;
            for(var key in data) {
                var producer = data[key];
                var destinationNameText = producer["DestinationName"];
                if(destinationNameText) {
                    var producerId = null;
                    var destinationNames = destinationNameText.split(",");
                    destinationNames.forEach(function (destinationName) {
                        var id = null;
                        var isQueue = producer["DestinationQueue"];
                        if(isQueue === $scope.isQueue && matchesSelection(destinationName)) {
                            if(isQueue) {
                                id = getOrCreate($scope.queues, destinationName, {
                                    label: destinationName,
                                    imageUrl: url("/app/activemq/img/queue.png")
                                });
                            } else {
                                id = getOrCreate($scope.topics, destinationName, {
                                    label: destinationName,
                                    imageUrl: url("/app/activemq/img/topic.png")
                                });
                            }
                            if(!producerId) {
                                var producerKey = producer["ProducerId"];
                                producer["label"] = producerKey;
                                producer["imageUrl"] = url("/app/activemq/img/sender.gif");
                                producerId = getOrCreate($scope.producers, producerKey, producer);
                            }
                            $scope.links.push({
                                source: producerId,
                                target: id
                            });
                        }
                    });
                }
            }
            Core.d3ForceGraph($scope, $scope.nodes, $scope.links, $element);
            $scope.$apply();
        };
        var populateNetworks = function (response) {
            var data = response.value;
            for(var key in data) {
                var bridge = data[key];
                var localId = getOrCreate($scope.networks, bridge["LocalBrokerName"], {
                    label: bridge["LocalBrokerName"],
                    imageUrl: url("/app/activemq/img/message_broker.png")
                });
                var remoteId = getOrCreate($scope.networks, bridge["RemoteBrokerName"], {
                    label: bridge["RemoteBrokerName"],
                    imageUrl: url("/app/activemq/img/message_broker.png")
                });
                $scope.links.push({
                    source: localId,
                    target: remoteId
                });
            }
            Core.d3ForceGraph($scope, $scope.nodes, $scope.links, $element);
            $scope.$apply();
        };
        $scope.updateGraph = function () {
            var canvas = $("#canvas");
            var parent = canvas.parent();
            var parentWidth = parent.width();
            var parentHeight = parent.height();
            var canvasWidth = canvas.width();
            var canvasHeight = canvas.height();
            if(canvasHeight !== parentHeight || canvasWidth !== parentWidth) {
                Core.d3ForceGraph($scope, $scope.nodes, $scope.links, $element);
            }
        };
        $scope.$watch($scope.updateGraph);
        $scope.$watch('workspace.selection', function () {
            if(workspace.moveIfViewInvalid()) {
                return;
            }
            $scope.nodes = [];
            $scope.links = [];
            var isQueue = false;
            var isTopic = false;
            if(jolokia) {
                var selection = workspace.selection;
                $scope.selectionDetinationName = null;
                var typeName = null;
                if(selection) {
                    typeName = selection.typeName || selection.title;
                    if(typeName) {
                        isQueue = typeName === "Queue";
                        isTopic = typeName === "Topic";
                    }
                    $scope.selectionDetinationName = selection.entries["Destination"];
                }
                $scope.isQueue = isQueue;
                $scope.isTopic = isTopic;
                if(!typeName) {
                    if(isQueue) {
                        typeName = "Queue";
                    } else {
                        typeName = "Topic";
                    }
                }
                if(isQueue || isTopic) {
                    jolokia.request([
                        {
                            type: 'read',
                            mbean: "org.apache.activemq:Type=Subscription,destinationType=" + typeName + ",*"
                        }, 
                        {
                            type: 'read',
                            mbean: "org.apache.activemq:Type=Producer,*"
                        }
                    ], onSuccess([
                        populateSubscribers, 
                        populateProducers
                    ], {
                        silent: true,
                        error: false
                    }));
                } else {
                    jolokia.request({
                        type: 'read',
                        mbean: "org.apache.activemq:Type=NetworkBridge,*"
                    }, onSuccess(populateNetworks, {
                        silent: true,
                        error: false
                    }));
                }
            }
        });
    }
    ActiveMQ.SubscriberGraphController = SubscriberGraphController;
})(ActiveMQ || (ActiveMQ = {}));
var ActiveMQ;
(function (ActiveMQ) {
    function getSelectionQueuesFolder(workspace) {
        function findQueuesFolder(node) {
            if(node) {
                if(node.title === "Queues" || node.title === "Queue") {
                    return node;
                }
                var parent = node.parent;
                if(parent) {
                    return findQueuesFolder(parent);
                }
            }
            return null;
        }
        var selection = workspace.selection;
        if(selection) {
            return findQueuesFolder(selection);
        }
        return null;
    }
    ActiveMQ.getSelectionQueuesFolder = getSelectionQueuesFolder;
})(ActiveMQ || (ActiveMQ = {}));
var ActiveMQ;
(function (ActiveMQ) {
    function TreeController($scope, $location, workspace) {
        $scope.$on("$routeChangeSuccess", function (event, current, previous) {
            setTimeout(updateSelectionFromURL, 50);
        });
        $scope.$watch('workspace.tree', function () {
            reloadTree();
        });
        $scope.$on('jmxTreeUpdated', function () {
            reloadTree();
        });
        function updateSelectionFromURL() {
            Jmx.updateTreeSelectionFromURL($location, $("#activemqtree"), true);
        }
        function reloadTree() {
            console.log("workspace tree has changed, lets reload the activemq tree");
            var children = [];
            var tree = workspace.tree;
            if(tree) {
                var domainName = "org.apache.activemq";
                var folder = tree.get(domainName);
                if(folder) {
                    children = folder.children;
                }
                if(children.length) {
                    var firstChild = children[0];
                    if(!firstChild.typeName && firstChild.children.length < 4) {
                        var answer = [];
                        angular.forEach(children, function (child) {
                            answer = answer.concat(child.children);
                        });
                        children = answer;
                    }
                }
                var treeElement = $("#activemqtree");
                Jmx.enableTree($scope, $location, workspace, treeElement, children, true);
                setTimeout(updateSelectionFromURL, 50);
            }
        }
    }
    ActiveMQ.TreeController = TreeController;
})(ActiveMQ || (ActiveMQ = {}));
var Camel;
(function (Camel) {
    function AttributesToolBarController($scope, workspace, jolokia) {
        $scope.deleteDialog = false;
        $scope.start = function () {
            $scope.invokeSelectedMBeans(function (item) {
                return Camel.isState(item, "suspend") ? "resume()" : "start()";
            });
        };
        $scope.pause = function () {
            $scope.invokeSelectedMBeans("suspend()");
        };
        $scope.stop = function () {
            $scope.invokeSelectedMBeans("stop()", function () {
                workspace.removeAndSelectParentNode();
            });
        };
        $scope.delete = function () {
            $scope.invokeSelectedMBeans("remove()", function () {
                $scope.workspace.operationCounter += 1;
                $scope.$apply();
            });
        };
        $scope.anySelectionHasState = function (state) {
            var selected = $scope.selectedItems || [];
            return selected.length && selected.any(function (s) {
                return Camel.isState(s, state);
            });
        };
        $scope.everySelectionHasState = function (state) {
            var selected = $scope.selectedItems || [];
            return selected.length && selected.every(function (s) {
                return Camel.isState(s, state);
            });
        };
    }
    Camel.AttributesToolBarController = AttributesToolBarController;
})(Camel || (Camel = {}));
var Camel;
(function (Camel) {
    function BrowseEndpointController($scope, workspace, jolokia) {
        $scope.workspace = workspace;
        $scope.forwardDialog = new Core.Dialog();
        $scope.showMessageDetails = false;
        $scope.mode = 'text';
        $scope.gridOptions = Camel.createBrowseGridOptions();
        $scope.$watch('workspace.selection', function () {
            if(workspace.moveIfViewInvalid()) {
                return;
            }
            loadData();
        });
        $scope.openMessageDialog = function (message) {
            var idx = Core.pathGet(message, [
                "rowIndex"
            ]);
            $scope.selectRowIndex(idx);
            if($scope.row) {
                $scope.mode = CodeEditor.detectTextFormat($scope.row.body);
                $scope.showMessageDetails = true;
            }
        };
        $scope.selectRowIndex = function (idx) {
            $scope.rowIndex = idx;
            var selected = $scope.gridOptions.selectedItems;
            selected.splice(0, selected.length);
            if(idx >= 0 && idx < $scope.messages.length) {
                $scope.row = $scope.messages[idx];
                if($scope.row) {
                    selected.push($scope.row);
                }
            } else {
                $scope.row = null;
            }
        };
        $scope.forwardMessagesAndCloseForwardDialog = function () {
            var mbean = Camel.getSelectionCamelContextMBean(workspace);
            var selectedItems = $scope.gridOptions.selectedItems;
            var uri = $scope.endpointUri;
            if(mbean && uri && selectedItems && selectedItems.length) {
                jolokia.execute(mbean, "createEndpoint(java.lang.String)", uri, onSuccess(intermediateResult));
                $scope.message = "Forwarded " + Core.maybePlural(selectedItems.length, "message" + " to " + uri);
                angular.forEach(selectedItems, function (item, idx) {
                    var callback = (idx + 1 < selectedItems.length) ? intermediateResult : operationSuccess;
                    var body = item.body;
                    var headers = item.headers;
                    jolokia.execute(mbean, "sendBodyAndHeaders(java.lang.String, java.lang.Object, java.util.Map)", uri, body, headers, onSuccess(callback));
                });
            }
            $scope.forwardDialog.close();
        };
        $scope.endpointUris = function () {
            var endpointFolder = Camel.getSelectionCamelContextEndpoints(workspace);
            return (endpointFolder) ? endpointFolder.children.map(function (n) {
                return n.title;
            }) : [];
        };
        $scope.refresh = loadData;
        function intermediateResult() {
        }
        function operationSuccess() {
            $scope.messageDialog.close();
            $scope.gridOptions.selectedItems.splice(0);
            notification("success", $scope.message);
            setTimeout(loadData, 50);
        }
        function loadData() {
            var mbean = workspace.getSelectedMBeanName();
            if(mbean) {
                var options = onSuccess(populateTable);
                jolokia.execute(mbean, 'browseAllMessagesAsXml(java.lang.Boolean)', true, options);
            }
        }
        function populateTable(response) {
            var data = [];
            if(angular.isString(response)) {
                var doc = $.parseXML(response);
                var allMessages = $(doc).find("message");
                allMessages.each(function (idx, message) {
                    var messageData = Camel.createMessageFromXml(message);
                    data.push(messageData);
                });
            }
            $scope.messages = data;
            Core.$apply($scope);
        }
    }
    Camel.BrowseEndpointController = BrowseEndpointController;
})(Camel || (Camel = {}));
var Camel;
(function (Camel) {
    function CamelController($scope, $element, workspace, jolokia) {
        $scope.routes = [];
        $scope.routeNodes = {
        };
        $scope.$on("$routeChangeSuccess", function (event, current, previous) {
            setTimeout(updateRoutes, 50);
        });
        $scope.$watch('workspace.selection', function () {
            if(workspace.moveIfViewInvalid()) {
                return;
            }
            updateRoutes();
        });
        $scope.$watch('nodeXmlNode', function () {
            if(workspace.moveIfViewInvalid()) {
                return;
            }
            updateRoutes();
        });
        function updateRoutes() {
            var routeXmlNode = null;
            if(!$scope.ignoreRouteXmlNode) {
                routeXmlNode = Camel.getSelectedRouteNode(workspace);
                if(!routeXmlNode) {
                    routeXmlNode = $scope.nodeXmlNode;
                }
                if(routeXmlNode && routeXmlNode.localName !== "route") {
                    var wrapper = document.createElement("route");
                    wrapper.appendChild(routeXmlNode.cloneNode(true));
                    routeXmlNode = wrapper;
                }
            }
            $scope.mbean = Camel.getSelectionCamelContextMBean(workspace);
            if(routeXmlNode) {
                $scope.nodes = {
                };
                var nodes = [];
                var links = [];
                Camel.addRouteXmlChildren($scope, routeXmlNode, nodes, links, null, 0, 0);
                showGraph(nodes, links);
            } else {
                if($scope.mbean) {
                    jolokia.request({
                        type: 'exec',
                        mbean: $scope.mbean,
                        operation: 'dumpRoutesAsXml()'
                    }, onSuccess(populateTable));
                } else {
                    console.log("No camel context bean!");
                }
            }
        }
        var populateTable = function (response) {
            var data = response.value;
            $scope.routes = data;
            $scope.nodes = {
            };
            $scope.routeNodes = {
            };
            var nodes = [];
            var links = [];
            var selectedRouteId = Camel.getSelectedRouteId(workspace);
            if(data) {
                var doc = $.parseXML(data);
                Camel.loadRouteXmlNodes($scope, doc, selectedRouteId, nodes, links, getWidth());
                showGraph(nodes, links);
            } else {
                console.log("No data from route XML!");
            }
            Core.$apply($scope);
        };
        var postfix = " selected";
        function isSelected(node) {
            if(node) {
                var className = node.getAttribute("class");
                return className && className.endsWith(postfix);
            }
            return false;
        }
        function setSelected(node, flag) {
            var answer = false;
            if(node) {
                var className = node.getAttribute("class");
                var selected = className && className.endsWith(postfix);
                if(selected) {
                    className = className.substring(0, className.length - postfix.length);
                } else {
                    if(!flag) {
                        return answer;
                    }
                    className = className + postfix;
                    answer = true;
                }
                node.setAttribute("class", className);
            }
            return answer;
        }
        function showGraph(nodes, links) {
            var canvasDiv = $($element);
            var width = getWidth();
            var height = getHeight();
            var svg = canvasDiv.children("svg")[0];
            $scope.graphData = Core.dagreLayoutGraph(nodes, links, width, height, svg);
            var nodes = canvasDiv.find("g.node");
            nodes.click(function () {
                var selected = isSelected(this);
                nodes.each(function (idx, element) {
                    setSelected(element, false);
                });
                var cid = null;
                if(!selected) {
                    cid = this.getAttribute("data-cid");
                    setSelected(this, true);
                }
                $scope.$emit("camel.diagram.selectedNodeId", cid);
                Core.$apply($scope);
            });
            if($scope.mbean) {
                Core.register(jolokia, $scope, {
                    type: 'exec',
                    mbean: $scope.mbean,
                    operation: 'dumpRoutesStatsAsXml',
                    arguments: [
                        true, 
                        true
                    ]
                }, onSuccess(statsCallback, {
                    silent: true,
                    error: false
                }));
            }
            $scope.$emit("camel.diagram.layoutComplete");
            return width;
        }
        function getWidth() {
            var canvasDiv = $($element);
            return canvasDiv.width();
        }
        function getHeight() {
            var canvasDiv = $($element);
            return Camel.getCanvasHeight(canvasDiv);
        }
        function statsCallback(response) {
            var data = response.value;
            if(data) {
                var doc = $.parseXML(data);
                var allStats = $(doc).find("routeStat");
                allStats.each(function (idx, stat) {
                    addTooltipToNode(true, stat);
                });
                var allStats = $(doc).find("processorStat");
                allStats.each(function (idx, stat) {
                    addTooltipToNode(false, stat);
                });
                Core.dagreUpdateGraphData($scope.graphData);
            }
            function addTooltipToNode(isRoute, stat) {
                var id = stat.getAttribute("id");
                var completed = stat.getAttribute("exchangesCompleted");
                var tooltip = "";
                if(id && completed) {
                    var node = isRoute ? $scope.routeNodes[id] : $scope.nodes[id];
                    if(node) {
                        var total = 0 + parseInt(completed);
                        var failed = stat.getAttribute("exchangesFailed");
                        if(failed) {
                            total += parseInt(failed);
                        }
                        var last = stat.getAttribute("lastProcessingTime");
                        var mean = stat.getAttribute("meanProcessingTime");
                        var min = stat.getAttribute("minProcessingTime");
                        var max = stat.getAttribute("maxProcessingTime");
                        tooltip = "last: " + last + " (ms)\nmean: " + mean + " (ms)\nmin: " + min + " (ms)\nmax: " + max + " (ms)";
                        node["counter"] = total;
                        node["tooltip"] = tooltip;
                    } else {
                    }
                }
            }
        }
    }
    Camel.CamelController = CamelController;
})(Camel || (Camel = {}));
var Camel;
(function (Camel) {
    Camel.camelHeaderSchema = {
        definitions: {
            headers: {
                properties: {
                    "CamelAuthentication": {
                        type: "java.lang.String"
                    },
                    "CamelAuthenticationFailurePolicyId": {
                        type: "java.lang.String"
                    },
                    "CamelAcceptContentType": {
                        type: "java.lang.String"
                    },
                    "CamelAggregatedSize": {
                        type: "java.lang.String"
                    },
                    "CamelAggregatedTimeout": {
                        type: "java.lang.String"
                    },
                    "CamelAggregatedCompletedBy": {
                        type: "java.lang.String"
                    },
                    "CamelAggregatedCorrelationKey": {
                        type: "java.lang.String"
                    },
                    "CamelAggregationStrategy": {
                        type: "java.lang.String"
                    },
                    "CamelAggregationCompleteAllGroups": {
                        type: "java.lang.String"
                    },
                    "CamelAsyncWait": {
                        type: "java.lang.String"
                    },
                    "CamelBatchIndex": {
                        type: "java.lang.String"
                    },
                    "CamelBatchSize": {
                        type: "java.lang.String"
                    },
                    "CamelBatchComplete": {
                        type: "java.lang.String"
                    },
                    "CamelBeanMethodName": {
                        type: "java.lang.String"
                    },
                    "CamelBeanMultiParameterArray": {
                        type: "java.lang.String"
                    },
                    "CamelBinding": {
                        type: "java.lang.String"
                    },
                    "breadcrumbId": {
                        type: "java.lang.String"
                    },
                    "CamelCharsetName": {
                        type: "java.lang.String"
                    },
                    "CamelCreatedTimestamp": {
                        type: "java.lang.String"
                    },
                    "Content-Encoding": {
                        type: "java.lang.String"
                    },
                    "Content-Length": {
                        type: "java.lang.String"
                    },
                    "Content-Type": {
                        type: "java.lang.String"
                    },
                    "CamelCorrelationId": {
                        type: "java.lang.String"
                    },
                    "CamelDataSetIndex": {
                        type: "java.lang.String"
                    },
                    "org.apache.camel.default.charset": {
                        type: "java.lang.String"
                    },
                    "CamelDestinationOverrideUrl": {
                        type: "java.lang.String"
                    },
                    "CamelDisableHttpStreamCache": {
                        type: "java.lang.String"
                    },
                    "CamelDuplicateMessage": {
                        type: "java.lang.String"
                    },
                    "CamelExceptionCaught": {
                        type: "java.lang.String"
                    },
                    "CamelEvaluateExpressionResult": {
                        type: "java.lang.String"
                    },
                    "CamelErrorHandlerHandled": {
                        type: "java.lang.String"
                    },
                    "CamelExternalRedelivered": {
                        type: "java.lang.String"
                    },
                    "CamelFailureHandled": {
                        type: "java.lang.String"
                    },
                    "CamelFailureEndpoint": {
                        type: "java.lang.String"
                    },
                    "CamelFailureRouteId": {
                        type: "java.lang.String"
                    },
                    "CamelFilterNonXmlChars": {
                        type: "java.lang.String"
                    },
                    "CamelFileLocalWorkPath": {
                        type: "java.lang.String"
                    },
                    "CamelFileName": {
                        type: "java.lang.String"
                    },
                    "CamelFileNameOnly": {
                        type: "java.lang.String"
                    },
                    "CamelFileNameProduced": {
                        type: "java.lang.String"
                    },
                    "CamelFilePath": {
                        type: "java.lang.String"
                    },
                    "CamelFileParent": {
                        type: "java.lang.String"
                    },
                    "CamelFileLastModified": {
                        type: "java.lang.String"
                    },
                    "CamelFileLength": {
                        type: "java.lang.String"
                    },
                    "CamelFilterMatched": {
                        type: "java.lang.String"
                    },
                    "CamelFileLockFileAcquired": {
                        type: "java.lang.String"
                    },
                    "CamelGroupedExchange": {
                        type: "java.lang.String"
                    },
                    "CamelHttpBaseUri": {
                        type: "java.lang.String"
                    },
                    "CamelHttpCharacterEncoding": {
                        type: "java.lang.String"
                    },
                    "CamelHttpMethod": {
                        type: "java.lang.String"
                    },
                    "CamelHttpPath": {
                        type: "java.lang.String"
                    },
                    "CamelHttpProtocolVersion": {
                        type: "java.lang.String"
                    },
                    "CamelHttpQuery": {
                        type: "java.lang.String"
                    },
                    "CamelHttpResponseCode": {
                        type: "java.lang.String"
                    },
                    "CamelHttpUri": {
                        type: "java.lang.String"
                    },
                    "CamelHttpUrl": {
                        type: "java.lang.String"
                    },
                    "CamelHttpChunked": {
                        type: "java.lang.String"
                    },
                    "CamelHttpServletRequest": {
                        type: "java.lang.String"
                    },
                    "CamelHttpServletResponse": {
                        type: "java.lang.String"
                    },
                    "CamelInterceptedEndpoint": {
                        type: "java.lang.String"
                    },
                    "CamelInterceptSendToEndpointWhenMatched": {
                        type: "java.lang.String"
                    },
                    "CamelLanguageScript": {
                        type: "java.lang.String"
                    },
                    "CamelLogDebugBodyMaxChars": {
                        type: "java.lang.String"
                    },
                    "CamelLogDebugStreams": {
                        type: "java.lang.String"
                    },
                    "CamelLoopIndex": {
                        type: "java.lang.String"
                    },
                    "CamelLoopSize": {
                        type: "java.lang.String"
                    },
                    "CamelMaximumCachePoolSize": {
                        type: "java.lang.String"
                    },
                    "CamelMaximumEndpointCacheSize": {
                        type: "java.lang.String"
                    },
                    "CamelMulticastIndex": {
                        type: "java.lang.String"
                    },
                    "CamelMulticastComplete": {
                        type: "java.lang.String"
                    },
                    "CamelNotifyEvent": {
                        type: "java.lang.String"
                    },
                    "CamelOnCompletion": {
                        type: "java.lang.String"
                    },
                    "CamelParentUnitOfWork": {
                        type: "java.lang.String"
                    },
                    "CamelReceivedTimestamp": {
                        type: "java.lang.String"
                    },
                    "CamelRedelivered": {
                        type: "java.lang.String"
                    },
                    "CamelRedeliveryCounter": {
                        type: "java.lang.String"
                    },
                    "CamelRedeliveryMaxCounter": {
                        type: "java.lang.String"
                    },
                    "CamelRedeliveryExhausted": {
                        type: "java.lang.String"
                    },
                    "CamelRedeliveryDelay": {
                        type: "java.lang.String"
                    },
                    "CamelRollbackOnly": {
                        type: "java.lang.String"
                    },
                    "CamelRollbackOnlyLast": {
                        type: "java.lang.String"
                    },
                    "CamelRouteStop": {
                        type: "java.lang.String"
                    },
                    "CamelSoapAction": {
                        type: "java.lang.String"
                    },
                    "CamelSkipGzipEncoding": {
                        type: "java.lang.String"
                    },
                    "CamelSlipEndpoint": {
                        type: "java.lang.String"
                    },
                    "CamelSplitIndex": {
                        type: "java.lang.String"
                    },
                    "CamelSplitComplete": {
                        type: "java.lang.String"
                    },
                    "CamelSplitSize": {
                        type: "java.lang.String"
                    },
                    "CamelTimerCounter": {
                        type: "java.lang.String"
                    },
                    "CamelTimerFiredTime": {
                        type: "java.lang.String"
                    },
                    "CamelTimerName": {
                        type: "java.lang.String"
                    },
                    "CamelTimerPeriod": {
                        type: "java.lang.String"
                    },
                    "CamelTimerTime": {
                        type: "java.lang.String"
                    },
                    "CamelToEndpoint": {
                        type: "java.lang.String"
                    },
                    "CamelTraceEvent": {
                        type: "java.lang.String"
                    },
                    "CamelTraceEventNodeId": {
                        type: "java.lang.String"
                    },
                    "CamelTraceEventTimestamp": {
                        type: "java.lang.String"
                    },
                    "CamelTraceEventExchange": {
                        type: "java.lang.String"
                    },
                    "Transfer-Encoding": {
                        type: "java.lang.String"
                    },
                    "CamelUnitOfWorkExhausted": {
                        type: "java.lang.String"
                    },
                    "CamelUnitOfWorkProcessSync": {
                        type: "java.lang.String"
                    },
                    "CamelXsltFileName": {
                        type: "java.lang.String"
                    }
                }
            }
        }
    };
})(Camel || (Camel = {}));
var Jmx;
(function (Jmx) {
    var attributesToolBars = {
    };
    Jmx.lazyLoaders = null;
    function findLazyLoadingFunction(workspace, folder) {
        var factories = workspace.jmxTreeLazyLoadRegistry[folder.domain];
        var lazyFunction = null;
        if(factories && factories.length) {
            angular.forEach(factories, function (customLoader) {
                if(!lazyFunction) {
                    lazyFunction = customLoader(folder);
                }
            });
        }
        return lazyFunction;
    }
    Jmx.findLazyLoadingFunction = findLazyLoadingFunction;
    function registerLazyLoadHandler(domain, lazyLoaderFactory) {
        if(!Jmx.lazyLoaders) {
            Jmx.lazyLoaders = {
            };
        }
        var array = Jmx.lazyLoaders[domain];
        if(!array) {
            array = [];
            Jmx.lazyLoaders[domain] = array;
        }
        array.push(lazyLoaderFactory);
    }
    Jmx.registerLazyLoadHandler = registerLazyLoadHandler;
    function unregisterLazyLoadHandler(domain, lazyLoaderFactory) {
        if(Jmx.lazyLoaders) {
            var array = Jmx.lazyLoaders[domain];
            if(array) {
                array.remove(lazyLoaderFactory);
            }
        }
    }
    Jmx.unregisterLazyLoadHandler = unregisterLazyLoadHandler;
    function addAttributeToolBar(pluginName, jmxDomain, fn) {
        var array = attributesToolBars[jmxDomain];
        if(!array) {
            array = [];
            attributesToolBars[jmxDomain] = array;
        }
        array.push(fn);
    }
    Jmx.addAttributeToolBar = addAttributeToolBar;
    function getAttributeToolBar(node, defaultValue) {
        if (typeof defaultValue === "undefined") { defaultValue = "app/jmx/html/attributeToolBar.html"; }
        var answer = null;
        var jmxDomain = (node) ? node.domain : null;
        if(jmxDomain) {
            var array = attributesToolBars[jmxDomain];
            if(array) {
                for(var idx in array) {
                    var fn = array[idx];
                    answer = fn(node);
                    if(answer) {
                        break;
                    }
                }
            }
        }
        return (answer) ? answer : defaultValue;
    }
    Jmx.getAttributeToolBar = getAttributeToolBar;
    function updateTreeSelectionFromURL($location, treeElement, activateIfNoneSelected) {
        if (typeof activateIfNoneSelected === "undefined") { activateIfNoneSelected = false; }
        var dtree = treeElement.dynatree("getTree");
        if(dtree) {
            var node = null;
            var key = $location.search()['nid'];
            if(key) {
                try  {
                    node = dtree.activateKey(key);
                } catch (e) {
                }
            }
            if(node) {
                node.expand(true);
            } else {
                if(!treeElement.dynatree("getActiveNode")) {
                    var root = treeElement.dynatree("getRoot");
                    var children = root ? root.getChildren() : null;
                    if(children && children.length) {
                        var first = children[0];
                        first.expand(true);
                        if(activateIfNoneSelected) {
                            first.activate();
                        }
                    }
                }
            }
        }
    }
    Jmx.updateTreeSelectionFromURL = updateTreeSelectionFromURL;
    function getUniqueTypeNames(children) {
        var typeNameMap = {
        };
        angular.forEach(children, function (mbean) {
            var typeName = mbean.typeName;
            if(typeName) {
                typeNameMap[typeName] = mbean;
            }
        });
        var typeNames = Object.keys(typeNameMap);
        return typeNames;
    }
    Jmx.getUniqueTypeNames = getUniqueTypeNames;
    function enableTree($scope, $location, workspace, treeElement, children, redraw) {
        if (typeof redraw === "undefined") { redraw = false; }
        if(treeElement.length) {
            workspace.treeElement = treeElement;
            treeElement.dynatree({
                onActivate: function (node) {
                    var data = node.data;
                    workspace.updateSelectionNode(data);
                    $scope.$apply();
                },
                onLazyRead: function (treeNode) {
                    var folder = treeNode.data;
                    var plugin = null;
                    if(folder) {
                        plugin = Jmx.findLazyLoadingFunction(workspace, folder);
                    }
                    if(plugin) {
                        console.log("Lazy loading folder " + folder.title);
                        var oldChildren = folder.childen;
                        plugin(workspace, folder, function () {
                            treeNode.setLazyNodeStatus(DTNodeStatus_Ok);
                            var newChildren = folder.children;
                            if(newChildren !== oldChildren) {
                                treeNode.removeChildren();
                                angular.forEach(newChildren, function (newChild) {
                                    treeNode.addChild(newChild);
                                });
                            }
                        });
                    } else {
                        treeNode.setLazyNodeStatus(DTNodeStatus_Ok);
                    }
                },
                onClick: function (node, event) {
                    if(event["metaKey"]) {
                        event.preventDefault();
                        var url = $location.absUrl();
                        if(node && node.data) {
                            var key = node.data["key"];
                            if(key) {
                                var hash = $location.search();
                                hash["nid"] = key;
                                var idx = url.indexOf('?');
                                if(idx <= 0) {
                                    url += "?";
                                } else {
                                    url = url.substring(0, idx + 1);
                                }
                                url += $.param(hash);
                            }
                        }
                        window.open(url, '_blank');
                        window.focus();
                        return false;
                    }
                    return true;
                },
                persist: false,
                debugLevel: 0,
                children: children
            });
            if(redraw) {
                workspace.redrawTree();
            }
        }
    }
    Jmx.enableTree = enableTree;
})(Jmx || (Jmx = {}));
var Camel;
(function (Camel) {
    var jmxModule = Jmx;
    var pluginName = 'camel';
    Camel.jmxDomain = 'org.apache.camel';
    var routeToolBar = "app/camel/html/attributeToolBarRoutes.html";
    var contextToolBar = "app/camel/html/attributeToolBarContext.html";
    angular.module(pluginName, [
        'bootstrap', 
        'ui.bootstrap', 
        'ui.bootstrap.dialog', 
        'ui.bootstrap.tabs', 
        'ui.bootstrap.typeahead', 
        'ngResource', 
        'hawtioCore', 
        'hawtio-ui'
    ]).config(function ($routeProvider) {
        $routeProvider.when('/camel/browseEndpoint', {
            templateUrl: 'app/camel/html/browseEndpoint.html'
        }).when('/camel/createEndpoint', {
            templateUrl: 'app/camel/html/createEndpoint.html'
        }).when('/camel/routes', {
            templateUrl: 'app/camel/html/routes.html'
        }).when('/camel/sendMessage', {
            templateUrl: 'app/camel/html/sendMessage.html'
        }).when('/camel/source', {
            templateUrl: 'app/camel/html/source.html'
        }).when('/camel/traceRoute', {
            templateUrl: 'app/camel/html/traceRoute.html'
        }).when('/camel/debugRoute', {
            templateUrl: 'app/camel/html/debug.html'
        }).when('/camel/profileRoute', {
            templateUrl: 'app/camel/html/profileRoute.html'
        }).when('/camel/properties', {
            templateUrl: 'app/camel/html/properties.html'
        });
    }).filter('camelIconClass', function () {
        return Camel.iconClass;
    }).filter('lastExchangeCompletedSince', function () {
        return Camel.lastExchangeCompletedSince;
    }).filter('lastExchangeFailedSince', function () {
        return Camel.lastExchangeFailedSince;
    }).run(function (workspace, jolokia, viewRegistry) {
        viewRegistry['camel'] = 'app/camel/html/layoutCamelTree.html';
        Jmx.addAttributeToolBar(pluginName, Camel.jmxDomain, function (selection) {
            var typeName = selection.typeName;
            if(typeName) {
                if(typeName.startsWith("context")) {
                    return contextToolBar;
                }
                if(typeName.startsWith("route")) {
                    return routeToolBar;
                }
            }
            var folderNames = selection.folderNames;
            if(folderNames && selection.domain === Camel.jmxDomain) {
                var last = folderNames.last();
                if("routes" === last) {
                    return routeToolBar;
                }
                if("context" === last) {
                    return contextToolBar;
                }
            }
            return null;
        });
        var stateTemplate = '<div class="ngCellText pagination-centered" title="{{row.getProperty(col.field)}}"><i class="{{row.getProperty(col.field) | camelIconClass}}"></i></div>';
        var stateColumn = {
            field: 'State',
            displayName: 'State',
            cellTemplate: stateTemplate,
            width: 56,
            minWidth: 56,
            maxWidth: 56,
            resizable: false
        };
        var sinceCompletedTemplate = '<div class="ngCellText">{{row.entity | lastExchangeCompletedSince}}</div>';
        var sinceFailedTemplate = '<div class="ngCellText">{{row.entity | lastExchangeFailedSince}}</div>';
        var attributes = workspace.attributeColumnDefs;
        attributes[Camel.jmxDomain + "/context/folder"] = [
            stateColumn, 
            {
                field: 'CamelId',
                displayName: 'Name'
            }, 
            {
                field: 'Uptime',
                displayName: 'Uptime',
                visible: false
            }, 
            {
                field: 'CamelVersion',
                displayName: 'Version',
                visible: false
            }, 
            {
                field: 'ExchangesCompleted',
                displayName: 'Completed #'
            }, 
            {
                field: 'LastCompletedSince',
                displayName: 'Last Completed Since',
                cellTemplate: sinceCompletedTemplate
            }, 
            {
                field: 'LastExchangeCompletedTimestamp',
                displayName: 'Last exchange completed timestamp',
                visible: false
            }, 
            {
                field: 'ExchangesFailed',
                displayName: 'Failed #'
            }, 
            {
                field: 'LastFailedSince',
                displayName: 'Last Failed Since',
                cellTemplate: sinceFailedTemplate
            }, 
            {
                field: 'LastExchangeFailedTimestamp',
                displayName: 'Last exchange failed timestamp',
                visible: false
            }, 
            {
                field: 'InflightExchanges',
                displayName: 'Inflight #'
            }, 
            {
                field: 'MeanProcessingTime',
                displayName: 'Mean Time'
            }, 
            {
                field: 'MinProcessingTime',
                displayName: 'Min Time'
            }, 
            {
                field: 'MaxProcessingTime',
                displayName: 'Max Time'
            }, 
            {
                field: 'TotalProcessingTime',
                displayName: 'Total Time',
                visible: false
            }
        ];
        attributes[Camel.jmxDomain + "/components/folder"] = [
            stateColumn, 
            {
                field: 'CamelId',
                displayName: 'Context'
            }, 
            {
                field: 'ComponentName',
                displayName: 'Name'
            }
        ];
        attributes[Camel.jmxDomain + "/consumers/folder"] = [
            stateColumn, 
            {
                field: 'CamelId',
                displayName: 'Context'
            }, 
            {
                field: 'RouteId',
                displayName: 'Route'
            }, 
            {
                field: 'EndpointUri',
                displayName: 'Endpoint URI',
                width: "**"
            }, 
            {
                field: 'Suspended',
                displayName: 'Suspended',
                resizable: false
            }, 
            {
                field: 'InflightExchanges',
                displayName: 'Inflight #'
            }
        ];
        attributes[Camel.jmxDomain + "/processors/folder"] = [
            stateColumn, 
            {
                field: 'CamelId',
                displayName: 'Context'
            }, 
            {
                field: 'RouteId',
                displayName: 'Route'
            }, 
            {
                field: 'ProcessorId',
                displayName: 'Processor'
            }, 
            {
                field: 'ExchangesCompleted',
                displayName: 'Completed #'
            }, 
            {
                field: 'ExchangesFailed',
                displayName: 'Failed #'
            }, 
            {
                field: 'MeanProcessingTime',
                displayName: 'Mean Time'
            }, 
            {
                field: 'MinProcessingTime',
                displayName: 'Min Time'
            }, 
            {
                field: 'MaxProcessingTime',
                displayName: 'Max Time'
            }, 
            {
                field: 'TotalProcessingTime',
                displayName: 'Total Time'
            }
        ];
        attributes[Camel.jmxDomain + "/services/folder"] = [
            stateColumn, 
            {
                field: 'CamelId',
                displayName: 'Context'
            }, 
            {
                field: 'RouteId',
                displayName: 'Route'
            }, 
            {
                field: 'Suspended',
                displayName: 'Suspended',
                resizable: false
            }, 
            {
                field: 'SupportsSuspended',
                displayName: 'Can Suspend',
                resizable: false
            }
        ];
        attributes[Camel.jmxDomain + "/endpoints/folder"] = [
            stateColumn, 
            {
                field: 'CamelId',
                displayName: 'Context'
            }, 
            {
                field: 'EndpointUri',
                displayName: 'Endpoint URI',
                width: "***"
            }, 
            {
                field: 'Singleton',
                displayName: 'Singleton',
                resizable: false
            }
        ];
        attributes[Camel.jmxDomain + "/routes/folder"] = [
            stateColumn, 
            {
                field: 'CamelId',
                displayName: 'Context'
            }, 
            {
                field: 'RouteId',
                displayName: 'Route'
            }, 
            {
                field: 'ExchangesCompleted',
                displayName: 'Completed #'
            }, 
            {
                field: 'ExchangesFailed',
                displayName: 'Failed #'
            }, 
            {
                field: 'MeanProcessingTime',
                displayName: 'Mean Time'
            }, 
            {
                field: 'MinProcessingTime',
                displayName: 'Min Time'
            }, 
            {
                field: 'MaxProcessingTime',
                displayName: 'Max Time'
            }, 
            {
                field: 'TotalProcessingTime',
                displayName: 'Total Time'
            }
        ];
        attributes[Camel.jmxDomain + "/threadpools/folder"] = [
            {
                field: 'Id',
                displayName: 'Id',
                width: "**"
            }, 
            {
                field: 'ActiveCount',
                displayName: 'Active #'
            }, 
            {
                field: 'PoolSize',
                displayName: 'Pool Size'
            }, 
            {
                field: 'CorePoolSize',
                displayName: 'Core Pool Size'
            }, 
            {
                field: 'TaskQueueSize',
                displayName: 'Task Queue Size'
            }, 
            {
                field: 'TaskCount',
                displayName: 'Task #'
            }, 
            {
                field: 'CompletedTaskCount',
                displayName: 'Completed Task #'
            }
        ];
        workspace.topLevelTabs.push({
            content: "Camel",
            title: "Manage your Apache Camel applications",
            isValid: function (workspace) {
                return workspace.treeContainsDomainAndProperties(Camel.jmxDomain);
            },
            href: function () {
                return "#/jmx/attributes?tab=camel";
            },
            isActive: function (workspace) {
                return workspace.isTopTabActive("camel");
            }
        });
        workspace.subLevelTabs.push({
            content: '<i class="icon-picture"></i> Diagram',
            title: "View a diagram of the Camel routes",
            isValid: function (workspace) {
                return workspace.isRoute();
            },
            href: function () {
                return "#/camel/routes";
            }
        });
        workspace.subLevelTabs.push({
            content: '<i class=" icon-file-alt"></i> Source',
            title: "View the source of the Camel routes",
            isValid: function (workspace) {
                return workspace.isRoute() || workspace.isRoutesFolder() || workspace.isCamelContext();
            },
            href: function () {
                return "#/camel/source";
            }
        });
        workspace.subLevelTabs.push({
            content: '<i class=" icon-edit"></i> Properties',
            title: "View the pattern properties",
            isValid: function (workspace) {
                return Camel.getSelectedRouteNode(workspace);
            },
            href: function () {
                return "#/camel/properties";
            }
        });
        workspace.subLevelTabs.push({
            content: '<i class="icon-envelope"></i> Browse',
            title: "Browse the messages on the endpoint",
            isValid: function (workspace) {
                return workspace.isEndpoint();
            },
            href: function () {
                return "#/camel/browseEndpoint";
            }
        });
        workspace.subLevelTabs.push({
            content: '<i class="icon-stethoscope"></i> Debug',
            title: "Debug the Camel route",
            isValid: function (workspace) {
                return workspace.isRoute() && Camel.getSelectionCamelDebugMBean(workspace);
            },
            href: function () {
                return "#/camel/debugRoute";
            }
        });
        workspace.subLevelTabs.push({
            content: '<i class="icon-envelope"></i> Trace',
            title: "Trace the messages flowing through the Camel route",
            isValid: function (workspace) {
                return workspace.isRoute() && Camel.getSelectionCamelTraceMBean(workspace);
            },
            href: function () {
                return "#/camel/traceRoute";
            }
        });
        workspace.subLevelTabs.push({
            content: '<i class="icon-bar-chart"></i> Profile',
            title: "Profile the messages flowing through the Camel route",
            isValid: function (workspace) {
                return workspace.isRoute() && Camel.getSelectionCamelTraceMBean(workspace);
            },
            href: function () {
                return "#/camel/profileRoute";
            }
        });
        workspace.subLevelTabs.push({
            content: '<i class="icon-pencil"></i> Send',
            title: "Send a message to this endpoint",
            isValid: function (workspace) {
                return workspace.isEndpoint();
            },
            href: function () {
                return "#/camel/sendMessage";
            }
        });
        workspace.subLevelTabs.push({
            content: '<i class="icon-plus"></i> Endpoint',
            title: "Create a new endpoint",
            isValid: function (workspace) {
                return workspace.isEndpointsFolder();
            },
            href: function () {
                return "#/camel/createEndpoint";
            }
        });
    });
    hawtioPluginLoader.addModule(pluginName);
    hawtioPluginLoader.loadPlugins(function () {
        jmxModule.registerLazyLoadHandler(Camel.jmxDomain, function (folder) {
            if(Camel.jmxDomain === folder.domain && "routes" === folder.typeName) {
                return function (workspace, folder, onComplete) {
                    if("routes" === folder.typeName) {
                        Camel.processRouteXml(workspace, workspace.jolokia, folder, function (route) {
                            if(route) {
                                Camel.addRouteChildren(folder, route);
                            }
                            onComplete();
                        });
                    } else {
                        onComplete();
                    }
                }
            }
            return null;
        });
    });
})(Camel || (Camel = {}));
var Camel;
(function (Camel) {
    function DebugRouteController($scope, $element, workspace, jolokia) {
        $scope.ignoreRouteXmlNode = true;
        $scope.startDebugging = function () {
            setDebugging(true);
        };
        $scope.stopDebugging = function () {
            setDebugging(false);
        };
        $scope.$on("$routeChangeSuccess", function (event, current, previous) {
            setTimeout(reloadData, 50);
        });
        $scope.$on("camel.diagram.selectedNodeId", function (event, value) {
            $scope.selectedDiagramNodeId = value;
            updateBreakpointFlag();
        });
        $scope.$on("camel.diagram.layoutComplete", function (event, value) {
            updateBreakpointIcons();
            $($element).find("g.node").dblclick(function (n) {
                var id = this.getAttribute("data-cid");
                $scope.toggleBreakpoint(id);
            });
        });
        $scope.$watch('workspace.selection', function () {
            if(workspace.moveIfViewInvalid()) {
                return;
            }
            reloadData();
        });
        $scope.toggleBreakpoint = function (id) {
            var mbean = Camel.getSelectionCamelDebugMBean(workspace);
            if(mbean && id) {
                var method = isBreakpointSet(id) ? "removeBreakpoint" : "addBreakpoint";
                jolokia.execute(mbean, method, id, onSuccess(breakpointsChanged));
            }
        };
        $scope.addBreakpoint = function () {
            var mbean = Camel.getSelectionCamelDebugMBean(workspace);
            if(mbean && $scope.selectedDiagramNodeId) {
                jolokia.execute(mbean, "addBreakpoint", $scope.selectedDiagramNodeId, onSuccess(breakpointsChanged));
            }
        };
        $scope.removeBreakpoint = function () {
            var mbean = Camel.getSelectionCamelDebugMBean(workspace);
            if(mbean && $scope.selectedDiagramNodeId) {
                jolokia.execute(mbean, "removeBreakpoint", $scope.selectedDiagramNodeId, onSuccess(breakpointsChanged));
            }
        };
        $scope.resume = function () {
            var mbean = Camel.getSelectionCamelDebugMBean(workspace);
            if(mbean) {
                jolokia.execute(mbean, "resumeAll", onSuccess(clearStoppedAndResume));
            }
        };
        $scope.suspend = function () {
            var mbean = Camel.getSelectionCamelDebugMBean(workspace);
            if(mbean) {
                jolokia.execute(mbean, "suspendAll", onSuccess(clearStoppedAndResume));
            }
        };
        $scope.step = function () {
            var mbean = Camel.getSelectionCamelDebugMBean(workspace);
            var stepNode = getStoppedBreakpointId();
            if(mbean && stepNode) {
                jolokia.execute(mbean, "stepBreakpoint(java.lang.String)", stepNode, onSuccess(clearStoppedAndResume));
            }
        };
        $scope.messages = [];
        $scope.mode = 'text';
        $scope.messageDialog = new Core.Dialog();
        $scope.gridOptions = Camel.createBrowseGridOptions();
        $scope.gridOptions.selectWithCheckboxOnly = false;
        $scope.gridOptions.showSelectionCheckbox = false;
        $scope.gridOptions.afterSelectionChange = onSelectionChanged;
        $scope.gridOptions.columnDefs.push({
            field: 'toNode',
            displayName: 'To Node'
        });
        $scope.openMessageDialog = function (message) {
            var idx = Core.pathGet(message, [
                "rowIndex"
            ]);
            $scope.selectRowIndex(idx);
            if($scope.row) {
                var body = $scope.row.body;
                $scope.mode = angular.isString(body) ? CodeEditor.detectTextFormat(body) : "text";
                $scope.messageDialog.open();
            }
        };
        $scope.selectRowIndex = function (idx) {
            $scope.rowIndex = idx;
            var selected = $scope.gridOptions.selectedItems;
            selected.splice(0, selected.length);
            if(idx >= 0 && idx < $scope.messages.length) {
                $scope.row = $scope.messages[idx];
                if($scope.row) {
                    selected.push($scope.row);
                }
            } else {
                $scope.row = null;
            }
            onSelectionChanged();
        };
        function onSelectionChanged() {
            var toNode = getStoppedBreakpointId();
            if(toNode) {
                var nodes = getDiagramNodes();
                nodes.attr("class", "node");
                nodes.filter(function (item) {
                    if(item) {
                        var cid = item["cid"];
                        var rid = item["rid"];
                        if(cid) {
                            return toNode === cid;
                        } else {
                            return toNode === rid;
                        }
                    }
                    return null;
                }).attr("class", "node selected");
            }
        }
        function reloadData() {
            $scope.debugging = false;
            var mbean = Camel.getSelectionCamelDebugMBean(workspace);
            if(mbean) {
                $scope.debugging = jolokia.getAttribute(mbean, "Enabled", onSuccess(null));
                if($scope.debugging) {
                    jolokia.execute(mbean, "getBreakpoints", onSuccess(onBreakpoints));
                    $scope.graphView = "app/camel/html/routes.html";
                    $scope.tableView = "app/camel/html/browseMessages.html";
                    Core.register(jolokia, $scope, {
                        type: 'exec',
                        mbean: mbean,
                        operation: 'getDebugCounter'
                    }, onSuccess(onBreakpointCounter));
                } else {
                    $scope.graphView = null;
                    $scope.tableView = null;
                }
            }
        }
        function onBreakpointCounter(response) {
            var counter = response.value;
            if(counter && counter !== $scope.breakpointCounter) {
                $scope.breakpointCounter = counter;
                loadCurrentStack();
            }
        }
        function loadCurrentStack() {
            var mbean = Camel.getSelectionCamelDebugMBean(workspace);
            if(mbean) {
                console.log("getting suspended breakpoints!");
                jolokia.execute(mbean, "getSuspendedBreakpointNodeIds", onSuccess(onSuspendedBreakpointNodeIds));
            }
        }
        function onSuspendedBreakpointNodeIds(response) {
            var mbean = Camel.getSelectionCamelDebugMBean(workspace);
            $scope.suspendedBreakpoints = response;
            $scope.stopped = response && response.length;
            var stopNodeId = getStoppedBreakpointId();
            if(mbean && stopNodeId) {
                jolokia.execute(mbean, 'dumpTracedMessagesAsXml', stopNodeId, onSuccess(onMessages));
                $scope.selectedDiagramNodeId = stopNodeId;
            }
            updateBreakpointIcons();
            Core.$apply($scope);
        }
        function onMessages(response) {
            console.log("onMessage! ");
            $scope.messages = [];
            if(response) {
                var xml = response;
                if(angular.isString(xml)) {
                    var doc = $.parseXML(xml);
                    var allMessages = $(doc).find("fabricTracerEventMessage");
                    if(!allMessages || !allMessages.length) {
                        allMessages = $(doc).find("backlogTracerEventMessage");
                    }
                    allMessages.each(function (idx, message) {
                        var messageData = Camel.createMessageFromXml(message);
                        var toNode = $(message).find("toNode").text();
                        if(toNode) {
                            messageData["toNode"] = toNode;
                        }
                        $scope.messages.push(messageData);
                    });
                }
            } else {
                console.log("WARNING: dumpTracedMessagesAsXml() returned no results!");
            }
            updateMessageSelection();
            console.log("has messages " + $scope.messages.length + " selected row " + $scope.row + " index " + $scope.rowIndex);
            Core.$apply($scope);
            updateBreakpointIcons();
        }
        function updateMessageSelection() {
            $scope.selectRowIndex($scope.rowIndex);
            if(!$scope.row && $scope.messageDialog.show) {
                $scope.row = {
                    headers: {
                    },
                    body: ""
                };
            }
        }
        function clearStoppedAndResume() {
            $scope.messages = [];
            $scope.suspendedBreakpoints = [];
            $scope.stopped = false;
            updateMessageSelection();
            Core.$apply($scope);
            updateBreakpointIcons();
        }
        function getStoppedBreakpointId() {
            var stepNode = null;
            var stepNodes = $scope.suspendedBreakpoints;
            if(stepNodes && stepNodes.length) {
                stepNode = stepNodes[0];
                if(stepNodes.length > 1 && isSuspendedAt($scope.selectedDiagramNodeId)) {
                    stepNode = $scope.selectedDiagramNodeId;
                }
            }
            return stepNode;
        }
        function isSuspendedAt(nodeId) {
            return containsNodeId($scope.suspendedBreakpoints, nodeId);
        }
        function onBreakpoints(response) {
            $scope.breakpoints = response;
            updateBreakpointFlag();
            var nodes = getDiagramNodes();
            if(nodes.length) {
                updateBreakpointIcons(nodes);
            }
            Core.$apply($scope);
        }
        function isBreakpointSet(nodeId) {
            return containsNodeId($scope.breakpoints, nodeId);
        }
        function updateBreakpointFlag() {
            $scope.hasBreakpoint = isBreakpointSet($scope.selectedDiagramNodeId);
        }
        function containsNodeId(breakpoints, nodeId) {
            return nodeId && breakpoints && breakpoints.some(nodeId);
        }
        function getDiagramNodes() {
            var svg = d3.select("svg");
            return svg.selectAll("g .node");
        }
        var breakpointImage = url("/app/camel/img/debug/breakpoint.gif");
        var suspendedBreakpointImage = url("/app/camel/img/debug/breakpoint-suspended.gif");
        function updateBreakpointIcons(nodes) {
            if (typeof nodes === "undefined") { nodes = getDiagramNodes(); }
            nodes.each(function (object) {
                var nodeId = object.cid;
                var thisNode = d3.select(this);
                var icons = thisNode.selectAll("image.breakpoint");
                var isSuspended = isSuspendedAt(nodeId);
                var isBreakpoint = isBreakpointSet(nodeId);
                if(isBreakpoint || isSuspended) {
                    var imageUrl = isSuspended ? suspendedBreakpointImage : breakpointImage;
                    if(!icons.length || !icons[0].length) {
                        thisNode.append("image").attr("xlink:href", function (d) {
                            return imageUrl;
                        }).attr("class", "breakpoint").attr("x", -12).attr("y", -20).attr("height", 24).attr("width", 24);
                    } else {
                        icons.attr("xlink:href", function (d) {
                            return imageUrl;
                        });
                    }
                } else {
                    icons.remove();
                }
            });
        }
        function breakpointsChanged(response) {
            reloadData();
            Core.$apply($scope);
        }
        function setDebugging(flag) {
            var mbean = Camel.getSelectionCamelDebugMBean(workspace);
            if(mbean) {
                var method = flag ? "enableDebugger" : "disableDebugger";
                jolokia.execute(mbean, method, onSuccess(breakpointsChanged));
            }
        }
    }
    Camel.DebugRouteController = DebugRouteController;
})(Camel || (Camel = {}));
var Camel;
(function (Camel) {
    function EndpointController($scope, $location, workspace, jolokia) {
        Camel.initEndpointChooserScope($scope, workspace, jolokia);
        $scope.workspace = workspace;
        $scope.message = "";
        $scope.createEndpoint = function (name) {
            var jolokia = workspace.jolokia;
            if(jolokia) {
                var mbean = Camel.getSelectionCamelContextMBean(workspace);
                if(mbean) {
                    $scope.message = "Creating endpoint " + name;
                    var operation = "createEndpoint(java.lang.String)";
                    jolokia.execute(mbean, operation, name, onSuccess(operationSuccess));
                } else {
                    notification("error", "Could not find the CamelContext MBean!");
                }
            }
        };
        $scope.createEndpointFromData = function () {
            if($scope.selectedComponentName && $scope.endpointPath) {
                var name = $scope.selectedComponentName + "://" + $scope.endpointPath;
                console.log("Have endpoint data " + JSON.stringify($scope.endpointParameters));
                var params = "";
                angular.forEach($scope.endpointParameters, function (value, key) {
                    var prefix = params ? "&" : "";
                    params += prefix + key + "=" + value;
                });
                if(params) {
                    name += "?" + params;
                }
                $scope.createEndpoint(name);
            }
        };
        $scope.deleteEndpoint = function () {
            var jolokia = workspace.jolokia;
            var selection = workspace.selection;
            var entries = selection.entries;
            if(selection && jolokia && entries) {
                var domain = selection.domain;
                var brokerName = entries["BrokerName"];
                var name = entries["Destination"];
                var isQueue = "Topic" !== entries["Type"];
                if(domain && brokerName) {
                    var mbean = "" + domain + ":BrokerName=" + brokerName + ",Type=Broker";
                    $scope.message = "Deleting " + (isQueue ? "queue" : "topic") + " " + name;
                    var operation = "removeEndpoint(java.lang.String)";
                    jolokia.execute(mbean, operation, name, onSuccess(deleteSuccess));
                }
            }
        };
        function operationSuccess() {
            $scope.endpointName = "";
            $scope.workspace.operationCounter += 1;
            $scope.$apply();
            notification("success", $scope.message);
        }
        function deleteSuccess() {
            if(workspace.selection) {
                var parent = workspace.selection.parent;
                if(parent) {
                    $scope.workspace.updateSelectionNode(parent);
                }
            }
            $scope.workspace.operationCounter += 1;
            $scope.$apply();
            notification("success", $scope.message);
        }
    }
    Camel.EndpointController = EndpointController;
})(Camel || (Camel = {}));
var Camel;
(function (Camel) {
    Camel.endpointCategories = {
        bigdata: {
            label: "Big Data",
            endpoints: [
                "hdfs", 
                "hbase", 
                "lucene", 
                "solr"
            ],
            endpointIcon: "/app/camel/img/endpointRepository24.png"
        },
        database: {
            label: "Database",
            endpoints: [
                "couchdb", 
                "elasticsearch", 
                "hbase", 
                "jdbc", 
                "jpa", 
                "hibernate", 
                "mongodb", 
                "mybatis", 
                "sql"
            ],
            endpointIcon: "/app/camel/img/endpointRepository24.png"
        },
        cloud: {
            label: "Cloud",
            endpoints: [
                "aws-cw", 
                "aws-ddb", 
                "aws-sdb", 
                "aws-ses", 
                "aws-sns", 
                "aws-sqs", 
                "aws-s3", 
                "gauth", 
                "ghhtp", 
                "glogin", 
                "gtask", 
                "jclouds"
            ]
        },
        core: {
            label: "Core",
            endpoints: [
                "bean", 
                "direct", 
                "seda"
            ]
        },
        messaging: {
            label: "Messaging",
            endpoints: [
                "jms", 
                "activemq", 
                "amqp", 
                "cometd", 
                "mqtt"
            ],
            endpointIcon: "/app/camel/img/endpointQueue24.png"
        },
        mobile: {
            label: "Mobile",
            endpoints: [
                "apns"
            ]
        },
        social: {
            label: "Social",
            endpoints: [
                "atom", 
                "irc", 
                "rss", 
                "smpp", 
                "twitter", 
                "weather"
            ]
        },
        storage: {
            label: "Storage",
            endpointIcon: "/app/camel/img/endpointFolder24.png",
            endpoints: [
                "file", 
                "ftp", 
                "sftp", 
                "scp", 
                "jsch"
            ]
        },
        template: {
            label: "Templating",
            endpoints: [
                "freemarker", 
                "velocity", 
                "xquery", 
                "xslt", 
                "scalate", 
                "string-template"
            ]
        }
    };
    Camel.endpointToCategory = {
    };
    Camel.endpointIcon = "/app/camel/img/endpoint24.png";
    Camel.endpointConfigurations = {
        drools: {
            icon: "/app/camel/img/endpointQueue24.png"
        },
        quartz: {
            icon: "/app/camel/img/endpointTimer24.png"
        },
        timer: {
            icon: "/app/camel/img/endpointTimer24.png"
        }
    };
    Camel.endpointForms = {
        file: {
            tabs: {
                'Options': [
                    '*'
                ]
            }
        },
        activemq: {
            tabs: {
                'Connection': [
                    'clientId', 
                    'transacted', 
                    'transactedInOut', 
                    'transactionName', 
                    'transactionTimeout'
                ],
                'Producer': [
                    'timeToLive', 
                    'priority', 
                    'allowNullBody', 
                    'pubSubNoLocal', 
                    'preserveMessageQos'
                ],
                'Consumer': [
                    'concurrentConsumers', 
                    'acknowledgementModeName', 
                    'selector', 
                    'receiveTimeout'
                ],
                'Reply': [
                    'replyToDestination', 
                    'replyToDeliveryPersistent', 
                    'replyToCacheLevelName', 
                    'replyToDestinationSelectorName'
                ],
                'Options': [
                    '*'
                ]
            }
        }
    };
    Camel.endpointForms["jms"] = Camel.endpointForms.activemq;
    angular.forEach(Camel.endpointCategories, function (category, catKey) {
        category.id = catKey;
        angular.forEach(category.endpoints, function (endpoint) {
            Camel.endpointToCategory[endpoint] = category;
        });
    });
    var camelModelTabExtensions = {
        route: {
            'Overview': [
                'id', 
                'description'
            ],
            'Advanced': [
                '*'
            ]
        }
    };
    function getEndpointConfig(endpointName, category) {
        var answer = Camel.endpointConfigurations[endpointName];
        if(!answer) {
            answer = {
            };
            Camel.endpointConfigurations[endpointName] = answer;
        }
        if(!answer.label) {
            answer.label = endpointName;
        }
        if(!answer.icon) {
            answer.icon = category.endpointIcon || Camel.endpointIcon;
        }
        if(!answer.category) {
            answer.category = category;
        }
        return answer;
    }
    Camel.getEndpointConfig = getEndpointConfig;
    function getEndpointCategory(endpointName) {
        return Camel.endpointToCategory[endpointName] || Camel.endpointCategories.core;
    }
    Camel.getEndpointCategory = getEndpointCategory;
    function getConfiguredCamelModel() {
        var schema = _apacheCamelModel;
        var definitions = schema["definitions"];
        if(definitions) {
            angular.forEach(camelModelTabExtensions, function (tabs, name) {
                var model = definitions[name];
                if(model) {
                    if(!model["tabs"]) {
                        model["tabs"] = tabs;
                    }
                }
            });
        }
        return schema;
    }
    Camel.getConfiguredCamelModel = getConfiguredCamelModel;
    function initEndpointChooserScope($scope, workspace, jolokia) {
        $scope.selectedComponentName = null;
        $scope.endpointParameters = {
        };
        $scope.schema = {
            definitions: {
            }
        };
        var silentOptions = {
            silent: true
        };
        $scope.$watch('workspace.selection', function () {
            workspace.moveIfViewInvalid();
            $scope.loadEndpointNames();
        });
        $scope.$watch('selectedComponentName', function () {
            if($scope.selectedComponentName !== $scope.loadedComponentName) {
                $scope.endpointParameters = {
                };
                $scope.loadEndpointSchema($scope.selectedComponentName);
                $scope.loadedComponentName = $scope.selectedComponentName;
            }
        });
        $scope.endpointCompletions = function () {
            var answer = [];
            var mbean = findCamelContextMBean();
            var componentName = $scope.selectedComponentName;
            var endpointParameters = {
            };
            var completionText = $scope.endpointPath || "";
            if(mbean && componentName && completionText) {
                answer = jolokia.execute(mbean, 'completeEndpointPath', componentName, endpointParameters, completionText, onSuccess(null, silentOptions));
            }
            return answer;
        };
        $scope.loadEndpointNames = function () {
            $scope.componentNames = null;
            var mbean = findCamelContextMBean();
            if(mbean) {
                jolokia.execute(mbean, 'findComponentNames', onSuccess(onComponents, silentOptions));
            } else {
                console.log("WARNING: No camel context mbean so cannot load component names");
            }
        };
        $scope.loadEndpointSchema = function (componentName) {
            var mbean = findCamelContextMBean();
            if(mbean && componentName) {
                jolokia.execute(mbean, 'componentParameterJsonSchema', componentName, onSuccess(onEndpointSchema, silentOptions));
            }
        };
        function onComponents(response) {
            $scope.componentNames = response;
            $scope.hasComponentNames = $scope.componentNames ? true : false;
            Core.$apply($scope);
        }
        function onEndpointSchema(response) {
            if(response) {
                try  {
                    var json = JSON.parse(response);
                    var endpointName = $scope.selectedComponentName;
                    configureEndpointSchema(endpointName, json);
                    $scope.endpointSchema = json;
                    $scope.schema.definitions[endpointName] = json;
                    Core.$apply($scope);
                } catch (e) {
                    console.log("Failed to parse JSON " + e);
                    console.log("JSON: " + response);
                }
            }
        }
        function configureEndpointSchema(endpointName, json) {
            console.log("======== configuring schema for " + endpointName);
            var config = Camel.endpointForms[endpointName];
            if(config && json) {
                if(config.tabs) {
                    json.tabs = config.tabs;
                }
            }
        }
        function findCamelContextMBean() {
            var mbean = Camel.getSelectionCamelContextMBean(workspace);
            if(!mbean && $scope.findProfileCamelContext) {
                var folder = Core.getMBeanTypeFolder(workspace, Camel.jmxDomain, "context");
                mbean = Core.pathGet(folder, [
                    "objectName"
                ]);
            }
            return mbean;
        }
    }
    Camel.initEndpointChooserScope = initEndpointChooserScope;
})(Camel || (Camel = {}));
var Camel;
(function (Camel) {
    function processRouteXml(workspace, jolokia, folder, onRoute) {
        var selectedRouteId = getSelectedRouteId(workspace, folder);
        var mbean = getSelectionCamelContextMBean(workspace);
        function onRouteXml(response) {
            var route = null;
            var data = response ? response.value : null;
            if(data) {
                var doc = $.parseXML(data);
                var routes = $(doc).find("route[id='" + selectedRouteId + "']");
                if(routes && routes.length) {
                    route = routes[0];
                }
            }
            onRoute(route);
        }
        if(mbean && selectedRouteId) {
            jolokia.request({
                type: 'exec',
                mbean: mbean,
                operation: 'dumpRoutesAsXml()'
            }, onSuccess(onRouteXml, {
                error: onRouteXml
            }));
        } else {
            if(!selectedRouteId) {
                console.log("No selectedRouteId when trying to lazy load the route!");
            }
            onRoute(null);
        }
    }
    Camel.processRouteXml = processRouteXml;
    function getRouteNodeUri(node) {
        var uri = null;
        if(node) {
            uri = node.getAttribute("uri");
            if(!uri) {
                var ref = node.getAttribute("ref");
                if(ref) {
                    uri = "ref:" + ref;
                }
            }
        }
        return uri;
    }
    Camel.getRouteNodeUri = getRouteNodeUri;
    function getRouteFolderJSON(folder, answer) {
        if (typeof answer === "undefined") { answer = {
        }; }
        var nodeData = folder["camelNodeData"];
        if(!nodeData) {
            var routeXmlNode = folder["routeXmlNode"];
            if(routeXmlNode) {
                nodeData = Camel.getRouteNodeJSON(routeXmlNode);
            }
            if(!nodeData) {
                nodeData = answer;
            }
            folder["camelNodeData"] = nodeData;
        }
        return nodeData;
    }
    Camel.getRouteFolderJSON = getRouteFolderJSON;
    function getRouteNodeJSON(routeXmlNode, answer) {
        if (typeof answer === "undefined") { answer = {
        }; }
        if(routeXmlNode) {
            angular.forEach(routeXmlNode.attributes, function (attr) {
                answer[attr.name] = attr.value;
            });
            var localName = routeXmlNode.localName;
            if(localName !== "route" && localName !== "routes" && localName !== "camelContext") {
                $(routeXmlNode).children("*").each(function (idx, element) {
                    var nodeName = element.localName;
                    var langSettings = Camel.camelLanguageSettings(nodeName);
                    if(langSettings) {
                        answer["expression"] = {
                            language: nodeName,
                            expression: element.textContent
                        };
                    } else {
                        if(!isCamelPattern(nodeName)) {
                            var nested = getRouteNodeJSON(element);
                            if(nested) {
                                answer[nodeName] = nested;
                            }
                        }
                    }
                });
            }
        }
        return answer;
    }
    Camel.getRouteNodeJSON = getRouteNodeJSON;
    function increaseIndent(currentIndent, indentAmount) {
        if (typeof indentAmount === "undefined") { indentAmount = "  "; }
        return currentIndent + indentAmount;
    }
    Camel.increaseIndent = increaseIndent;
    function setRouteNodeJSON(routeXmlNode, newData, indent) {
        if(routeXmlNode) {
            var childIndent = increaseIndent(indent);
            angular.forEach(newData, function (value, key) {
                if(angular.isObject(value)) {
                    var textContent = null;
                    if(key === "expression") {
                        var languageName = value["language"];
                        if(languageName) {
                            key = languageName;
                            textContent = value["expression"];
                            value = angular.copy(value);
                            delete value["expression"];
                            delete value["language"];
                        }
                    }
                    var nested = $(routeXmlNode).children(key);
                    var element = null;
                    if(!nested || !nested.length) {
                        var doc = routeXmlNode.ownerDocument || document;
                        routeXmlNode.appendChild(doc.createTextNode("\n" + childIndent));
                        element = doc.createElement(key);
                        if(textContent) {
                            element.appendChild(doc.createTextNode(textContent));
                        }
                        routeXmlNode.appendChild(element);
                    } else {
                        element = nested[0];
                    }
                    setRouteNodeJSON(element, value, childIndent);
                    if(textContent) {
                        nested.text(textContent);
                    }
                } else {
                    if(value) {
                        if(key.startsWith("_")) {
                        } else {
                            var text = value.toString();
                            routeXmlNode.setAttribute(key, text);
                        }
                    } else {
                        routeXmlNode.removeAttribute(key);
                    }
                }
            });
        }
    }
    Camel.setRouteNodeJSON = setRouteNodeJSON;
    function getRouteNodeIcon(nodeSettingsOrXmlNode) {
        var nodeSettings = null;
        if(nodeSettingsOrXmlNode) {
            var nodeName = nodeSettingsOrXmlNode.localName;
            if(nodeName) {
                nodeSettings = getCamelSchema(nodeName);
            } else {
                nodeSettings = nodeSettingsOrXmlNode;
            }
        }
        if(nodeSettings) {
            var imageName = nodeSettings["icon"] || "generic24.png";
            return url("/app/camel/img/" + imageName);
        } else {
            return null;
        }
    }
    Camel.getRouteNodeIcon = getRouteNodeIcon;
    function getSelectedRouteNode(workspace) {
        var selection = workspace.selection;
        return (selection && Camel.jmxDomain === selection.domain) ? selection["routeXmlNode"] : null;
    }
    Camel.getSelectedRouteNode = getSelectedRouteNode;
    function clearSelectedRouteNode(workspace) {
        var selection = workspace.selection;
        if(selection && Camel.jmxDomain === selection.domain) {
            delete selection["routeXmlNode"];
        }
    }
    Camel.clearSelectedRouteNode = clearSelectedRouteNode;
    function getCamelSchema(nodeIdOrDefinition) {
        return (angular.isObject(nodeIdOrDefinition)) ? nodeIdOrDefinition : Forms.lookupDefinition(nodeIdOrDefinition, _apacheCamelModel);
    }
    Camel.getCamelSchema = getCamelSchema;
    function isCamelPattern(nodeId) {
        return Forms.isJsonType(nodeId, _apacheCamelModel, "org.apache.camel.model.OptionalIdentifiedDefinition");
    }
    Camel.isCamelPattern = isCamelPattern;
    function isNextSiblingAddedAsChild(nodeIdOrDefinition) {
        var definition = getCamelSchema(nodeIdOrDefinition);
        if(definition) {
            return definition["nextSiblingAddedAsChild"] || false;
        }
        return null;
    }
    Camel.isNextSiblingAddedAsChild = isNextSiblingAddedAsChild;
    function acceptInput(nodeIdOrDefinition) {
        var definition = getCamelSchema(nodeIdOrDefinition);
        if(definition) {
            return definition["acceptInput"] || false;
        }
        return null;
    }
    Camel.acceptInput = acceptInput;
    function acceptOutput(nodeIdOrDefinition) {
        var definition = getCamelSchema(nodeIdOrDefinition);
        if(definition) {
            return definition["acceptOutput"] || false;
        }
        return null;
    }
    Camel.acceptOutput = acceptOutput;
    function camelLanguageSettings(nodeName) {
        return _apacheCamelModel.languages[nodeName];
    }
    Camel.camelLanguageSettings = camelLanguageSettings;
    function isCamelLanguage(nodeName) {
        return (camelLanguageSettings(nodeName) || nodeName === "expression") ? true : false;
    }
    Camel.isCamelLanguage = isCamelLanguage;
    function loadCamelTree(xml, key) {
        var doc = xml;
        if(angular.isString(xml)) {
            doc = $.parseXML(xml);
        }
        var id = "camelContext";
        var folder = new Folder(id);
        folder.addClass = "org-apache-camel-context";
        folder.domain = Camel.jmxDomain;
        folder.typeName = "context";
        folder.key = Core.toSafeDomID(key);
        var context = $(doc).find("camelContext");
        if(!context || !context.length) {
            context = $(doc).find("routes");
        }
        if(context && context.length) {
            folder["xmlDocument"] = doc;
            folder["routeXmlNode"] = context;
            $(context).children("route").each(function (idx, route) {
                var id = route.getAttribute("id");
                if(!id) {
                    id = "route" + idx;
                    route.setAttribute("id", id);
                }
                var routeFolder = new Folder(id);
                routeFolder.addClass = "org-apache-camel-route";
                routeFolder.typeName = "routes";
                routeFolder.domain = Camel.jmxDomain;
                routeFolder.key = folder.key + "_" + Core.toSafeDomID(id);
                routeFolder.parent = folder;
                var nodeSettings = getCamelSchema("route");
                if(nodeSettings) {
                    var imageUrl = getRouteNodeIcon(nodeSettings);
                    routeFolder.tooltip = nodeSettings["tooltip"] || nodeSettings["description"] || id;
                    routeFolder.icon = imageUrl;
                }
                folder.children.push(routeFolder);
                addRouteChildren(routeFolder, route);
            });
        }
        return folder;
    }
    Camel.loadCamelTree = loadCamelTree;
    function addRouteChildren(folder, route) {
        folder.children = [];
        folder["routeXmlNode"] = route;
        route.setAttribute("_cid", folder.key);
        $(route).children("*").each(function (idx, n) {
            addRouteChild(folder, n);
        });
    }
    Camel.addRouteChildren = addRouteChildren;
    function addRouteChild(folder, n) {
        var nodeName = n.localName;
        if(nodeName) {
            var nodeSettings = getCamelSchema(nodeName);
            if(nodeSettings) {
                var imageUrl = getRouteNodeIcon(nodeSettings);
                var child = new Folder(nodeName);
                child.domain = Camel.jmxDomain;
                child.typeName = "routeNode";
                updateRouteNodeLabelAndTooltip(child, n, nodeSettings);
                child.parent = folder;
                child.folderNames = folder.folderNames;
                var id = n.getAttribute("id") || nodeName;
                var key = folder.key + "_" + Core.toSafeDomID(id);
                var counter = 1;
                var notFound = true;
                while(notFound) {
                    var tmpKey = key + counter;
                    if(folder.children.some({
                        key: tmpKey
                    })) {
                        counter += 1;
                    } else {
                        notFound = false;
                        key = tmpKey;
                    }
                }
                child.key = key;
                child.icon = imageUrl;
                child["routeXmlNode"] = n;
                if(!folder.children) {
                    folder.children = [];
                }
                folder.children.push(child);
                addRouteChildren(child, n);
                return child;
            }
        }
        return null;
    }
    Camel.addRouteChild = addRouteChild;
    function getFolderCamelNodeId(folder) {
        var answer = Core.pathGet(folder, [
            "routeXmlNode", 
            "localName"
        ]);
        return ("from" === answer || "to" === answer) ? "endpoint" : answer;
    }
    Camel.getFolderCamelNodeId = getFolderCamelNodeId;
    function createFolderXmlTree(treeNode, xmlNode, indent) {
        if (typeof indent === "undefined") { indent = Camel.increaseIndent(""); }
        var folder = treeNode.data || treeNode;
        var count = 0;
        var parentName = getFolderCamelNodeId(folder);
        if(folder) {
            if(!xmlNode) {
                xmlNode = document.createElement(parentName);
                var rootJson = Camel.getRouteFolderJSON(folder);
                if(rootJson) {
                    Camel.setRouteNodeJSON(xmlNode, rootJson, indent);
                }
            }
            var doc = xmlNode.ownerDocument || document;
            var namespaceURI = xmlNode.namespaceURI;
            var from = parentName !== "route";
            var childIndent = Camel.increaseIndent(indent);
            angular.forEach(treeNode.children || treeNode.getChildren(), function (childTreeNode) {
                var childFolder = childTreeNode.data || childTreeNode;
                var name = Camel.getFolderCamelNodeId(childFolder);
                var json = Camel.getRouteFolderJSON(childFolder);
                if(name && json) {
                    var language = false;
                    if(name === "endpoint") {
                        if(from) {
                            name = "to";
                        } else {
                            name = "from";
                            from = true;
                        }
                    }
                    if(name === "expression") {
                        var languageName = json["language"];
                        if(languageName) {
                            name = languageName;
                            language = true;
                        }
                    }
                    xmlNode.appendChild(doc.createTextNode("\n" + childIndent));
                    var newNode = doc.createElementNS(namespaceURI, name);
                    Camel.setRouteNodeJSON(newNode, json, childIndent);
                    xmlNode.appendChild(newNode);
                    count += 1;
                    createFolderXmlTree(childTreeNode, newNode, childIndent);
                }
            });
            if(count) {
                xmlNode.appendChild(doc.createTextNode("\n" + indent));
            }
        }
        return xmlNode;
    }
    Camel.createFolderXmlTree = createFolderXmlTree;
    function updateRouteNodeLabelAndTooltip(folder, routeXmlNode, nodeSettings) {
        var localName = routeXmlNode.localName;
        var id = routeXmlNode.getAttribute("id");
        var label = nodeSettings["title"] || localName;
        var tooltip = nodeSettings["tooltip"] || nodeSettings["description"] || label;
        if(id) {
            label = id;
        } else {
            var uri = getRouteNodeUri(routeXmlNode);
            if(uri) {
                label = uri;
            } else {
                var children = $(routeXmlNode).children("*");
                if(children && children.length) {
                    var child = children[0];
                    var childName = child.localName;
                    var expression = null;
                    if(Camel.isCamelLanguage(childName)) {
                        expression = child.textContent;
                        if(!expression) {
                            expression = child.getAttribute("expression");
                        }
                    }
                    if(expression) {
                        label += " " + expression;
                        tooltip += " " + childName + " expression";
                    }
                }
            }
        }
        folder.title = label;
        folder.tooltip = tooltip;
        return label;
    }
    Camel.updateRouteNodeLabelAndTooltip = updateRouteNodeLabelAndTooltip;
    function getSelectionCamelContextMBean(workspace) {
        if(workspace) {
            var contextId = getContextId(workspace);
            var selection = workspace.selection;
            var tree = workspace.tree;
            if(tree && selection) {
                var domain = selection.domain;
                if(domain && contextId) {
                    var result = tree.navigate(domain, contextId, "context");
                    if(result && result.children) {
                        var contextBean = result.children.first();
                        if(contextBean.title) {
                            var contextName = contextBean.title;
                            return "" + domain + ":context=" + contextId + ',type=context,name="' + contextName + '"';
                        }
                    }
                }
            }
        }
        return null;
    }
    Camel.getSelectionCamelContextMBean = getSelectionCamelContextMBean;
    function getSelectionCamelContextEndpoints(workspace) {
        if(workspace) {
            var contextId = getContextId(workspace);
            var selection = workspace.selection;
            var tree = workspace.tree;
            if(tree && selection) {
                var domain = selection.domain;
                if(domain && contextId) {
                    return tree.navigate(domain, contextId, "endpoints");
                }
            }
        }
        return null;
    }
    Camel.getSelectionCamelContextEndpoints = getSelectionCamelContextEndpoints;
    function getSelectionCamelTraceMBean(workspace) {
        if(workspace) {
            var contextId = getContextId(workspace);
            var selection = workspace.selection;
            var tree = workspace.tree;
            if(tree && selection) {
                var domain = selection.domain;
                if(domain && contextId) {
                    var result = tree.navigate(domain, contextId, "tracer");
                    if(result && result.children) {
                        var mbean = result.children.find(function (m) {
                            return m.title.startsWith("BacklogTracer");
                        });
                        if(mbean) {
                            return mbean.objectName;
                        }
                    }
                    var fabricResult = tree.navigate(domain, contextId, "fabric");
                    if(fabricResult && fabricResult.children) {
                        var mbean = fabricResult.children.first();
                        return mbean.objectName;
                    }
                }
            }
        }
        return null;
    }
    Camel.getSelectionCamelTraceMBean = getSelectionCamelTraceMBean;
    function getSelectionCamelDebugMBean(workspace) {
        if(workspace) {
            var contextId = getContextId(workspace);
            var selection = workspace.selection;
            var tree = workspace.tree;
            if(tree && selection) {
                var domain = selection.domain;
                if(domain && contextId) {
                    var result = tree.navigate(domain, contextId, "tracer");
                    if(result && result.children) {
                        var mbean = result.children.find(function (m) {
                            return m.title.startsWith("BacklogDebugger");
                        });
                        if(mbean) {
                            return mbean.objectName;
                        }
                    }
                }
            }
        }
        return null;
    }
    Camel.getSelectionCamelDebugMBean = getSelectionCamelDebugMBean;
    function getContextId(workspace) {
        var selection = workspace.selection;
        if(selection) {
            var tree = workspace.tree;
            var folderNames = selection.folderNames;
            var entries = selection.entries;
            var contextId;
            if(tree) {
                if(folderNames && folderNames.length > 1) {
                    contextId = folderNames[1];
                } else {
                    if(entries) {
                        contextId = entries["context"];
                    }
                }
            }
        }
        return contextId;
    }
    Camel.getContextId = getContextId;
    function isState(item, state) {
        var value = (item.State || "").toLowerCase();
        if(angular.isArray(state)) {
            return state.any(function (stateText) {
                return value.startsWith(stateText);
            });
        } else {
            return value.startsWith(state);
        }
    }
    Camel.isState = isState;
    function iconClass(state) {
        if(state) {
            switch(state.toLowerCase()) {
                case 'started': {
                    return "green icon-play-circle";

                }
                case 'suspended': {
                    return "icon-pause";

                }
            }
        }
        return "orange icon-off";
    }
    Camel.iconClass = iconClass;
    function lastExchangeCompletedSince(entity) {
        var answer = null;
        if(entity && isState(entity, "started")) {
            answer = entity.lastExchangeCompletedSince;
            if(!answer) {
                answer = sinceFromTimestamp(entity["LastExchangeCompletedTimestamp"]);
                if(answer) {
                    entity.lastExchangeCompletedSince = answer;
                }
            }
        }
        return answer;
    }
    Camel.lastExchangeCompletedSince = lastExchangeCompletedSince;
    function lastExchangeFailedSince(entity) {
        var answer = null;
        if(entity && isState(entity, "started")) {
            answer = entity.lastExchangeFailedSince;
            if(!answer) {
                answer = sinceFromTimestamp(entity["LastExchangeFailedTimestamp"]);
                if(answer) {
                    entity.lastExchangeFailedSince = answer;
                }
            }
        }
        return answer;
    }
    Camel.lastExchangeFailedSince = lastExchangeFailedSince;
    function sinceFromTimestamp(timestamp) {
        if(!timestamp) {
            return null;
        }
        var time = new Date(timestamp);
        var now = new Date();
        var diff = now.getTime() - time.getTime();
        return diff;
    }
    Camel.sinceFromTimestamp = sinceFromTimestamp;
    function getSelectedRouteId(workspace, folder) {
        if (typeof folder === "undefined") { folder = null; }
        var selection = folder || workspace.selection;
        var selectedRouteId = null;
        if(selection) {
            if(selection && selection.entries) {
                var typeName = selection.entries["type"];
                var name = selection.entries["name"];
                if("routes" === typeName && name) {
                    selectedRouteId = trimQuotes(name);
                }
            }
        }
        return selectedRouteId;
    }
    Camel.getSelectedRouteId = getSelectedRouteId;
    function getSelectionRouteMBean(workspace, routeId) {
        if(workspace) {
            var contextId = getContextId(workspace);
            var selection = workspace.selection;
            var tree = workspace.tree;
            if(tree && selection) {
                var domain = selection.domain;
                if(domain && contextId) {
                    var result = tree.navigate(domain, contextId, "routes");
                    if(result && result.children) {
                        var mbean = result.children.find(function (m) {
                            return m.title === routeId;
                        });
                        if(mbean) {
                            return mbean.objectName;
                        }
                    }
                }
            }
        }
        return null;
    }
    Camel.getSelectionRouteMBean = getSelectionRouteMBean;
    function getCamelVersion(workspace, jolokia) {
        var mbean = getSelectionCamelContextMBean(workspace);
        if(mbean) {
            return jolokia.getAttribute(mbean, "CamelVersion", onSuccess(null));
        } else {
            return null;
        }
    }
    Camel.getCamelVersion = getCamelVersion;
    function createMessageFromXml(exchange) {
        var exchangeElement = $(exchange);
        var uid = exchangeElement.children("uid").text();
        var timestamp = exchangeElement.children("timestamp").text();
        var messageData = {
            headers: {
            },
            headerTypes: {
            },
            id: null,
            uid: uid,
            timestamp: timestamp,
            headerHtml: ""
        };
        var message = exchangeElement.children("message")[0];
        if(!message) {
            message = exchange;
        }
        var messageElement = $(message);
        var headers = messageElement.find("header");
        var headerHtml = "";
        headers.each(function (idx, header) {
            var key = header.getAttribute("key");
            var typeName = header.getAttribute("type");
            var value = header.textContent;
            if(key) {
                if(value) {
                    messageData.headers[key] = value;
                }
                if(typeName) {
                    messageData.headerTypes[key] = typeName;
                }
                headerHtml += "<tr><td class='property-name'>" + key + "</td>" + "<td class='property-value'>" + (value || "") + "</td></tr>";
            }
        });
        messageData.headerHtml = headerHtml;
        var id = messageData.headers["breadcrumbId"];
        if(!id) {
            var postFixes = [
                "MessageID", 
                "ID", 
                "Path", 
                "Name"
            ];
            angular.forEach(postFixes, function (postfix) {
                if(!id) {
                    angular.forEach(messageData.headers, function (value, key) {
                        if(!id && key.endsWith(postfix)) {
                            id = value;
                        }
                    });
                }
            });
            angular.forEach(messageData.headers, function (value, key) {
                if(!id) {
                    id = value;
                }
            });
        }
        messageData.id = id;
        var body = messageElement.children("body")[0];
        if(body) {
            var bodyText = body.textContent;
            var bodyType = body.getAttribute("type");
            messageData["body"] = bodyText;
            messageData["bodyType"] = bodyType;
        }
        return messageData;
    }
    Camel.createMessageFromXml = createMessageFromXml;
    function createBrowseGridOptions() {
        return {
            selectedItems: [],
            data: 'messages',
            displayFooter: false,
            showFilter: false,
            showColumnMenu: true,
            enableColumnResize: true,
            enableColumnReordering: true,
            filterOptions: {
                filterText: ''
            },
            selectWithCheckboxOnly: true,
            showSelectionCheckbox: true,
            maintainColumnRatios: false,
            columnDefs: [
                {
                    field: 'id',
                    displayName: 'ID',
                    cellTemplate: '<div class="ngCellText"><a ng-click="openMessageDialog(row)">{{row.entity.id}}</a></div>'
                }
            ]
        };
    }
    Camel.createBrowseGridOptions = createBrowseGridOptions;
    function loadRouteXmlNodes($scope, doc, selectedRouteId, nodes, links, width) {
        var allRoutes = $(doc).find("route");
        var routeDelta = width / allRoutes.length;
        var rowX = 0;
        allRoutes.each(function (idx, route) {
            var routeId = route.getAttribute("id");
            if(!selectedRouteId || !routeId || selectedRouteId === routeId) {
                Camel.addRouteXmlChildren($scope, route, nodes, links, null, rowX, 0);
                rowX += routeDelta;
            }
        });
    }
    Camel.loadRouteXmlNodes = loadRouteXmlNodes;
    function addRouteXmlChildren($scope, parent, nodes, links, parentId, parentX, parentY, parentNode) {
        if (typeof parentNode === "undefined") { parentNode = null; }
        var delta = 150;
        var x = parentX;
        var y = parentY + delta;
        var rid = parent.getAttribute("id");
        var siblingNodes = [];
        var parenNodeName = parent.localName;
        $(parent).children().each(function (idx, route) {
            var id = nodes.length;
            var nodeId = route.localName;
            if(nodeId === "from" && !parentId) {
                parentId = id;
            }
            var nodeSettings = getCamelSchema(nodeId);
            var node = null;
            if(nodeSettings) {
                var label = nodeSettings["title"] || nodeId;
                var uri = getRouteNodeUri(route);
                if(uri) {
                    label += " " + uri;
                }
                var tooltip = nodeSettings["tooltip"] || nodeSettings["description"] || name;
                var imageUrl = getRouteNodeIcon(nodeSettings);
                var cid = route.getAttribute("_cid") || route.getAttribute("id");
                node = {
                    "name": name,
                    "label": label,
                    "group": 1,
                    "id": id,
                    "x": x,
                    "y:": y,
                    "imageUrl": imageUrl,
                    "cid": cid,
                    "tooltip": tooltip
                };
                if(rid) {
                    node["rid"] = rid;
                    if(!$scope.routeNodes) {
                        $scope.routeNodes = {
                        };
                    }
                    $scope.routeNodes[rid] = node;
                }
                if(!cid) {
                    cid = nodeId + (nodes.length + 1);
                }
                if(cid) {
                    node["cid"] = cid;
                    if(!$scope.nodes) {
                        $scope.nodes = {
                        };
                    }
                    $scope.nodes[cid] = node;
                }
                rid = null;
                nodes.push(node);
                if(parentId !== null && parentId !== id) {
                    if(siblingNodes.length === 0 || parenNodeName === "choice") {
                        links.push({
                            "source": parentId,
                            "target": id,
                            "value": 1
                        });
                    } else {
                        siblingNodes.forEach(function (nodeId) {
                            links.push({
                                "source": nodeId,
                                "target": id,
                                "value": 1
                            });
                        });
                        siblingNodes.length = 0;
                    }
                }
            } else {
                var langSettings = Camel.camelLanguageSettings(nodeId);
                if(langSettings && parentNode) {
                    var name = langSettings["name"] || nodeId;
                    var text = route.textContent;
                    if(text) {
                        parentNode["tooltip"] = parentNode["label"] + " " + name + " " + text;
                        parentNode["label"] = text;
                    } else {
                        parentNode["label"] = parentNode["label"] + " " + name;
                    }
                }
            }
            var siblings = addRouteXmlChildren($scope, route, nodes, links, id, x, y, node);
            if(parenNodeName === "choice") {
                siblingNodes = siblingNodes.concat(siblings);
                x += delta;
            } else {
                if(nodeId === "choice") {
                    siblingNodes = siblings;
                    y += delta;
                } else {
                    siblingNodes = [
                        nodes.length - 1
                    ];
                    y += delta;
                }
            }
        });
        return siblingNodes;
    }
    Camel.addRouteXmlChildren = addRouteXmlChildren;
    function getCanvasHeight(canvasDiv) {
        var height = canvasDiv.height();
        if(height < 300) {
            console.log("browse thinks the height is only " + height + " so calculating offset from doc height");
            var offset = canvasDiv.offset();
            height = $(document).height() - 5;
            if(offset) {
                var top = offset['top'];
                if(top) {
                    height -= top;
                }
            }
        }
        return height;
    }
    Camel.getCanvasHeight = getCanvasHeight;
    function addFoldersToIndex(folder, map) {
        if (typeof map === "undefined") { map = {
        }; }
        if(folder) {
            var key = folder.key;
            if(key) {
                map[key] = folder;
            }
            angular.forEach(folder.children, function (child) {
                return addFoldersToIndex(child, map);
            });
        }
        return map;
    }
    Camel.addFoldersToIndex = addFoldersToIndex;
    function generateXmlFromFolder(treeNode) {
        var folder = (treeNode && treeNode.data) ? treeNode.data : treeNode;
        if(!folder) {
            return null;
        }
        var doc = folder["xmlDocument"];
        var context = folder["routeXmlNode"];
        if(context && context.length) {
            var element = context[0];
            var children = element.childNodes;
            var routeIndices = [];
            for(var i = 0; i < children.length; i++) {
                var node = children[i];
                var name = node.localName;
                if("route" === name && parent) {
                    routeIndices.push(i);
                }
            }
            while(routeIndices.length) {
                var idx = routeIndices.pop();
                var nextIndex = idx + 1;
                while(true) {
                    var node = element.childNodes[nextIndex];
                    if(Core.isTextNode(node)) {
                        element.removeChild(node);
                    } else {
                        break;
                    }
                }
                if(idx < element.childNodes.length) {
                    element.removeChild(element.childNodes[idx]);
                }
                for(var i = idx - 1; i >= 0; i--) {
                    var node = element.childNodes[i];
                    if(Core.isTextNode(node)) {
                        element.removeChild(node);
                    } else {
                        break;
                    }
                }
            }
            Camel.createFolderXmlTree(treeNode, context[0]);
        }
        return doc;
    }
    Camel.generateXmlFromFolder = generateXmlFromFolder;
})(Camel || (Camel = {}));
var Camel;
(function (Camel) {
    Camel.jmsHeaderSchema = {
        definitions: {
            headers: {
                properties: {
                    JMSCorrelationID: {
                        type: "java.lang.String"
                    },
                    JMSDeliveryMode: {
                        "type": "string",
                        "enum": [
                            "PERSISTENT", 
                            "NON_PERSISTENT"
                        ]
                    },
                    JMSDestination: {
                        type: "javax.jms.Destination"
                    },
                    JMSExpiration: {
                        type: "long"
                    },
                    JMSPriority: {
                        type: "int"
                    },
                    JMSReplyTo: {
                        type: "javax.jms.Destination"
                    },
                    JMSType: {
                        type: "java.lang.String"
                    },
                    JMSXGroupId: {
                        type: "java.lang.String"
                    }
                }
            },
            "javax.jms.Destination": {
                type: "java.lang.String"
            }
        }
    };
})(Camel || (Camel = {}));
var Camel;
(function (Camel) {
    function ProfileRouteController($scope, $location, workspace, jolokia) {
        $scope.data = [];
        $scope.calcManually = true;
        $scope.icons = {
        };
        $scope.selectedRouteId = "";
        var columnDefs = [
            {
                field: 'id',
                displayName: 'Id',
                cellTemplate: '<div class="ngCellText" ng-bind-html-unsafe="rowIcon(row.entity.id)"></div>',
                cellFilter: null,
                width: "*",
                resizable: true
            }, 
            {
                field: 'count',
                displayName: 'Count',
                cellFilter: null,
                width: "*",
                resizable: true
            }, 
            {
                field: 'last',
                displayName: 'Last',
                cellFilter: null,
                width: "*",
                resizable: true
            }, 
            {
                field: 'delta',
                displayName: 'Delta',
                cellFilter: null,
                width: "*",
                resizable: true
            }, 
            {
                field: 'mean',
                displayName: 'Mean',
                cellFilter: null,
                width: "*",
                resizable: true
            }, 
            {
                field: 'min',
                displayName: 'Min',
                cellFilter: null,
                width: "*",
                resizable: true
            }, 
            {
                field: 'max',
                displayName: 'Max',
                cellFilter: null,
                width: "*",
                resizable: true
            }, 
            {
                field: 'total',
                displayName: 'Total',
                cellFilter: null,
                width: "*",
                resizable: true
            }, 
            {
                field: 'self',
                displayName: 'Self',
                cellFilter: null,
                width: "*",
                resizable: true
            }
        ];
        $scope.rowIcon = function (id) {
            var entry = $scope.icons[id];
            if(entry) {
                return entry.img + " " + id;
            } else {
                return id;
            }
        };
        $scope.gridOptions = {
            data: 'data',
            displayFooter: true,
            displaySelectionCheckbox: false,
            canSelectRows: false,
            enableSorting: false,
            columnDefs: columnDefs,
            filterOptions: {
                filterText: ''
            }
        };
        var populateProfileMessages = function (response) {
            var updatedData = [];
            var xml = response.value;
            if(angular.isString(xml)) {
                var doc = $.parseXML(xml);
                var routeMessages = $(doc).find("routeStat");
                routeMessages.each(function (idx, message) {
                    var messageData = {
                        id: {
                        },
                        count: {
                        },
                        last: {
                        },
                        delta: {
                        },
                        mean: {
                        },
                        min: {
                        },
                        max: {
                        },
                        total: {
                        },
                        self: {
                        }
                    };
                    messageData.id = message.getAttribute("id");
                    var total = 0;
                    total += +message.getAttribute("exchangesCompleted");
                    total += +message.getAttribute("exchangesFailed");
                    messageData.count = total;
                    messageData.last = message.getAttribute("lastProcessingTime");
                    var delta = message.getAttribute("deltaProcessingTime");
                    if(delta) {
                        messageData.delta = delta;
                    } else {
                        messageData.delta = 0;
                    }
                    messageData.mean = message.getAttribute("meanProcessingTime");
                    messageData.min = message.getAttribute("minProcessingTime");
                    messageData.max = message.getAttribute("maxProcessingTime");
                    messageData.total = message.getAttribute("totalProcessingTime");
                    var self = message.getAttribute("selfProcessingTime");
                    if(self) {
                        messageData.self = self;
                    } else {
                        $scope.calcManually = true;
                        messageData.self = "0";
                    }
                    updatedData.push(messageData);
                });
                var processorMessages = $(doc).find("processorStat");
                processorMessages.each(function (idx, message) {
                    var messageData = {
                        id: {
                        },
                        count: {
                        },
                        last: {
                        },
                        delta: {
                        },
                        mean: {
                        },
                        min: {
                        },
                        max: {
                        },
                        total: {
                        },
                        self: {
                        }
                    };
                    messageData.id = message.getAttribute("id");
                    var total = 0;
                    total += +message.getAttribute("exchangesCompleted");
                    total += +message.getAttribute("exchangesFailed");
                    messageData.count = total;
                    messageData.last = message.getAttribute("lastProcessingTime");
                    var delta = message.getAttribute("deltaProcessingTime");
                    if(delta) {
                        messageData.delta = delta;
                    } else {
                        messageData.delta = 0;
                    }
                    messageData.mean = message.getAttribute("meanProcessingTime");
                    messageData.min = message.getAttribute("minProcessingTime");
                    messageData.max = message.getAttribute("maxProcessingTime");
                    var total = message.getAttribute("accumulatedProcessingTime");
                    if(total) {
                        messageData.total = total;
                    } else {
                        messageData.total = "0";
                    }
                    messageData.self = message.getAttribute("totalProcessingTime");
                    updatedData.push(messageData);
                });
            }
            if($scope.calcManually) {
                updatedData.sort(function (e1, e2) {
                    var entry1 = $scope.icons[e1.id];
                    var entry2 = $scope.icons[e2.id];
                    if(entry1 && entry2) {
                        return entry1.index - entry2.index;
                    } else {
                        return 0;
                    }
                });
                var accTotal = 0;
                updatedData.reverse().forEach(function (data, idx) {
                    if(idx < updatedData.length - 1) {
                        accTotal += +data.self;
                        data.total = accTotal;
                    } else {
                        data.self = +(data.total - accTotal);
                        if(data.self < 0) {
                            data.self = 0;
                        }
                    }
                });
                updatedData.reverse();
            }
            $scope.data = updatedData;
            Core.$apply($scope);
        };
        $scope.onResponse = function (response) {
            loadData();
        };
        $scope.$watch('workspace.tree', function () {
            setTimeout(loadData, 50);
        });
        function initIdToIcon() {
            console.log("initializing id and icons");
            $scope.icons = {
            };
            var routeXml = Core.pathGet(workspace.selection, [
                "routeXmlNode"
            ]);
            if(routeXml) {
                var entry = {
                    img: "",
                    index: 0
                };
                entry.index = -1;
                entry.img = "<img src='app/camel/img/camel_route.png'>";
                $scope.icons[$scope.selectedRouteId] = entry;
                $(routeXml).find('*').each(function (idx, element) {
                    var id = element.getAttribute("id");
                    if(id) {
                        var entry = {
                            img: "",
                            index: 0
                        };
                        entry.index = idx;
                        var icon = Camel.getRouteNodeIcon(element);
                        if(icon) {
                            entry.img = "<img src='" + icon + "'>";
                        } else {
                            entry.img = "";
                        }
                        $scope.icons[id] = entry;
                    }
                });
            }
        }
        function loadData() {
            console.log("Loading Camel route profile data...");
            $scope.selectedRouteId = Camel.getSelectedRouteId(workspace);
            var routeMBean = Camel.getSelectionRouteMBean(workspace, $scope.selectedRouteId);
            console.log("Selected route is " + $scope.selectedRouteId);
            var camelVersion = Camel.getCamelVersion(workspace, jolokia);
            if(camelVersion) {
                console.log("Camel version " + camelVersion);
                camelVersion += "camel-";
                var numbers = Core.parseVersionNumbers(camelVersion);
                if(Core.compareVersionNumberArrays(numbers, [
                    2, 
                    11
                ]) >= 0) {
                    console.log("Camel 2.11 or better detected");
                    $scope.calcManually = false;
                } else {
                    console.log("Camel 2.10 or older detected");
                    $scope.calcManually = true;
                }
            }
            initIdToIcon();
            console.log("Initialized icons, with " + $scope.icons.length + " icons");
            var query = {
                type: 'exec',
                mbean: routeMBean,
                operation: 'dumpRouteStatsAsXml(boolean,boolean)',
                arguments: [
                    false, 
                    true
                ]
            };
            scopeStoreJolokiaHandle($scope, jolokia, jolokia.register(populateProfileMessages, query));
        }
    }
    Camel.ProfileRouteController = ProfileRouteController;
})(Camel || (Camel = {}));
var Camel;
(function (Camel) {
    function PropertiesController($scope, workspace) {
        $scope.viewTemplate = null;
        $scope.schema = _apacheCamelModel;
        $scope.$on("$routeChangeSuccess", function (event, current, previous) {
            setTimeout(updateData, 50);
        });
        $scope.$watch('workspace.selection', function () {
            if(workspace.moveIfViewInvalid()) {
                return;
            }
            updateData();
        });
        function updateData() {
            var routeXmlNode = Camel.getSelectedRouteNode(workspace);
            $scope.nodeData = Camel.getRouteNodeJSON(routeXmlNode);
            if(routeXmlNode) {
                var nodeName = routeXmlNode.nodeName;
                $scope.model = Camel.getCamelSchema(nodeName);
                if($scope.model) {
                    console.log("data is: " + JSON.stringify($scope.nodeData, null, "  "));
                    console.log("model schema is: " + JSON.stringify($scope.model, null, "  "));
                    $scope.viewTemplate = "app/camel/html/nodePropertiesView.html";
                }
            }
        }
    }
    Camel.PropertiesController = PropertiesController;
})(Camel || (Camel = {}));
var Camel;
(function (Camel) {
    function SendMessageController($scope, workspace, localStorage) {
        var LANGUAGE_FORMAT_PREFERENCE = "defaultLanguageFormat";
        var sourceFormat = workspace.getLocalStorage(LANGUAGE_FORMAT_PREFERENCE) || "javascript";
        $scope.message = "";
        $scope.codeMirror = undefined;
        var options = {
            mode: {
                name: sourceFormat
            },
            onChange: function (codeMirror) {
                if(!$scope.codeMirror) {
                    $scope.codeMirror = codeMirror;
                }
            }
        };
        $scope.codeMirrorOptions = CodeEditor.createEditorSettings(options);
        $scope.headers = [];
        $scope.addHeader = function () {
            $scope.headers.push({
                name: "",
                value: ""
            });
        };
        $scope.addHeader();
        $scope.removeHeader = function (header) {
            $scope.headers = $scope.headers.remove(header);
        };
        $scope.defaultHeaderNames = function () {
            var answer = [];
            function addHeaderSchema(schema) {
                angular.forEach(schema.definitions.headers.properties, function (value, name) {
                    answer.push(name);
                });
            }
            if(isJmsEndpoint()) {
                addHeaderSchema(Camel.jmsHeaderSchema);
            }
            if(isCamelEndpoint()) {
                addHeaderSchema(Camel.camelHeaderSchema);
            }
            return answer;
        };
        $scope.$watch('workspace.selection', function () {
            workspace.moveIfViewInvalid();
        });
        $scope.$watch('codeMirrorOptions.mode.name', function (newValue, oldValue) {
            workspace.setLocalStorage(LANGUAGE_FORMAT_PREFERENCE, newValue);
        });
        var sendWorked = function () {
            $scope.message = "";
            notification("success", "Message sent!");
        };
        $scope.autoFormat = function () {
            setTimeout(function () {
                CodeEditor.autoFormatEditor($scope.codeMirror);
            }, 50);
        };
        $scope.sendMessage = function () {
            var body = $scope.message;
            var selection = workspace.selection;
            if(selection) {
                var mbean = selection.objectName;
                if(mbean) {
                    var headers = null;
                    if($scope.headers.length) {
                        headers = {
                        };
                        angular.forEach($scope.headers, function (object) {
                            var key = object.name;
                            if(key) {
                                headers[key] = object.value;
                            }
                        });
                        console.log("About to send headers: " + JSON.stringify(headers));
                    }
                    var jolokia = workspace.jolokia;
                    var callback = onSuccess(sendWorked);
                    if(selection.domain === "org.apache.camel") {
                        var uri = selection.title.replace("\\?", "?");
                        mbean = Camel.getSelectionCamelContextMBean(workspace);
                        if(mbean) {
                            if(headers) {
                                jolokia.execute(mbean, "sendBodyAndHeaders(java.lang.String, java.lang.Object, java.util.Map)", uri, body, headers, callback);
                            } else {
                                jolokia.execute(mbean, "sendStringBody(java.lang.String, java.lang.String)", uri, body, callback);
                            }
                        } else {
                            notification("error", "Could not find CamelContext MBean!");
                        }
                    } else {
                        var user = localStorage["activemqUserName"];
                        var pwd = localStorage["activemqPassword"];
                        if(headers) {
                            jolokia.execute(mbean, "sendTextMessage(java.util.Map, java.lang.String, java.lang.String, java.lang.String)", headers, body, user, pwd, callback);
                        } else {
                            jolokia.execute(mbean, "sendTextMessage(java.lang.String, java.lang.String, java.lang.String)", body, user, pwd, callback);
                        }
                    }
                }
            }
        };
        function isCamelEndpoint() {
            return true;
        }
        function isJmsEndpoint() {
            return true;
        }
    }
    Camel.SendMessageController = SendMessageController;
})(Camel || (Camel = {}));
var Camel;
(function (Camel) {
    function SourceController($scope, workspace) {
        $scope.$on("$routeChangeSuccess", function (event, current, previous) {
            setTimeout(updateRoutes, 50);
        });
        $scope.$watch('workspace.selection', function () {
            if(workspace.moveIfViewInvalid()) {
                return;
            }
            updateRoutes();
        });
        var options = {
            mode: {
                name: 'xml'
            }
        };
        $scope.codeMirrorOptions = CodeEditor.createEditorSettings(options);
        function updateRoutes() {
            var routeXmlNode = Camel.getSelectedRouteNode(workspace);
            $scope.mbean = Camel.getSelectionCamelContextMBean(workspace);
            if(routeXmlNode) {
                $scope.source = Core.xmlNodeToString(routeXmlNode);
                Core.$apply($scope);
            } else {
                if($scope.mbean) {
                    var jolokia = workspace.jolokia;
                    jolokia.request({
                        type: 'exec',
                        mbean: $scope.mbean,
                        operation: 'dumpRoutesAsXml()'
                    }, onSuccess(populateTable));
                }
            }
        }
        var populateTable = function (response) {
            var data = response.value;
            var selectedRouteId = Camel.getSelectedRouteId(workspace);
            if(data && selectedRouteId) {
                var doc = $.parseXML(data);
                var routes = $(doc).find('route[id="' + selectedRouteId + '"]');
                if(routes && routes.length) {
                    var selectedRoute = routes[0];
                    var routeXml = Core.xmlNodeToString(selectedRoute);
                    if(routeXml) {
                        data = routeXml;
                    }
                }
            }
            $scope.source = data;
            $scope.$apply();
        };
        var saveWorked = function () {
            notification("success", "Route updated!");
            Camel.clearSelectedRouteNode(workspace);
            updateRoutes();
        };
        $scope.saveRouteXml = function () {
            var routeXml = $scope.source;
            if(routeXml) {
                var jolokia = workspace.jolokia;
                var mbean = Camel.getSelectionCamelContextMBean(workspace);
                if(mbean) {
                    jolokia.execute(mbean, "addOrUpdateRoutesFromXml(java.lang.String)", routeXml, onSuccess(saveWorked));
                } else {
                    notification("error", "Could not find CamelContext MBean!");
                }
            }
        };
    }
    Camel.SourceController = SourceController;
})(Camel || (Camel = {}));
var Camel;
(function (Camel) {
    function TraceRouteController($scope, workspace, jolokia) {
        $scope.tracing = false;
        $scope.messages = [];
        $scope.graphView = null;
        $scope.tableView = null;
        $scope.mode = 'text';
        $scope.messageDialog = new Core.Dialog();
        $scope.gridOptions = Camel.createBrowseGridOptions();
        $scope.gridOptions.selectWithCheckboxOnly = false;
        $scope.gridOptions.showSelectionCheckbox = false;
        $scope.gridOptions.afterSelectionChange = onSelectionChanged;
        $scope.gridOptions.columnDefs.push({
            field: 'toNode',
            displayName: 'To Node'
        });
        $scope.startTracing = function () {
            setTracing(true);
        };
        $scope.stopTracing = function () {
            setTracing(false);
        };
        $scope.$watch('workspace.selection', function () {
            if(workspace.moveIfViewInvalid()) {
                return;
            }
            $scope.messages = [];
            reloadTracingFlag();
        });
        $scope.openMessageDialog = function (message) {
            var idx = Core.pathGet(message, [
                "rowIndex"
            ]);
            $scope.selectRowIndex(idx);
            if($scope.row) {
                $scope.mode = CodeEditor.detectTextFormat($scope.row.body);
                $scope.messageDialog.open();
            }
        };
        $scope.selectRowIndex = function (idx) {
            $scope.rowIndex = idx;
            var selected = $scope.gridOptions.selectedItems;
            selected.splice(0, selected.length);
            if(idx >= 0 && idx < $scope.messages.length) {
                $scope.row = $scope.messages[idx];
                if($scope.row) {
                    selected.push($scope.row);
                }
            } else {
                $scope.row = null;
            }
            onSelectionChanged();
        };
        function reloadTracingFlag() {
            $scope.tracing = false;
            closeHandle($scope, jolokia);
            var mbean = Camel.getSelectionCamelTraceMBean(workspace);
            if(mbean) {
                $scope.tracing = jolokia.getAttribute(mbean, "Enabled", onSuccess(null));
                if($scope.tracing) {
                    var traceMBean = mbean;
                    if(traceMBean) {
                        var query = {
                            type: 'exec',
                            mbean: traceMBean,
                            operation: 'dumpAllTracedMessagesAsXml'
                        };
                        scopeStoreJolokiaHandle($scope, jolokia, jolokia.register(populateRouteMessages, query));
                    }
                    $scope.graphView = "app/camel/html/routes.html";
                    $scope.tableView = "app/camel/html/browseMessages.html";
                } else {
                    $scope.messages = [];
                    $scope.graphView = null;
                    $scope.tableView = null;
                }
                console.log("Tracing is now " + $scope.tracing);
            }
        }
        function populateRouteMessages(response) {
            var first = $scope.messages.length === 0;
            var xml = response.value;
            if(angular.isString(xml)) {
                var doc = $.parseXML(xml);
                var allMessages = $(doc).find("fabricTracerEventMessage");
                if(!allMessages || !allMessages.length) {
                    allMessages = $(doc).find("backlogTracerEventMessage");
                }
                allMessages.each(function (idx, message) {
                    var messageData = Camel.createMessageFromXml(message);
                    var toNode = $(message).find("toNode").text();
                    if(toNode) {
                        messageData["toNode"] = toNode;
                    }
                    $scope.messages.push(messageData);
                    Core.$apply($scope);
                });
            }
        }
        function onSelectionChanged() {
            angular.forEach($scope.gridOptions.selectedItems, function (selected) {
                if(selected) {
                    var toNode = selected["toNode"];
                    if(toNode) {
                        var nodes = d3.select("svg").selectAll("g .node");
                        nodes.attr("class", "node");
                        nodes.filter(function (item) {
                            if(item) {
                                var cid = item["cid"];
                                var rid = item["rid"];
                                if(cid) {
                                    return toNode === cid;
                                } else {
                                    return toNode === rid;
                                }
                            }
                            return null;
                        }).attr("class", "node selected");
                    }
                }
            });
        }
        function tracingChanged(response) {
            reloadTracingFlag();
            $scope.$apply();
        }
        function setTracing(flag) {
            var mbean = Camel.getSelectionCamelTraceMBean(workspace);
            if(mbean) {
                jolokia.setAttribute(mbean, "Enabled", flag, onSuccess(tracingChanged));
            }
        }
    }
    Camel.TraceRouteController = TraceRouteController;
})(Camel || (Camel = {}));
var Camel;
(function (Camel) {
    function TreeController($scope, $location, workspace) {
        $scope.$on("$routeChangeSuccess", function (event, current, previous) {
            setTimeout(updateSelectionFromURL, 50);
        });
        $scope.$watch('workspace.tree', function () {
            reloadFunction();
        });
        $scope.$on('jmxTreeUpdated', function () {
            reloadFunction();
        });
        function reloadFunction() {
            console.log("reloading the camel tree!!!");
            var children = [];
            var domainName = "org.apache.camel";
            var tree = workspace.tree;
            if(tree) {
                var rootFolder = new Folder("Camel Contexts");
                rootFolder.addClass = "org-apache-camel-context-folder";
                rootFolder.children = children;
                rootFolder.typeName = "context";
                rootFolder.key = "camelContexts";
                rootFolder.domain = domainName;
                var folder = tree.get(domainName);
                if(folder) {
                    angular.forEach(folder.children, function (value, key) {
                        var entries = value.map;
                        if(entries) {
                            var contextsFolder = entries["context"];
                            var routesNode = entries["routes"];
                            var endpointsNode = entries["endpoints"];
                            if(contextsFolder) {
                                var contextNode = contextsFolder.children[0];
                                if(contextNode) {
                                    var folder = new Folder(contextNode.title);
                                    folder.addClass = "org-apache-camel-context";
                                    folder.domain = domainName;
                                    folder.objectName = contextNode.objectName;
                                    folder.entries = contextNode.entries;
                                    folder.typeName = contextNode.typeName;
                                    folder.key = contextNode.key;
                                    if(routesNode) {
                                        var routesFolder = new Folder("Routes");
                                        routesFolder.addClass = "org-apache-camel-routes-folder";
                                        routesFolder.children = routesNode.children;
                                        angular.forEach(routesFolder.children, function (n) {
                                            return n.addClass = "org-apache-camel-routes";
                                        });
                                        folder.children.push(routesFolder);
                                        routesFolder.typeName = "routes";
                                        routesFolder.key = routesNode.key;
                                        routesFolder.domain = routesNode.domain;
                                    }
                                    if(endpointsNode) {
                                        var endpointsFolder = new Folder("Endpoints");
                                        endpointsFolder.addClass = "org-apache-camel-endpoints-folder";
                                        endpointsFolder.children = endpointsNode.children;
                                        angular.forEach(endpointsFolder.children, function (n) {
                                            n.addClass = "org-apache-camel-endpoints";
                                            if(!Camel.getContextId(n)) {
                                                n.entries["context"] = contextNode.entries["context"];
                                            }
                                        });
                                        folder.children.push(endpointsFolder);
                                        endpointsFolder.entries = contextNode.entries;
                                        endpointsFolder.typeName = "endpoints";
                                        endpointsFolder.key = endpointsNode.key;
                                        endpointsFolder.domain = endpointsNode.domain;
                                    }
                                    var jmxNode = new Folder("MBeans");
                                    angular.forEach(entries, function (jmxChild, name) {
                                        if(name !== "context" && name !== "routes" && name !== "endpoints") {
                                            jmxNode.children.push(jmxChild);
                                        }
                                    });
                                    if(jmxNode.children.length > 0) {
                                        jmxNode.sortChildren(false);
                                        folder.children.push(jmxNode);
                                    }
                                    folder.parent = rootFolder;
                                    children.push(folder);
                                }
                            }
                        }
                    });
                }
                var treeElement = $("#cameltree");
                Jmx.enableTree($scope, $location, workspace, treeElement, [
                    rootFolder
                ], true);
                setTimeout(updateSelectionFromURL, 50);
            }
        }
        function updateSelectionFromURL() {
            Jmx.updateTreeSelectionFromURL($location, $("#cameltree"), true);
        }
    }
    Camel.TreeController = TreeController;
})(Camel || (Camel = {}));
var Core;
(function (Core) {
    function AppController($scope, $location, workspace, $document, pageTitle, localStorage) {
        $scope.collapse = '';
        $scope.match = null;
        $scope.pageTitle = pageTitle.exclude('hawtio');
        $scope.setPageTitle = function () {
            var tab = workspace.getActiveTab();
            if(tab && tab.content) {
                var foo = Array;
                Core.setPageTitle($document, foo.create(pageTitle, tab.content));
            } else {
                Core.setPageTitle($document, pageTitle);
            }
        };
        $scope.setRegexIndicator = function () {
            try  {
                var regexs = angular.fromJson(localStorage['regexs']);
                if(regexs) {
                    regexs.reverse().each(function (regex) {
                        var r = new RegExp(regex.regex, 'g');
                        if(r.test($location.absUrl())) {
                            $scope.match = {
                                name: regex.name,
                                color: regex.color
                            };
                        }
                    });
                }
            } catch (e) {
            }
        };
        $scope.$watch(function () {
            return localStorage['regexs'];
        }, $scope.setRegexIndicator);
        $scope.$on('$routeChangeSuccess', function () {
            $scope.setPageTitle();
            $scope.setRegexIndicator();
        });
        $scope.fullScreen = function () {
            var tab = $location.search()['tab'];
            if(tab) {
                return tab === "fullscreen";
            }
            return false;
        };
    }
    Core.AppController = AppController;
})(Core || (Core = {}));
var CodeEditor;
(function (CodeEditor) {
    var GlobalCodeMirrorOptions = {
        theme: "default",
        tabSize: 4,
        lineNumbers: true,
        indentWithTabs: true,
        lineWrapping: true,
        autoCloseTags: true
    };
    function PreferencesController($scope, workspace, localStorage) {
        $scope.preferences = GlobalCodeMirrorOptions;
        $scope.$watch("preferences", function (newValue, oldValue) {
        });
    }
    CodeEditor.PreferencesController = PreferencesController;
    function detectTextFormat(value) {
        var answer = "text";
        if(value) {
            answer = "javascript";
            var trimmed = value.toString().trimLeft().trimRight();
            if(trimmed && trimmed.first() === '<' && trimmed.last() === '>') {
                answer = "xml";
            }
        }
        return answer;
    }
    CodeEditor.detectTextFormat = detectTextFormat;
    function autoFormatEditor(editor) {
        if(editor) {
            var totalLines = editor.lineCount();
            var start = {
                line: 0,
                ch: 0
            };
            var end = {
                line: totalLines - 1,
                ch: editor.getLine(totalLines - 1).length
            };
            editor.autoFormatRange(start, end);
            editor.setSelection(start, start);
        }
    }
    CodeEditor.autoFormatEditor = autoFormatEditor;
    function createEditorSettings(options) {
        if (typeof options === "undefined") { options = {
        }; }
        options.extraKeys = options.extraKeys || {
        };
        (function (mode) {
            mode = mode || {
                name: "text"
            };
            if(typeof mode !== "object") {
                mode = {
                    name: mode
                };
            }
            var modeName = mode.name;
            if(modeName === "javascript") {
                angular.extend(mode, {
                    "json": true
                });
            }
        })(options.mode);
        (function (options) {
            var javascriptFolding = CodeMirror.newFoldFunction(CodeMirror.braceRangeFinder);
            var xmlFolding = CodeMirror.newFoldFunction(CodeMirror.tagRangeFinder);
            var foldFunction = function (codeMirror, line) {
                var mode = codeMirror.getOption("mode");
                var modeName = mode["name"];
                if(!mode || !modeName) {
                    return;
                }
                if(modeName === 'javascript') {
                    javascriptFolding(codeMirror, line);
                } else {
                    if(modeName === "xml" || modeName.startsWith("html")) {
                        xmlFolding(codeMirror, line);
                    }
                }
                ; ;
            };
            options.onGutterClick = foldFunction;
            options.extraKeys = angular.extend(options.extraKeys, {
                "Ctrl-Q": function (codeMirror) {
                    foldFunction(codeMirror, codeMirror.getCursor().line);
                }
            });
        })(options);
        var readOnly = options.readOnly;
        if(!readOnly) {
            options.matchBrackets = true;
        }
        angular.extend(options, GlobalCodeMirrorOptions);
        return options;
    }
    CodeEditor.createEditorSettings = createEditorSettings;
})(CodeEditor || (CodeEditor = {}));
var jolokiaUrls = [
    "/" + window.location.pathname.split('/')[1] + "/jolokia", 
    "/hawtio/jolokia", 
    "/jolokia"
];
var jolokiaUrl = getJolokiaUrl();
console.log("jolokiaUrl " + jolokiaUrl);
function getJolokiaUrl() {
    var query = hawtioPluginLoader.parseQueryString();
    var uri = query['url'];
    if(angular.isArray(uri)) {
        uri = uri[0];
    }
    return uri ? decodeURIComponent(uri) : null;
}
if(!jolokiaUrl) {
    jolokiaUrl = jolokiaUrls.find(function (url) {
        var jqxhr = $.ajax(url, {
            async: false
        });
        return jqxhr.status === 200;
    });
}
if(jolokiaUrl) {
}
hawtioPluginLoader.addUrl('/hawtio/test.json');
hawtioPluginLoader.addModule('hawtioCore');
angular.module('hawtioCore', [
    'bootstrap', 
    'ngResource', 
    'ui', 
    'ui.bootstrap.dialog'
]).config(function ($routeProvider, $dialogProvider) {
    $dialogProvider.options({
        backdropFade: true,
        dialogFade: true
    });
    $routeProvider.when('/preferences', {
        templateUrl: 'app/core/html/preferences.html'
    }).when('/help', {
        redirectTo: '/help/overview'
    }).when('/help/:topic/', {
        templateUrl: 'app/core/html/help.html'
    }).when('/help/:topic/:subtopic', {
        templateUrl: 'app/core/html/help.html'
    }).otherwise({
        redirectTo: '/help/overview'
    });
}).constant('layoutTree', 'app/core/html/layoutTree.html').constant('layoutFull', 'app/core/html/layoutFull.html').constant('editablePropertyTemplate', '<div ng-mouseenter="showEdit()" ng-mouseleave="hideEdit()" class="ep" ng-hide="editing">' + '{{text}}&nbsp;<i class="ep-edit icon-pencil" title="Edit this item" ng-click="doEdit()"></i>' + '</div>' + '<div class="ep" ng-show="editing">' + '<form class="form-inline no-bottom-margin" ng-submit="saveEdit()">' + '<fieldset>' + '<input type="text" value="{{text}}">' + '<i class="green icon-ok" title="Save changes" ng-click="saveEdit()"></i>' + '<i class="red icon-remove" title="Discard changes" ng-click="stopEdit()"></i>' + '</fieldset>' + '</form>' + '</div>').service('localStorage', function () {
    var storage = window.localStorage || (function () {
        return {
        };
    })();
    return storage;
}).factory('marked', function () {
    marked.setOptions({
        gfm: true,
        tables: true,
        breaks: false,
        pedantic: true,
        sanitize: false,
        smartLists: true,
        langPrefix: 'language-'
    });
    return marked;
}).factory('pageTitle', function () {
    return [
        'hawtio'
    ];
}).factory('viewRegistry', function () {
    return {
    };
}).factory('helpRegistry', function ($rootScope) {
    return new Core.HelpRegistry($rootScope);
}).factory('jolokia', function ($location, localStorage) {
    var _this = this;
    if(jolokiaUrl) {
        var jolokiaParams = {
            url: jolokiaUrl,
            canonicalNaming: false,
            ignoreErrors: true,
            mimeType: 'application/json'
        };
        var credentials = hawtioPluginLoader.getCredentials(jolokiaUrl);
        var username = null;
        var password = null;
        if(credentials.length === 2) {
            username = credentials[0];
            password = credentials[1];
        } else {
            var search = hawtioPluginLoader.parseQueryString();
            username = search["_user"];
            password = search["_pwd"];
            if(angular.isArray(username)) {
                username = username[0];
            }
            if(angular.isArray(password)) {
                password = password[0];
            }
        }
        if(username && password) {
            jolokiaParams['username'] = username;
            jolokiaParams['password'] = password;
            console.log("Using user / pwd " + username + " / " + password);
        }
        var jolokia = new Jolokia(jolokiaParams);
        localStorage['url'] = jolokiaUrl;
        return jolokia;
    } else {
        return {
            request: function () {
                return null;
            },
            register: function () {
                return null;
            },
            list: function () {
                return null;
            },
            search: function () {
                return null;
            },
            read: function () {
                return null;
            },
            execute: function () {
                return null;
            },
            start: function () {
                _this.running = true;
                return null;
            },
            stop: function () {
                _this.running = false;
                return null;
            },
            isRunning: function () {
                return _this.running;
            },
            jobs: function () {
                return [];
            }
        };
    }
}).factory('toastr', function ($window) {
    return $window.toastr;
}).factory('workspace', function ($location, jmxTreeLazyLoadRegistry, $compile, $templateCache, localStorage, jolokia, $rootScope) {
    var answer = new Workspace(jolokia, jmxTreeLazyLoadRegistry, $location, $compile, $templateCache, localStorage, $rootScope);
    answer.loadTree();
    return answer;
}).filter("valueToHtml", function () {
    return Core.valueToHtml;
}).filter('humanize', function () {
    return humanizeValue;
}).run(function ($rootScope, $routeParams, jolokia, workspace, localStorage, viewRegistry, layoutFull, helpRegistry) {
    $.support.cors = true;
    $rootScope.lineCount = lineCount;
    $rootScope.params = $routeParams;
    $rootScope.is = function (type, value) {
        return angular['is' + type](value);
    };
    $rootScope.empty = function (value) {
        return $.isEmptyObject(value);
    };
    var updateRate = localStorage['updateRate'];
    if(angular.isUndefined(updateRate)) {
        localStorage['updateRate'] = 5000;
    }
    $rootScope.$on('UpdateRate', function (event, rate) {
        jolokia.stop();
        if(rate > 0) {
            jolokia.start(rate);
        }
        console.log("Set update rate to: " + rate);
    });
    $rootScope.$emit('UpdateRate', localStorage['updateRate']);
    $rootScope.log = function (variable) {
        console.log(variable);
    };
    $rootScope.alert = function (text) {
        alert(text);
    };
    viewRegistry['fullscreen'] = layoutFull;
    viewRegistry['notree'] = layoutFull;
    viewRegistry['help'] = layoutFull;
    viewRegistry['preferences'] = layoutFull;
    helpRegistry.addUserDoc('overview', 'app/core/doc/overview.md');
    helpRegistry.addSubTopic('overview', 'faq', 'app/core/doc/faq.md');
    helpRegistry.discoverHelpFiles(hawtioPluginLoader.getModules());
}).directive('expandable', function () {
    return {
        restrict: 'C',
        replace: false,
        link: function (scope, element, attrs) {
            var expandable = $(element);
            var title = expandable.find('.title');
            var button = expandable.find('.cancel');
            button.bind('click', function () {
                expandable.find('.expandable-body').slideUp(400, function () {
                    expandable.addClass('closed');
                    expandable.removeClass('opened');
                });
                return false;
            });
            title.bind('click', function () {
                if(expandable.hasClass('opened')) {
                    expandable.find('.expandable-body').slideUp(400, function () {
                        expandable.toggleClass('opened');
                        expandable.toggleClass('closed');
                    });
                } else {
                    expandable.find('.expandable-body').slideDown(400, function () {
                        expandable.toggleClass('opened');
                        expandable.toggleClass('closed');
                    });
                }
                return false;
            });
        }
    };
}).directive('editableProperty', [
    '$compile', 
    'editablePropertyTemplate', 
    function ($compile, editablePropertyTemplate) {
        var editableProperty = {
            restrict: 'E',
            scope: true,
            template: editablePropertyTemplate,
            require: 'ngModel',
            link: function (scope, element, attrs, ngModel) {
                scope.editing = false;
                $(element.find(".icon-pencil")[0]).hide();
                ngModel.$render = function () {
                    scope.text = ngModel.$viewValue[attrs['property']];
                };
                scope.showEdit = function () {
                    $(element.find(".icon-pencil")[0]).show();
                };
                scope.hideEdit = function () {
                    $(element.find(".icon-pencil")[0]).hide();
                };
                scope.doEdit = function () {
                    scope.editing = true;
                };
                scope.stopEdit = function () {
                    scope.editing = false;
                };
                scope.saveEdit = function () {
                    var value = $(element.find(":input[type=text]")[0]).val();
                    var obj = ngModel.$viewValue;
                    obj[attrs['property']] = value;
                    ngModel.$setViewValue(obj);
                    ngModel.$render();
                    scope.editing = false;
                    scope.$parent.$eval(attrs['onSave']);
                };
            }
        };
        return editableProperty;
    }]).directive('gridStyle', function ($window) {
    return new Core.GridStyle($window);
});
$(function () {
    $("a[title]").tooltip({
        selector: '',
        delay: {
            show: 1000,
            hide: 100
        }
    });
});
var adjustHeight = function () {
    var windowHeight = $(window).height();
    var headerHeight = $("#main-nav").height();
    var containerHeight = windowHeight - headerHeight;
    $("#main").css("min-height", "" + containerHeight + "px");
};
$(function () {
    hawtioPluginLoader.loadPlugins(function () {
        var doc = $(document);
        angular.bootstrap(doc, hawtioPluginLoader.getModules());
        $(document.documentElement).attr('xmlns:ng', "http://angularjs.org");
        $(document.documentElement).attr('ng-app', 'hawtioCore');
        adjustHeight();
        $(window).resize(adjustHeight);
    });
});
var Core;
(function (Core) {
    var Dialog = (function () {
        function Dialog() {
            this.show = false;
            this.options = {
                backdropFade: true,
                dialogFade: true
            };
        }
        Dialog.prototype.open = function () {
            this.show = true;
        };
        Dialog.prototype.close = function () {
            this.show = false;
        };
        return Dialog;
    })();
    Core.Dialog = Dialog;    
})(Core || (Core = {}));
var Core;
(function (Core) {
    function EditorController($scope, workspace) {
        var options = {
            readOnly: true,
            mode: {
                name: CodeEditor.detectTextFormat($scope.row.Text)
            }
        };
        $scope.codeMirrorOptions = CodeEditor.createEditorSettings(options);
    }
    Core.EditorController = EditorController;
})(Core || (Core = {}));
var Folder = (function () {
    function Folder(title) {
        this.title = title;
        this.key = null;
        this.typeName = null;
        this.children = [];
        this.folderNames = [];
        this.domain = null;
        this.objectName = null;
        this.map = {
        };
        this.entries = {
        };
        this.addClass = null;
        this.parent = null;
        this.isLazy = false;
        this.icon = null;
        this.tooltip = null;
        this.addClass = escapeTreeCssStyles(title);
    }
    Folder.prototype.get = function (key) {
        return this.map[key];
    };
    Folder.prototype.isFolder = function () {
        return this.children.length > 0;
    };
    Folder.prototype.navigate = function () {
        var paths = [];
        for (var _i = 0; _i < (arguments.length - 0); _i++) {
            paths[_i] = arguments[_i + 0];
        }
        var node = this;
        paths.forEach(function (path) {
            if(node) {
                node = node.get(path);
            }
        });
        return node;
    };
    Folder.prototype.hasEntry = function (key, value) {
        var entries = this.entries;
        if(entries) {
            var actual = entries[key];
            return actual && value === actual;
        }
        return false;
    };
    Folder.prototype.parentHasEntry = function (key, value) {
        if(this.parent) {
            return this.parent.hasEntry(key, value);
        }
        return false;
    };
    Folder.prototype.ancestorHasEntry = function (key, value) {
        var parent = this.parent;
        while(parent) {
            if(parent.hasEntry(key, value)) {
                return true;
            }
            parent = parent.parent;
        }
        return false;
    };
    Folder.prototype.ancestorHasType = function (typeName) {
        var parent = this.parent;
        while(parent) {
            if(typeName === parent.typeName) {
                return true;
            }
            parent = parent.parent;
        }
        return false;
    };
    Folder.prototype.getOrElse = function (key, defaultValue) {
        if (typeof defaultValue === "undefined") { defaultValue = new Folder(key); }
        var answer = this.map[key];
        if(!answer) {
            answer = defaultValue;
            this.map[key] = answer;
            this.children.push(answer);
            answer.parent = this;
            this.children = this.children.sortBy("title");
        }
        return answer;
    };
    Folder.prototype.sortChildren = function (recursive) {
        var children = this.children;
        if(children) {
            this.children = children.sortBy("title");
            if(recursive) {
                angular.forEach(children, function (child) {
                    return child.sortChildren(recursive);
                });
            }
        }
    };
    Folder.prototype.moveChild = function (child) {
        if(child && child.parent !== this) {
            child.detach();
            child.parent = this;
            this.children.push(child);
        }
    };
    Folder.prototype.detach = function () {
        var oldParent = this.parent;
        if(oldParent) {
            var oldParentChildren = oldParent.children;
            if(oldParentChildren) {
                var idx = oldParentChildren.indexOf(this);
                if(idx < 0) {
                    oldParent.children = oldParent.children.remove({
                        key: this.key
                    });
                } else {
                    oldParentChildren.splice(idx, 1);
                }
            }
            this.parent = null;
        }
    };
    Folder.prototype.findDescendant = function (filter) {
        if(filter(this)) {
            return this;
        }
        var answer = null;
        angular.forEach(this.children, function (child) {
            if(!answer) {
                answer = child.findDescendant(filter);
            }
        });
        return answer;
    };
    return Folder;
})();
var Core;
(function (Core) {
    function d3ForceGraph(scope, nodes, links, canvasElement) {
        if(scope.graphForce) {
            scope.graphForce.stop();
        }
        if(!canvasElement) {
            canvasElement = $("#canvas")[0];
        }
        var canvasDiv = $(canvasElement);
        canvasDiv.children("svg").remove();
        if(nodes.length) {
            var width = canvasDiv.parent().width();
            var height = canvasDiv.parent().height();
            if(height < 100) {
                var offset = canvasDiv.offset();
                height = $(document).height() - 5;
                if(offset) {
                    height -= offset['top'];
                }
            }
            var svg = d3.select(canvasDiv[0]).append("svg").attr("width", width).attr("height", height);
            var force = d3.layout.force().distance(100).charge(-120 * 10).linkDistance(50).size([
                width, 
                height
            ]);
            scope.graphForce = force;
            svg.append("svg:defs").selectAll("marker").data([
                "from"
            ]).enter().append("svg:marker").attr("id", String).attr("viewBox", "0 -5 10 10").attr("refX", 25).attr("refY", -1.5).attr("markerWidth", 6).attr("markerHeight", 6).attr("orient", "auto").append("svg:path").attr("d", "M0,-5L10,0L0,5");
            force.nodes(nodes).links(links).start();
            var link = svg.selectAll(".link").data(links).enter().append("line").attr("class", "link");
            link.attr("class", "link from");
            link.attr("marker-end", "url(#from)");
            var node = svg.selectAll(".node").data(nodes).enter().append("g").attr("class", "node").call(force.drag);
            node.append("image").attr("xlink:href", function (d) {
                return d.imageUrl;
            }).attr("x", -15).attr("y", -15).attr("width", 30).attr("height", 30);
            node.append("text").attr("dx", 20).attr("dy", ".35em").text(function (d) {
                return d.label;
            });
            force.on("tick", function () {
                link.attr("x1", function (d) {
                    return d.source.x;
                }).attr("y1", function (d) {
                    return d.source.y;
                }).attr("x2", function (d) {
                    return d.target.x;
                }).attr("y2", function (d) {
                    return d.target.y;
                });
                node.attr("transform", function (d) {
                    return "translate(" + d.x + "," + d.y + ")";
                });
            });
        }
    }
    Core.d3ForceGraph = d3ForceGraph;
    function createGraphStates(nodes, links, transitions) {
        var stateKeys = {
        };
        nodes.forEach(function (node) {
            var idx = node.id;
            if(idx === undefined) {
                console.log("No node found for node " + JSON.stringify(node));
            } else {
                if(node.edges === undefined) {
                    node.edges = [];
                }
                if(!node.label) {
                    node.label = "node " + idx;
                }
                stateKeys[idx] = node;
            }
        });
        var states = d3.values(stateKeys);
        links.forEach(function (d) {
            var source = stateKeys[d.source];
            var target = stateKeys[d.target];
            if(source === undefined || target === undefined) {
                console.log("Bad link!  " + source + " target " + target + " for " + d);
            } else {
                var edge = {
                    source: source,
                    target: target
                };
                transitions.push(edge);
                source.edges.push(edge);
                target.edges.push(edge);
            }
        });
        return states;
    }
    Core.createGraphStates = createGraphStates;
    function dagreLayoutGraph(nodes, links, width, height, svgElement) {
        var nodePadding = 10;
        var transitions = [];
        var states = Core.createGraphStates(nodes, links, transitions);
        function spline(e) {
            var points = e.dagre.points.slice(0);
            var source = dagre.util.intersectRect(e.source.dagre, points.length > 0 ? points[0] : e.source.dagre);
            var target = dagre.util.intersectRect(e.target.dagre, points.length > 0 ? points[points.length - 1] : e.source.dagre);
            points.unshift(source);
            points.push(target);
            return d3.svg.line().x(function (d) {
                return d.x;
            }).y(function (d) {
                return d.y;
            }).interpolate("linear")(points);
        }
        function translateEdge(e, dx, dy) {
            e.dagre.points.forEach(function (p) {
                p.x = Math.max(0, Math.min(svgBBox.width, p.x + dx));
                p.y = Math.max(0, Math.min(svgBBox.height, p.y + dy));
            });
        }
        var svg = svgElement ? d3.select(svgElement) : d3.select("svg");
        if(svgElement) {
            $(svgElement).children("g").remove();
        }
        $(svg).children("g").remove();
        var svgGroup = svg.append("g").attr("transform", "translate(5, 5)");
        var nodes = svgGroup.selectAll("g .node").data(states).enter().append("g").attr("class", "node").attr("data-cid", function (d) {
            return d.cid;
        }).attr("id", function (d) {
            return "node-" + d.label;
        });
        nodes.append("title").text(function (d) {
            return d.tooltip || "";
        });
        var edges = svgGroup.selectAll("path .edge").data(transitions).enter().append("path").attr("class", "edge").attr("marker-end", "url(#arrowhead)");
        var rects = nodes.append("rect").attr("rx", "5").attr("ry", "5").attr("filter", "url(#drop-shadow)");
        var images = nodes.append("image").attr("xlink:href", function (d) {
            return d.imageUrl;
        }).attr("x", -12).attr("y", -20).attr("height", 24).attr("width", 24);
        var counters = nodes.append("text").attr("text-anchor", "end").attr("class", "counter").attr("x", 0).attr("dy", 0).text(_counterFunction);
        var labels = nodes.append("text").attr("text-anchor", "middle").attr("x", 0);
        labels.append("tspan").attr("x", 0).attr("dy", 28).text(function (d) {
            return d.label;
        });
        var labelPadding = 12;
        var minLabelwidth = 80;
        labels.each(function (d) {
            var bbox = this.getBBox();
            d.bbox = bbox;
            if(bbox.width < minLabelwidth) {
                bbox.width = minLabelwidth;
            }
            d.width = bbox.width + 2 * nodePadding;
            d.height = bbox.height + 2 * nodePadding + labelPadding;
        });
        rects.attr("x", function (d) {
            return -(d.bbox.width / 2 + nodePadding);
        }).attr("y", function (d) {
            return -(d.bbox.height / 2 + nodePadding + (labelPadding / 2));
        }).attr("width", function (d) {
            return d.width;
        }).attr("height", function (d) {
            return d.height;
        });
        images.attr("x", function (d) {
            return -(d.bbox.width) / 2;
        });
        labels.attr("x", function (d) {
            return -d.bbox.width / 2;
        }).attr("y", function (d) {
            return -d.bbox.height / 2;
        });
        counters.attr("x", function (d) {
            var w = d.bbox.width;
            return w / 2;
        });
        dagre.layout().nodeSep(50).edgeSep(10).rankSep(50).nodes(states).edges(transitions).debugLevel(1).run();
        nodes.attr("transform", function (d) {
            return 'translate(' + d.dagre.x + ',' + d.dagre.y + ')';
        });
        edges.attr('id', function (e) {
            return e.dagre.id;
        }).attr("d", function (e) {
            return spline(e);
        });
        var svgNode = svg.node();
        if(svgNode) {
            var svgBBox = svgNode.getBBox();
            if(svgBBox) {
                svg.attr("width", svgBBox.width + 10);
                svg.attr("height", svgBBox.height + 10);
            }
        }
        var nodeDrag = d3.behavior.drag().origin(function (d) {
            return d.pos ? {
                x: d.pos.x,
                y: d.pos.y
            } : {
                x: d.dagre.x,
                y: d.dagre.y
            };
        }).on('drag', function (d, i) {
            var prevX = d.dagre.x, prevY = d.dagre.y;
            d.dagre.x = Math.max(d.width / 2, Math.min(svgBBox.width - d.width / 2, d3.event.x));
            d.dagre.y = Math.max(d.height / 2, Math.min(svgBBox.height - d.height / 2, d3.event.y));
            d3.select(this).attr('transform', 'translate(' + d.dagre.x + ',' + d.dagre.y + ')');
            var dx = d.dagre.x - prevX, dy = d.dagre.y - prevY;
            d.edges.forEach(function (e) {
                translateEdge(e, dx, dy);
                d3.select('#' + e.dagre.id).attr('d', spline(e));
            });
        });
        var edgeDrag = d3.behavior.drag().on('drag', function (d, i) {
            translateEdge(d, d3.event.dx, d3.event.dy);
            d3.select(this).attr('d', spline(d));
        });
        nodes.call(nodeDrag);
        edges.call(edgeDrag);
        return states;
    }
    Core.dagreLayoutGraph = dagreLayoutGraph;
    function dagreUpdateGraphData(data) {
        var svg = d3.select("svg");
        svg.selectAll("text.counter").text(_counterFunction);
        svg.selectAll("g .node title").text(function (d) {
            return d.tooltip || "";
        });
    }
    Core.dagreUpdateGraphData = dagreUpdateGraphData;
    function _counterFunction(d) {
        return d.counter || "";
    }
})(Core || (Core = {}));
var Core;
(function (Core) {
    var GridStyle = (function () {
        function GridStyle($window) {
            this.$window = $window;
            var _this = this;
            this.restrict = 'C';
            this.link = function (scope, element, attrs) {
                return _this.doLink(scope, element, attrs);
            };
        }
        GridStyle.prototype.doLink = function (scope, element, attrs) {
            var lastHeight = 0;
            var resizeFunc = angular.bind(this, function (scope) {
                var top = element.position().top;
                var windowHeight = $(this.$window).height();
                var height = windowHeight - top - 15;
                var heightStr = height + 'px';
                element.css({
                    'min-height': heightStr,
                    'height': heightStr
                });
                if(lastHeight !== height) {
                    lastHeight = height;
                    element.trigger('resize');
                }
            });
            resizeFunc();
            scope.$watch(resizeFunc);
            $(this.$window).resize(function () {
                resizeFunc();
                Core.$apply(scope);
                return false;
            });
        };
        return GridStyle;
    })();
    Core.GridStyle = GridStyle;    
})(Core || (Core = {}));
var Core;
(function (Core) {
    function HelpController($scope, $routeParams, marked, helpRegistry) {
        $scope.$on('hawtioNewHelpTopic', function () {
            $scope.topics = helpRegistry.getTopics();
        });
        $scope.isTopicActive = function (topic) {
            if(topic === $scope.topic) {
                return true;
            }
            return false;
        };
        $scope.isSubTopicActive = function (topic) {
            if(topic === $scope.subTopic) {
                return true;
            }
            return false;
        };
        $scope.mapTopicName = function (topic) {
            return helpRegistry.mapTopicName(topic);
        };
        $scope.mapSubTopicName = function (topic, subtopic) {
            return helpRegistry.mapSubTopicName(subtopic);
        };
        $scope.topics = helpRegistry.getTopics();
        $scope.topic = $routeParams.topic;
        $scope.subTopic = Object.extended($scope.topics[$scope.topic]).keys().at(0);
        if(angular.isDefined($routeParams.subtopic)) {
            $scope.subTopic = $routeParams.subtopic;
        }
        if(!angular.isDefined($scope.topics[$scope.topic])) {
            $scope.html = "Unable to download help data for " + $scope.topic;
        } else {
            $.ajax({
                url: $scope.topics[$scope.topic][$scope.subTopic],
                dataType: 'html',
                cache: false,
                success: function (data, textStatus, jqXHR) {
                    $scope.html = "Unable to download help data for " + $scope.topic;
                    if(angular.isDefined(data)) {
                        $scope.html = marked(data);
                    }
                    $scope.$apply();
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    $scope.html = "Unable to download help data for " + $scope.topic;
                    $scope.$apply();
                }
            });
        }
    }
    Core.HelpController = HelpController;
})(Core || (Core = {}));
var logQueryMBean = 'org.fusesource.insight:type=LogQuery';
var _urlPrefix = null;
var numberTypeNames = {
    'byte': true,
    'short': true,
    'int': true,
    'long': true,
    'float': true,
    'double': true,
    'java.lang.Byte': true,
    'java.lang.Short': true,
    'java.lang.Integer': true,
    'java.lang.Long': true,
    'java.lang.Float': true,
    'java.lang.Double': true
};
function lineCount(value) {
    var rows = 0;
    if(value) {
        rows = 1;
        value.toString().each(/\n/, function () {
            return rows++;
        });
    }
    return rows;
}
function url(path) {
    if(path) {
        if(path.startsWith && path.startsWith("/")) {
            if(_urlPrefix === null) {
                _urlPrefix = window.location.pathname || "";
                if(_urlPrefix) {
                    var idx = _urlPrefix.lastIndexOf("/");
                    if(idx >= 0) {
                        _urlPrefix = _urlPrefix.substring(0, idx);
                    }
                }
                console.log("URI prefix is " + _urlPrefix);
            }
            return _urlPrefix + path;
        }
    }
    return path;
}
function humanizeValue(value) {
    if(value) {
        var text = value.toString();
        return trimQuotes(text.underscore().humanize());
    }
    return value;
}
function trimQuotes(text) {
    while(text.endsWith('"') || text.endsWith("'")) {
        text = text.substring(0, text.length - 1);
    }
    while(text.startsWith('"') || text.startsWith("'")) {
        text = text.substring(1, text.length);
    }
    return text;
}
function toSearchArgumentArray(value) {
    if(value) {
        if(angular.isArray(value)) {
            return value;
        }
        if(angular.isString(value)) {
            return value.split(',');
        }
    }
    return [];
}
function folderMatchesPatterns(node, patterns) {
    if(node) {
        var folderNames = node.folderNames;
        if(folderNames) {
            return patterns.any(function (ignorePaths) {
                for(var i = 0; i < ignorePaths.length; i++) {
                    var folderName = folderNames[i];
                    var ignorePath = ignorePaths[i];
                    if(!folderName) {
                        return false;
                    }
                    var idx = ignorePath.indexOf(folderName);
                    if(idx < 0) {
                        return false;
                    }
                }
                return true;
            });
        }
    }
    return false;
}
function scopeStoreJolokiaHandle($scope, jolokia, jolokiaHandle) {
    if(jolokiaHandle) {
        $scope.$on('$destroy', function () {
            closeHandle($scope, jolokia);
        });
        $scope.jolokiaHandle = jolokiaHandle;
    }
}
function closeHandle($scope, jolokia) {
    var jolokiaHandle = $scope.jolokiaHandle;
    if(jolokiaHandle) {
        jolokia.unregister(jolokiaHandle);
        $scope.jolokiaHandle = null;
    }
}
function onSuccess(fn, options) {
    if (typeof options === "undefined") { options = {
    }; }
    options['mimeType'] = 'application/json';
    if(angular.isDefined(fn)) {
        options['success'] = fn;
    }
    if(!options['method']) {
        options['method'] = "POST";
    }
    options['canonicalNaming'] = false;
    options['canonicalProperties'] = false;
    if(!options['error']) {
        options['error'] = function (response) {
            var stacktrace = response.stacktrace;
            if(stacktrace) {
                var silent = options['silent'];
                if(!silent) {
                    console.log(stacktrace);
                    if(stacktrace.indexOf("javax.management.InstanceNotFoundException") >= 0 || stacktrace.indexOf("javax.management.AttributeNotFoundException") >= 0 || stacktrace.indexOf(" java.lang.IllegalArgumentException: No operation") >= 0) {
                    } else {
                        notification("error", "Operation failed due to: " + stacktrace);
                        console.log("Jolokia request failed: " + response.error);
                    }
                }
            }
        };
    }
    return options;
}
function supportsLocalStorage() {
    try  {
        return 'localStorage' in window && window['localStorage'] !== null;
    } catch (e) {
        return false;
    }
}
function isNumberTypeName(typeName) {
    if(typeName) {
        var text = typeName.toString().toLowerCase();
        var flag = numberTypeNames[text];
        return flag;
    }
    return false;
}
function encodeMBeanPath(mbean) {
    return mbean.replace(/\//g, '!/').replace(':', '/').escapeURL();
}
function escapeMBeanPath(mbean) {
    return mbean.replace(/\//g, '!/').replace(':', '/');
}
function encodeMBean(mbean) {
    return mbean.replace(/\//g, '!/').escapeURL();
}
function escapeDots(text) {
    return text.replace(/\./g, '-');
}
function escapeTreeCssStyles(text) {
    return escapeDots(text).replace(/span/g, 'sp-an');
}
function notification(type, message) {
    var w = window;
    w.toastr[type](message);
}
function clearNotifications() {
    var w = window;
    w.toastr.clear();
}
function logLevelClass(level) {
    if(level) {
        var first = level[0];
        if(first === 'w' || first === "W") {
            return "warning";
        } else {
            if(first === 'e' || first === "E") {
                return "error";
            } else {
                if(first === 'd' || first === "d") {
                    return "info";
                }
            }
        }
    }
    return "";
}
if(!Object.keys) {
    Object.keys = function (obj) {
        var keys = [], k;
        for(k in obj) {
            if(Object.prototype.hasOwnProperty.call(obj, k)) {
                keys.push(k);
            }
        }
        return keys;
    };
}
var Core;
(function (Core) {
    function createHref($location, href, removeParams) {
        if (typeof removeParams === "undefined") { removeParams = null; }
        var hashMap = angular.copy($location.search());
        if(removeParams) {
            angular.forEach(removeParams, function (param) {
                return delete hashMap[param];
            });
        }
        var hash = Core.hashToString(hashMap);
        if(hash) {
            var prefix = (href.indexOf("?") >= 0) ? "&" : "?";
            href += prefix + hash;
        }
        return href;
    }
    Core.createHref = createHref;
    function trimLeading(text, prefix) {
        if(text && prefix) {
            if(text.startsWith(prefix)) {
                return text.substring(prefix.length);
            }
        }
        return text;
    }
    Core.trimLeading = trimLeading;
    function trimTrailing(text, postfix) {
        if(text && postfix) {
            if(text.endsWith(postfix)) {
                return text.substring(0, text.length - postfix.length);
            }
        }
        return text;
    }
    Core.trimTrailing = trimTrailing;
    function hashToString(hash) {
        var keyValuePairs = [];
        angular.forEach(hash, function (value, key) {
            keyValuePairs.push(key + "=" + value);
        });
        var params = keyValuePairs.join("&");
        return encodeURI(params);
    }
    Core.hashToString = hashToString;
    function register(jolokia, scope, arguments, callback) {
        if(!angular.isDefined(scope.$jhandle) || !angular.isArray(scope.$jhandle)) {
            scope.$jhandle = [];
        }
        if(angular.isDefined(scope.$on)) {
            scope.$on('$destroy', function (event) {
                unregister(jolokia, scope);
            });
        }
        if(angular.isArray(arguments)) {
            if(arguments.length >= 1) {
                var args = [
                    callback
                ];
                angular.forEach(arguments, function (value) {
                    return args.push(value);
                });
                var registerFn = jolokia.register;
                var handle = registerFn.apply(jolokia, args);
                scope.$jhandle.push(handle);
                jolokia.request(arguments, callback);
            }
        } else {
            var handle = jolokia.register(callback, arguments);
            scope.$jhandle.push(handle);
            jolokia.request(arguments, callback);
        }
    }
    Core.register = register;
    function registerSearch(jolokia, scope, mbeanPattern, callback) {
        if(!angular.isDefined(scope.$jhandle) || !angular.isArray(scope.$jhandle)) {
            scope.$jhandle = [];
        }
        if(angular.isDefined(scope.$on)) {
            scope.$on('$destroy', function (event) {
                unregister(jolokia, scope);
            });
        }
        if(angular.isArray(arguments)) {
            if(arguments.length >= 1) {
                var args = [
                    callback
                ];
                angular.forEach(arguments, function (value) {
                    return args.push(value);
                });
                var registerFn = jolokia.register;
                var handle = registerFn.apply(jolokia, args);
                scope.$jhandle.push(handle);
                jolokia.search(mbeanPattern, callback);
            }
        } else {
            var handle = jolokia.register(callback, arguments);
            scope.$jhandle.push(handle);
            jolokia.search(mbeanPattern, callback);
        }
    }
    Core.registerSearch = registerSearch;
    function unregister(jolokia, scope) {
        if(angular.isDefined(scope.$jhandle)) {
            scope.$jhandle.forEach(function (handle) {
                jolokia.unregister(handle);
            });
            delete scope.$jhandle;
        }
    }
    Core.unregister = unregister;
    function xmlNodeToString(xmlNode) {
        try  {
            return (new XMLSerializer()).serializeToString(xmlNode);
        } catch (e) {
            try  {
                return xmlNode.xml;
            } catch (e) {
                console.log('WARNING: XMLSerializer not supported');
            }
        }
        return false;
    }
    Core.xmlNodeToString = xmlNodeToString;
    function isTextNode(node) {
        return node && node.nodeType === 3;
    }
    Core.isTextNode = isTextNode;
    function $applyNowOrLater($scope) {
        if($scope.$$phase) {
            setTimeout(function () {
                Core.$apply($scope);
            }, 50);
        } else {
            $scope.$apply();
        }
    }
    Core.$applyNowOrLater = $applyNowOrLater;
    function $applyLater($scope, timeout) {
        if (typeof timeout === "undefined") { timeout = 50; }
        setTimeout(function () {
            Core.$apply($scope);
        }, timeout);
    }
    Core.$applyLater = $applyLater;
    function $apply($scope) {
        var phase = $scope.$$phase;
        if(!phase) {
            $scope.$apply();
        }
    }
    Core.$apply = $apply;
    function $digest($scope) {
        var phase = $scope.$$phase;
        if(!phase) {
            $scope.$digest();
        }
    }
    Core.$digest = $digest;
    function fileExtension(name, defaultValue) {
        if (typeof defaultValue === "undefined") { defaultValue = ""; }
        var extension = defaultValue;
        if(name) {
            var idx = name.lastIndexOf(".");
            if(idx > 0) {
                extension = name.substring(idx + 1, name.length).toLowerCase();
            }
        }
        return extension;
    }
    Core.fileExtension = fileExtension;
    function parseIntValue(value, description) {
        if(angular.isString(value)) {
            try  {
                return parseInt(value);
            } catch (e) {
                console.log("Failed to parse " + description + " with text '" + value + "'");
            }
        }
        return null;
    }
    Core.parseIntValue = parseIntValue;
    function parseFloatValue(value, description) {
        if(angular.isString(value)) {
            try  {
                return parseFloat(value);
            } catch (e) {
                console.log("Failed to parse " + description + " with text '" + value + "'");
            }
        }
        return null;
    }
    Core.parseFloatValue = parseFloatValue;
    function getOrCreateElements(domElement, arrayOfElementNames) {
        var element = domElement;
        angular.forEach(arrayOfElementNames, function (name) {
            if(element) {
                var children = $(element).children(name);
                if(!children || !children.length) {
                    $("<" + name + "></" + name + ">").appendTo(element);
                    children = $(element).children(name);
                }
                element = children;
            }
        });
        return element;
    }
    Core.getOrCreateElements = getOrCreateElements;
    function getUUID() {
        var d = new Date();
        var ms = (d.getTime() * 1000) + d.getUTCMilliseconds();
        var random = Math.floor((1 + Math.random()) * 65536);
        return ms.toString(16) + random.toString(16);
    }
    Core.getUUID = getUUID;
    function pathGet(object, paths) {
        var pathArray = (angular.isArray(paths)) ? paths : (paths || "").split(".");
        var value = object;
        angular.forEach(pathArray, function (name) {
            if(angular.isObject(value)) {
                value = value[name];
            } else {
                return null;
            }
        });
        return value;
    }
    Core.pathGet = pathGet;
    function pathSet(object, paths, newValue) {
        var pathArray = (angular.isArray(paths)) ? paths : (paths || "").split(".");
        var value = object;
        var lastIndex = pathArray.length - 1;
        angular.forEach(pathArray, function (name, idx) {
            var next = value[name];
            if(!angular.isObject(next)) {
                next = (idx < lastIndex) ? {
                } : newValue;
                value[name] = next;
            }
            value = next;
        });
        return value;
    }
    Core.pathSet = pathSet;
    var _escapeHtmlChars = {
        "#": "&#35;",
        "'": "&#39;",
        "<": "&lt;",
        "\"": "&quot;"
    };
    function unescapeHtml(str) {
        angular.forEach(_escapeHtmlChars, function (value, key) {
            var regex = new RegExp(value, "g");
            str = str.replace(regex, key);
        });
        str = str.replace(/&gt;/g, ">");
        return str;
    }
    Core.unescapeHtml = unescapeHtml;
    function escapeHtml(str) {
        if(angular.isString(str)) {
            var newStr = "";
            for(var i = 0; i < str.length; i++) {
                var ch = str.charAt(i);
                var ch = _escapeHtmlChars[ch] || ch;
                newStr += ch;
            }
            return newStr;
        } else {
            return str;
        }
    }
    Core.escapeHtml = escapeHtml;
    var _versionRegex = /[^\d]*(\d+)\.(\d+)(\.(\d+))?.*/;
    function parseVersionNumbers(text) {
        if(text) {
            var m = text.match(_versionRegex);
            if(m && m.length > 4) {
                var m1 = m[1];
                var m2 = m[2];
                var m4 = m[4];
                if(angular.isDefined(m4)) {
                    return [
                        parseInt(m1), 
                        parseInt(m2), 
                        parseInt(m4)
                    ];
                } else {
                    if(angular.isDefined(m2)) {
                        return [
                            parseInt(m1), 
                            parseInt(m2)
                        ];
                    } else {
                        if(angular.isDefined(m1)) {
                            return [
                                parseInt(m1)
                            ];
                        }
                    }
                }
            }
        }
        return null;
    }
    Core.parseVersionNumbers = parseVersionNumbers;
    function compareVersionNumberArrays(v1, v2) {
        if(v1 && !v2) {
            return 1;
        }
        if(!v1 && v2) {
            return -1;
        }
        if(v1 === v2) {
            return 0;
        }
        for(var i = 0; i < v1.length; i++) {
            var n1 = v1[i];
            if(i >= v2.length) {
                return 1;
            }
            var n2 = v2[i];
            if(!angular.isDefined(n1)) {
                return -1;
            }
            if(!angular.isDefined(n2)) {
                return 1;
            }
            if(n1 > n2) {
                return 1;
            } else {
                if(n1 < n2) {
                    return -1;
                }
            }
        }
        return 0;
    }
    Core.compareVersionNumberArrays = compareVersionNumberArrays;
    function asArray(value) {
        return angular.isArray(value) ? value : [
            value
        ];
    }
    Core.asArray = asArray;
    function valueToHtml(value) {
        if(angular.isArray(value)) {
            var size = value.length;
            if(!size) {
                return "";
            } else {
                if(size === 1) {
                    return valueToHtml(value[0]);
                } else {
                    var buffer = "<ul>";
                    angular.forEach(value, function (childValue) {
                        buffer += "<li>" + valueToHtml(childValue) + "</li>";
                    });
                    return buffer + "</ul>";
                }
            }
        } else {
            if(angular.isObject(value)) {
                var buffer = "<table>";
                angular.forEach(value, function (childValue, key) {
                    buffer += "<tr><td>" + key + "</td><td>" + valueToHtml(childValue) + "</td></tr>";
                });
                return buffer + "</table>";
            } else {
                if(angular.isString(value)) {
                    var uriPrefixes = [
                        "http://", 
                        "https://", 
                        "file://", 
                        "mailto:"
                    ];
                    var answer = value;
                    angular.forEach(uriPrefixes, function (prefix) {
                        if(answer.startsWith(prefix)) {
                            answer = "<a href='" + value + "'>" + value + "</a>";
                        }
                    });
                    return answer;
                }
            }
        }
        return value;
    }
    Core.valueToHtml = valueToHtml;
    function tryParseJson(text) {
        text = text.trim();
        if((text.startsWith("[") && text.endsWith("]")) || (text.startsWith("{") && text.endsWith("}"))) {
            try  {
                return JSON.parse(text);
            } catch (e) {
            }
        }
        return null;
    }
    Core.tryParseJson = tryParseJson;
    function maybePlural(count, word) {
        var pluralWord = (count === 1) ? word : word.pluralize();
        return "" + count + " " + pluralWord;
    }
    Core.maybePlural = maybePlural;
    function objectNameProperties(objectName) {
        var entries = {
        };
        if(objectName) {
            var idx = objectName.indexOf(":");
            if(idx > 0) {
                var path = objectName.substring(idx + 1);
                var items = path.split(',');
                angular.forEach(items, function (item) {
                    var kv = item.split('=');
                    var key = kv[0];
                    var value = kv[1] || key;
                    entries[key] = value;
                });
            }
        }
        return entries;
    }
    Core.objectNameProperties = objectNameProperties;
    function setPageTitle($document, title) {
        document.title = title.join(' : ');
    }
    Core.setPageTitle = setPageTitle;
    function getMBeanTypeFolder(workspace, domain, typeName) {
        if(workspace) {
            var mbeanTypesToDomain = workspace.mbeanTypesToDomain || {
            };
            var types = mbeanTypesToDomain[typeName] || {
            };
            var answer = types[domain];
            if(angular.isArray(answer) && answer.length) {
                return answer[0];
            }
            return answer;
        }
        return null;
    }
    Core.getMBeanTypeFolder = getMBeanTypeFolder;
    function getMBeanTypeObjectName(workspace, domain, typeName) {
        var folder = Core.getMBeanTypeFolder(workspace, domain, typeName);
        return Core.pathGet(folder, [
            "objectName"
        ]);
    }
    Core.getMBeanTypeObjectName = getMBeanTypeObjectName;
    function toSafeDomID(text) {
        return text ? text.replace(/(\/|\.)/g, "_") : text;
    }
    Core.toSafeDomID = toSafeDomID;
})(Core || (Core = {}));
var Core;
(function (Core) {
    var HelpRegistry = (function () {
        function HelpRegistry($rootScope) {
            this.$rootScope = $rootScope;
            this.discoverableDocTypes = {
                user: 'help.md'
            };
            this.topicNameMappings = {
                activemq: 'ActiveMQ',
                camel: 'Camel',
                jmx: 'JMX',
                log: 'Logs',
                datatable: 'hawtio-datatable'
            };
            this.subTopicNameMappings = {
                user: 'For Users',
                developer: 'For Developers',
                faq: 'FAQ'
            };
            this.topics = {
            };
        }
        HelpRegistry.prototype.addUserDoc = function (topic, path) {
            this.addSubTopic(topic, 'user', path);
        };
        HelpRegistry.prototype.addDevDoc = function (topic, path) {
            this.addSubTopic(topic, 'developer', path);
        };
        HelpRegistry.prototype.addSubTopic = function (topic, subtopic, path) {
            this.getOrCreateTopic(topic)[subtopic] = path;
        };
        HelpRegistry.prototype.getOrCreateTopic = function (topic) {
            if(!angular.isDefined(this.topics[topic])) {
                this.topics[topic] = {
                };
                this.$rootScope.$broadcast('hawtioNewHelpTopic');
            }
            return this.topics[topic];
        };
        HelpRegistry.prototype.mapTopicName = function (name) {
            if(angular.isDefined(this.topicNameMappings[name])) {
                return this.topicNameMappings[name];
            }
            return name.capitalize();
        };
        HelpRegistry.prototype.mapSubTopicName = function (name) {
            if(angular.isDefined(this.subTopicNameMappings[name])) {
                return this.subTopicNameMappings[name];
            }
            return name.capitalize();
        };
        HelpRegistry.prototype.getTopics = function () {
            return this.topics;
        };
        HelpRegistry.prototype.discoverHelpFiles = function (plugins) {
            var self = this;
            plugins.forEach(function (plugin) {
                angular.forEach(self.discoverableDocTypes, function (value, key) {
                    var target = 'app/' + plugin + '/doc/' + value;
                    if(!angular.isDefined(self['plugin']) || !angular.isDefined(self['plugin'][key])) {
                        $.ajax(target, {
                            type: 'HEAD',
                            statusCode: {
                                200: function () {
                                    self.getOrCreateTopic(plugin)[key] = target;
                                }
                            }
                        });
                    }
                });
            });
        };
        return HelpRegistry;
    })();
    Core.HelpRegistry = HelpRegistry;    
})(Core || (Core = {}));
var Core;
(function (Core) {
    function NavBarController($scope, $location, workspace, $document, pageTitle, localStorage) {
        $scope.hash = null;
        $scope.topLevelTabs = function () {
            return workspace.topLevelTabs;
        };
        $scope.subLevelTabs = function () {
            return workspace.subLevelTabs;
        };
        $scope.validSelection = function (uri) {
            return workspace.validSelection(uri);
        };
        $scope.isValid = function (nav) {
            return nav && nav.isValid(workspace);
        };
        $scope.$on('$routeChangeSuccess', function () {
            $scope.hash = workspace.hash();
        });
        $scope.link = function (nav) {
            var href;
            if(angular.isString(nav)) {
                href = nav;
            } else {
                href = nav.href();
            }
            return Core.createHref($location, href, [
                'tab'
            ]);
        };
        $scope.fullScreenLink = function () {
            var href = "#" + $location.path() + "?tab=notree";
            return Core.createHref($location, href, [
                'tab'
            ]);
        };
        $scope.addToDashboardLink = function () {
            var href = "#" + $location.path() + workspace.hash();
            return "#/dashboard/add?tab=dashboard&href=" + encodeURIComponent(href);
        };
        $scope.isActive = function (nav) {
            if(angular.isString(nav)) {
                return workspace.isLinkActive(nav);
            }
            var fn = nav.isActive;
            if(fn) {
                return fn(workspace);
            }
            return workspace.isLinkActive(nav.href());
        };
        $scope.isTopTabActive = function (nav) {
            if(angular.isString(nav)) {
                return workspace.isTopTabActive(nav);
            }
            var fn = nav.isActive;
            if(fn) {
                return fn(workspace);
            }
            return workspace.isTopTabActive(nav.href());
        };
        $scope.activeLink = function () {
            var tabs = $scope.topLevelTabs();
            if(!tabs) {
                return "Loading...";
            }
            var tab = tabs.find(function (nav) {
                return $scope.isActive(nav);
            });
            return tab ? tab['content'] : "";
        };
    }
    Core.NavBarController = NavBarController;
})(Core || (Core = {}));
var Core;
(function (Core) {
    function PreferencesController($scope, localStorage) {
        $scope.updateRate = localStorage['updateRate'];
        $scope.url = localStorage['url'];
        $scope.autoRefresh = localStorage['autoRefresh'] === "true";
        $scope.hosts = [];
        $scope.newHost = {
        };
        $scope.addRegexDialog = false;
        $scope.hostSchema = {
            properties: {
                'name': {
                    description: 'Indicator name',
                    type: 'string'
                },
                'regex': {
                    description: 'Indicator regex',
                    type: 'string'
                }
            }
        };
        $scope.delete = function (index) {
            $scope.hosts.removeAt(index);
        };
        $scope.moveUp = function (index) {
            var tmp = $scope.hosts[index];
            $scope.hosts[index] = $scope.hosts[index - 1];
            $scope.hosts[index - 1] = tmp;
        };
        $scope.moveDown = function (index) {
            var tmp = $scope.hosts[index];
            $scope.hosts[index] = $scope.hosts[index + 1];
            $scope.hosts[index + 1] = tmp;
        };
        $scope.onOk = function () {
            $scope.newHost['color'] = UI.colors.sample();
            if(!angular.isArray($scope.hosts)) {
                $scope.hosts = [
                    Object.clone($scope.newHost)
                ];
            } else {
                $scope.hosts.push(Object.clone($scope.newHost));
            }
            $scope.newHost = {
            };
        };
        $scope.$watch('hosts', function (oldValue, newValue) {
            if(!Object.equal(oldValue, newValue)) {
                localStorage['regexs'] = angular.toJson($scope.hosts);
            } else {
                $scope.hosts = angular.fromJson(localStorage['regexs']);
            }
        }, true);
        var defaults = {
            logCacheSize: 1000
        };
        var converters = {
            logCacheSize: parseInt
        };
        $scope.$watch('updateRate', function () {
            localStorage['updateRate'] = $scope.updateRate;
            $scope.$emit('UpdateRate', $scope.updateRate);
        });
        $scope.$watch('autoRefresh', function (newValue, oldValue) {
            if(newValue === oldValue) {
                return;
            }
            localStorage['autoRefresh'] = $scope.autoRefresh;
        });
        var names = [
            "gitUserName", 
            "gitUserEmail", 
            "activemqUserName", 
            "activemqPassword", 
            "logCacheSize"
        ];
        angular.forEach(names, function (name) {
            $scope[name] = localStorage[name];
            var converter = converters[name];
            if(converter) {
                $scope[name] = converter($scope[name]);
            }
            if(!$scope[name]) {
                $scope[name] = defaults[name] || "";
            }
            $scope.$watch(name, function () {
                var value = $scope[name];
                if(value) {
                    localStorage[name] = value;
                }
            });
        });
        console.log("logCacheSize " + $scope.logCacheSize);
    }
    Core.PreferencesController = PreferencesController;
})(Core || (Core = {}));
var TableWidget = (function () {
    function TableWidget(scope, workspace, dataTableColumns, config) {
        if (typeof config === "undefined") { config = {
        }; }
        this.scope = scope;
        this.workspace = workspace;
        this.dataTableColumns = dataTableColumns;
        this.config = config;
        var _this = this;
        this.ignoreColumnHash = {
        };
        this.flattenColumnHash = {
        };
        this.detailTemplate = null;
        this.openMessages = [];
        this.addedExpandNodes = false;
        this.tableElement = null;
        this.sortColumns = null;
        this.dataTableConfig = {
            bPaginate: false,
            sDom: 'Rlfrtip',
            bDestroy: true,
            bAutoWidth: true
        };
        this.dataTable = null;
        angular.forEach(config.ignoreColumns, function (name) {
            _this.ignoreColumnHash[name] = true;
        });
        angular.forEach(config.flattenColumns, function (name) {
            _this.flattenColumnHash[name] = true;
        });
        var templateId = config.rowDetailTemplateId;
        if(templateId) {
            this.detailTemplate = workspace.$templateCache.get(templateId);
        }
    }
    TableWidget.prototype.addData = function (newData) {
        var dataTable = this.dataTable;
        dataTable.fnAddData(newData);
    };
    TableWidget.prototype.populateTable = function (data) {
        var _this = this;
        var $scope = this.scope;
        if(!data) {
            $scope.messages = [];
        } else {
            $scope.messages = data;
            var formatMessageDetails = function (dataTable, parentRow) {
                var oData = dataTable.fnGetData(parentRow);
                var div = $('<div>');
                div.addClass('innerDetails');
                _this.populateDetailDiv(oData, div);
                return div;
            };
            var array = data;
            if(angular.isArray(data)) {
            } else {
                if(angular.isObject(data)) {
                    array = [];
                    angular.forEach(data, function (object) {
                        return array.push(object);
                    });
                }
            }
            var tableElement = this.tableElement;
            if(!tableElement) {
                tableElement = $('#grid');
            }
            var tableTr = Core.getOrCreateElements(tableElement, [
                "thead", 
                "tr"
            ]);
            var tableBody = Core.getOrCreateElements(tableElement, [
                "tbody"
            ]);
            var ths = $(tableTr).find("th");
            var columns = [];
            angular.forEach(this.dataTableColumns, function (value) {
                return columns.push(value);
            });
            var addColumn = function (key, title) {
                columns.push({
                    "sDefaultContent": "",
                    "mData": null,
                    mDataProp: key
                });
                if(tableTr) {
                    $("<th>" + title + "</th>").appendTo(tableTr);
                }
            };
            var checkForNewColumn = function (value, key, prefix) {
                var found = _this.ignoreColumnHash[key] || columns.any(function (k, v) {
                    return "mDataProp" === k && v === key;
                });
                if(!found) {
                    if(_this.flattenColumnHash[key]) {
                        if(angular.isObject(value)) {
                            var childPrefix = prefix + key + ".";
                            angular.forEach(value, function (value, key) {
                                return checkForNewColumn(value, key, childPrefix);
                            });
                        }
                    } else {
                        addColumn(prefix + key, humanizeValue(key));
                    }
                }
            };
            if(!this.config.disableAddColumns && angular.isArray(array) && array.length > 0) {
                var first = array[0];
                if(angular.isObject(first)) {
                    angular.forEach(first, function (value, key) {
                        return checkForNewColumn(value, key, "");
                    });
                }
            }
            if(columns.length > 1) {
                var col0 = columns[0];
                if(!this.sortColumns && !col0["mDataProp"] && !col0["mData"]) {
                    var sortOrder = [
                        [
                            1, 
                            "asc"
                        ]
                    ];
                    this.sortColumns = sortOrder;
                }
            }
            if(array.length && !angular.isArray(array[0])) {
                this.dataTableConfig["aaData"] = array;
            } else {
                this.dataTableConfig["aaData"] = array;
            }
            this.dataTableConfig["aoColumns"] = columns;
            if(this.sortColumns) {
                this.dataTableConfig["aaSorting"] = this.sortColumns;
            }
            if(this.dataTable) {
                this.dataTable.fnClearTable(false);
                this.dataTable.fnAddData(array);
                this.dataTable.fnDraw();
            } else {
                this.dataTable = tableElement.dataTable(this.dataTableConfig);
            }
            var widget = this;
            if(this.dataTable) {
                var keys = new KeyTable({
                    "table": tableElement[0],
                    "datatable": this.dataTable
                });
                keys.fnSetPosition(0, 0);
                if(angular.isArray(data) && data.length) {
                    var selected = data[0];
                    var selectHandler = widget.config.selectHandler;
                    if(selected && selectHandler) {
                        selectHandler(selected);
                    }
                }
            }
            $(tableElement).focus();
            var widget = this;
            var expandCollapseNode = function () {
                var dataTable = widget.dataTable;
                var parentRow = this.parentNode;
                var openMessages = widget.openMessages;
                var i = $.inArray(parentRow, openMessages);
                var element = $('i', this);
                if(i === -1) {
                    element.removeClass('icon-plus');
                    element.addClass('icon-minus');
                    var dataDiv = formatMessageDetails(dataTable, parentRow);
                    var detailsRow = $(dataTable.fnOpen(parentRow, dataDiv, 'details'));
                    detailsRow.css("padding", "0");
                    setTimeout(function () {
                        detailsRow.find(".innerDetails").slideDown(400, function () {
                            $(parentRow).addClass('opened');
                            openMessages.push(parentRow);
                        });
                    }, 20);
                } else {
                    $(parentRow.nextSibling).find(".innerDetails").slideUp(400, function () {
                        $(parentRow).removeClass('opened');
                        element.removeClass('icon-minus');
                        element.addClass('icon-plus');
                        dataTable.fnClose(parentRow);
                        openMessages.splice(i, 1);
                    });
                }
                Core.$apply($scope);
            };
            if(!this.addedExpandNodes) {
                this.addedExpandNodes = true;
                $(tableElement).on("click", "td.control", expandCollapseNode);
                keys.event.action(0, null, function (node) {
                    expandCollapseNode.call(node);
                });
            }
            keys.event.focus(null, null, function (node) {
                var dataTable = widget.dataTable;
                var row = node;
                if(node) {
                    var nodeName = node.nodeName;
                    if(nodeName) {
                        if(nodeName.toLowerCase() === "td") {
                            row = $(node).parents("tr")[0];
                        }
                        var selected = dataTable.fnGetData(row);
                        var selectHandler = widget.config.selectHandler;
                        if(selected && selectHandler) {
                            selectHandler(selected);
                        }
                    }
                }
            });
            $(tableElement).on("click", "td.control", function () {
                var dataTable = widget.dataTable;
                if($(this).hasClass('selected')) {
                    $(this).removeClass('focus selected');
                } else {
                    if(!widget.config.multiSelect) {
                        dataTable.$('td.selected').removeClass('focus selected');
                    }
                    $(this).addClass('focus selected');
                    var row = $(this).parents("tr")[0];
                    var selected = dataTable.fnGetData(row);
                    var selectHandler = widget.config.selectHandler;
                    if(selected && selectHandler) {
                        selectHandler(selected);
                    }
                }
            });
        }
        Core.$apply($scope);
    };
    TableWidget.prototype.populateDetailDiv = function (row, div) {
        delete row["0"];
        var scope = this.scope.$new();
        scope.row = row;
        scope.templateDiv = div;
        var template = this.detailTemplate;
        if(!template) {
            var templateId = this.config.rowDetailTemplateId;
            if(templateId) {
                this.detailTemplate = this.workspace.$templateCache.get(templateId);
                template = this.detailTemplate;
            }
        }
        if(template) {
            div.html(template);
            this.workspace.$compile(div.contents())(scope);
        }
    };
    return TableWidget;
})();
var Core;
(function (Core) {
    function ViewController($scope, $route, $location, layoutTree, layoutFull, viewRegistry) {
        findViewPartial();
        $scope.$on("$routeChangeSuccess", function (event, current, previous) {
            findViewPartial();
        });
        function searchRegistry(path) {
            var answer = undefined;
            Object.extended(viewRegistry).keys(function (key, value) {
                if(!answer) {
                    if(key.startsWith("/") && key.endsWith("/")) {
                        var text = key.substring(1, key.length - 1);
                        try  {
                            var reg = new RegExp(text, "");
                            if(reg.exec(path)) {
                                answer = value;
                            }
                        } catch (e) {
                            console.log("Invalid RegExp " + text + " for viewRegistry value: " + value);
                        }
                    } else {
                        if(path.startsWith(key)) {
                            answer = value;
                        }
                    }
                }
            });
            return answer;
        }
        function findViewPartial() {
            var answer = null;
            var hash = $location.search();
            var tab = hash['tab'];
            if(angular.isString(tab)) {
                answer = searchRegistry(tab);
            }
            if(!answer) {
                var path = $location.path();
                if(path) {
                    if(path.startsWith("")) {
                        path = path.substring(1);
                    }
                    answer = searchRegistry(path);
                }
            }
            if(!answer) {
                answer = layoutTree;
            }
            $scope.viewPartial = answer;
            return answer;
        }
    }
    Core.ViewController = ViewController;
})(Core || (Core = {}));
var Workspace = (function () {
    function Workspace(jolokia, jmxTreeLazyLoadRegistry, $location, $compile, $templateCache, localStorage, $rootScope) {
        this.jolokia = jolokia;
        this.jmxTreeLazyLoadRegistry = jmxTreeLazyLoadRegistry;
        this.$location = $location;
        this.$compile = $compile;
        this.$templateCache = $templateCache;
        this.localStorage = localStorage;
        this.$rootScope = $rootScope;
        this.operationCounter = 0;
        this.tree = new Folder('MBeans');
        this.treeResponse = {
        };
        this.mbeanTypesToDomain = {
        };
        this.mbeanServicesToDomain = {
        };
        this.attributeColumnDefs = {
        };
        this.treePostProcessors = [];
        this.topLevelTabs = [];
        this.subLevelTabs = [];
        this.keyToNodeMap = {
        };
        this.pluginRegisterHandle = null;
        this.pluginUpdateCounter = null;
        this.treeWatchRegisterHandle = null;
        this.treeWatcherCounter = null;
        this.treeElement = null;
    }
    Workspace.prototype.createChildWorkspace = function (location) {
        var child = new Workspace(this.jolokia, this.jmxTreeLazyLoadRegistry, this.$location, this.$compile, this.$templateCache, this.localStorage, this.$rootScope);
        angular.forEach(this, function (value, key) {
            return child[key] = value;
        });
        child.$location = location;
        return child;
    };
    Workspace.prototype.getLocalStorage = function (key) {
        return this.localStorage[key];
    };
    Workspace.prototype.setLocalStorage = function (key, value) {
        this.localStorage[key] = value;
    };
    Workspace.prototype.loadTree = function () {
        var options = onSuccess(null, {
            ignoreErrors: true,
            maxDepth: 2
        });
        var data = this.jolokia.list(null, options);
        this.populateTree({
            value: data
        });
    };
    Workspace.prototype.addTreePostProcessor = function (processor) {
        this.treePostProcessors.push(processor);
        var tree = this.tree;
        if(tree) {
            processor(tree);
        }
    };
    Workspace.prototype.maybeMonitorPlugins = function () {
        if(this.treeContainsDomainAndProperties("hawtio", {
            type: "registry"
        })) {
            if(this.pluginRegisterHandle === null) {
                this.pluginRegisterHandle = this.jolokia.register(angular.bind(this, this.maybeUpdatePlugins), {
                    type: "read",
                    mbean: "hawtio:type=registry",
                    attribute: "UpdateCounter"
                });
            }
        } else {
            if(this.pluginRegisterHandle !== null) {
                this.jolokia.unregister(this.pluginRegisterHandle);
                this.pluginRegisterHandle = null;
                this.pluginUpdateCounter = null;
            }
        }
        if(this.treeContainsDomainAndProperties("io.hawt.jmx", {
            type: "TreeWatcher"
        })) {
            if(this.treeWatchRegisterHandle === null) {
                this.treeWatchRegisterHandle = this.jolokia.register(angular.bind(this, this.maybeReloadTree), {
                    type: "read",
                    mbean: "io.hawt.jmx:type=TreeWatcher",
                    attribute: "Counter"
                });
            } else {
            }
        }
    };
    Workspace.prototype.maybeUpdatePlugins = function (response) {
        if(this.pluginUpdateCounter === null) {
            this.pluginUpdateCounter = response.value;
            return;
        }
        if(this.pluginUpdateCounter !== response.value) {
            if(localStorage['autoRefresh'] === "true") {
                window.location.reload();
            }
        }
    };
    Workspace.prototype.maybeReloadTree = function (response) {
        var counter = response.value;
        if(this.treeWatcherCounter === null) {
            this.treeWatcherCounter = counter;
            return;
        }
        if(this.treeWatcherCounter !== counter) {
            this.treeWatcherCounter = counter;
            var workspace = this;
            function wrapInValue(response) {
                var wrapper = {
                    value: response
                };
                workspace.populateTree(wrapper);
            }
            this.jolokia.list(null, onSuccess(wrapInValue, {
                ignoreErrors: true,
                maxDepth: 2
            }));
        }
    };
    Workspace.prototype.folderGetOrElse = function (folder, value) {
        if(folder) {
            try  {
                return folder.getOrElse(value);
            } catch (e) {
                console.log("Failed to find value " + value + " on folder " + folder);
            }
        }
        return null;
    };
    Workspace.prototype.populateTree = function (response) {
        var _this = this;
        if(!Object.equal(this.treeResponse, response.value)) {
            this.treeResponse = response.value;
            console.log("JMX tree has been loaded!");
            var rootId = 'root';
            var separator = '-';
            this.mbeanTypesToDomain = {
            };
            this.mbeanServicesToDomain = {
            };
            this.keyToNodeMap = {
            };
            var tree = new Folder('MBeans');
            tree.key = rootId;
            var domains = response.value;
            for(var domain in domains) {
                var domainClass = escapeDots(domain);
                var mbeans = domains[domain];
                for(var path in mbeans) {
                    var entries = {
                    };
                    var folder = this.folderGetOrElse(tree, domain);
                    folder.domain = domain;
                    if(!folder.key) {
                        folder.key = rootId + separator + domain;
                    }
                    var folderNames = [
                        domain
                    ];
                    folder.folderNames = folderNames;
                    folderNames = folderNames.clone();
                    var items = path.split(',');
                    var paths = [];
                    var typeName = null;
                    var serviceName = null;
                    items.forEach(function (item) {
                        var kv = item.split('=');
                        var key = kv[0];
                        var value = kv[1] || key;
                        entries[key] = value;
                        var moveToFront = false;
                        var lowerKey = key.toLowerCase();
                        if(lowerKey === "type") {
                            typeName = value;
                            if(folder.map[value]) {
                                moveToFront = true;
                            }
                        }
                        if(lowerKey === "service") {
                            serviceName = value;
                        }
                        if(moveToFront) {
                            paths.splice(0, 0, value);
                        } else {
                            paths.push(value);
                        }
                    });
                    var configureFolder = function (folder, name) {
                        folder.domain = domain;
                        if(!folder.key) {
                            folder.key = rootId + separator + folderNames.join(separator);
                        }
                        this.keyToNodeMap[folder.key] = folder;
                        folder.folderNames = folderNames.clone();
                        var classes = "";
                        var entries = folder.entries;
                        var entryKeys = Object.keys(entries).filter(function (n) {
                            return n.toLowerCase().indexOf("type") >= 0;
                        });
                        if(entryKeys.length) {
                            angular.forEach(entryKeys, function (entryKey) {
                                var entryValue = entries[entryKey];
                                if(!folder.ancestorHasEntry(entryKey, entryValue)) {
                                    classes += " " + domainClass + separator + entryValue;
                                }
                            });
                        } else {
                            var kindName = folderNames.last();
                            if(kindName === name) {
                                kindName += "-folder";
                            }
                            if(kindName) {
                                classes += " " + domainClass + separator + kindName;
                            }
                        }
                        folder.addClass = escapeTreeCssStyles(classes);
                        return folder;
                    };
                    var lastPath = paths.pop();
                    paths.forEach(function (value) {
                        folder = _this.folderGetOrElse(folder, value);
                        if(folder) {
                            folderNames.push(value);
                            angular.bind(_this, configureFolder, folder, value)();
                        }
                    });
                    var key = rootId + separator + folderNames.join(separator) + separator + lastPath;
                    var objectName = domain + ":" + path;
                    if(folder) {
                        folder = this.folderGetOrElse(folder, lastPath);
                        if(folder) {
                            folder.entries = entries;
                            folder.key = key;
                            angular.bind(this, configureFolder, folder, lastPath)();
                            folder.title = trimQuotes(lastPath);
                            folder.objectName = objectName;
                            folder.typeName = typeName;
                            var addFolderByDomain = function (owner, typeName) {
                                var map = owner[typeName];
                                if(!map) {
                                    map = {
                                    };
                                    owner[typeName] = map;
                                }
                                var value = map[domain];
                                if(!value) {
                                    map[domain] = folder;
                                } else {
                                    var array = null;
                                    if(angular.isArray(value)) {
                                        array = value;
                                    } else {
                                        array = [
                                            value
                                        ];
                                        map[domain] = array;
                                    }
                                    array.push(folder);
                                }
                            };
                            if(serviceName) {
                                angular.bind(this, addFolderByDomain, this.mbeanServicesToDomain, serviceName)();
                            }
                            if(typeName) {
                                angular.bind(this, addFolderByDomain, this.mbeanTypesToDomain, typeName)();
                            }
                        }
                    } else {
                        console.log("No folder found for lastPath: " + lastPath);
                    }
                }
            }
            tree.sortChildren(true);
            this.enableLazyLoading(tree);
            this.tree = tree;
            var processors = this.treePostProcessors;
            angular.forEach(processors, function (processor) {
                return processor(tree);
            });
            this.maybeMonitorPlugins();
            this.$rootScope.$broadcast('jmxTreeUpdated');
        }
    };
    Workspace.prototype.enableLazyLoading = function (folder) {
        var _this = this;
        var children = folder.children;
        if(children && children.length) {
            angular.forEach(children, function (child) {
                _this.enableLazyLoading(child);
            });
        } else {
            var lazyFunction = Jmx.findLazyLoadingFunction(this, folder);
            if(lazyFunction) {
                folder.isLazy = true;
            }
        }
    };
    Workspace.prototype.hash = function () {
        var hash = this.$location.search();
        var params = Core.hashToString(hash);
        if(params) {
            return "?" + params;
        }
        return "";
    };
    Workspace.prototype.getActiveTab = function () {
        var workspace = this;
        return this.topLevelTabs.find(function (tab) {
            if(!angular.isDefined(tab.isActive)) {
                return workspace.isLinkActive(tab.href());
            } else {
                return tab.isActive(workspace);
            }
        });
    };
    Workspace.prototype.isLinkActive = function (href) {
        var pathName = Core.trimLeading((this.$location.path() || '/'), "#");
        pathName = Core.trimLeading(pathName, "/");
        var link = Core.trimLeading(href, "#");
        link = Core.trimLeading(link, "/");
        var idx = link.indexOf('?');
        if(idx >= 0) {
            link = link.substring(0, idx);
        }
        if(!pathName.length) {
            return link === pathName;
        } else {
            return pathName.startsWith(link);
        }
    };
    Workspace.prototype.isTopTabActive = function (path) {
        var tab = this.$location.search()['tab'];
        if(angular.isString(tab)) {
            return tab.startsWith(path);
        }
        return this.isLinkActive(path);
    };
    Workspace.prototype.getSelectedMBeanName = function () {
        var selection = this.selection;
        if(selection) {
            return selection.objectName;
        }
        return null;
    };
    Workspace.prototype.validSelection = function (uri) {
        var workspace = this;
        var filter = function (t) {
            var fn = t.href;
            if(fn) {
                var href = fn();
                if(href) {
                    if(href.startsWith("#/")) {
                        href = href.substring(2);
                    }
                    return href === uri;
                }
            }
            return false;
        };
        var tab = this.subLevelTabs.find(filter);
        if(!tab) {
            tab = this.topLevelTabs.find(filter);
        }
        if(tab) {
            var validFn = tab.isValid;
            return !angular.isDefined(validFn) || validFn(workspace);
        } else {
            console.log("Could not find tab for " + uri);
            return false;
        }
    };
    Workspace.prototype.removeAndSelectParentNode = function () {
        var selection = this.selection;
        if(selection) {
            var parent = selection.parent;
            if(parent) {
                var idx = parent.children.indexOf(selection);
                if(idx < 0) {
                    idx = parent.children.findIndex({
                        key: selection.key
                    });
                }
                if(idx >= 0) {
                    parent.children.splice(idx, 1);
                }
                this.updateSelectionNode(parent);
            }
        }
    };
    Workspace.prototype.selectParentNode = function () {
        var selection = this.selection;
        if(selection) {
            var parent = selection.parent;
            if(parent) {
                this.updateSelectionNode(parent);
            }
        }
    };
    Workspace.prototype.selectionViewConfigKey = function () {
        return this.selectionConfigKey("view/");
    };
    Workspace.prototype.selectionConfigKey = function (prefix) {
        if (typeof prefix === "undefined") { prefix = ""; }
        var key = null;
        var selection = this.selection;
        if(selection) {
            key = prefix + selection.domain;
            var typeName = selection.typeName;
            if(!typeName) {
                typeName = selection.title;
            }
            key += "/" + typeName;
            if(selection.isFolder()) {
                key += "/folder";
            }
        }
        return key;
    };
    Workspace.prototype.moveIfViewInvalid = function () {
        var workspace = this;
        var uri = Core.trimLeading(this.$location.path(), "/");
        if(this.selection) {
            var key = this.selectionViewConfigKey();
            if(this.validSelection(uri)) {
                this.setLocalStorage(key, uri);
                return false;
            } else {
                console.log("the uri '" + uri + "' is not valid for this selection");
                var defaultPath = this.getLocalStorage(key);
                if(!defaultPath || !this.validSelection(defaultPath)) {
                    defaultPath = null;
                    angular.forEach(this.subLevelTabs, function (tab) {
                        var fn = tab.isValid;
                        if(!defaultPath && tab.href && angular.isDefined(fn) && fn(workspace)) {
                            defaultPath = tab.href();
                        }
                    });
                }
                if(!defaultPath) {
                    defaultPath = "#/jmx/help";
                }
                console.log("moving the URL to be " + defaultPath);
                if(defaultPath.startsWith("#")) {
                    defaultPath = defaultPath.substring(1);
                }
                this.$location.path(defaultPath);
                return true;
            }
        } else {
            return false;
        }
    };
    Workspace.prototype.updateSelectionNode = function (node) {
        var originalSelection = this.selection;
        this.selection = node;
        var key = null;
        if(node) {
            key = node['key'];
        }
        var $location = this.$location;
        var q = $location.search();
        if(key) {
            q['nid'] = key;
        }
        $location.search(q);
        if(originalSelection) {
            key = this.selectionViewConfigKey();
            if(key) {
                var defaultPath = this.getLocalStorage(key);
                if(defaultPath) {
                    this.$location.path(defaultPath);
                }
            }
        }
    };
    Workspace.prototype.redrawTree = function () {
        var treeElement = this.treeElement;
        if(treeElement) {
            treeElement.dynatree("getTree").reload();
        }
    };
    Workspace.prototype.expandSelection = function (flag) {
        var treeElement = this.treeElement;
        if(treeElement) {
            var node = treeElement.dynatree("getActiveNode");
            if(node) {
                node.expand(flag);
            }
        }
    };
    Workspace.prototype.matchesProperties = function (entries, properties) {
        if(!entries) {
            return false;
        }
        for(var key in properties) {
            var value = properties[key];
            if(!value || entries[key] !== value) {
                return false;
            }
        }
        return true;
    };
    Workspace.prototype.treeContainsDomainAndProperties = function (domainName, properties) {
        if (typeof properties === "undefined") { properties = null; }
        var _this = this;
        var workspace = this;
        var tree = workspace.tree;
        if(tree) {
            var folder = tree.get(domainName);
            if(folder) {
                if(properties) {
                    var children = folder.children || [];
                    return children.some(function (node) {
                        return _this.matchesProperties(node.entries, properties);
                    });
                }
                return true;
            } else {
            }
        } else {
        }
        return false;
    };
    Workspace.prototype.matches = function (folder, properties, propertiesCount) {
        if(folder) {
            var entries = folder.entries;
            if(properties) {
                if(!entries) {
                    return false;
                }
                for(var key in properties) {
                    var value = properties[key];
                    if(!value || entries[key] !== value) {
                        return false;
                    }
                }
            }
            if(propertiesCount) {
                return entries && Object.keys(entries).length === propertiesCount;
            }
            return true;
        }
        return false;
    };
    Workspace.prototype.hasDomainAndProperties = function (domainName, properties, propertiesCount) {
        if (typeof properties === "undefined") { properties = null; }
        if (typeof propertiesCount === "undefined") { propertiesCount = null; }
        var node = this.selection;
        if(node) {
            return this.matches(node, properties, propertiesCount) && node.domain === domainName;
        }
        return false;
    };
    Workspace.prototype.findMBeanWithProperties = function (domainName, properties, propertiesCount) {
        if (typeof properties === "undefined") { properties = null; }
        if (typeof propertiesCount === "undefined") { propertiesCount = null; }
        var tree = this.tree;
        if(tree) {
            return this.findChildMBeanWithProperties(tree.get(domainName), properties, propertiesCount);
        }
        return null;
    };
    Workspace.prototype.findChildMBeanWithProperties = function (folder, properties, propertiesCount) {
        if (typeof properties === "undefined") { properties = null; }
        if (typeof propertiesCount === "undefined") { propertiesCount = null; }
        var _this = this;
        var workspace = this;
        if(folder) {
            var children = folder.children;
            if(children) {
                var answer = children.find(function (node) {
                    return _this.matches(node, properties, propertiesCount);
                });
                if(answer) {
                    return answer;
                }
                return children.map(function (node) {
                    return workspace.findChildMBeanWithProperties(node, properties, propertiesCount);
                }).find(function (node) {
                    return node;
                });
            }
        }
        return null;
    };
    Workspace.prototype.selectionHasDomainAndLastFolderName = function (objectName, lastName) {
        var lastNameLower = (lastName || "").toLowerCase();
        function isName(name) {
            return (name || "").toLowerCase() === lastNameLower;
        }
        var node = this.selection;
        if(node) {
            if(objectName === node.domain) {
                var folders = node.folderNames;
                if(folders) {
                    var last = folders.last();
                    return (isName(last) || isName(node.title)) && node.isFolder() && !node.objectName;
                }
            }
        }
        return false;
    };
    Workspace.prototype.selectionHasDomainAndType = function (objectName, typeName) {
        var node = this.selection;
        if(node) {
            return objectName === node.domain && typeName === node.typeName;
        }
        return false;
    };
    Workspace.prototype.hasFabricMBean = function () {
        return this.hasDomainAndProperties('org.fusesource.fabric', {
            type: 'Fabric'
        });
    };
    Workspace.prototype.isFabricFolder = function () {
        return this.hasDomainAndProperties('org.fusesource.fabric');
    };
    Workspace.prototype.isCamelContext = function () {
        return this.hasDomainAndProperties('org.apache.camel', {
            type: 'context'
        });
    };
    Workspace.prototype.isCamelFolder = function () {
        return this.hasDomainAndProperties('org.apache.camel');
    };
    Workspace.prototype.isEndpointsFolder = function () {
        return this.selectionHasDomainAndLastFolderName('org.apache.camel', 'endpoints');
    };
    Workspace.prototype.isEndpoint = function () {
        return this.hasDomainAndProperties('org.apache.camel', {
            type: 'endpoints'
        });
    };
    Workspace.prototype.isRoutesFolder = function () {
        return this.selectionHasDomainAndLastFolderName('org.apache.camel', 'routes');
    };
    Workspace.prototype.isRoute = function () {
        return this.hasDomainAndProperties('org.apache.camel', {
            type: 'routes'
        });
    };
    Workspace.prototype.isOsgiFolder = function () {
        return this.hasDomainAndProperties('osgi.core');
    };
    Workspace.prototype.isKarafFolder = function () {
        return this.hasDomainAndProperties('org.apache.karaf');
    };
    Workspace.prototype.isOsgiCompendiumFolder = function () {
        return this.hasDomainAndProperties('osgi.compendium');
    };
    return Workspace;
})();
var Dashboard;
(function (Dashboard) {
    function DashboardController($scope, $location, $routeParams, $injector, $route, $templateCache, workspace, dashboardRepository, $compile) {
        $scope.route = $route;
        $scope.injector = $injector;
        var gridSize = 150;
        var gridMargin = 6;
        var gridHeight;
        $scope.gridX = gridSize;
        $scope.gridY = gridSize;
        $scope.widgetMap = {
        };
        updateWidgets();
        $scope.removeWidget = function (widget) {
            var gridster = getGridster();
            var widgetElem = null;
            var widgetData = $scope.widgetMap[widget.id];
            if(widgetData) {
                delete $scope.widgetMap[widget.id];
                var scope = widgetData.scope;
                widgetElem = widgetData.widget;
                if(scope) {
                    scope.$destroy();
                }
            }
            if(!widgetElem) {
                widgetElem = $("div").find("[data-widgetId='" + widget.id + "']").parent();
            }
            if(gridster && widgetElem) {
                gridster.remove_widget(widgetElem);
            }
            if($scope.dashboard) {
                var widgets = $scope.dashboard.widgets;
                if(widgets) {
                    widgets.remove(widget);
                }
            }
            updateDashboardRepository("Removed widget " + widget.title);
        };
        function changeWidgetSize(widget, sizefunc, savefunc) {
            var gridster = getGridster();
            var entry = $scope.widgetMap[widget.id];
            var w = entry.widget;
            var scope = entry.scope;
            sizefunc(entry);
            gridster.resize_widget(w, entry.size_x, entry.size_y);
            gridster.set_dom_grid_height();
            setTimeout(function () {
                var template = $templateCache.get("widgetTemplate");
                var div = $('<div></div>');
                div.html(template);
                w.html($compile(div.contents())(scope));
                makeResizable();
                $scope.$apply();
                setTimeout(function () {
                    savefunc(widget);
                }, 50);
            }, 30);
        }
        $scope.onWidgetRenamed = function (widget) {
            updateDashboardRepository("Renamed widget to " + widget.title);
        };
        function updateWidgets() {
            $scope.id = $routeParams["dashboardId"];
            $scope.idx = $routeParams["dashboardIndex"];
            if($scope.id) {
                dashboardRepository.getDashboard($scope.id, onDashboardLoad);
            } else {
                dashboardRepository.getDashboards(function (dashboards) {
                    var idx = $scope.idx ? parseInt($scope.idx) : 0;
                    var id = null;
                    if(dashboards.length > 0) {
                        var dashboard = dashboards.length > idx ? dashboards[idx] : dashboard[0];
                        id = dashboard.id;
                    }
                    if(id) {
                        $location.path("/dashboard/id/" + id);
                    } else {
                        $location.path("/dashboard/edit?tab=dashboard");
                    }
                });
            }
        }
        function onDashboardLoad(dashboard) {
            $scope.dashboard = dashboard;
            var widgetElement = $("#widgets");
            var gridster = widgetElement.gridster({
                widget_margins: [
                    gridMargin, 
                    gridMargin
                ],
                widget_base_dimensions: [
                    $scope.gridX, 
                    $scope.gridY
                ],
                extra_rows: 10,
                extra_cols: 6,
                draggable: {
                    stop: function (event, ui) {
                        if(serializeDashboard()) {
                            updateDashboardRepository("Changing dashboard layout");
                        }
                    }
                }
            }).data('gridster');
            var template = $templateCache.get("widgetTemplate");
            var widgets = ((dashboard) ? dashboard.widgets : null) || [];
            angular.forEach(widgets, function (widget) {
                var childScope = $scope.$new(false);
                childScope.widget = widget;
                var path = widget.path;
                var search = Dashboard.decodeURIComponentProperties(widget.search);
                var hash = widget.hash;
                var location = new Dashboard.RectangleLocation($location, path, search, hash);
                var childWorkspace = workspace.createChildWorkspace(location);
                childWorkspace.$location = location;
                var key = location.search()['nid'];
                if(key && workspace.tree) {
                    childWorkspace.selection = workspace.keyToNodeMap[key];
                    if(!childWorkspace.selection) {
                        var decodedKey = decodeURIComponent(key);
                        childWorkspace.selection = workspace.keyToNodeMap[decodedKey];
                    }
                }
                var $$scopeInjections = {
                    workspace: childWorkspace,
                    location: location,
                    $location: location,
                    $routeParams: {
                        x: "123",
                        y: "Cheese!"
                    }
                };
                childScope.$$scopeInjections = $$scopeInjections;
                if(!widget.size_x || widget.size_x < 1) {
                    widget.size_x = 1;
                }
                if(!widget.size_y || widget.size_y < 1) {
                    widget.size_y = 1;
                }
                var div = $('<div></div>');
                div.html(template);
                var outerDiv = $('<li class="grid-block" style="display: list-item; position: absolute"></li>');
                outerDiv.html($compile(div.contents())(childScope));
                var w = gridster.add_widget(outerDiv, widget.size_x, widget.size_y, widget.col, widget.row);
                $scope.widgetMap[widget.id] = {
                    widget: w,
                    scope: childScope
                };
            });
            makeResizable();
            getGridster().enable();
            if(!$scope.$$phase) {
                $scope.$apply();
            }
        }
        function serializeDashboard() {
            var gridster = getGridster();
            if(gridster) {
                var data = gridster.serialize();
                console.log("got data: " + JSON.stringify(data));
                var widgets = $scope.dashboard.widgets || [];
                angular.forEach(widgets, function (widget, idx) {
                    var value = data[idx];
                    if(value && widget) {
                        angular.forEach(value, function (attr, key) {
                            return widget[key] = attr;
                        });
                    }
                });
                return true;
            }
            return false;
        }
        function makeResizable() {
            var blocks = $('.grid-block');
            blocks.resizable('destroy');
            blocks.resizable({
                grid: [
                    gridSize + (gridMargin * 2), 
                    gridSize + (gridMargin * 2)
                ],
                animate: false,
                minWidth: gridSize,
                minHeight: gridSize,
                autoHide: false,
                start: function (event, ui) {
                    gridHeight = getGridster().$el.height();
                },
                resize: function (event, ui) {
                    var g = getGridster();
                    var delta = gridSize + gridMargin * 2;
                    if(event.offsetY > g.$el.height()) {
                        var extra = Math.floor((event.offsetY - gridHeight) / delta + 1);
                        var newHeight = gridHeight + extra * delta;
                        g.$el.css('height', newHeight);
                    }
                },
                stop: function (event, ui) {
                    var resized = $(this);
                    setTimeout(function () {
                        resizeBlock(resized);
                    }, 300);
                }
            });
            $('.ui-resizable-handle').hover(function () {
                getGridster().disable();
            }, function () {
                getGridster().enable();
            });
        }
        function resizeBlock(elmObj) {
            var elmObj = $(elmObj);
            var area = elmObj.find('.widget-area');
            var w = elmObj.width() - gridSize;
            var h = elmObj.height() - gridSize;
            for(var grid_w = 1; w > 0; w -= (gridSize + (gridMargin * 2))) {
                grid_w++;
            }
            for(var grid_h = 1; h > 0; h -= (gridSize + (gridMargin * 2))) {
                grid_h++;
            }
            var widget = {
                id: area.attr('data-widgetId')
            };
            changeWidgetSize(widget, function (widget) {
                widget.size_x = grid_w;
                widget.size_y = grid_h;
            }, function (widget) {
                if(serializeDashboard()) {
                    updateDashboardRepository("Changed size of widget: " + widget.id);
                }
            });
        }
        function updateDashboardRepository(message) {
            if($scope.dashboard) {
                var commitMessage = message;
                if($scope.dashboard && $scope.dashboard.title) {
                    commitMessage += " on dashboard " + $scope.dashboard.title;
                }
                dashboardRepository.putDashboards([
                    $scope.dashboard
                ], commitMessage, Dashboard.onOperationComplete);
            }
        }
        function getGridster() {
            return $("#widgets").gridster().data('gridster');
        }
    }
    Dashboard.DashboardController = DashboardController;
})(Dashboard || (Dashboard = {}));
var Dashboard;
(function (Dashboard) {
    var pluginName = 'dashboard';
    angular.module(pluginName, [
        'bootstrap', 
        'ngResource', 
        'hawtioCore'
    ]).config(function ($routeProvider) {
        $routeProvider.when('/dashboard/add', {
            templateUrl: 'app/dashboard/html/addToDashboard.html'
        }).when('/dashboard/edit', {
            templateUrl: 'app/dashboard/html/editDashboards.html'
        }).when('/dashboard/idx/:dashboardIndex', {
            templateUrl: 'app/dashboard/html/dashboard.html'
        }).when('/dashboard/id/:dashboardId', {
            templateUrl: 'app/dashboard/html/dashboard.html'
        }).when('/dashboard/id/:dashboardId/share', {
            templateUrl: 'app/dashboard/html/share.html'
        }).when('/dashboard/import', {
            templateUrl: 'app/dashboard/html/import.html'
        });
    }).value('ui.config', {
        jq: {
            gridster: {
                widget_margins: [
                    10, 
                    10
                ],
                widget_base_dimensions: [
                    140, 
                    140
                ]
            }
        }
    }).factory('dashboardRepository', function (workspace, jolokia, localStorage) {
        return new Dashboard.DefaultDashboardRepository(workspace, jolokia, localStorage);
    }).run(function ($location, workspace, viewRegistry) {
        viewRegistry['dashboard'] = 'app/dashboard/html/layoutDashboard.html';
        workspace.topLevelTabs.push({
            content: "Dashboard",
            title: "View and edit your own custom dashboards",
            isValid: function (workspace) {
                return true;
            },
            href: function () {
                return "#/dashboard/idx/0?tab=dashboard";
            },
            isActive: function (workspace) {
                return workspace.isTopTabActive("dashboard");
            }
        });
    });
    hawtioPluginLoader.addModule(pluginName);
})(Dashboard || (Dashboard = {}));
var Dashboard;
(function (Dashboard) {
    var DefaultDashboardRepository = (function () {
        function DefaultDashboardRepository(workspace, jolokia, localStorage) {
            this.workspace = workspace;
            this.jolokia = jolokia;
            this.localStorage = localStorage;
            this.dashboards = [];
        }
        DefaultDashboardRepository.prototype.putDashboards = function (array, commitMessage, fn) {
            this.getRepository().putDashboards(array, commitMessage, fn);
        };
        DefaultDashboardRepository.prototype.deleteDashboards = function (array, fn) {
            this.getRepository().deleteDashboards(array, fn);
        };
        DefaultDashboardRepository.prototype.getDashboards = function (fn) {
            var _this = this;
            this.getRepository().getDashboards(function (values) {
                _this.dashboards = values;
                fn(values);
            });
        };
        DefaultDashboardRepository.prototype.getDashboard = function (id, onLoad) {
            this.getRepository().getDashboard(id, onLoad);
        };
        DefaultDashboardRepository.prototype.getRepository = function () {
            var git = Git.createGitRepository(this.workspace, this.jolokia, this.localStorage);
            if(git) {
                return new GitDashboardRepository(git);
            }
            return new LocalDashboardRepository();
        };
        return DefaultDashboardRepository;
    })();
    Dashboard.DefaultDashboardRepository = DefaultDashboardRepository;    
    var LocalDashboardRepository = (function () {
        function LocalDashboardRepository() {
            this.dashboards = [
                {
                    id: "m1",
                    title: "Monitor",
                    group: "Personal",
                    widgets: [
                        {
                            id: "w1",
                            title: "Operating System",
                            row: 1,
                            col: 1,
                            path: "jmx/attributes",
                            include: "app/jmx/html/attributes.html",
                            search: {
                                nid: "root-java.lang-OperatingSystem"
                            },
                            hash: ""
                        }, 
                        {
                            id: "w2",
                            title: "Broker",
                            row: 1,
                            col: 2,
                            path: "jmx/attributes",
                            include: "app/jmx/html/attributes.html",
                            search: {
                                nid: "root-org.apache.activemq-broker1-Broker"
                            },
                            hash: ""
                        }
                    ]
                }, 
                {
                    id: "t1",
                    title: "Threading",
                    group: "Admin",
                    widgets: [
                        {
                            id: "w1",
                            title: "Operating System",
                            row: 1,
                            col: 1,
                            path: "jmx/attributes",
                            include: "app/jmx/html/attributes.html",
                            search: {
                                nid: "root-java.lang-OperatingSystem"
                            },
                            hash: ""
                        }
                    ]
                }
            ];
        }
        LocalDashboardRepository.prototype.putDashboards = function (array, commitMessage, fn) {
            this.dashboards = this.dashboards.concat(array);
            fn(null);
        };
        LocalDashboardRepository.prototype.deleteDashboards = function (array, fn) {
            var _this = this;
            angular.forEach(array, function (item) {
                _this.dashboards.remove(item);
            });
            fn(null);
        };
        LocalDashboardRepository.prototype.getDashboards = function (fn) {
            fn(this.dashboards);
        };
        LocalDashboardRepository.prototype.getDashboard = function (id, onLoad) {
            var dashboard = this.dashboards.find({
                id: id
            });
            onLoad(dashboard);
        };
        return LocalDashboardRepository;
    })();
    Dashboard.LocalDashboardRepository = LocalDashboardRepository;    
    var GitDashboardRepository = (function () {
        function GitDashboardRepository(git) {
            this.git = git;
            this.branch = null;
        }
        GitDashboardRepository.prototype.putDashboards = function (array, commitMessage, fn) {
            var _this = this;
            angular.forEach(array, function (dash) {
                var path = _this.getDashboardPath(dash);
                var contents = JSON.stringify(dash, null, "  ");
                _this.git.write(_this.branch, path, commitMessage, contents, fn);
            });
        };
        GitDashboardRepository.prototype.deleteDashboards = function (array, fn) {
            var _this = this;
            angular.forEach(array, function (dash) {
                var path = _this.getDashboardPath(dash);
                var commitMessage = "Removing dashboard " + path;
                _this.git.remove(path, commitMessage, fn);
            });
        };
        GitDashboardRepository.prototype.getDashboardPath = function (dash) {
            var id = dash.id || Core.getUUID();
            var path = this.getUserDashboardPath(id);
            return path;
        };
        GitDashboardRepository.prototype.getDashboards = function (fn) {
            var _this = this;
            var path = this.getUserDashboardDirectory();
            var dashboards = [];
            this.git.read(this.branch, path, function (details) {
                var files = details.children;
                angular.forEach(files, function (file, idx) {
                    var path = file.path;
                    if(!file.directory && path.endsWith(".json")) {
                        _this.git.read(_this.branch, path, function (details) {
                            var content = details.text;
                            if(content) {
                                try  {
                                    var json = JSON.parse(content);
                                    json.uri = path;
                                    dashboards.push(json);
                                } catch (e) {
                                    console.log("Failed to parse: " + content + " due to: " + e);
                                }
                            }
                            if(idx + 1 === files.length) {
                                fn(dashboards);
                            }
                        });
                    }
                });
            });
        };
        GitDashboardRepository.prototype.getDashboard = function (id, fn) {
            var path = this.getUserDashboardPath(id);
            this.git.read(this.branch, path, function (details) {
                var dashboard = null;
                var content = details.text;
                if(content) {
                    try  {
                        dashboard = JSON.parse(content);
                    } catch (e) {
                        console.log("Failed to parse: " + content + " due to: " + e);
                    }
                }
                fn(dashboard);
            });
        };
        GitDashboardRepository.prototype.getUserDashboardDirectory = function () {
            return "/dashboards/team/all";
        };
        GitDashboardRepository.prototype.getUserDashboardPath = function (id) {
            return this.getUserDashboardDirectory() + "/" + id + ".json";
        };
        return GitDashboardRepository;
    })();
    Dashboard.GitDashboardRepository = GitDashboardRepository;    
})(Dashboard || (Dashboard = {}));
var Dashboard;
(function (Dashboard) {
    function EditDashboardsController($scope, $routeParams, $route, $location, workspace, dashboardRepository) {
        $scope.selectedItems = [];
        $scope.repository = dashboardRepository;
        setTimeout(updateData, 100);
        $scope.hasUrl = function () {
            return ($scope.url) ? true : false;
        };
        $scope.hasSelection = function () {
            return !$scope.selectedItems.length;
        };
        $scope.gridOptions = {
            selectedItems: $scope.selectedItems,
            showFilter: false,
            showColumnMenu: false,
            filterOptions: {
                filterText: ''
            },
            data: 'repository.dashboards',
            selectWithCheckboxOnly: true,
            columnDefs: [
                {
                    field: 'title',
                    displayName: 'Dashboard',
                    cellTemplate: '<div class="ngCellText"><a ng-href="#/dashboard/id/{{row.getProperty(' + "'id'" + ')}}{{hash}}">{{row.getProperty(col.field)}}</a></div>'
                }, 
                {
                    field: 'group',
                    displayName: 'Group'
                }
            ]
        };
        $scope.$on("$routeChangeSuccess", function (event, current, previous) {
            setTimeout(updateData, 50);
        });
        $scope.goBack = function () {
            var href = Core.trimLeading($scope.url, "#");
            if(href) {
                $location.url(href);
            }
        };
        $scope.addViewToDashboard = function () {
            var nextHref = null;
            angular.forEach($scope.selectedItems, function (selectedItem) {
                var text = $scope.url;
                var query = null;
                if(text) {
                    var idx = text.indexOf('?');
                    if(idx) {
                        query = text.substring(idx + 1);
                        text = text.substring(0, idx);
                    }
                    text = Core.trimLeading(text, "#");
                }
                var search = {
                };
                if(query) {
                    var expressions = query.split("&");
                    angular.forEach(expressions, function (expression) {
                        if(expression) {
                            var names = expression.split("=");
                            var key = names[0];
                            var value = names.length > 1 ? names[1] : null;
                            if(value) {
                                value = encodeURIComponent(value);
                            }
                            var old = search[key];
                            if(old) {
                                if(!angular.isArray(old)) {
                                    old = [
                                        old
                                    ];
                                    search[key] = old;
                                }
                                old.push(value);
                            } else {
                                search[key] = value;
                            }
                        }
                    });
                }
                if($route && $route.routes) {
                    var value = $route.routes[text];
                    if(value) {
                        var templateUrl = value["templateUrl"];
                        if(templateUrl) {
                            if(!selectedItem.widgets) {
                                selectedItem.widgets = [];
                            }
                            var nextNumber = selectedItem.widgets.length + 1;
                            var widget = {
                                id: "w" + nextNumber,
                                title: "Untitled" + nextNumber,
                                row: nextNumber,
                                col: 1,
                                path: Core.trimLeading(text, "/"),
                                include: templateUrl,
                                search: search,
                                hash: ""
                            };
                            selectedItem.widgets.push(widget);
                            if(!nextHref && selectedItem.id) {
                                nextHref = "/dashboard/id/" + selectedItem.id;
                            }
                        }
                    } else {
                    }
                }
            });
            var commitMessage = "Add widget";
            dashboardRepository.putDashboards($scope.selectedItems, commitMessage, Dashboard.onOperationComplete);
            if(nextHref) {
                delete $location.search()["href"];
                $location.path(nextHref);
            }
        };
        $scope.create = function () {
            var counter = dashboards().length + 1;
            var id = Core.getUUID();
            var title = "Untitled" + counter;
            var newDash = {
                id: id,
                title: title,
                group: "Personal",
                widgets: []
            };
            addDashboard(newDash, "Created new dashboard " + title);
        };
        $scope.duplicate = function () {
            angular.forEach($scope.selectedItems, function (item, idx) {
                $scope.selectedItems = $scope.selectedItems.splice(idx, 1);
                var counter = dashboards().length + 1;
                var id = Core.getUUID();
                var widgets = item.widgets || [];
                var commitMessage = "Duplicated dashboard " + item.title;
                var newDash = {
                    id: id,
                    title: item.title + " Copy",
                    group: item.group,
                    widgets: widgets
                };
                addDashboard(newDash, commitMessage);
            });
        };
        $scope.delete = function () {
            dashboardRepository.deleteDashboards($scope.selectedItems, Dashboard.onOperationComplete);
            angular.forEach($scope.selectedItems, function (item) {
                dashboards().remove(item);
            });
            $scope.selectedItems.splice(0, $scope.selectedItems.length);
        };
        $scope.gist = function () {
            if($scope.selectedItems.length > 0) {
                var id = $scope.selectedItems[0].id;
                $location.path("/dashboard/id/" + id + "/share");
            }
        };
        function updateData() {
            var url = $routeParams["href"];
            if(url) {
                $scope.url = decodeURIComponent(url);
            }
            dashboardRepository.getDashboards(dashboardLoaded);
        }
        function dashboardLoaded(dashboards) {
            $scope.dashboards = dashboards;
            Core.$apply($scope);
        }
        function addDashboard(newDash, commitMessage) {
            dashboardRepository.putDashboards([
                newDash
            ], commitMessage, Dashboard.onOperationComplete);
            dashboards().push(newDash);
            $scope.selectedItems.push(newDash);
        }
        function dashboards() {
            return dashboardRepository.dashboards;
        }
    }
    Dashboard.EditDashboardsController = EditDashboardsController;
})(Dashboard || (Dashboard = {}));
var Dashboard;
(function (Dashboard) {
    function cleanDashboardData(item) {
        var cleanItem = {
        };
        angular.forEach(item, function (value, key) {
            if(!angular.isString(key) || (!key.startsWith("$") && !key.startsWith("_"))) {
                cleanItem[key] = value;
            }
        });
        return cleanItem;
    }
    Dashboard.cleanDashboardData = cleanDashboardData;
    function decodeURIComponentProperties(hash) {
        if(!hash) {
            return hash;
        }
        var decodeHash = {
        };
        angular.forEach(hash, function (value, key) {
            decodeHash[key] = value ? decodeURIComponent(value) : value;
        });
        return decodeHash;
    }
    Dashboard.decodeURIComponentProperties = decodeURIComponentProperties;
    function onOperationComplete(result) {
        console.log("Completed adding the dashboard with response " + JSON.stringify(result));
    }
    Dashboard.onOperationComplete = onOperationComplete;
})(Dashboard || (Dashboard = {}));
var Dashboard;
(function (Dashboard) {
    function ImportController($scope, $location, $routeParams, workspace, dashboardRepository) {
        $scope.placeholder = "Paste the JSON here for the dashboard configuration to import...";
        $scope.source = $scope.placeholder;
        var options = {
            mode: {
                name: "javascript"
            }
        };
        $scope.codeMirrorOptions = CodeEditor.createEditorSettings(options);
        $scope.isValid = function () {
            return $scope.source && $scope.source !== $scope.placeholder;
        };
        $scope.importJSON = function () {
            var json = [];
            try  {
                json = JSON.parse($scope.source);
            } catch (e) {
                notification("ERROR", "Could not parse the JSON\n" + e);
                json = [];
            }
            var array = [];
            if(angular.isArray(json)) {
                array = json;
            } else {
                if(angular.isObject(json)) {
                    array.push(json);
                }
            }
            if(array.length) {
                angular.forEach(array, function (dash, index) {
                    var counter = index + 1;
                    if(!dash.id) {
                        dash.id = "imported" + counter;
                    }
                    if(!dash.title) {
                        dash.title = "Imported" + counter;
                    }
                    if(!dash.group) {
                        dash.group = "Personal";
                    }
                });
                dashboardRepository.putDashboards(array, "Imported dashboard JSON", Dashboard.onOperationComplete);
                $location.path("/dashboard/edit");
            }
        };
    }
    Dashboard.ImportController = ImportController;
})(Dashboard || (Dashboard = {}));
var Dashboard;
(function (Dashboard) {
    function NavBarController($scope, $routeParams, $location, workspace, dashboardRepository) {
        $scope.activeDashboard = $routeParams['dashboardId'];
        $scope.dashboards = function () {
            return dashboardRepository.dashboards;
        };
        $scope.isActive = function (dash) {
            return workspace.isLinkActive("#/dashboard/id/" + dash.id);
        };
        $scope.isEditing = function () {
            return workspace.isLinkActive("#/dashboard/edit");
        };
        $scope.onTabRenamed = function (dash) {
            dashboardRepository.putDashboards([
                dash
            ], "Renamed dashboard", Dashboard.onOperationComplete);
        };
        setTimeout(updateData, 100);
        function updateData() {
            dashboardRepository.getDashboards(dashboardLoaded);
        }
        function dashboardLoaded(dashboards) {
            Core.$apply($scope);
        }
    }
    Dashboard.NavBarController = NavBarController;
})(Dashboard || (Dashboard = {}));
var Dashboard;
(function (Dashboard) {
    var RectangleLocation = (function () {
        function RectangleLocation(delegate, path, search, hash) {
            this.delegate = delegate;
            this._path = path;
            this._search = search;
            this._hash = hash;
        }
        RectangleLocation.prototype.absUrl = function () {
            return this.protocol() + this.host() + ":" + this.port() + this.path() + this.search();
        };
        RectangleLocation.prototype.hash = function (newHash) {
            if (typeof newHash === "undefined") { newHash = null; }
            if(newHash) {
                this._hash = newHash;
            }
            return this._hash;
        };
        RectangleLocation.prototype.host = function () {
            return this.delegate.host();
        };
        RectangleLocation.prototype.path = function (newPath) {
            if (typeof newPath === "undefined") { newPath = null; }
            if(newPath) {
                this._path = newPath;
            }
            return this._path;
        };
        RectangleLocation.prototype.port = function () {
            return this.delegate.port();
        };
        RectangleLocation.prototype.protocol = function () {
            return this.delegate.port();
        };
        RectangleLocation.prototype.replace = function () {
            return this;
        };
        RectangleLocation.prototype.search = function (parametersMap) {
            if (typeof parametersMap === "undefined") { parametersMap = null; }
            return this._search;
        };
        RectangleLocation.prototype.url = function (newValue) {
            if (typeof newValue === "undefined") { newValue = null; }
            if(newValue) {
            }
            return this.absUrl();
        };
        return RectangleLocation;
    })();
    Dashboard.RectangleLocation = RectangleLocation;    
})(Dashboard || (Dashboard = {}));
var Dashboard;
(function (Dashboard) {
    function ShareController($scope, $location, $routeParams, workspace, dashboardRepository) {
        var id = $routeParams["dashboardId"];
        dashboardRepository.getDashboard(id, onDashboardLoad);
        var options = {
            mode: {
                name: "javascript"
            }
        };
        $scope.codeMirrorOptions = CodeEditor.createEditorSettings(options);
        function onDashboardLoad(dashboard) {
            $scope.dashboard = Dashboard.cleanDashboardData(dashboard);
            $scope.json = {
                "description": "hawtio dashboards",
                "public": true,
                "files": {
                    "dashboards.json": {
                        "content": JSON.stringify($scope.dashboard, null, "  ")
                    }
                }
            };
            $scope.source = JSON.stringify($scope.dashboard, null, "  ");
            Core.$applyNowOrLater($scope);
        }
    }
    Dashboard.ShareController = ShareController;
})(Dashboard || (Dashboard = {}));
var DataTable;
(function (DataTable) {
    var pluginName = 'datatable';
    angular.module(pluginName, [
        'bootstrap', 
        'ngResource', 
        'hawtioCore'
    ]).directive('hawtioDatatable', function (workspace, $timeout, $filter, $compile) {
        return function (scope, element, attrs) {
            var gridOptions = null;
            var data = null;
            var widget = null;
            var timeoutId = null;
            var initialised = false;
            var childScopes = [];
            var rowDetailTemplate = null;
            var rowDetailTemplateId = null;
            var selectedItems = null;
            function updateGrid() {
                Core.$applyNowOrLater(scope);
            }
            function convertToDataTableColumn(columnDef) {
                var data = {
                    mData: columnDef.field,
                    sDefaultContent: ""
                };
                var name = columnDef.displayName;
                if(name) {
                    data["sTitle"] = name;
                }
                var width = columnDef.width;
                if(angular.isNumber(width)) {
                    data["sWidth"] = "" + width + "px";
                } else {
                    if(angular.isString(width) && !width.startsWith("*")) {
                        data["sWidth"] = width;
                    }
                }
                var template = columnDef.cellTemplate;
                if(template) {
                    data["fnCreatedCell"] = function (nTd, sData, oData, iRow, iCol) {
                        var childScope = childScopes[iRow];
                        if(!childScope) {
                            childScope = scope.$new(false);
                            childScopes[iRow] = childScope;
                        }
                        var entity = oData;
                        childScope["row"] = {
                            entity: entity,
                            getProperty: function (name) {
                                return entity[name];
                            }
                        };
                        var elem = $(nTd);
                        elem.html(template);
                        var contents = elem.contents();
                        contents.removeClass("ngCellText");
                        $compile(contents)(childScope);
                    };
                } else {
                    var cellFilter = columnDef.cellFilter;
                    var render = columnDef.render;
                    if(cellFilter && !render) {
                        var filter = $filter(cellFilter);
                        if(filter) {
                            render = function (data, type, full) {
                                return filter(data);
                            };
                        }
                    }
                    if(render) {
                        data["mRender"] = render;
                    }
                }
                return data;
            }
            function destroyChildScopes() {
                angular.forEach(childScopes, function (childScope) {
                    childScope.$destroy();
                });
                childScopes = [];
            }
            function selectHandler(selection) {
                if(selection && selectedItems) {
                    selectedItems.splice(0, selectedItems.length);
                    selectedItems.push(selection);
                    Core.$apply(scope);
                }
            }
            function onTableDataChange(value) {
                gridOptions = value;
                if(gridOptions) {
                    selectedItems = gridOptions.selectedItems;
                    rowDetailTemplate = gridOptions.rowDetailTemplate;
                    rowDetailTemplateId = gridOptions.rowDetailTemplateId;
                    if(widget === null) {
                        var widgetOptions = {
                            selectHandler: selectHandler,
                            disableAddColumns: true,
                            rowDetailTemplateId: rowDetailTemplateId,
                            ignoreColumns: gridOptions.ignoreColumns,
                            flattenColumns: gridOptions.flattenColumns
                        };
                        var rootElement = $(element);
                        var tableElement = rootElement.children("table");
                        if(!tableElement.length) {
                            $("<table class='table table-bordered table-condensed'></table>").appendTo(rootElement);
                            tableElement = rootElement.children("table");
                        }
                        tableElement.removeClass('table-striped');
                        tableElement.addClass('dataTable');
                        var trElement = Core.getOrCreateElements(tableElement, [
                            "thead", 
                            "tr"
                        ]);
                        destroyChildScopes();
                        var columns = [];
                        var columnCounter = 1;
                        var extraLeftColumn = rowDetailTemplate || rowDetailTemplateId;
                        if(extraLeftColumn) {
                            columns.push({
                                "mDataProp": null,
                                "sClass": "control center",
                                "sWidth": "30px",
                                "sDefaultContent": '<i class="icon-plus"></i>'
                            });
                            var th = trElement.children("th");
                            if(th.length < columnCounter++) {
                                $("<th></th>").appendTo(trElement);
                            }
                        }
                        var columnDefs = gridOptions.columnDefs;
                        if(angular.isString(columnDefs)) {
                            columnDefs = scope[columnDefs];
                        }
                        angular.forEach(columnDefs, function (columnDef) {
                            th = trElement.children("th");
                            if(th.length < columnCounter++) {
                                var name = columnDef.displayName || "";
                                $("<th>" + name + "</th>").appendTo(trElement);
                            }
                            columns.push(convertToDataTableColumn(columnDef));
                        });
                        widget = new TableWidget(scope, workspace, columns, widgetOptions);
                        widget.tableElement = tableElement;
                        var sortInfo = gridOptions.sortInfo;
                        if(sortInfo && columnDefs) {
                            var sortColumns = [];
                            var field = sortInfo.field;
                            if(field) {
                                var idx = columnDefs.findIndex({
                                    field: field
                                });
                                if(idx >= 0) {
                                    if(extraLeftColumn) {
                                        idx += 1;
                                    }
                                    var asc = sortInfo.direction || "asc";
                                    asc = asc.toLowerCase();
                                    sortColumns.push([
                                        idx, 
                                        asc
                                    ]);
                                }
                            }
                            if(sortColumns.length) {
                                widget.sortColumns = sortColumns;
                            }
                        }
                        if(columns.every(function (col) {
                            return col.sWidth;
                        })) {
                            widget.dataTableConfig.bAutoWidth = false;
                        }
                        var filterText = null;
                        var filterOptions = gridOptions.filterOptions;
                        if(filterOptions) {
                            filterText = filterOptions.filterText;
                        }
                        if(filterText || (angular.isDefined(gridOptions.showFilter) && !gridOptions.showFilter)) {
                            widget.dataTableConfig.sDom = 'Rlrtip';
                        }
                        if(filterText) {
                            scope.$watch(filterText, function (value) {
                                var dataTable = widget.dataTable;
                                if(dataTable) {
                                    dataTable.fnFilter(value);
                                }
                            });
                        }
                        if(angular.isDefined(gridOptions.displayFooter) && !gridOptions.displayFooter && widget.dataTableConfig.sDom) {
                            widget.dataTableConfig.sDom = widget.dataTableConfig.sDom.replace('i', '');
                        }
                    }
                    if(!data) {
                        data = gridOptions.data;
                        if(data) {
                            var listener = function (value) {
                                if(initialised || (value && (!angular.isArray(value) || value.length))) {
                                    initialised = true;
                                    destroyChildScopes();
                                    widget.populateTable(value);
                                    updateLater();
                                }
                            };
                            scope.$watch(data, listener);
                            scope.$on("hawtio.datatable." + data, function (args) {
                                var value = Core.pathGet(scope, data);
                                listener(value);
                            });
                        }
                    }
                }
                updateGrid();
            }
            scope.$watch(attrs.hawtioDatatable, onTableDataChange);
            function updateLater() {
                timeoutId = $timeout(function () {
                    updateGrid();
                }, 300);
            }
            element.bind('$destroy', function () {
                destroyChildScopes();
                $timeout.cancel(timeoutId);
            });
            updateLater();
        }
    }).run(function (helpRegistry) {
        helpRegistry.addDevDoc(pluginName, 'app/datatable/doc/developer.md');
    });
    hawtioPluginLoader.addModule(pluginName);
})(DataTable || (DataTable = {}));
var Fabric;
(function (Fabric) {
    function AssignProfilesController($scope, jolokia, $location) {
        $scope.defaultVersion = jolokia.execute(Fabric.managerMBean, "defaultVersion()");
        $scope.version = {
            id: $scope.defaultVersion.id
        };
        $scope.versions = [];
        $scope.profiles = [];
        $scope.containers = [];
        $scope.versionResponse = [];
        $scope.profileIds = [];
        $scope.containerIds = [];
        $scope.selectedProfiles = [];
        $scope.selectedContainers = [];
        $scope.showApply = false;
        $scope.profileGridOptions = {
            data: 'profiles',
            selectedItems: $scope.selectedProfiles,
            showSelectionCheckbox: true,
            multiSelect: true,
            keepLastSelected: false,
            columnDefs: [
                {
                    field: 'id',
                    displayName: 'Profile Name'
                }
            ],
            sortInfo: {
                fields: [
                    'id'
                ],
                directions: [
                    'asc'
                ]
            },
            filterOptions: {
                filterText: ''
            }
        };
        $scope.containerGridOptions = {
            data: 'containers',
            selectedItems: $scope.selectedContainers,
            showSelectionCheckbox: true,
            multiSelect: true,
            keepLastSelected: false,
            columnDefs: [
                {
                    field: 'id',
                    displayName: 'Container Name'
                }
            ],
            sortInfo: {
                fields: [
                    'id'
                ],
                directions: [
                    'asc'
                ]
            },
            filterOptions: {
                filterText: ''
            }
        };
        $scope.canApply = function () {
            return !($scope.selectedProfiles.length > 0 && $scope.selectedContainers.length > 0);
        };
        $scope.applyProfiles = function () {
            var containerIds = $scope.selectedContainers.map(function (container) {
                return container.id;
            });
            var profileIds = $scope.selectedProfiles.map(function (profile) {
                return profile.id;
            });
            var versionId = $scope.version.id;
            notification('info', "Applying profiles to containers");
            $location.path("/fabric/containers");
            Fabric.applyProfiles(jolokia, versionId, profileIds, containerIds, function () {
                notification('success', "Successfully applied profiles");
            }, function (response) {
                notification('error', "Failed to apply profiles due to " + response.error);
            });
        };
        $scope.render = function (response) {
            switch(response.request.operation) {
                case 'versions()': {
                    if(!Object.equal($scope.versionResponse, response.value)) {
                        $scope.versionResponse = response.value;
                        $scope.versions = response.value.map(function (version) {
                            var v = {
                                id: version.id,
                                'defaultVersion': version.defaultVersion
                            };
                            if(v['defaultVersion']) {
                                $scope.defaultVersion = v;
                            }
                            return v;
                        });
                        $scope.version = Fabric.setSelect($scope.version, $scope.versions);
                        $scope.$apply();
                    }
                    break;

                }
                case 'getProfileIds(java.lang.String)': {
                    if(!Object.equal($scope.profileIds, response.value)) {
                        $scope.profileIds = response.value;
                        $scope.profiles = [];
                        $scope.profileIds.each(function (profile) {
                            $scope.profiles.push({
                                id: profile
                            });
                        });
                        $scope.$apply();
                    }
                    break;

                }
                case 'containerIdsForVersion(java.lang.String)': {
                    if(!Object.equal($scope.containerIds, response.value)) {
                        $scope.containerIds = response.value;
                        $scope.containers = [];
                        $scope.containerIds.each(function (container) {
                            $scope.containers.push({
                                id: container
                            });
                        });
                        $scope.$apply();
                    }
                    break;

                }
            }
        };
        $scope.$watch('version', function (oldValue, newValue) {
            if(oldValue === newValue) {
                notification('info', "Please wait, fetching data for version " + $scope.version.id);
            }
            Core.unregister(jolokia, $scope);
            Core.register(jolokia, $scope, [
                {
                    type: 'exec',
                    mbean: Fabric.managerMBean,
                    operation: 'versions()'
                }, 
                {
                    type: 'exec',
                    mbean: Fabric.managerMBean,
                    operation: 'getProfileIds(java.lang.String)',
                    arguments: [
                        $scope.version.id
                    ]
                }, 
                {
                    type: 'exec',
                    mbean: Fabric.managerMBean,
                    operation: 'containerIdsForVersion(java.lang.String)',
                    arguments: [
                        $scope.version.id
                    ]
                }
            ], onSuccess($scope.render));
        });
    }
    Fabric.AssignProfilesController = AssignProfilesController;
})(Fabric || (Fabric = {}));
var Fabric;
(function (Fabric) {
    function ClusterController($scope, $location, $routeParams, workspace, jolokia) {
        $scope.path = $routeParams["page"] || "/";
        if(!$scope.path.startsWith("/")) {
            $scope.path = "/" + $scope.path;
        }
        $scope.gridOptions = {
            data: 'children',
            displayFooter: false,
            sortInfo: {
                fields: [
                    'name'
                ],
                directions: [
                    'asc'
                ]
            },
            columnDefs: [
                {
                    field: 'name',
                    displayName: 'Name',
                    cellTemplate: '<div class="ngCellText"><a href="{{childLink(row.entity)}}"><i class="{{row | fileIconClass}}"></i> {{row.getProperty(col.field)}}</a></div>',
                    cellFilter: ""
                }
            ]
        };
        $scope.isTabActive = function (href) {
            var tidy = Core.trimLeading(href, "#");
            var loc = $location.path();
            return loc === tidy;
        };
        $scope.childLink = function (child) {
            var prefix = "#/fabric/clusters/" + Core.trimLeading($scope.path, "/") + "/";
            var postFix = "";
            var path = child.name;
            return Core.createHref($location, prefix + path + postFix);
        };
        $scope.$watch('workspace.tree', function () {
            setTimeout(updateView, 50);
        });
        $scope.$on("$routeChangeSuccess", function (event, current, previous) {
            setTimeout(updateView, 50);
        });
        updateView();
        function updateView() {
            loadBreadcrumbs();
            var mbean = Fabric.getZooKeeperFacadeMBean(workspace);
            if(mbean) {
                jolokia.execute(mbean, "read", $scope.path, onSuccess(onContents));
            }
        }
        function onContents(contents) {
            $scope.children = [];
            $scope.stringData = null;
            $scope.html = null;
            if(contents) {
                angular.forEach(contents.children, function (childName) {
                    $scope.children.push({
                        name: childName
                    });
                });
                if(!$scope.children.length) {
                    var stringData = contents.stringData;
                    if(stringData) {
                        $scope.stringData = stringData;
                        var json = Core.tryParseJson(stringData);
                        if(json) {
                            $scope.html = Core.valueToHtml(json);
                        } else {
                            $scope.html = stringData;
                        }
                    }
                }
            }
            Core.$apply($scope);
        }
        function loadBreadcrumbs() {
            var href = "#/fabric/clusters";
            $scope.breadcrumbs = [
                {
                    href: href + "/",
                    name: "/"
                }
            ];
            var path = $scope.path;
            var array = path ? path.split("/") : [];
            angular.forEach(array, function (name) {
                if(name) {
                    if(!name.startsWith("/") && !href.endsWith("/")) {
                        href += "/";
                    }
                    href += name;
                    $scope.breadcrumbs.push({
                        href: href,
                        name: name
                    });
                }
            });
        }
    }
    Fabric.ClusterController = ClusterController;
})(Fabric || (Fabric = {}));
var Fabric;
(function (Fabric) {
    function ContainerController($scope, workspace, $routeParams, jolokia) {
        $scope.containerId = $routeParams.containerId;
        $scope.profileQuery = [
            null, 
            [
                "id"
            ]
        ];
        $scope.profiles = [];
        $scope.addProfileArray = [];
        $scope.connect = function () {
            var userName = "admin";
            var password = "admin";
            Fabric.connect($scope.row, userName, password, true);
        };
        $scope.stop = function () {
            Fabric.stopContainer(jolokia, $scope.containerId, function () {
                console.log("Stopped!");
            }, function () {
                console.log("Failed to stop!");
            });
        };
        $scope.delete = function () {
            Fabric.destroyContainer(jolokia, $scope.containerId, function () {
                console.log("Deleted!");
            }, function () {
                console.log("Failed to delete!");
            });
        };
        $scope.start = function () {
            Fabric.startContainer(jolokia, $scope.containerId, function () {
                console.log("Started!");
            }, function () {
                console.log("Failed to start!");
            });
        };
        $scope.getType = function () {
            if($scope.row) {
                if($scope.row.ensembleServer) {
                    return "Fabric Server";
                } else {
                    if($scope.row.managed) {
                        return "Managed Container";
                    } else {
                        return "Unmanaged Container";
                    }
                }
            }
            return "";
        };
        $scope.profilesGridOptions = {
            data: 'profileIdArray',
            selectedItems: [],
            afterSelectionChange: function () {
                $scope.profileIdHtml = "";
                angular.forEach($scope.profilesGridOptions.selectedItems, function (object) {
                    $scope.profileIdHtml += "<li>" + object.id + "</li>";
                });
            },
            showSelectionCheckbox: true,
            multiSelect: true,
            selectWithCheckboxOnly: true,
            keepLastSelected: false,
            columnDefs: [
                {
                    field: 'id',
                    displayName: 'Profiles',
                    cellTemplate: '<div class="ngCellText"><a href="#/fabric/profile/{{versionId}}/{{row.entity.id}}{{hash}}">{{row.entity.id}}</a></div>'
                }
            ]
        };
        $scope.addProfileGridOptions = {
            data: 'addProfileArray',
            selectedItems: [],
            showSelectionCheckbox: true,
            multiSelect: true,
            selectWithCheckboxOnly: false,
            keepLastSelected: false,
            columnDefs: [
                {
                    field: 'id',
                    displayName: 'Name'
                }
            ]
        };
        $scope.addProfiles = function () {
            console.log("Adding profiles: " + $scope.addProfileGridOptions.selectedItems);
            var containerIds = [
                $scope.containerId
            ];
            var profileIds = $scope.row.profileIds;
            angular.forEach($scope.addProfileGridOptions.selectedItems, function (object) {
                profileIds.push(object.id);
            });
            profileIds = profileIds.unique();
            var versionId = $scope.versionId;
            var text = Core.maybePlural($scope.addProfileGridOptions.selectedItems.length, "profile");
            Fabric.applyProfiles(jolokia, versionId, profileIds, containerIds, function () {
                notification('success', "Successfully added " + text);
            }, function (response) {
                notification('error', "Failed to add " + text + " due to " + response.error);
            });
        };
        $scope.deleteProfiles = function () {
            var containerIds = [
                $scope.containerId
            ];
            var profileIds = $scope.row.profileIds;
            angular.forEach($scope.profilesGridOptions.selectedItems, function (object) {
                profileIds = profileIds.remove(object.id);
            });
            var versionId = $scope.versionId;
            var text = Core.maybePlural($scope.profilesGridOptions.selectedItems.length, "profile");
            Fabric.applyProfiles(jolokia, versionId, profileIds, containerIds, function () {
                notification('success', "Successfully removed " + text);
            }, function (response) {
                notification('error', "Failed to remove " + text + " due to " + response.error);
            });
        };
        if(angular.isDefined($scope.containerId)) {
            Core.register(jolokia, $scope, {
                type: 'exec',
                mbean: Fabric.managerMBean,
                operation: 'getContainer(java.lang.String)',
                arguments: [
                    $scope.containerId
                ]
            }, onSuccess(render));
        }
        function render(response) {
            if(!Object.equal($scope.row, response.value)) {
                $scope.row = response.value;
                if($scope.row) {
                    var versionId = $scope.row.versionId;
                    if(versionId) {
                        $scope.versionId = versionId;
                        $scope.profileQuery[0] = versionId;
                        if(!$scope.registeredProfiles) {
                            $scope.registeredProfiles = true;
                            Core.register(jolokia, $scope, {
                                type: 'exec',
                                mbean: Fabric.managerMBean,
                                operation: 'getProfiles(java.lang.String, java.util.List)',
                                arguments: $scope.profileQuery
                            }, onSuccess(onProfiles));
                        }
                    }
                    var profileIds = $scope.row.profileIds;
                    $scope.profileIdArray = profileIds ? profileIds.map(function (value) {
                        return {
                            id: value,
                            versionId: versionId
                        };
                    }) : [];
                    $scope.services = Fabric.getServiceList($scope.row);
                    updateAddProfiles();
                }
            }
        }
        function onProfiles(response) {
            if(response.value) {
                $scope.profiles = response.value;
            }
            updateAddProfiles();
        }
        function updateAddProfiles() {
            var newData = $scope.profiles.filter(function (object) {
                return !$scope.profileIdArray.find({
                    id: object.id
                });
            });
            $scope.addProfileArray = newData;
            Core.$apply($scope);
        }
    }
    Fabric.ContainerController = ContainerController;
})(Fabric || (Fabric = {}));
var Fabric;
(function (Fabric) {
    function ContainersController($scope, $location, workspace, jolokia) {
        $scope.profile = empty();
        $scope.version = empty();
        var key = $location.search()['cv'];
        if(key) {
            $scope.version = {
                id: key
            };
        }
        key = $location.search()['cp'];
        if(key) {
            $scope.profile = {
                id: key
            };
        }
        $scope.result = [];
        $scope.containers = [];
        $scope.profiles = [];
        $scope.versions = [];
        $scope.selectedContainers = [];
        $scope.stopContainer = function (name) {
            Fabric.stopContainer(jolokia, name, function () {
                notification('success', "Stopped " + name);
            }, function (response) {
                notification('error', "Failed to stop " + name + " due to " + response.error);
                console.log("Failed to stop " + name);
            });
        };
        $scope.extractSelected = function () {
            var rc = [];
            $scope.selectedContainers.forEach(function (container) {
                rc.push(container.name);
            });
            $scope.selectedContainers.splice(0, $scope.selectedContainers.length);
            return rc;
        };
        $scope.stop = function () {
            $scope.extractSelected().forEach(function (name) {
                $scope.stopContainer(name);
            });
        };
        $scope.deleteContainer = function (name) {
            Fabric.destroyContainer(jolokia, name, function () {
                notification('success', "Deleted " + name);
            }, function (response) {
                notification('error', "Failed to delete " + name + " due to " + response.error);
            });
        };
        $scope.delete = function () {
            $scope.extractSelected().forEach(function (name) {
                $scope.deleteContainer(name);
            });
        };
        $scope.startContainer = function (name) {
            Fabric.startContainer(jolokia, name, function () {
                notification('success', "Started " + name);
            }, function (response) {
                notification('error', "Failed to start " + name + " due to " + response.error);
            });
        };
        $scope.start = function () {
            $scope.extractSelected().forEach(function (name) {
                $scope.startContainer(name);
            });
        };
        $scope.connect = function (row) {
            if(row) {
                var userName = "admin";
                var password = "admin";
                Fabric.connect(row, userName, password, true);
            }
        };
        $scope.anySelectionAlive = function (state) {
            var selected = $scope.selectedContainers || [];
            return selected.length && selected.any(function (s) {
                return s.alive === state;
            });
        };
        $scope.everySelectionAlive = function (state) {
            var selected = $scope.selectedContainers || [];
            return selected.length && selected.every(function (s) {
                return s.alive === state;
            });
        };
        $scope.statusIcon = function (row) {
            if(row) {
                if(row.alive) {
                    switch(row.provisionResult) {
                        case 'success': {
                            return "green icon-play-circle";

                        }
                        case 'downloading': {
                            return "icon-download-alt";

                        }
                        case 'installing': {
                            return "icon-hdd";

                        }
                        case 'analyzing':
                        case 'finalizing': {
                            return "icon-refresh icon-spin";

                        }
                        case 'resolving': {
                            return "icon-sitemap";

                        }
                        case 'error': {
                            return "red icon-warning-sign";

                        }
                    }
                } else {
                    return "orange icon-off";
                }
            }
            return "icon-refresh icon-spin";
        };
        $scope.containerOptions = {
            data: 'containers',
            showFilter: false,
            showColumnMenu: false,
            filterOptions: {
                filterText: ''
            },
            selectedItems: $scope.selectedContainers,
            rowHeight: 32,
            showSelectionCheckbox: true,
            selectWithCheckboxOnly: true,
            keepLastSelected: false,
            multiSelect: true,
            columnDefs: [
                {
                    field: 'status',
                    displayName: 'Status',
                    cellTemplate: '<div class="ngCellText pagination-centered"><i class="icon1point5x {{row.getProperty(col.field)}}"></i></div>',
                    width: 56,
                    resizable: false
                }, 
                {
                    field: 'jolokiaUrl',
                    displayName: 'Connect',
                    headerCellTemplate: '<div ng-click="col.sort()" class="ngHeaderSortColumn {{col.headerClass}}" ng-style="{\'cursor\': col.cursor}" ng-class="{ \'ngSorted\': !noSortVisible }"><div class="ngHeaderText colt{{$index}} pagination-centered" title="Connect to container"><i class="icon-cloud"></i></div><div class="ngSortButtonDown" ng-show="col.showSortButtonDown()"></div><div class="ngSortButtonUp" ng-show="col.showSortButtonUp()"></div></div>',
                    cellTemplate: '<div class="ngCellText pagination-centered"><a href="" ng-show="row.entity.jolokiaUrl" title="Open a new window and connect to this container" ng-click="connect(row.entity)"><i class="icon-signin"></i></a></div>',
                    width: 48
                }, 
                {
                    field: 'name',
                    displayName: 'Name',
                    cellTemplate: '<div class="ngCellText"><a href="#/fabric/container/{{row.getProperty(col.field)}}{{hash}}">{{row.getProperty(col.field)}}</a></div>',
                    width: 200
                }, 
                {
                    field: 'version',
                    displayName: 'Version',
                    cellTemplate: '<div class="ngCellText pagination-centered"><a href="#/fabric/profiles?pv={{row.getProperty(col.field)}}">{{row.getProperty(col.field)}}</a></div>',
                    width: 70
                }, 
                {
                    field: 'services',
                    displayName: 'Services',
                    cellTemplate: '<div class="ngCellText"><ul class="unstyled inline"><li ng-repeat="service in row.getProperty(col.field)" ng-switch="service.type"><i ng-switch-when="icon" class="{{service.src}}" title="{{service.title}}"></i><img ng-switch-when="img" ng-src="{{service.src}}" title="{{service.title}}"></li></ul>',
                    width: 200
                }, 
                {
                    field: 'profileIds',
                    displayName: 'Profiles',
                    cellTemplate: '<div style="whitespace: wrap;" class="ngCellText"><ul class="inline unstyled"><li ng-repeat="profile in row.getProperty(col.field)"><a ng-href="#/fabric/profile/{{row.entity.version}}/{{profile}}">{{profile}}</a></li></div>',
                    width: 900
                }
            ]
        };
        Core.register(jolokia, $scope, {
            type: 'exec',
            mbean: Fabric.managerMBean,
            operation: 'containers(java.util.List)',
            arguments: [
                [
                    "id", 
                    "alive", 
                    "versionId", 
                    "profileIds", 
                    "jmxDomains", 
                    "alive", 
                    "provisionResult", 
                    "jolokiaUrl"
                ]
            ]
        }, onSuccess(render));
        function empty() {
            return [
                {
                    id: ""
                }
            ];
        }
        function activeProfilesForVersion(version, containers) {
            if(version === "") {
                return activeProfiles(containers);
            }
            var answer = empty();
            containers.findAll(function (container) {
                return container.version === version;
            }).forEach(function (container) {
                answer = answer.union(container.profileIds.map(function (id) {
                    return {
                        id: id
                    };
                }));
            });
            return answer;
        }
        function activeProfiles(containers) {
            var answer = empty();
            containers.forEach(function (container) {
                answer = answer.union(container.profileIds.map(function (id) {
                    return {
                        id: id
                    };
                }));
            });
            return answer;
        }
        function render(response) {
            if(!Object.equal($scope.result, response.value)) {
                $scope.result = response.value;
                $scope.containers = [];
                $scope.profiles = empty();
                $scope.versions = empty();
                $scope.result.forEach(function (container) {
                    var services = Fabric.getServiceList(container);
                    $scope.profiles = $scope.profiles.union(container.profileIds.map(function (id) {
                        return {
                            id: id
                        };
                    }));
                    $scope.versions = $scope.versions.union([
                        {
                            id: container.versionId
                        }
                    ]);
                    $scope.containers.push({
                        name: container.id,
                        alive: container.alive,
                        version: container.versionId,
                        status: $scope.statusIcon(container),
                        services: services,
                        profileIds: container.profileIds,
                        jolokiaUrl: container.jolokiaUrl
                    });
                });
                $scope.version = Fabric.setSelect($scope.version, $scope.versions);
                $scope.profiles = activeProfilesForVersion($scope.version.id, $scope.containers);
                $scope.profile = Fabric.setSelect($scope.profile, $scope.profiles);
                $scope.$apply();
            }
        }
    }
    Fabric.ContainersController = ContainersController;
})(Fabric || (Fabric = {}));
var Fabric;
(function (Fabric) {
    function CreateContainerController($scope, $window, $location, workspace, jolokia, localStorage) {
        $scope.versionsOp = 'versions()';
        $scope.activeTab = 'org_fusesource_fabric_api_CreateContainerChildOptions';
        $scope.schema = {
        };
        $scope.entity = {
        };
        $scope.response = {
        };
        $scope.versions = [];
        $scope.profiles = [];
        $scope.selectedVersion = undefined;
        $scope.selectedProfiles = [];
        $scope.selectedProfileIds = '';
        $scope.selectedVersionId = '';
        $scope.profileIdFilter = '';
        $scope.showAddProfileDialog = false;
        $scope.init = function () {
            var tab = $location.search()['tab'];
            if(tab) {
                switch(tab) {
                    case 'child': {
                        $scope.activeTab = 'org_fusesource_fabric_api_CreateContainerChildOptions';
                        break;

                    }
                    case 'ssh': {
                        $scope.activeTab = 'org_fusesource_fabric_api_CreateSshContainerOptions';
                        break;

                    }
                    case 'cloud': {
                        $scope.activeTab = 'org_fusesource_fabric_api_CreateJCloudsContainerOptions';
                        break;

                    }
                    default: {
                        $scope.activeTab = 'org_fusesource_fabric_api_CreateContainerChildOptions';

                    }
                }
            }
            var parentId = $location.search()['parentId'];
            if(parentId) {
                $scope.entity['parent'] = parentId;
            }
            var versionId = $location.search()['versionId'];
            if(versionId) {
                $scope.selectedVersionId = versionId;
            }
            var profileIds = $location.search()['profileIds'];
            if(profileIds) {
                $scope.selectedProfileIds = profileIds;
            }
        };
        $scope.init();
        $scope.$on('$routeUpdate', $scope.init);
        $scope.$watch('versions', function (newValue, oldValue) {
            if(newValue !== oldValue) {
                if(!$scope.selectedVersion) {
                    if($scope.selectedVersionId !== '') {
                        $scope.selectedVersion = $scope.versions.find(function (v) {
                            return v.id === $scope.selectedVersionId;
                        });
                    } else {
                        $scope.selectedVersion = $scope.versions.find(function (v) {
                            return v.defaultVersion;
                        });
                    }
                }
            }
        });
        $scope.$watch('selectedVersion', function (newValue, oldValue) {
            if(oldValue !== newValue) {
                $scope.selectedVersionId = $scope.selectedVersion.id;
                $scope.profiles = $scope.selectedVersion.profiles.map(function (p) {
                    return {
                        id: p
                    };
                });
                $location.search('versionId', $scope.selectedVersionId);
            }
        }, true);
        $scope.$watch('profiles', function (newValue, oldValue) {
            if(oldValue !== newValue) {
                var sp = $scope.selectedProfileIds.split(',');
                newValue.each(function (profile) {
                    if(!angular.isDefined(profile.selected)) {
                        var selected = false;
                        if(oldValue) {
                            var p = oldValue.find(function (p) {
                                return p.id === profile.id;
                            });
                            if(p) {
                                selected = p.selected;
                            }
                        }
                        if(!selected && sp.length > 0) {
                            selected = sp.any(profile.id);
                        }
                        profile.selected = selected;
                    }
                });
            }
        });
        $scope.$watch('profiles', function (newValue, oldValue) {
            if(newValue !== oldValue) {
                $scope.selectedProfiles = $scope.profiles.filter(function (p) {
                    return p.selected;
                });
            }
        }, true);
        $scope.$watch('selectedProfiles', function (newValue, oldValue) {
            if(oldValue !== newValue) {
                $scope.selectedProfileIds = $scope.selectedProfiles.map(function (p) {
                    return p.id;
                }).join(',');
            }
        }, true);
        $scope.$watch('selectedProfileIds', function (newValue, oldValue) {
            $location.search('profileIds', $scope.selectedProfileIds);
        });
        $scope.render = function (response) {
            if(!Object.equal($scope.response, response.value)) {
                $scope.response = response.value;
                $scope.versions = Object.clone($scope.response);
                $scope.$apply();
            }
        };
        $scope.renderForm = function () {
            $scope.schema = Object.extended($window[$scope.activeTab]).clone();
            $scope.schema.description = '';
            angular.forEach($scope.schema.properties, function (value, key) {
                if(!value) {
                    delete $scope.schema.properties[key];
                }
            });
            $scope.entity['number'] = 1;
            delete $scope.schema.properties['metadataMap'];
            delete $scope.schema.properties['zookeeperUrl'];
            delete $scope.schema.properties['zookeeperPassword'];
            $scope.schema.properties['providerType']['type'] = 'hidden';
            switch($scope.activeTab) {
                case 'org_fusesource_fabric_api_CreateContainerChildOptions': {
                    $scope.entity['providerType'] = 'child';
                    $scope.entity['jmxUser'] = localStorage['fabric.userName'];
                    $scope.entity['jmxPassword'] = localStorage['fabric.password'];
                    $scope.schema.properties['jmxPassword']['type'] = 'password';
                    $scope.schema.properties['saveJmxCredentials'] = {
                        'type': 'boolean'
                    };
                    delete $scope.schema.properties['preferredAddress'];
                    delete $scope.schema.properties['resolver'];
                    delete $scope.schema.properties['ensembleServer'];
                    delete $scope.schema.properties['proxyUri'];
                    delete $scope.schema.properties['adminAccess'];
                    $location.search('tab', 'child');
                    break;

                }
                case 'org_fusesource_fabric_api_CreateSshContainerOptions': {
                    $scope.entity['providerType'] = 'ssh';
                    delete $scope.schema.properties['parent'];
                    $location.search('tab', 'ssh');
                    break;

                }
                case 'org_fusesource_fabric_api_CreateJCloudsContainerOptions': {
                    $scope.entity['providerType'] = 'jclouds';
                    delete $scope.schema.properties['parent'];
                    $location.search('tab', 'cloud');
                    break;

                }
            }
        };
        $scope.onSubmit = function (json, form) {
            if($scope.entity.saveJmxCredentials) {
                localStorage['fabric.userName'] = $scope.entity.jmxUser;
                localStorage['fabric.password'] = $scope.entity.jmxPassword;
            }
            json['version'] = $scope.selectedVersion.id;
            if($scope.selectedProfiles.length > 0) {
                json['profiles'] = $scope.selectedProfiles.map(function (p) {
                    return p.id;
                });
            }
            jolokia.request({
                type: 'exec',
                mbean: Fabric.managerMBean,
                operation: 'createContainers(java.util.Map)',
                arguments: [
                    JSON.stringify(json)
                ]
            }, {
                success: function (response) {
                    var error = false;
                    angular.forEach(response.value, function (value, key) {
                        error = true;
                        notification('error', "Creating container " + key + " failed: " + value);
                    });
                    if(!error) {
                        notification('success', "Successfully created containers");
                    }
                    $scope.$apply();
                },
                error: function (response) {
                    notification('error', "Error creating containers: " + response.error);
                    $scope.$apply();
                }
            });
            notification('info', "Requesting that new container(s) be created");
            $location.url('/fabric/view');
        };
        $scope.$watch('activeTab', $scope.renderForm);
        Core.register(jolokia, $scope, [
            {
                type: 'exec',
                mbean: Fabric.managerMBean,
                operation: $scope.versionsOp
            }
        ], onSuccess($scope.render));
    }
    Fabric.CreateContainerController = CreateContainerController;
})(Fabric || (Fabric = {}));
var Fabric;
(function (Fabric) {
    Fabric.jmxDomain = 'org.fusesource.fabric';
    angular.module('fabric', [
        'bootstrap', 
        'ui.bootstrap', 
        'ui.bootstrap.dialog', 
        'ngResource', 
        'ngGrid', 
        'hawtio-forms', 
        'hawtioCore', 
        'ngDragDrop'
    ]).config(function ($routeProvider) {
        $routeProvider.when('/fabric/containers/createContainer', {
            templateUrl: 'app/fabric/html/createContainer.html',
            reloadOnSearch: false
        }).when('/fabric/map', {
            templateUrl: 'app/fabric/html/map.html'
        }).when('/fabric/clusters/*page', {
            templateUrl: 'app/fabric/html/clusters.html'
        }).when('/fabric/container/:containerId', {
            templateUrl: 'app/fabric/html/container.html'
        }).when('/fabric/profile/:versionId/:profileId', {
            templateUrl: 'app/fabric/html/profile.html'
        }).when('/fabric/profile/:versionId/:profileId/:fname', {
            templateUrl: 'app/fabric/html/pid.html'
        }).when('/fabric/view', {
            templateUrl: 'app/fabric/html/fabricView.html',
            reloadOnSearch: false
        });
    }).run(function ($location, workspace, jolokia, viewRegistry, pageTitle) {
        viewRegistry['fabric'] = "app/fabric/html/layoutFabric.html";
        try  {
            var id = jolokia.getAttribute('org.fusesource.fabric:type=Fabric', 'CurrentContainerName', {
                timeout: 1
            });
            if(id) {
                pageTitle.push(id);
            }
        } catch (e) {
        }
        var isValid = function (workspace) {
            if(workspace.treeContainsDomainAndProperties(Fabric.jmxDomain, {
                type: 'Fabric'
            })) {
                try  {
                    var status = workspace.jolokia.getAttribute(Fabric.managerMBean, 'FabricServiceStatus', {
                        timeout: 1
                    });
                    if(status) {
                        return status.clientValid && status.clientConnected;
                    }
                } catch (e) {
                }
            }
            return false;
        };
        workspace.topLevelTabs.push({
            content: "Fabric",
            title: "Manage your containers and middleware in a fabric",
            isValid: isValid,
            href: function () {
                return "#/fabric/view";
            },
            isActive: function (workspace) {
                return workspace.isLinkActive("fabric");
            }
        });
    });
    hawtioPluginLoader.addModule('fabric');
})(Fabric || (Fabric = {}));
var Fabric;
(function (Fabric) {
    function FabricViewController($scope, $location, jolokia, localStorage) {
        $scope.containerArgs = [
            "id", 
            "alive", 
            "profileIds", 
            "versionId", 
            "provisionResult", 
            "jolokiaUrl", 
            "root"
        ];
        $scope.versionsOp = 'versions()';
        $scope.containersOp = 'containers(java.util.List)';
        $scope.init = function () {
            $scope.activeVersionId = $location.search()['cv'];
            var profiles = $location.search()['sp'];
            $scope.selectedProfileIds = [];
            if(profiles) {
                $scope.selectedProfileIds = profiles.split(',');
            }
            var containers = $location.search()['sc'];
            $scope.selectedContainerIds = [];
            if(containers) {
                $scope.selectedContainerIds = containers.split(',');
            }
        };
        $scope.init();
        $scope.versions = [];
        $scope.profiles = [];
        $scope.containers = [];
        $scope.activeProfiles = [];
        $scope.selectedVersion = {
        };
        $scope.selectedContainers = [];
        $scope.selectedProfiles = [];
        $scope.selectedActiveProfiles = [];
        $scope.dialogProfiles = [];
        $scope.profileIdFilter = '';
        $scope.activeProfileIdFilter = '';
        $scope.containerIdFilter = '';
        $scope.userName = localStorage['fabric.userName'];
        $scope.password = localStorage['fabric.password'];
        $scope.saveCredentials = false;
        $scope.filterActiveVersion = false;
        $scope.filterActiveProfile = false;
        $scope.deleteVersionDialog = false;
        $scope.deleteProfileDialog = false;
        $scope.createProfileDialog = false;
        $scope.createVersionDialog = false;
        $scope.connectToContainerDialog = false;
        $scope.targetContainer = {
        };
        $scope.createProfileGridOptions = {
            data: 'profiles',
            selectedItems: $scope.selectedParents,
            showSelectionCheckbox: true,
            multiSelect: true,
            selectWithCheckboxOnly: false,
            keepLastSelected: false,
            columnDefs: [
                {
                    field: 'id',
                    displayName: 'Name'
                }
            ]
        };
        $scope.createVersionGridOptions = {
            data: 'versions',
            selectedItems: $scope.selectedParentVersion,
            showSelectionCheckbox: true,
            multiSelect: false,
            selectWithCheckboxOnly: false,
            keepLastSelected: false,
            columnDefs: [
                {
                    field: 'id',
                    displayName: 'Name'
                }
            ]
        };
        $scope.triggerResize = function () {
            setTimeout(function () {
                $('.dialogGrid').trigger('resize');
            }, 10);
        };
        $scope.$watch('createProfileDialog', function () {
            if($scope.createProfileDialog) {
                $scope.triggerResize();
            }
        });
        $scope.$watch('createVersionDialog', function () {
            if($scope.createVersionDialog) {
                $scope.triggerResize();
            }
        });
        $scope.newProfileName = '';
        $scope.newVersionName = '';
        $scope.selectedParents = [];
        $scope.selectedParentVersion = [];
        $scope.$on('$routeUpdate', $scope.init);
        $scope.$watch('activeVersionId', function (oldValue, newValue) {
            if(!$scope.activeVersionId) {
                $scope.activeVersionId = '';
            }
            $scope.profiles = $scope.currentVersionProfiles($scope.activeVersionId);
            if($scope.activeVersionId === '') {
                $scope.profiles = [];
            }
            $location.search('cv', $scope.activeVersionId);
        });
        $scope.$watch('profiles', function (oldValue, newValue) {
            if(oldValue !== newValue) {
                if($scope.profiles.length === 0) {
                    $scope.selectedProfiles = [];
                } else {
                    $scope.selectedProfiles = $scope.profiles.filter(function (p) {
                        return p.selected;
                    });
                }
            }
        }, true);
        $scope.$watch('containers', function (oldValue, newValue) {
            if(oldValue !== newValue) {
                $scope.selectedContainers = $scope.containers.filter(function (c) {
                    return c.selected;
                });
                if($scope.selectedContainers.length > 0) {
                    $scope.activeContainerId = '';
                }
            }
        }, true);
        $scope.$watch('activeProfiles', function (oldValue, newValue) {
            if(oldValue !== newValue) {
                $scope.selectedActiveProfiles = $scope.activeProfiles.filter(function (ap) {
                    return ap.selected;
                });
            }
        }, true);
        $scope.$watch('selectedProfiles', function (oldValue, newValue) {
            if(oldValue !== newValue) {
                var ids = $scope.getSelectedProfileIds().join(',');
                $location.search('sp', ids);
            }
        }, true);
        $scope.$watch('selectedContainers', function (oldValue, newValue) {
            if(oldValue !== newValue) {
                var ids = $scope.getSelectedContainerIds().join(',');
                $location.search('sc', ids);
            }
        }, true);
        $scope.doCreateProfile = function () {
            $scope.createProfileDialog = false;
            var parents = $scope.selectedParents.map(function (profile) {
                return profile.id;
            });
            Fabric.createProfile(jolokia, $scope.activeVersionId, $scope.newProfileName, parents, function () {
                notification('success', "Created profile " + $scope.newProfileName);
                $scope.profileIdFilter = $scope.newProfileName;
                $scope.newProfileName = "";
                $scope.$apply();
            }, function (response) {
                notification('error', "Failed to create profile " + $scope.newProfileName + " due to " + response.error);
                $scope.$apply();
            });
        };
        $scope.doCreateVersion = function () {
            $scope.createVersionDialog = false;
            var success = function (response) {
                notification('success', "Created version " + response.value.id);
                $scope.newVersionName = '';
                $scope.$apply();
            };
            var error = function (response) {
                var msg = "Error creating new version: " + response.error;
                if($scope.newVersionName !== '') {
                    msg = "Error creating " + $scope.newVersionName + " : " + response.error;
                }
                notification('error', msg);
            };
            if($scope.selectedParentVersion.length > 0 && $scope.newVersionName !== '') {
                Fabric.createVersionWithParentAndId(jolokia, $scope.selectedParentVersion[0].id, $scope.newVersionName, success, error);
            } else {
                if($scope.newVersionName !== '') {
                    Fabric.createVersionWithId(jolokia, $scope.newVersionName, success, error);
                } else {
                    Fabric.createVersion(jolokia, success, error);
                }
            }
        };
        $scope.deleteVersion = function () {
            Fabric.deleteVersion(jolokia, $scope.activeVersionId, function () {
                notification('success', "Deleted version " + $scope.version.id);
                $scope.activeVersionId = '';
                $scope.$apply();
            }, function (response) {
                notification('error', "Failed to delete version " + $scope.version.id + " due to " + response.error);
                $scope.$apply();
            });
        };
        $scope.deleteSelectedProfiles = function () {
            $scope.selectedProfiles.each(function (profile) {
                Fabric.deleteProfile(jolokia, $scope.activeVersionId, profile.id, function () {
                    notification('success', "Deleted profile " + profile.id);
                }, function (response) {
                    notification('error', "Failed to delete profile " + profile.id + ' due to ' + response.error);
                });
            });
        };
        $scope.migrateVersion = function (targetName, sourceName) {
            notification('info', "Moving " + targetName + " to " + sourceName);
            Fabric.migrateContainers(jolokia, sourceName, [
                targetName
            ], function () {
                notification('success', "Moved " + targetName + " to version " + sourceName);
            }, function (response) {
                notification('error', "Failed to move " + targetName + " to version " + sourceName + " due to " + response.error);
            });
        };
        $scope.addProfiles = function (targetName, profiles) {
            notification('info', "Adding " + profiles.join(', ') + " to " + targetName);
            Fabric.addProfilesToContainer(jolokia, targetName, profiles, function () {
                notification('success', "Added " + profiles.join(', ') + " to " + targetName);
            }, function (response) {
                notification('error', "Failed to add " + profiles.join(', ') + " to " + targetName + " due to " + response.error);
            });
        };
        $scope.removeActiveProfiles = function () {
            $scope.selectedActiveProfiles.each(function (profile) {
                $scope.removeActiveProfile(profile);
            });
        };
        $scope.removeActiveProfile = function (profile) {
            if($scope.selectedContainers.length > 0) {
                $scope.selectedContainers.each(function (container) {
                    if(container.profileIds.some(profile.id) && container.versionId === profile.versionId) {
                        $scope.removeProfile(container.id, profile.id);
                    }
                });
            } else {
                $scope.removeProfile($scope.activeContainerId, profile.id);
            }
        };
        $scope.removeProfile = function (containerId, profileId) {
            notification('info', "Removing " + profileId + " from " + containerId);
            Fabric.removeProfilesFromContainer(jolokia, containerId, [
                profileId
            ], function () {
                notification('success', "Removed " + profileId + " from " + containerId);
            }, function (response) {
                notification('error', "Failed to remove " + profileId + " from " + containerId + " due to " + response.error);
            });
        };
        $scope.getFilteredName = function (item) {
            return item.versionId + " / " + item.id;
        };
        $scope.filterContainer = function (container) {
            if(!$scope.getFilteredName(container).has($scope.containerIdFilter)) {
                return false;
            }
            if($scope.selectedActiveProfiles.length > 0) {
                if($scope.selectedActiveProfiles.none(function (ap) {
                    return ap.versionId === container.versionId && container.profileIds.some(ap.id);
                })) {
                    return false;
                }
            }
            return true;
        };
        $scope.filterActiveProfile = function (profile) {
            if(!$scope.getFilteredName(profile).has($scope.activeProfileIdFilter)) {
                return false;
            }
            if($scope.filterActiveVersion && $scope.activeVersionId && $scope.activeVersionId !== '' && profile.versionId !== $scope.activeVersionId) {
                return false;
            }
            if($scope.selectedContainers.length > 0) {
                if($scope.selectedContainers.none(function (c) {
                    return c.versionId === profile.versionId && c.profileIds.some(profile.id);
                })) {
                    return false;
                }
            }
            if($scope.activeContainerId && $scope.activeContainerId !== '') {
                if($scope.activeContainerVersion && $scope.activeContainerVersion !== '' && $scope.activeContainerVersion !== profile.versionId) {
                    return false;
                }
                if(!profile.containers.some($scope.activeContainerId)) {
                    return false;
                }
            }
            return true;
        };
        $scope.showMigrateButton = function () {
            return $scope.selectedContainers.length > 0 && $scope.activeVersionId && $scope.activeVersionId !== '';
        };
        $scope.applyVersionToContainers = function () {
            $scope.selectedContainers.each(function (c) {
                $scope.migrateVersion(c.id, $scope.activeVersionId);
            });
        };
        $scope.showProfileAddButton = function () {
            return $scope.selectedProfiles.length > 0 && $scope.selectedContainers.length > 0 && $scope.selectedContainers.every(function (c) {
                return c.versionId === $scope.activeVersionId;
            });
        };
        $scope.addProfilesToContainers = function () {
            var profileIds = $scope.selectedProfiles.map(function (p) {
                return p.id;
            });
            $scope.selectedContainers.each(function (c) {
                $scope.addProfiles(c.id, profileIds);
            });
        };
        $scope.currentVersionProfiles = function (id) {
            if(id === '') {
                return [];
            }
            var version = $scope.versions.find(function (version) {
                return version.id === $scope.activeVersionId;
            });
            if(!version) {
                return [];
            }
            var answer = [];
            version.profiles.each(function (p) {
                var profile = $scope.profiles.find(function (prof) {
                    return p === prof.id;
                });
                var selected = false;
                if(profile && profile.version === version.id) {
                    selected = profile.selected;
                }
                if($scope.selectedProfileIds.any(p)) {
                    selected = true;
                }
                answer.push({
                    id: p,
                    versionId: version.id,
                    selected: selected
                });
            });
            return answer;
        };
        $scope.currentActiveProfiles = function () {
            var answer = [];
            $scope.containers.each(function (container) {
                container.profileIds.each(function (profile) {
                    var activeProfile = answer.find(function (o) {
                        return o.versionId === container.versionId && o.id === profile;
                    });
                    if(activeProfile) {
                        activeProfile.count++;
                        activeProfile.containers = activeProfile.containers.include(container.id).unique();
                    } else {
                        answer.push({
                            id: profile,
                            count: 1,
                            versionId: container.versionId,
                            containers: [
                                container.id
                            ],
                            selected: false
                        });
                    }
                });
            });
            return answer;
        };
        $scope.statusIcon = function (row) {
            if(row) {
                if(row.alive) {
                    switch(row.provisionResult) {
                        case 'success': {
                            return "green icon-play-circle";

                        }
                        case 'downloading': {
                            return "icon-download-alt";

                        }
                        case 'installing': {
                            return "icon-hdd";

                        }
                        case 'analyzing':
                        case 'finalizing': {
                            return "icon-refresh icon-spin";

                        }
                        case 'resolving': {
                            return "icon-sitemap";

                        }
                        case 'error': {
                            return "red icon-warning-sign";

                        }
                    }
                } else {
                    return "orange icon-off";
                }
            }
            return "icon-refresh icon-spin";
        };
        $scope.versionCanBeDeleted = function () {
            return $scope.containers.none(function (c) {
                return c.versionId === $scope.activeVersionId;
            });
        };
        $scope.profilesCanBeDeleted = function () {
            var possibleMatches = $scope.containers.filter(function (c) {
                return c.versionId === $scope.activeVersionId;
            });
            if(possibleMatches.length === 0) {
                return true;
            }
            possibleMatches = possibleMatches.filter(function (c) {
                return $scope.selectedProfiles.some(function (p) {
                    return c.profileIds.some(p.id);
                });
            });
            if(possibleMatches.length === 0) {
                return true;
            }
            return false;
        };
        $scope.doConnect = function (container) {
            $scope.targetContainer = container;
            $scope.connectToContainerDialog = true;
        };
        $scope.connect = function (row) {
            Fabric.connect($scope.targetContainer, $scope.userName, $scope.password, true);
            if($scope.saveCredentials) {
                $scope.saveCredentials = false;
                localStorage['fabric.userName'] = $scope.userName;
                localStorage['fabric.password'] = $scope.password;
            }
            $scope.targetContainer = {
            };
            $scope.connectToContainerDialog = false;
        };
        $scope.getSelectedProfileIds = function () {
            return $scope.getIds($scope.selectedProfiles);
        };
        $scope.getSelectedContainerIds = function () {
            return $scope.getIds($scope.selectedContainers);
        };
        $scope.getIds = function (arr) {
            return arr.map(function (o) {
                return o.id;
            });
        };
        $scope.getStatusTitle = function (container) {
            var answer = 'Alive';
            if(!container.alive) {
                answer = 'Not Running';
            } else {
                answer += ' - ' + humanizeValue(container.provisionResult);
            }
            return answer;
        };
        $scope.containersForVersion = function (id) {
            var count = $scope.containers.findAll(function (container) {
                return container.versionId === id;
            }).length;
            if(count === 0) {
                return '';
            }
            return "(" + count + ")";
        };
        $scope.containersForProfile = function (id) {
            var profile = $scope.currentActiveProfiles().find(function (profile) {
                return profile.versionId === $scope.activeVersionId && profile.id === id;
            });
            if(profile) {
                return "(" + profile.count + ")";
            } else {
                return "";
            }
        };
        $scope.isSelectedVersion = function (id) {
            if($scope.activeVersionId === id) {
                return 'selected';
            }
            return '';
        };
        $scope.getSelectedClass = function (obj) {
            if(obj.selected) {
                return 'selected';
            }
            return '';
        };
        $scope.setActiveVersionId = function (id) {
            $scope.activeVersionId = id;
        };
        $scope.clearSelection = function (group) {
            group.each(function (item) {
                item.selected = false;
            });
        };
        $scope.setActiveProfile = function (profile) {
            $scope.clearSelection($scope.activeProfiles);
            if(!profile || profile === null) {
                return;
            }
            profile.selected = true;
        };
        $scope.selectAllContainers = function () {
            $scope.containers.each(function (container) {
                if($scope.filterContainer(container)) {
                    container.selected = true;
                }
            });
        };
        $scope.setActiveContainer = function (container) {
            $scope.clearSelection($scope.containers);
            if(!container || container === null) {
                return;
            }
            container.selected = true;
        };
        $scope.createContainer = function () {
            $location.url('/fabric/containers/createContainer').search('tab', 'ssh');
        };
        $scope.deleteSelectedContainers = function () {
            $scope.selectedContainers.each(function (c) {
                $scope.deleteContainer(c.id);
            });
        };
        $scope.startSelectedContainers = function () {
            $scope.selectedContainers.each(function (c) {
                $scope.startContainer(c.id);
            });
        };
        $scope.stopSelectedContainers = function () {
            $scope.selectedContainers.each(function (c) {
                $scope.stopContainer(c.id);
            });
        };
        $scope.deleteContainer = function (name) {
            notification('info', "Deleting " + name);
            Fabric.destroyContainer(jolokia, name, function () {
                notification('success', "Deleted " + name);
            }, function (response) {
                notification('error', "Failed to delete " + name + " due to " + response.error);
            });
        };
        $scope.startContainer = function (name) {
            notification('info', "Starting " + name);
            Fabric.startContainer(jolokia, name, function () {
                notification('success', "Started " + name);
            }, function (response) {
                notification('error', "Failed to start " + name + " due to " + response.error);
            });
        };
        $scope.stopContainer = function (name) {
            notification('info', "Stopping " + name);
            Fabric.stopContainer(jolokia, name, function () {
                notification('success', "Stopped " + name);
            }, function (response) {
                notification('error', "Failed to stop " + name + " due to " + response.error);
            });
        };
        $scope.anySelectionAlive = function (state) {
            var selected = $scope.selectedContainers;
            return selected.length > 0 && selected.any(function (s) {
                return s.alive === state;
            });
        };
        $scope.everySelectionAlive = function (state) {
            var selected = $scope.selectedContainers;
            return selected.length > 0 && selected.every(function (s) {
                return s.alive === state;
            });
        };
        $scope.updateVersions = function (newVersions) {
            var response = angular.toJson(newVersions);
            if($scope.versionsResponse !== response) {
                $scope.versionsResponse = response;
                $scope.versions = newVersions;
                if($scope.activeVersion !== '') {
                    $scope.profiles = $scope.currentVersionProfiles($scope.activeVersion);
                }
                Core.$apply($scope);
            }
        };
        $scope.showProfile = function (profile) {
            if(angular.isDefined(profile.versionId)) {
                $location.path('/fabric/profile/' + profile.versionId + '/' + profile.id);
            } else {
                $location.path('/fabric/profile/' + $scope.activeVersionId + '/' + profile.id);
            }
        };
        $scope.showContainer = function (container) {
            $location.path('/fabric/container/' + container.id);
        };
        $scope.createChildContainer = function (container) {
            $location.url('/fabric/containers/createContainer').search({
                'tab': 'child',
                'parentId': container.id
            });
        };
        $scope.updateContainers = function (newContainers) {
            var response = angular.toJson(newContainers);
            if($scope.containersResponse !== response) {
                $scope.containersResponse = response;
                newContainers.each(function (container) {
                    var c = $scope.containers.find(function (c) {
                        return c.id === container.id;
                    });
                    if(c) {
                        container['selected'] = c.selected;
                    } else {
                        container['selected'] = false;
                    }
                    if($scope.selectedContainerIds.any(container.id)) {
                        container.selected = true;
                    }
                });
                $scope.containers = newContainers;
                var activeProfiles = $scope.activeProfiles;
                $scope.activeProfiles = $scope.currentActiveProfiles();
                $scope.activeProfiles.each(function (activeProfile) {
                    var ap = activeProfiles.find(function (ap) {
                        return ap.id === activeProfile.id && ap.versionId === activeProfile.versionId;
                    });
                    if(ap) {
                        activeProfile['selected'] = ap.selected;
                    } else {
                        activeProfile['selected'] = false;
                    }
                });
                Core.$apply($scope);
            }
        };
        $scope.dispatch = function (response) {
            switch(response.request.operation) {
                case ($scope.versionsOp): {
                    $scope.updateVersions(response.value);
                    break;

                }
                case ($scope.containersOp): {
                    $scope.updateContainers(response.value);
                    break;

                }
            }
        };
        Core.register(jolokia, $scope, [
            {
                type: 'exec',
                mbean: Fabric.managerMBean,
                operation: $scope.versionsOp
            }, 
            {
                type: 'exec',
                mbean: Fabric.managerMBean,
                operation: $scope.containersOp,
                arguments: [
                    $scope.containerArgs
                ]
            }
        ], onSuccess($scope.dispatch));
    }
    Fabric.FabricViewController = FabricViewController;
    ; ;
})(Fabric || (Fabric = {}));
var Fabric;
(function (Fabric) {
    Fabric.managerMBean = "org.fusesource.fabric:type=Fabric";
    function initScope($scope, workspace) {
        $scope.hasFabricWiki = function () {
            return Git.isGitMBeanFabric(workspace);
        };
    }
    Fabric.initScope = initScope;
    function setSelect(selection, group) {
        if(!angular.isDefined(selection)) {
            return group[0];
        }
        var answer = group.findIndex(function (item) {
            return item.id === selection.id;
        });
        if(answer !== -1) {
            return group[answer];
        } else {
            return group[0];
        }
    }
    Fabric.setSelect = setSelect;
    function deleteConfigFile(jolokia, version, profile, pid, success, error) {
        doAction('deleteConfigurationFile(java.lang.String, java.lang.String, java.lang.String)', jolokia, [
            version, 
            profile, 
            pid
        ], success, error);
    }
    Fabric.deleteConfigFile = deleteConfigFile;
    function newConfigFile(jolokia, version, profile, pid, success, error) {
        doAction('setConfigurationFile(java.lang.String, java.lang.String, java.lang.String, java.lang.String)', jolokia, [
            version, 
            profile, 
            pid, 
            ''
        ], success, error);
    }
    Fabric.newConfigFile = newConfigFile;
    function saveConfigFile(jolokia, version, profile, pid, data, success, error) {
        doAction('setConfigurationFile(java.lang.String, java.lang.String, java.lang.String, java.lang.String)', jolokia, [
            version, 
            profile, 
            pid, 
            data
        ], success, error);
    }
    Fabric.saveConfigFile = saveConfigFile;
    function addProfilesToContainer(jolokia, container, profiles, success, error) {
        doAction('addProfilesToContainer(java.lang.String, java.util.List)', jolokia, [
            container, 
            profiles
        ], success, error);
    }
    Fabric.addProfilesToContainer = addProfilesToContainer;
    function removeProfilesFromContainer(jolokia, container, profiles, success, error) {
        doAction('removeProfilesFromContainer(java.lang.String, java.util.List)', jolokia, [
            container, 
            profiles
        ], success, error);
    }
    Fabric.removeProfilesFromContainer = removeProfilesFromContainer;
    function applyProfiles(jolokia, version, profiles, containers, success, error) {
        doAction('applyProfilesToContainers(java.lang.String, java.util.List, java.util.List)', jolokia, [
            version, 
            profiles, 
            containers
        ], success, error);
    }
    Fabric.applyProfiles = applyProfiles;
    function migrateContainers(jolokia, version, containers, success, error) {
        doAction('applyVersionToContainers(java.lang.String, java.util.List)', jolokia, [
            version, 
            containers
        ], success, error);
    }
    Fabric.migrateContainers = migrateContainers;
    function createProfile(jolokia, version, id, parents, success, error) {
        doAction('createProfile(java.lang.String, java.lang.String, java.util.List)', jolokia, [
            version, 
            id, 
            parents
        ], success, error);
    }
    Fabric.createProfile = createProfile;
    function copyProfile(jolokia, version, sourceName, targetName, force, success, error) {
        doAction('copyProfile(java.lang.String, java.lang.String, java.lang.String, boolean)', jolokia, [
            version, 
            sourceName, 
            targetName, 
            force
        ], success, error);
    }
    Fabric.copyProfile = copyProfile;
    function createVersionWithParentAndId(jolokia, base, id, success, error) {
        doAction('createVersion(java.lang.String, java.lang.String)', jolokia, [
            base, 
            id
        ], success, error);
    }
    Fabric.createVersionWithParentAndId = createVersionWithParentAndId;
    function createVersionWithId(jolokia, id, success, error) {
        doAction('createVersion(java.lang.String)', jolokia, [
            id
        ], success, error);
    }
    Fabric.createVersionWithId = createVersionWithId;
    function createVersion(jolokia, success, error) {
        doAction('createVersion()', jolokia, [], success, error);
    }
    Fabric.createVersion = createVersion;
    function deleteVersion(jolokia, id, success, error) {
        doAction('deleteVersion(java.lang.String)', jolokia, [
            id
        ], success, error);
    }
    Fabric.deleteVersion = deleteVersion;
    function deleteProfile(jolokia, version, id, success, error) {
        doAction('deleteProfile(java.lang.String, java.lang.String)', jolokia, [
            version, 
            id
        ], success, error);
    }
    Fabric.deleteProfile = deleteProfile;
    function doAction(action, jolokia, arguments, success, error) {
        jolokia.request({
            type: 'exec',
            mbean: Fabric.managerMBean,
            operation: action,
            arguments: arguments
        }, {
            method: 'POST',
            success: success,
            error: error
        });
    }
    Fabric.doAction = doAction;
    function stopContainer(jolokia, id, success, error) {
        doAction('stopContainer(java.lang.String)', jolokia, [
            id
        ], success, error);
    }
    Fabric.stopContainer = stopContainer;
    function destroyContainer(jolokia, id, success, error) {
        doAction('destroyContainer(java.lang.String)', jolokia, [
            id
        ], success, error);
    }
    Fabric.destroyContainer = destroyContainer;
    function startContainer(jolokia, id, success, error) {
        doAction('startContainer(java.lang.String)', jolokia, [
            id
        ], success, error);
    }
    Fabric.startContainer = startContainer;
    function getServiceList(container) {
        var answer = [];
        if(angular.isDefined(container) && angular.isDefined(container.jmxDomains) && angular.isArray(container.jmxDomains)) {
            container.jmxDomains.forEach(function (domain) {
                if(domain === "org.apache.activemq") {
                    answer.push({
                        title: "Apache ActiveMQ",
                        type: "img",
                        src: "app/fabric/img/message_broker.png"
                    });
                }
                if(domain === "org.apache.camel") {
                    answer.push({
                        title: "Apache Camel",
                        type: "img",
                        src: "app/fabric/img/camel.png"
                    });
                }
                if(domain === "org.fusesource.fabric") {
                    answer.push({
                        title: "Fuse Fabric",
                        type: "img",
                        src: "app/fabric/img/fabric.png"
                    });
                }
                if(domain === "hawtio") {
                    answer.push({
                        title: "hawtio",
                        type: "img",
                        src: "app/fabric/img/hawtio.png"
                    });
                }
                if(domain === "org.apache.karaf") {
                    answer.push({
                        title: "Apache Karaf",
                        type: "icon",
                        src: "icon-beaker"
                    });
                }
                if(domain === "org.apache.zookeeper") {
                    answer.push({
                        title: "Apache Zookeeper",
                        type: "icon",
                        src: "icon-group"
                    });
                }
            });
        }
        return answer;
    }
    Fabric.getServiceList = getServiceList;
    function defaultContainerValues(workspace, $scope, values) {
        var map = {
        };
        angular.forEach(values, function (row) {
            var profileIds = row["profileIds"];
            if(profileIds) {
                angular.forEach(profileIds, function (profileId) {
                    var containers = map[profileId];
                    if(!containers) {
                        containers = [];
                        map[profileId] = containers;
                    }
                    containers.push(row);
                });
            }
            $scope.profileMap = map;
            row["link"] = containerLinks(workspace, row["id"]);
            row["profileLinks"] = profileLinks(workspace, row["versionId"], profileIds);
            var versionId = row["versionId"];
            var versionHref = url("#/fabric/profiles?v=" + versionId);
            var versionLink = "<a href='" + versionHref + "'>" + versionId + "</a>";
            row["versionHref"] = versionHref;
            row["versionLink"] = versionLink;
            var id = row['id'] || "";
            var title = "container " + id + " ";
            var img = "red-dot.png";
            if(row['managed'] === false) {
                img = "spacer.gif";
            } else {
                if(!row['alive']) {
                    img = "gray-dot.png";
                } else {
                    if(row['provisionPending']) {
                        img = "pending.gif";
                    } else {
                        if(row['provisionStatus'] === 'success') {
                            img = "green-dot.png";
                        }
                    }
                }
            }
            img = "img/dots/" + img;
            row["statusImageHref"] = img;
            row["link"] = "<img src='" + img + "' title='" + title + "'/> " + (row["link"] || id);
        });
        return values;
    }
    Fabric.defaultContainerValues = defaultContainerValues;
    function toCollection(values) {
        var collection = values;
        if(!angular.isArray(values)) {
            collection = [
                values
            ];
        }
        return collection;
    }
    Fabric.toCollection = toCollection;
    function containerLinks(workspace, values) {
        var answer = "";
        angular.forEach(toCollection(values), function (value, key) {
            var prefix = "";
            if(answer.length > 0) {
                prefix = " ";
            }
            answer += prefix + "<a href='" + url("#/fabric/container/" + value + workspace.hash()) + "'>" + value + "</a>";
        });
        return answer;
    }
    Fabric.containerLinks = containerLinks;
    function profileLinks(workspace, versionId, values) {
        var answer = "";
        angular.forEach(toCollection(values), function (value, key) {
            var prefix = "";
            if(answer.length > 0) {
                prefix = " ";
            }
            answer += prefix + "<a href='" + url("#/fabric/profile/" + versionId + "/" + value + workspace.hash()) + "'>" + value + "</a>";
        });
        return answer;
    }
    Fabric.profileLinks = profileLinks;
    function defaultProfileValues(workspace, versionId, values) {
        angular.forEach(values, function (row) {
            var id = row["id"];
            row["link"] = profileLinks(workspace, versionId, id);
            row["parentLinks"] = profileLinks(workspace, versionId, row["parentIds"]);
            var containersHref = url("#/fabric/containers?p=" + id);
            var containerCount = row["containerCount"];
            var containersLink = "";
            if(containerCount) {
                containersLink = "<a href='" + containersHref + "'>" + containerCount + "</a>";
            }
            row["containersCountLink"] = containersLink;
            row["containersHref"] = containersHref;
        });
        return values;
    }
    Fabric.defaultProfileValues = defaultProfileValues;
    function getZooKeeperFacadeMBean(workspace) {
        var folder = workspace.findMBeanWithProperties(Fabric.jmxDomain, {
            type: "ZooKeeper"
        });
        return Core.pathGet(folder, "objectName");
    }
    Fabric.getZooKeeperFacadeMBean = getZooKeeperFacadeMBean;
    function connect(row, userName, password, useProxy) {
        if (typeof userName === "undefined") { userName = ""; }
        if (typeof password === "undefined") { password = ""; }
        if (typeof useProxy === "undefined") { useProxy = true; }
        var url = row.jolokiaUrl;
        if(url) {
            if(useProxy) {
                var idx = url.indexOf("://");
                if(idx > 0) {
                    url = url.substring(idx + 3);
                }
                url = url.replace(":", "/");
                url = Core.trimLeading(url, "/");
                url = Core.trimTrailing(url, "/");
                url = "/hawtio/proxy/" + url;
            } else {
                if(url.indexOf("://") < 0) {
                    url = "http://" + url;
                }
            }
            console.log("going to server: " + url + " as user " + userName);
            var full = "?url=" + encodeURIComponent(url);
            if(userName) {
                full += "&_user=" + userName;
            }
            if(password) {
                full += "&_pwd=" + password;
            }
            window.open(full + "/#/jmx/attributes?nid=root-java.lang-Runtime");
        }
    }
    Fabric.connect = connect;
})(Fabric || (Fabric = {}));
var Fabric;
(function (Fabric) {
    function MapController($scope, workspace, $routeParams, jolokia) {
        $scope.myMarkers = [];
        $scope.containers = {
        };
        $scope.mapOptions = {
            center: new google.maps.LatLng(35.784, -78.67),
            zoom: 15,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        };
        Core.register(jolokia, $scope, {
            type: 'exec',
            mbean: Fabric.managerMBean,
            operation: 'containers()',
            arguments: []
        }, onSuccess(render));
        $scope.addMarker = function ($event) {
            $scope.myMarkers.push(new google.maps.Marker({
                map: $scope.myMap,
                position: $event.latLng
            }));
        };
        $scope.setZoomMessage = function (zoom) {
            console.log(zoom, 'zoomed');
        };
        $scope.openMarkerInfo = function (marker) {
            $scope.currentMarker = marker;
            $scope.currentMarkerLat = marker.getPosition().lat();
            $scope.currentMarkerLng = marker.getPosition().lng();
            $scope.myInfoWindow.open($scope.myMap, marker);
        };
        $scope.setMarkerPosition = function (marker, lat, lng) {
            marker.setPosition(new google.maps.LatLng(lat, lng));
        };
        function render(response) {
            if(response && response.value) {
                response.value.forEach(function (container) {
                    var addMarker = false;
                    var id = container.id;
                    var containerData = $scope.containers[id];
                    if(!containerData) {
                        containerData = {
                            name: id
                        };
                        $scope.containers[id] = containerData;
                        addMarker = true;
                    }
                    containerData.alive = container.alive;
                    containerData.version = container.versionId;
                    containerData.profileIds = container.profileIds;
                    var geoLocation = container["geoLocation"];
                    if(geoLocation) {
                        var values = geoLocation.split(",");
                        if(values.length >= 2) {
                            var lattitude = Core.parseFloatValue(values[0], "lattitude");
                            var longitude = Core.parseFloatValue(values[1], "longitude");
                            if(lattitude && longitude) {
                                var marker = containerData.marker;
                                if(addMarker || !marker) {
                                    marker = new google.maps.Marker({
                                        map: $scope.myMap,
                                        position: new google.maps.LatLng(lattitude, longitude),
                                        title: container.id
                                    });
                                    containerData.marker = marker;
                                    $scope.myMarkers.push(marker);
                                    if($scope.myMarkers.length === 1) {
                                        if($scope.myMap) {
                                            $scope.myMap.panTo(marker.getPosition());
                                        }
                                    }
                                } else {
                                    if(containerData.marker) {
                                        containerData.marker.position = new google.maps.LatLng(lattitude, longitude);
                                    }
                                }
                                containerData.lattitude = lattitude;
                                containerData.longitude = longitude;
                            }
                        }
                    }
                });
                Core.$apply($scope);
            }
        }
    }
    Fabric.MapController = MapController;
})(Fabric || (Fabric = {}));
var Fabric;
(function (Fabric) {
    function MigrateContainersController($scope, jolokia, $location) {
        $scope.versions = [];
        $scope.containers = [];
        $scope.containersResponse = [];
        $scope.selectedVersion = [];
        $scope.selectedContainers = [];
        $scope.showApply = false;
        $scope.versionGridOptions = {
            data: 'versions',
            selectedItems: $scope.selectedVersion,
            showSelectionCheckbox: true,
            multiSelect: false,
            keepLastSelected: true,
            columnDefs: [
                {
                    field: 'id',
                    displayName: 'Version Name',
                    width: '94%'
                }
            ],
            filterOptions: {
                filterText: ''
            }
        };
        $scope.containerGridOptions = {
            data: 'containers',
            selectedItems: $scope.selectedContainers,
            showSelectionCheckbox: true,
            multiSelect: true,
            keepLastSelected: false,
            columnDefs: [
                {
                    field: 'id',
                    displayName: 'Container Name',
                    width: '94%'
                }
            ],
            filterOptions: {
                filterText: ''
            }
        };
        $scope.canApply = function () {
            return !($scope.selectedVersion.length > 0 && $scope.selectedContainers.length > 0);
        };
        $scope.render = function (response) {
            if(response.request.operation === 'versions()') {
                if(!Object.equal($scope.versions, response.value)) {
                    $scope.versions = response.value;
                    $scope.$apply();
                }
            }
            if(response.request.operation === 'containerIds()') {
                if(!Object.equal($scope.containersResponse, response.value)) {
                    $scope.containersResponse = response.value;
                    $scope.containers = [];
                    $scope.containersResponse.each(function (container) {
                        $scope.containers.push({
                            id: container
                        });
                    });
                    $scope.$apply();
                }
            }
        };
        $scope.migrateContainers = function () {
            var containerIds = $scope.selectedContainers.map(function (container) {
                return container.id;
            });
            var versionId = $scope.selectedVersion[0].id;
            notification('info', "Moving containers to version " + versionId);
            $location.path("/fabric/containers");
            Fabric.migrateContainers(jolokia, versionId, containerIds, function () {
                notification('success', "Successfully migrated containers");
            }, function (response) {
                notification('error', "Failed to migrate containers due to " + response.error);
            });
        };
        Core.register(jolokia, $scope, [
            {
                type: 'exec',
                mbean: Fabric.managerMBean,
                operation: 'versions()'
            }, 
            {
                type: 'exec',
                mbean: Fabric.managerMBean,
                operation: 'containerIds()'
            }
        ], onSuccess($scope.render));
    }
    Fabric.MigrateContainersController = MigrateContainersController;
})(Fabric || (Fabric = {}));
var Fabric;
(function (Fabric) {
    function NavBarController($scope, $location, workspace) {
        $scope.isActive = function (href) {
            return workspace.isLinkActive(href);
        };
        $scope.clusterLink = function () {
            return Core.createHref($location, "#/fabric/clusters/fabric/registry/clusters", [
                "cv", 
                "cp", 
                "pv"
            ]);
        };
    }
    Fabric.NavBarController = NavBarController;
})(Fabric || (Fabric = {}));
var Fabric;
(function (Fabric) {
    function PIDController($scope, $routeParams, jolokia, $location) {
        $scope.versionId = $routeParams.versionId;
        $scope.profileId = $routeParams.profileId;
        $scope.fname = $routeParams.fname;
        $scope.response = undefined;
        $scope.data = "";
        $scope.dirty = false;
        $scope.getMode = function () {
            var parts = $scope.fname.split('.');
            var mode = parts[parts.length - 1];
            if(!mode) {
                return 'text';
            }
            switch(mode) {
                case 'cfg': {
                    mode = "properties";
                    break;

                }
            }
            return mode;
        };
        $scope.mode = $scope.getMode();
        if(angular.isDefined($scope.versionId) && angular.isDefined($scope.profileId) && angular.isDefined($scope.fname)) {
            Core.register(jolokia, $scope, {
                type: 'exec',
                mbean: Fabric.managerMBean,
                operation: 'getConfigurationFile(java.lang.String,java.lang.String,java.lang.String)',
                arguments: [
                    $scope.versionId, 
                    $scope.profileId, 
                    $scope.fname
                ]
            }, onSuccess(render));
        }
        $scope.save = function () {
            Fabric.saveConfigFile(jolokia, $scope.versionId, $scope.profileId, $scope.fname, $scope.data.encodeBase64(), function () {
                $scope.dirty = false;
                notification('success', "Saved " + $scope.fname);
                $location.path("/fabric/profile/" + $scope.versionId + "/" + $scope.profileId);
            }, function (response) {
                notification('error', "Failed to save " + $scope.fname + " due to " + response.error);
            });
        };
        function stringToBytes(s) {
            return s.codes();
        }
        function bytesToString(b) {
            var answer = [];
            b.forEach(function (b) {
                answer.push(String.fromCharCode(b));
            });
            return answer.join('');
        }
        function render(response) {
            if(!Object.equal($scope.response, response.value)) {
                $scope.response = response.value;
                $scope.data = $scope.response.decodeBase64();
                $scope.mode = $scope.getMode();
                $scope.$apply();
            }
        }
    }
    Fabric.PIDController = PIDController;
})(Fabric || (Fabric = {}));
var Fabric;
(function (Fabric) {
    function ProfileController($scope, $routeParams, jolokia, $location, workspace) {
        Fabric.initScope($scope, workspace);
        $scope.versionId = $routeParams.versionId;
        $scope.profileId = $routeParams.profileId;
        $scope.newFileDialog = false;
        $scope.deleteFileDialog = false;
        $scope.newFileName = '';
        $scope.markedForDeletion = '';
        $scope.newProfileName = '';
        if(angular.isDefined($scope.versionId) && angular.isDefined($scope.profileId)) {
            Core.register(jolokia, $scope, {
                type: 'exec',
                mbean: Fabric.managerMBean,
                operation: 'getProfile(java.lang.String, java.lang.String)',
                arguments: [
                    $scope.versionId, 
                    $scope.profileId
                ]
            }, onSuccess(render));
        }
        $scope.deleteFile = function (file) {
            $scope.markedForDeletion = file;
            $scope.deleteFileDialog = true;
        };
        $scope.doDeleteFile = function () {
            $scope.deleteFileDialog = false;
            Fabric.deleteConfigFile(jolokia, $scope.versionId, $scope.profileId, $scope.markedForDeletion, function () {
                notification('success', 'Deleted file ' + $scope.markedForDeletion);
                $scope.markedForDeletion = '';
                $scope.$apply();
            }, function (response) {
                notification('error', 'Failed to delete file ' + $scope.markedForDeletion + ' due to ' + response.error);
                $scope.markedForDeletion = '';
                $scope.$apply();
            });
        };
        $scope.doCreateFile = function () {
            $scope.newFileDialog = false;
            Fabric.newConfigFile(jolokia, $scope.versionId, $scope.profileId, $scope.newFileName, function () {
                notification('success', 'Created new configuration file ' + $scope.newFileName);
                $location.path("/fabric/profile/" + $scope.versionId + "/" + $scope.profileId + "/" + $scope.newFileName);
            }, function (response) {
                notification('error', 'Failed to create ' + $scope.newFileName + ' due to ' + response.error);
            });
        };
        $scope.copyProfile = function () {
            $scope.copyProfileDialog = false;
            notification('info', 'Copying ' + $scope.profileId + ' to ' + $scope.newProfileName);
            Fabric.copyProfile(jolokia, $scope.versionId, $scope.profileId, $scope.newProfileName, true, function () {
                notification('success', 'Created new profile ' + $scope.newProfileName);
                $location.url("/fabric/profile/" + $scope.versionId + "/" + $scope.newProfileName);
                $scope.$apply();
            }, function (response) {
                notification('error', 'Failed to create new profile ' + $scope.newProfileName + ' due to ' + response.error);
                $scope.$apply();
            });
        };
        function render(response) {
            if(!Object.equal($scope.row, response.value)) {
                $scope.row = response.value;
                $scope.$apply();
            }
        }
    }
    Fabric.ProfileController = ProfileController;
})(Fabric || (Fabric = {}));
var Fabric;
(function (Fabric) {
    function ProfilesController($scope, $location, workspace, jolokia) {
        Fabric.initScope($scope, workspace);
        $scope.defaultVersion = jolokia.execute(Fabric.managerMBean, "defaultVersion()");
        $scope.version = {
            id: $scope.defaultVersion.id
        };
        $scope.selected = [];
        $scope.selectedParents = [];
        $scope.selectedParentVersion = [];
        $scope.deleteVersionDialog = false;
        $scope.deleteProfileDialog = false;
        $scope.createProfileDialog = false;
        $scope.createVersionDialog = false;
        $scope.triggerResize = function () {
            setTimeout(function () {
                $('.dialogGrid').trigger('resize');
            }, 10);
        };
        $scope.$watch('createProfileDialog', function () {
            if($scope.createProfileDialog) {
                $scope.triggerResize();
            }
        });
        $scope.$watch('createVersionDialog', function () {
            if($scope.createVersionDialog) {
                $scope.triggerResize();
            }
        });
        $scope.newProfileName = '';
        $scope.newVersionName = '';
        var key = $location.search()['pv'];
        if(key) {
            $scope.version = {
                id: key
            };
        }
        key = $location.search()['ao'];
        $scope.activeOnly = !angular.isDefined(key) || key === 'true';
        $scope.versions = [];
        $scope.profiles = [];
        $scope.versionResponse = [];
        $scope.profilesResponse = [];
        $scope.$watch('activeOnly', function (oldValue, newValue) {
            if(oldValue === newValue) {
                return;
            }
            var q = $location.search();
            q['ao'] = "" + $scope.activeOnly;
            $location.search(q);
        });
        $scope.$watch('version', function (oldValue, newValue) {
            var q = $location.search();
            q['pv'] = $scope.version.id;
            $location.search(q);
            if(oldValue === newValue) {
                notification('info', "Please wait, fetching profile data for version " + $scope.version.id);
            }
            Core.unregister(jolokia, $scope);
            Core.register(jolokia, $scope, [
                {
                    type: 'exec',
                    mbean: Fabric.managerMBean,
                    operation: 'versions()'
                }, 
                {
                    type: 'exec',
                    mbean: Fabric.managerMBean,
                    operation: 'getProfiles(java.lang.String, java.util.List)',
                    arguments: [
                        $scope.version.id, 
                        [
                            "id", 
                            "parentIds", 
                            "childIds", 
                            "containerCount", 
                            "locked", 
                            "abstract"
                        ]
                    ]
                }
            ], onSuccess(render));
        });
        $scope.selectedHasContainers = function () {
            return $scope.selected.findAll(function (item) {
                return item.containerCount > 0;
            }).length > 0;
        };
        $scope.versionCanBeDeleted = function () {
            if($scope.version.id === $scope.defaultVersion.id) {
                return true;
            }
            if($scope.versions.length === 0) {
                return true;
            }
            return $scope.profiles.findAll(function (item) {
                return item.containerCount > 0;
            }).length > 0;
        };
        $scope.createProfileGridOptions = {
            data: 'profiles',
            selectedItems: $scope.selectedParents,
            showSelectionCheckbox: true,
            multiSelect: true,
            selectWithCheckboxOnly: false,
            keepLastSelected: false,
            columnDefs: [
                {
                    field: 'id',
                    displayName: 'Name'
                }
            ]
        };
        $scope.createVersionGridOptions = {
            data: 'versions',
            selectedItems: $scope.selectedParentVersion,
            showSelectionCheckbox: true,
            multiSelect: false,
            selectWithCheckboxOnly: false,
            keepLastSelected: false,
            columnDefs: [
                {
                    field: 'id',
                    displayName: 'Name'
                }
            ]
        };
        $scope.gridOptions = {
            data: 'profiles',
            showFilter: false,
            showColumnMenu: false,
            filterOptions: {
                filterText: ''
            },
            selectedItems: $scope.selected,
            showSelectionCheckbox: true,
            multiSelect: true,
            selectWithCheckboxOnly: true,
            keepLastSelected: false,
            checkboxCellTemplate: '<div class="ngSelectionCell"><input tabindex="-1" class="ngSelectionCheckbox" type="checkbox" ng-checked="row.selected" ng-disabled="row.entity.containerCount > 0 || row.entity.childIds.length > 0"/></div>',
            columnDefs: [
                {
                    field: 'id',
                    displayName: 'Name',
                    cellTemplate: '<div class="ngCellText"><a ng-href="#/fabric/profile/{{$parent.version.id}}/{{row.getProperty(col.field)}}{{hash}}">{{row.getProperty(col.field)}}</a></div>',
                    width: 300
                }, 
                {
                    field: 'attributes',
                    displayName: 'A',
                    headerCellTemplate: '<div ng-click="col.sort()" class="ngHeaderSortColumn {{col.headerClass}}" ng-style="{\'cursor\': col.cursor}" ng-class="{ \'ngSorted\': !noSortVisible }"><div class="ngHeaderText colt{{$index}} pagination-centered" title="Attributes"><i class="icon-cogs"></i></div><div class="ngSortButtonDown" ng-show="col.showSortButtonDown()"></div><div class="ngSortButtonUp" ng-show="col.showSortButtonUp()"></div></div>',
                    cellTemplate: '<div class="ngCellText"><ul class="unstyled inline"><li class="attr-column"><i ng-show="row.entity.locked" title="Locked" class="icon-lock"></i></li><li class="attr-column"><i ng-show="row.entity.abstract" title="Abstract" class="icon-font"></i></li></ul></div>',
                    width: 52
                }, 
                {
                    field: 'containerCount',
                    displayName: 'C',
                    headerCellTemplate: '<div ng-click="col.sort()" class="ngHeaderSortColumn {{col.headerClass}}" ng-style="{\'cursor\': col.cursor}" ng-class="{ \'ngSorted\': !noSortVisible }"><div class="ngHeaderText colt{{$index}} pagination-centered" title="Containers"><i class="icon-truck"></i></div><div class="ngSortButtonDown" ng-show="col.showSortButtonDown()"></div><div class="ngSortButtonUp" ng-show="col.showSortButtonUp()"></div></div>',
                    cellTemplate: '<div class="ngCellText pagination-centered"><a ng-show="row.getProperty(col.field) > 0" title="{{row.entity.containers.sortBy().join(\'\n\')}}" href="#/fabric/containers?cv={{$parent.version.id}}&cp={{row.entity.id}}{{hash}}">{{row.getProperty(col.field)}}</a></div>',
                    width: 28
                }, 
                {
                    field: 'parentIds',
                    displayName: 'Parent Profiles',
                    cellTemplate: '<div class="ngCellText"><ul class="unstyled inline"><li ng-repeat="profile in row.entity.parentIds.sortBy()"><a href="#/fabric/profile/{{$parent.version.id}}/{{profile}}">{{profile}}</a></li></ul></div>',
                    width: 400
                }, 
                {
                    field: 'childIds',
                    displayName: 'Child Profiles',
                    cellTemplate: '<div class="ngCellText"><ul class="unstyled inline"><li ng-repeat="profile in row.entity.childIds.sortBy()"><a href="#/fabric/profile/{{$parent.version.id}}/{{profile}}">{{profile}}</a></li></ul></div>',
                    width: 800
                }
            ]
        };
        $scope.doCreateProfile = function () {
            $scope.createProfileDialog = false;
            var parents = $scope.selectedParents.map(function (profile) {
                return profile.id;
            });
            Fabric.createProfile(jolokia, $scope.version.id, $scope.newProfileName, parents, function () {
                notification('success', "Created profile " + $scope.newProfileName);
                $scope.newProfileName = "";
                $scope.$apply();
            }, function (response) {
                notification('error', "Failed to create profile " + $scope.newProfileName + " due to " + response.error);
            });
        };
        $scope.doCreateVersion = function () {
            $scope.createVersionDialog = false;
            var success = function (response) {
                notification('success', "Created version " + response.value.id);
                $scope.newVersionName = '';
                $scope.version = response.value;
                $scope.$apply();
            };
            var error = function (response) {
                var msg = "Error creating new version: " + response.error;
                if($scope.newVersionName !== '') {
                    msg = "Error creating " + $scope.newVersionName + " : " + response.error;
                }
                notification('error', msg);
            };
            if($scope.selectedParentVersion.length > 0 && $scope.newVersionName !== '') {
                Fabric.createVersionWithParentAndId(jolokia, $scope.selectedParentVersion[0].id, $scope.newVersionName, success, error);
            } else {
                if($scope.newVersionName !== '') {
                    Fabric.createVersionWithId(jolokia, $scope.newVersionName, success, error);
                } else {
                    Fabric.createVersion(jolokia, success, error);
                }
            }
        };
        $scope.deleteVersion = function () {
            Core.unregister(jolokia, $scope);
            Fabric.deleteVersion(jolokia, $scope.version.id, function () {
                notification('success', "Deleted version " + $scope.version.id);
                $scope.version = $scope.defaultVersion;
                $scope.$apply();
            }, function (response) {
                notification('error', "Failed to delete version " + $scope.version.id + " due to " + response.error);
                $scope.version = $scope.defaultVersion;
                $scope.$apply();
            });
        };
        $scope.deleteSelected = function () {
            $scope.selected.each(function (profile) {
                Fabric.deleteProfile(jolokia, $scope.version.id, profile.id, function () {
                    notification('success', "Deleted profile " + profile.id);
                }, function (response) {
                    notification('error', "Failed to delete profile " + profile.id + ' due to ' + response.error);
                });
            });
        };
        function filterActive(data) {
            var rc = data;
            if($scope.activeOnly) {
                rc = data.filter(function (item) {
                    return item.containerCount > 0;
                });
            }
            return rc;
        }
        function render(response) {
            clearNotifications();
            if(response.request.operation === 'versions()') {
                if(!Object.equal($scope.versionResponse, response.value)) {
                    $scope.versionResponse = response.value;
                    $scope.versions = response.value.map(function (version) {
                        var v = {
                            id: version.id,
                            'defaultVersion': version.defaultVersion
                        };
                        if(v['defaultVersion']) {
                            $scope.defaultVersion = v;
                        }
                        return v;
                    });
                    $scope.version = Fabric.setSelect($scope.version, $scope.versions);
                    $scope.$apply();
                }
            } else {
                if(!Object.equal($scope.profilesResponse, response.value)) {
                    $scope.profilesResponse = response.value;
                    $scope.profiles = [];
                    $scope.profilesResponse.forEach(function (profile) {
                        $scope.profiles.push({
                            id: profile.id,
                            parentIds: profile.parentIds,
                            childIds: profile.childIds,
                            containerCount: profile.containerCount,
                            containers: profile.containers,
                            locked: profile.locked,
                            abstract: profile['abstract']
                        });
                    });
                    $scope.profiles = filterActive($scope.profiles);
                    $scope.$apply();
                }
            }
        }
    }
    Fabric.ProfilesController = ProfilesController;
})(Fabric || (Fabric = {}));
var __extends = this.__extends || function (d, b) {
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var Forms;
(function (Forms) {
    var InputBaseConfig = (function () {
        function InputBaseConfig() {
            this.name = 'input';
            this.type = '';
            this.description = '';
            this._default = '';
            this.scope = null;
            this.mode = 'edit';
            this.schemaName = "schema";
            this.controlgroupclass = 'control-group';
            this.controlclass = 'controls';
            this.labelclass = 'control-label';
            this.showtypes = 'false';
            this.formtemplate = null;
            this.entity = 'entity';
            this.model = undefined;
        }
        InputBaseConfig.prototype.getEntity = function () {
            return this.entity || "entity";
        };
        InputBaseConfig.prototype.getMode = function () {
            return this.mode || "edit";
        };
        InputBaseConfig.prototype.isReadOnly = function () {
            return this.getMode() === "view";
        };
        return InputBaseConfig;
    })();
    Forms.InputBaseConfig = InputBaseConfig;    
    var InputBase = (function () {
        function InputBase(workspace, $compile) {
            this.workspace = workspace;
            this.$compile = $compile;
            var _this = this;
            this.restrict = 'A';
            this.scope = true;
            this.replace = false;
            this.transclude = false;
            this.attributeName = '';
            this.link = function (scope, element, attrs) {
                return _this.doLink(scope, element, attrs);
            };
        }
        InputBase.prototype.doLink = function (scope, element, attrs) {
            var config = new InputBaseConfig();
            config = Forms.configure(config, null, attrs);
            config.scope = scope;
            config.schemaName = attrs["schema"] || "schema";
            var id = config.name;
            var group = this.getControlGroup(config, config, id);
            var modelName = config.model;
            if(!angular.isDefined(modelName)) {
                modelName = config.getEntity() + "." + id;
            }
            group.append(Forms.getLabel(config, config, attrs["title"] || id));
            var controlDiv = Forms.getControlDiv(config);
            controlDiv.append(this.getInput(config, config, id, modelName));
            controlDiv.append(Forms.getHelpSpan(config, config, id));
            group.append(controlDiv);
            $(element).append(this.$compile(group)(scope));
            if(scope && modelName) {
                scope.$watch(modelName, onModelChange);
            }
            function onModelChange(newValue) {
                scope.$emit("hawtio.form.modelChange", modelName, newValue);
            }
        };
        InputBase.prototype.getControlGroup = function (config1, config2, id) {
            return Forms.getControlGroup(config1, config2, id);
        };
        InputBase.prototype.getInput = function (config, arg, id, modelName) {
            var rc = $('<span class="form-data"></span>');
            if(modelName) {
                rc.attr('ng-model', modelName);
                rc.append('{{' + modelName + '}}');
            }
            return rc;
        };
        return InputBase;
    })();
    Forms.InputBase = InputBase;    
    var TextInput = (function (_super) {
        __extends(TextInput, _super);
        function TextInput(workspace, $compile) {
                _super.call(this, workspace, $compile);
            this.workspace = workspace;
            this.$compile = $compile;
            this.type = "text";
        }
        TextInput.prototype.getInput = function (config, arg, id, modelName) {
            if(config.isReadOnly()) {
                return _super.prototype.getInput.call(this, config, arg, id, modelName);
            }
            var rc = $('<input type="' + this.type + '">');
            rc.attr('name', id);
            if(modelName) {
                rc.attr('ng-model', modelName);
            }
            if(config.isReadOnly()) {
                rc.attr('readonly', 'true');
            }
            return rc;
        };
        return TextInput;
    })(InputBase);
    Forms.TextInput = TextInput;    
    var HiddenText = (function (_super) {
        __extends(HiddenText, _super);
        function HiddenText(workspace, $compile) {
                _super.call(this, workspace, $compile);
            this.workspace = workspace;
            this.$compile = $compile;
            this.type = "hidden";
        }
        HiddenText.prototype.getControlGroup = function (config1, config2, id) {
            var group = _super.prototype.getControlGroup.call(this, config1, config2, id);
            group.css({
                'display': 'none'
            });
            return group;
        };
        HiddenText.prototype.getInput = function (config, arg, id, modelName) {
            var rc = _super.prototype.getInput.call(this, config, arg, id, modelName);
            rc.attr('readonly', 'true');
            return rc;
        };
        return HiddenText;
    })(TextInput);
    Forms.HiddenText = HiddenText;    
    var PasswordInput = (function (_super) {
        __extends(PasswordInput, _super);
        function PasswordInput(workspace, $compile) {
                _super.call(this, workspace, $compile);
            this.workspace = workspace;
            this.$compile = $compile;
            this.type = "password";
        }
        return PasswordInput;
    })(TextInput);
    Forms.PasswordInput = PasswordInput;    
    var CustomInput = (function (_super) {
        __extends(CustomInput, _super);
        function CustomInput(workspace, $compile) {
                _super.call(this, workspace, $compile);
            this.workspace = workspace;
            this.$compile = $compile;
        }
        CustomInput.prototype.getInput = function (config, arg, id, modelName) {
            var template = arg.formtemplate;
            template = Core.unescapeHtml(template);
            var rc = $(template);
            if(!rc.attr("name")) {
                rc.attr('name', id);
            }
            if(modelName) {
                rc.attr('ng-model', modelName);
            }
            if(config.isReadOnly()) {
                rc.attr('readonly', 'true');
            }
            return rc;
        };
        return CustomInput;
    })(InputBase);
    Forms.CustomInput = CustomInput;    
    var SelectInput = (function (_super) {
        __extends(SelectInput, _super);
        function SelectInput(workspace, $compile) {
                _super.call(this, workspace, $compile);
            this.workspace = workspace;
            this.$compile = $compile;
        }
        SelectInput.prototype.getInput = function (config, arg, id, modelName) {
            if(config.isReadOnly()) {
                return _super.prototype.getInput.call(this, config, arg, id, modelName);
            }
            var required = true;
            var defaultOption = required ? "" : '<option value=""></option>';
            var rc = $('<select>' + defaultOption + '</select>');
            rc.attr('name', id);
            var scope = config.scope;
            var data = config.data;
            if(data && scope) {
                var fullSchema = scope[config.schemaName];
                var model = scope[data];
                var paths = id.split(".");
                var property = null;
                angular.forEach(paths, function (path) {
                    property = Core.pathGet(model, [
                        "properties", 
                        path
                    ]);
                    var typeName = Core.pathGet(property, [
                        "type"
                    ]);
                    var alias = Forms.lookupDefinition(typeName, fullSchema);
                    if(alias) {
                        model = alias;
                    }
                });
                var values = Core.pathGet(property, [
                    "enum"
                ]);
                scope["$selectValues"] = values;
                rc.attr("ng-options", "value for value in $selectValues");
            }
            if(modelName) {
                rc.attr('ng-model', modelName);
            }
            if(config.isReadOnly()) {
                rc.attr('readonly', 'true');
            }
            return rc;
        };
        return SelectInput;
    })(InputBase);
    Forms.SelectInput = SelectInput;    
    var NumberInput = (function (_super) {
        __extends(NumberInput, _super);
        function NumberInput(workspace, $compile) {
                _super.call(this, workspace, $compile);
            this.workspace = workspace;
            this.$compile = $compile;
        }
        NumberInput.prototype.getInput = function (config, arg, id, modelName) {
            if(config.isReadOnly()) {
                return _super.prototype.getInput.call(this, config, arg, id, modelName);
            }
            var rc = $('<input type="number">');
            rc.attr('name', id);
            if(angular.isDefined(arg.def)) {
                rc.attr('value', arg.def);
            }
            if(angular.isDefined(arg.minimum)) {
                rc.attr('min', arg.minimum);
            }
            if(angular.isDefined(arg.maximum)) {
                rc.attr('max', arg.maximum);
            }
            if(modelName) {
                rc.attr('ng-model', modelName);
            }
            if(config.isReadOnly()) {
                rc.attr('readonly', 'true');
            }
            return rc;
        };
        return NumberInput;
    })(InputBase);
    Forms.NumberInput = NumberInput;    
    var ArrayInput = (function (_super) {
        __extends(ArrayInput, _super);
        function ArrayInput(workspace, $compile) {
                _super.call(this, workspace, $compile);
            this.workspace = workspace;
            this.$compile = $compile;
        }
        ArrayInput.prototype.doLink = function (scope, element, attrs) {
            var config = new InputBaseConfig();
            config = Forms.configure(config, null, attrs);
            var id = config.name;
            var dataName = attrs["data"] || "";
            var entityName = attrs["entity"] || config.entity;
            function renderRow(cell, type, data) {
                if(data) {
                    var description = data["description"];
                    if(!description) {
                        angular.forEach(data, function (value, key) {
                            if(value && !description) {
                                description = value;
                            }
                        });
                    }
                    return description;
                }
                return null;
            }
            var tableConfigPaths = [
                "properties", 
                id, 
                "inputTable"
            ];
            var tableConfig = null;
            Core.pathGet(scope, tableConfigPaths);
            if(!tableConfig) {
                var tableConfigScopeName = tableConfigPaths.join(".");
                var cellDescription = humanizeValue(id);
                tableConfig = {
                    formConfig: config,
                    title: cellDescription,
                    data: config.entity + "." + id,
                    displayFooter: false,
                    showFilter: false,
                    columnDefs: [
                        {
                            field: '_id',
                            displayName: cellDescription,
                            render: renderRow
                        }
                    ]
                };
                Core.pathSet(scope, tableConfigPaths, tableConfig);
            }
            var table = $('<div hawtio-input-table="' + tableConfigScopeName + '" data="' + dataName + '" property="' + id + '" entity="' + entityName + '"></div>');
            if(config.isReadOnly()) {
                table.attr("readonly", "true");
            }
            $(element).append(this.$compile(table)(scope));
        };
        return ArrayInput;
    })(InputBase);
    Forms.ArrayInput = ArrayInput;    
    var BooleanInput = (function (_super) {
        __extends(BooleanInput, _super);
        function BooleanInput(workspace, $compile) {
                _super.call(this, workspace, $compile);
            this.workspace = workspace;
            this.$compile = $compile;
        }
        BooleanInput.prototype.getInput = function (config, arg, id, modelName) {
            var rc = $('<input class="hawtio-checkbox" type="checkbox">');
            rc.attr('name', id);
            if(config.isReadOnly()) {
                rc.attr('disabled', 'true');
            }
            if(modelName) {
                rc.attr('ng-model', modelName);
            }
            if(config.isReadOnly()) {
                rc.attr('readonly', 'true');
            }
            return rc;
        };
        return BooleanInput;
    })(InputBase);
    Forms.BooleanInput = BooleanInput;    
})(Forms || (Forms = {}));
var Forms;
(function (Forms) {
    Forms.pluginName = 'hawtio-forms';
    angular.module(Forms.pluginName, [
        'bootstrap', 
        'ngResource', 
        'hawtioCore', 
        'datatable', 
        'ui.bootstrap', 
        'ui.bootstrap.dialog', 
        'hawtio-ui'
    ]).config(function ($routeProvider) {
        $routeProvider.when('/forms/test', {
            templateUrl: 'app/forms/html/test.html'
        }).when('/forms/testTable', {
            templateUrl: 'app/forms/html/testTable.html'
        });
    }).directive('simpleForm', function (workspace, $compile) {
        return new Forms.SimpleForm(workspace, $compile);
    }).directive('hawtioInputTable', function (workspace, $compile) {
        return new Forms.InputTable(workspace, $compile);
    }).directive('hawtioFormText', function (workspace, $compile) {
        return new Forms.TextInput(workspace, $compile);
    }).directive('hawtioFormPassword', function (workspace, $compile) {
        return new Forms.PasswordInput(workspace, $compile);
    }).directive('hawtioFormHidden', function (workspace, $compile) {
        return new Forms.HiddenText(workspace, $compile);
    }).directive('hawtioFormNumber', function (workspace, $compile) {
        return new Forms.NumberInput(workspace, $compile);
    }).directive('hawtioFormSelect', function (workspace, $compile) {
        return new Forms.SelectInput(workspace, $compile);
    }).directive('hawtioFormArray', function (workspace, $compile) {
        return new Forms.ArrayInput(workspace, $compile);
    }).directive('hawtioFormCheckbox', function (workspace, $compile) {
        return new Forms.BooleanInput(workspace, $compile);
    }).directive('hawtioFormCustom', function (workspace, $compile) {
        return new Forms.CustomInput(workspace, $compile);
    }).directive('hawtioSubmit', function () {
        return new Forms.SubmitForm();
    }).directive('hawtioReset', function () {
        return new Forms.ResetForm();
    });
    hawtioPluginLoader.addModule(Forms.pluginName);
})(Forms || (Forms = {}));
var Forms;
(function (Forms) {
    function resolveTypeNameAlias(type, schema) {
        if(type && schema) {
            var alias = lookupDefinition(type, schema);
            if(alias) {
                var realType = alias["type"];
                if(realType) {
                    type = realType;
                }
            }
        }
        return type;
    }
    Forms.resolveTypeNameAlias = resolveTypeNameAlias;
    function isJsonType(name, schema, typeName) {
        var definition = lookupDefinition(name, schema);
        while(definition) {
            var extendsTypes = Core.pathGet(definition, [
                "extends", 
                "type"
            ]);
            if(extendsTypes) {
                if(typeName === extendsTypes) {
                    return true;
                } else {
                    definition = lookupDefinition(extendsTypes, schema);
                }
            } else {
                return false;
            }
        }
        return false;
    }
    Forms.isJsonType = isJsonType;
    function lookupDefinition(name, schema) {
        if(schema) {
            var defs = schema.definitions;
            if(defs) {
                var answer = defs[name];
                if(answer) {
                    var fullSchema = answer["fullSchema"];
                    if(fullSchema) {
                        return fullSchema;
                    }
                    var extendsTypes = Core.pathGet(answer, [
                        "extends", 
                        "type"
                    ]);
                    if(extendsTypes) {
                        fullSchema = angular.copy(answer);
                        fullSchema.properties = fullSchema.properties || {
                        };
                        if(!angular.isArray(extendsTypes)) {
                            extendsTypes = [
                                extendsTypes
                            ];
                        }
                        angular.forEach(extendsTypes, function (extendType) {
                            if(angular.isString(extendType)) {
                                var extendDef = lookupDefinition(extendType, schema);
                                var properties = Core.pathGet(extendDef, [
                                    "properties"
                                ]);
                                if(properties) {
                                    angular.forEach(properties, function (property, key) {
                                        fullSchema.properties[key] = property;
                                    });
                                }
                            }
                        });
                        answer["fullSchema"] = fullSchema;
                        return fullSchema;
                    }
                }
                return answer;
            }
        }
        return null;
    }
    Forms.lookupDefinition = lookupDefinition;
    function findArrayItemsSchema(property, schema) {
        var items = null;
        if(property && schema) {
            items = property.items;
            if(items) {
                var typeName = items["type"];
                if(typeName) {
                    var definition = lookupDefinition(typeName, schema);
                    if(definition) {
                        return definition;
                    }
                }
            }
            var additionalProperties = property.additionalProperties;
            if(additionalProperties) {
                if(additionalProperties["$ref"] === "#") {
                    return schema;
                }
            }
        }
        return items;
    }
    Forms.findArrayItemsSchema = findArrayItemsSchema;
    function isObjectType(definition) {
        var typeName = Core.pathGet(definition, "type");
        return typeName && "object" === typeName;
    }
    Forms.isObjectType = isObjectType;
    function isArrayOrNestedObject(property, schema) {
        if(property) {
            var propType = resolveTypeNameAlias(property["type"], schema);
            if(propType) {
                if(propType === "object" || propType === "array") {
                    return true;
                }
            }
        }
        return false;
    }
    Forms.isArrayOrNestedObject = isArrayOrNestedObject;
    function configure(config, scopeConfig, attrs) {
        if(angular.isDefined(scopeConfig)) {
            config = angular.extend(config, scopeConfig);
        }
        return angular.extend(config, attrs);
    }
    Forms.configure = configure;
    function getControlGroup(config, arg, id) {
        var rc = $('<div class="' + config.controlgroupclass + '"></div>');
        if(angular.isDefined(arg.description)) {
            rc.attr('title', arg.description);
        }
        return rc;
    }
    Forms.getControlGroup = getControlGroup;
    function getLabel(config, arg, id) {
        return $('<label class="' + config.labelclass + '">' + humanizeValue(id) + ': </label>');
    }
    Forms.getLabel = getLabel;
    function getControlDiv(config) {
        return $('<div class="' + config.controlclass + '"></div>');
    }
    Forms.getControlDiv = getControlDiv;
    function getHelpSpan(config, arg, id) {
        var rc = $('<span class="help-block"></span>');
        if(angular.isDefined(arg.type) && config.showtypes !== 'false') {
            rc.append('Type: ' + arg.type);
        }
        return rc;
    }
    Forms.getHelpSpan = getHelpSpan;
})(Forms || (Forms = {}));
var Forms;
(function (Forms) {
    var InputTableConfig = (function () {
        function InputTableConfig() {
            this.name = 'form';
            this.method = 'post';
            this.entity = 'entity';
            this.tableConfig = 'tableConfig';
            this.mode = 'edit';
            this.data = {
            };
            this.json = undefined;
            this.properties = [];
            this.action = '';
            this.tableclass = 'gridStyle';
            this.controlgroupclass = 'control-group';
            this.controlclass = 'controls pull-right';
            this.labelclass = 'control-label';
            this.showtypes = 'true';
            this.removeicon = 'icon-remove';
            this.editicon = 'icon-edit';
            this.addicon = 'icon-plus';
            this.removetext = 'Remove';
            this.edittext = 'Edit';
            this.addtext = 'Add';
            this.onadd = 'onadd';
            this.onedit = 'onedit';
            this.onremove = 'onRemove';
        }
        InputTableConfig.prototype.getTableConfig = function () {
            return this.tableConfig || "tableConfig";
        };
        return InputTableConfig;
    })();
    Forms.InputTableConfig = InputTableConfig;    
    var InputTable = (function () {
        function InputTable(workspace, $compile) {
            this.workspace = workspace;
            this.$compile = $compile;
            var _this = this;
            this.restrict = 'A';
            this.scope = true;
            this.replace = true;
            this.transclude = true;
            this.attributeName = 'hawtioInputTable';
            this.link = function (scope, element, attrs) {
                return _this.doLink(scope, element, attrs);
            };
        }
        InputTable.prototype.doLink = function (scope, element, attrs) {
            var _this = this;
            var config = new InputTableConfig();
            var configName = attrs[this.attributeName];
            var tableConfig = Core.pathGet(scope, configName);
            config = Forms.configure(config, tableConfig, attrs);
            var entityName = attrs["entity"] || config.data || "entity";
            var propertyName = attrs["property"] || "arrayData";
            var entityPath = entityName + "." + propertyName;
            var tableName = config["title"] || entityName;
            if(angular.isDefined(config.json)) {
                config.data = $.parseJSON(config.json);
            } else {
                config.data = scope[config.data];
            }
            scope.selectedItems = [];
            var div = $("<div></div>");
            var tableConfig = Core.pathGet(scope, configName);
            if(!tableConfig) {
                console.log("No table configuration for table " + tableName);
            } else {
                tableConfig["selectedItems"] = scope.selectedItems;
            }
            var table = this.createTable(config, configName);
            var group = this.getControlGroup(config, {
            }, "");
            var controlDiv = this.getControlDiv(config);
            controlDiv.addClass('btn-group');
            group.append(controlDiv);
            function updateData(action) {
                var data = Core.pathGet(scope, entityPath);
                if(data) {
                    data = action(data);
                }
                Core.pathSet(scope, entityPath, data);
                scope.$emit("hawtio.datatable." + entityPath, data);
                Core.$apply(scope);
            }
            function removeSelected(data) {
                angular.forEach(scope.selectedItems, function (selected) {
                    var id = selected["_id"];
                    if(angular.isArray(data)) {
                        data = data.remove(function (value) {
                            return Object.equal(value, selected);
                        });
                        delete selected["_id"];
                        data = data.remove(function (value) {
                            return Object.equal(value, selected);
                        });
                    } else {
                        delete selected["_id"];
                        if(id) {
                            delete data[id];
                        } else {
                            var found = false;
                            angular.forEach(data, function (value, key) {
                                if(!found && (Object.equal(value, selected))) {
                                    console.log("Found row to delete! " + key);
                                    delete data[key];
                                    found = true;
                                }
                            });
                            if(!found) {
                                console.log("Could not find " + JSON.stringify(selected) + " in " + JSON.stringify(data));
                            }
                        }
                    }
                });
                return data;
            }
            var add = null;
            var edit = null;
            var remove = null;
            var addDialog = null;
            var editDialog = null;
            var readOnly = attrs["readonly"];
            if(!readOnly) {
                var property = null;
                var schema = null;
                var dataName = attrs["data"];
                if(dataName) {
                    schema = Core.pathGet(scope, dataName);
                }
                if(propertyName && schema) {
                    property = Core.pathGet(schema, [
                        "properties", 
                        propertyName
                    ]);
                }
                add = this.getAddButton(config);
                scope.addDialogOptions = {
                    backdropFade: true,
                    dialogFade: true
                };
                scope.showAddDialog = false;
                scope.openAddDialog = function () {
                    scope.addEntity = {
                    };
                    scope.addFormConfig = Forms.findArrayItemsSchema(property, schema);
                    if(!addDialog) {
                        var title = "Add " + tableName;
                        addDialog = $('<div modal="showAddDialog" close="closeAddDialog()" options="addDialogOptions">\n' + '<div class="modal-header"><h4>' + title + '</h4></div>\n' + '<div class="modal-body"><div simple-form="addFormConfig" entity="addEntity"></div></div>\n' + '<div class="modal-footer">' + '<button class="btn btn-primary add" type="button" ng-click="addAndCloseDialog()">Add</button>' + '<button class="btn btn-warning cancel" type="button" ng-click="closeAddDialog()">Cancel</button>' + '</div></div>');
                        div.append(addDialog);
                        _this.$compile(addDialog)(scope);
                    }
                    scope.showAddDialog = true;
                    Core.$apply(scope);
                };
                scope.closeAddDialog = function () {
                    scope.showAddDialog = false;
                    scope.addEntity = {
                    };
                };
                scope.addAndCloseDialog = function () {
                    var newData = scope.addEntity;
                    console.log("About to add the new entity " + JSON.stringify(newData));
                    if(newData) {
                        updateData(function (data) {
                            data.push(newData);
                            return data;
                        });
                    }
                    scope.closeAddDialog();
                };
                edit = this.getEditButton(config);
                scope.editDialogOptions = {
                    backdropFade: true,
                    dialogFade: true
                };
                scope.showEditDialog = false;
                scope.openEditDialog = function () {
                    var selected = scope.selectedItems;
                    var editObject = {
                    };
                    if(selected && selected.length) {
                        angular.copy(selected[0], editObject);
                    }
                    scope.editEntity = editObject;
                    scope.editFormConfig = Forms.findArrayItemsSchema(property, schema);
                    if(!editDialog) {
                        var title = "Edit " + tableName;
                        editDialog = $('<div modal="showEditDialog" close="closeEditDialog()" options="editDialogOptions">\n' + '<div class="modal-header"><h4>' + title + '</h4></div>\n' + '<div class="modal-body"><div simple-form="editFormConfig" entity="editEntity"></div></div>\n' + '<div class="modal-footer">' + '<button class="btn btn-primary save" type="button" ng-click="editAndCloseDialog()">Save</button>' + '<button class="btn btn-warning cancel" type="button" ng-click="closeEditDialog()">Cancel</button>' + '</div></div>');
                        div.append(editDialog);
                        _this.$compile(editDialog)(scope);
                    }
                    scope.showEditDialog = true;
                    Core.$apply(scope);
                };
                scope.closeEditDialog = function () {
                    scope.showEditDialog = false;
                    scope.editEntity = {
                    };
                };
                scope.editAndCloseDialog = function () {
                    var newData = scope.editEntity;
                    console.log("About to edit the new entity " + JSON.stringify(newData));
                    if(newData) {
                        updateData(function (data) {
                            data = removeSelected(data);
                            data.push(newData);
                            return data;
                        });
                    }
                    scope.closeEditDialog();
                };
                remove = this.getRemoveButton(config);
            }
            var findFunction = function (scope, func) {
                if(angular.isDefined(scope[func]) && angular.isFunction(scope[func])) {
                    return scope;
                }
                if(angular.isDefined(scope.$parent) && scope.$parent !== null) {
                    return findFunction(scope.$parent, func);
                } else {
                    return null;
                }
            };
            function maybeGet(scope, func) {
                if(scope !== null) {
                    return scope[func];
                }
                return null;
            }
            var onRemoveFunc = config.onremove.replace('(', '').replace(')', '');
            var onEditFunc = config.onedit.replace('(', '').replace(')', '');
            var onAddFunc = config.onadd.replace('(', '').replace(')', '');
            var onRemove = maybeGet(findFunction(scope, onRemoveFunc), onRemoveFunc);
            var onEdit = maybeGet(findFunction(scope, onEditFunc), onEditFunc);
            var onAdd = maybeGet(findFunction(scope, onAddFunc), onAddFunc);
            if(onRemove === null) {
                onRemove = function () {
                    updateData(function (data) {
                        return removeSelected(data);
                    });
                };
            }
            if(onEdit === null) {
                onEdit = function () {
                    scope.openEditDialog();
                };
            }
            if(onAdd === null) {
                onAdd = function (form) {
                    scope.openAddDialog();
                };
            }
            if(add) {
                add.click(function (event) {
                    onAdd();
                    return false;
                });
                controlDiv.append(add);
            }
            if(edit) {
                edit.click(function (event) {
                    onEdit();
                    return false;
                });
                controlDiv.append(edit);
            }
            if(remove) {
                remove.click(function (event) {
                    onRemove();
                    return false;
                });
                controlDiv.append(remove);
            }
            $(div).append(group);
            $(div).append(table);
            $(element).append(div);
            this.$compile(div)(scope);
        };
        InputTable.prototype.getAddButton = function (config) {
            return $('<button type="button" class="btn add"><i class="' + config.addicon + '"></i> ' + config.addtext + '</button>');
        };
        InputTable.prototype.getEditButton = function (config) {
            return $('<button type="button" class="btn edit" ng-disabled="!selectedItems.length"><i class="' + config.editicon + '"></i> ' + config.edittext + '</button>');
        };
        InputTable.prototype.getRemoveButton = function (config) {
            return $('<button type="remove" class="btn remove" ng-disabled="!selectedItems.length"><i class="' + config.removeicon + '"></i> ' + config.removetext + '</button>');
        };
        InputTable.prototype.createTable = function (config, tableConfig) {
            var table = $('<div class="' + config.tableclass + '" hawtio-datatable="' + tableConfig + '">');
            return table;
        };
        InputTable.prototype.getLegend = function (config) {
            var description = Core.pathGet(config, "data.description");
            if(description) {
                return '<legend>' + config.data.description + '</legend>';
            }
            return '';
        };
        InputTable.prototype.getControlGroup = function (config, arg, id) {
            var rc = $('<div class="' + config.controlgroupclass + '"></div>');
            if(angular.isDefined(arg.description)) {
                rc.attr('title', arg.description);
            }
            return rc;
        };
        InputTable.prototype.getControlDiv = function (config) {
            return $('<div class="' + config.controlclass + '"></div>');
        };
        InputTable.prototype.getHelpSpan = function (config, arg, id) {
            var rc = $('<span class="help-block"></span>');
            if(angular.isDefined(arg.type) && config.showtypes !== 'false') {
                rc.append('Type: ' + arg.type);
            }
            return rc;
        };
        return InputTable;
    })();
    Forms.InputTable = InputTable;    
})(Forms || (Forms = {}));
var Forms;
(function (Forms) {
    function normalize(type, property, schema) {
        type = Forms.resolveTypeNameAlias(type, schema);
        if(!type) {
            return "hawtio-form-text";
        }
        var custom = Core.pathGet(property, [
            "formTemplate"
        ]);
        if(custom) {
            return "hawtio-form-custom";
        }
        var enumValues = Core.pathGet(property, [
            "enum"
        ]);
        if(enumValues) {
            return "hawtio-form-select";
        }
        switch(type.toLowerCase()) {
            case "int":
            case "integer":
            case "long":
            case "short":
            case "java.lang.integer":
            case "java.lang.long":
            case "float":
            case "double":
            case "java.lang.float":
            case "java.lang.double": {
                return "hawtio-form-number";

            }
            case "array":
            case "java.lang.array":
            case "java.lang.iterable":
            case "java.util.list":
            case "java.util.collection":
            case "java.util.iterator":
            case "java.util.set":
            case "object[]": {
                return "hawtio-form-array";

            }
            case "boolean":
            case "bool":
            case "java.lang.boolean": {
                return "hawtio-form-checkbox";

            }
            case "password": {
                return "hawtio-form-password";

            }
            case "hidden": {
                return "hawtio-form-hidden";

            }
            default: {
                return "hawtio-form-text";

            }
        }
    }
    Forms.normalize = normalize;
})(Forms || (Forms = {}));
var Forms;
(function (Forms) {
    var ResetForm = (function () {
        function ResetForm() {
            var _this = this;
            this.restrict = 'A';
            this.scope = true;
            this.link = function (scope, element, attrs) {
                return _this.doLink(scope, element, attrs);
            };
        }
        ResetForm.prototype.doLink = function (scope, element, attrs) {
            var el = $(element);
            var target = 'form[name=' + attrs['hawtioReset'] + ']';
            el.click(function () {
                var forms = $(target);
                for(var i = 0; i < forms.length; i++) {
                    forms[i].reset();
                }
                return false;
            });
        };
        return ResetForm;
    })();
    Forms.ResetForm = ResetForm;    
})(Forms || (Forms = {}));
var Forms;
(function (Forms) {
    var SimpleFormConfig = (function () {
        function SimpleFormConfig() {
            this.name = 'form';
            this.method = 'post';
            this.entity = 'entity';
            this.schemaName = 'schema';
            this.mode = 'edit';
            this.data = {
            };
            this.json = undefined;
            this.scope = null;
            this.scopeName = null;
            this.properties = [];
            this.action = '';
            this.formclass = 'hawtio-form form-horizontal no-bottom-margin';
            this.controlgroupclass = 'control-group';
            this.controlclass = 'controls';
            this.labelclass = 'control-label';
            this.showtypes = 'false';
            this.onsubmit = 'onSubmit';
        }
        SimpleFormConfig.prototype.getMode = function () {
            return this.mode || "edit";
        };
        SimpleFormConfig.prototype.getEntity = function () {
            return this.entity || "entity";
        };
        SimpleFormConfig.prototype.isReadOnly = function () {
            return this.getMode() === "view";
        };
        return SimpleFormConfig;
    })();
    Forms.SimpleFormConfig = SimpleFormConfig;    
    var SimpleForm = (function () {
        function SimpleForm(workspace, $compile) {
            this.workspace = workspace;
            this.$compile = $compile;
            var _this = this;
            this.restrict = 'A';
            this.scope = true;
            this.replace = true;
            this.transclude = true;
            this.attributeName = 'simpleForm';
            this.link = function (scope, element, attrs) {
                return _this.doLink(scope, element, attrs);
            };
        }
        SimpleForm.prototype.isReadOnly = function () {
            return false;
        };
        SimpleForm.prototype.doLink = function (scope, element, attrs) {
            var config = new SimpleFormConfig();
            var fullSchemaName = attrs["schema"];
            var fullSchema = fullSchemaName ? scope[fullSchemaName] : null;
            var compiledNode = null;
            var childScope = null;
            var tabs = null;
            var fieldset = null;
            var schema = null;
            var configScopeName = attrs[this.attributeName] || attrs["data"];
            var simple = this;
            scope.$watch(configScopeName, onWidgetDataChange);
            function onWidgetDataChange(scopeData) {
                if(scopeData) {
                    onScopeData(scopeData);
                }
            }
            function onScopeData(scopeData) {
                config = Forms.configure(config, scopeData, attrs);
                config.schemaName = fullSchemaName;
                config.scopeName = configScopeName;
                config.scope = scope;
                var entityName = config.getEntity();
                if(angular.isDefined(config.json)) {
                    config.data = $.parseJSON(config.json);
                } else {
                    config.data = scopeData;
                }
                var form = simple.createForm(config);
                fieldset = form.find('fieldset');
                schema = config.data;
                tabs = {
                    elements: {
                    },
                    locations: {
                    },
                    use: false
                };
                if(schema && angular.isDefined(schema.tabs)) {
                    tabs.use = true;
                    tabs['div'] = $('<div class="tabbable hawtio-form-tabs"></div>');
                    angular.forEach(schema.tabs, function (value, key) {
                        tabs.elements[key] = $('<div class="tab-pane" title="' + key + '"></div>');
                        tabs['div'].append(tabs.elements[key]);
                        value.forEach(function (val) {
                            tabs.locations[val] = key;
                        });
                    });
                    if(!tabs.locations['*']) {
                        tabs.locations['*'] = Object.extended(schema.tabs).keys()[0];
                    }
                }
                if(!tabs.use) {
                    fieldset.append('<div class="spacer"></div>');
                }
                if(schema) {
                    angular.forEach(schema.properties, function (property, id) {
                        addProperty(id, property);
                    });
                }
                if(tabs.use) {
                    fieldset.append(tabs['div']);
                }
                var findFunction = function (scope, func) {
                    if(angular.isDefined(scope[func]) && angular.isFunction(scope[func])) {
                        return scope;
                    }
                    if(angular.isDefined(scope.$parent) && scope.$parent !== null) {
                        return findFunction(scope.$parent, func);
                    } else {
                        return null;
                    }
                };
                var onSubmitFunc = config.onsubmit.replace('(', '').replace(')', '');
                var onSubmit = maybeGet(findFunction(scope, onSubmitFunc), onSubmitFunc);
                if(onSubmit === null) {
                    onSubmit = function (json, form) {
                        notification('error', 'No submit handler defined for form ' + form.get(0).name);
                    };
                }
                if(angular.isDefined(onSubmit)) {
                    form.submit(function () {
                        var entity = scope[entityName];
                        onSubmit(entity, form);
                        return false;
                    });
                }
                fieldset.append('<input type="submit" style="position: absolute; left: -9999px; width: 1px; height: 1px;">');
                if(compiledNode) {
                    $(compiledNode).remove();
                }
                if(childScope) {
                    childScope.$destroy();
                }
                childScope = scope.$new(false);
                compiledNode = simple.$compile(form)(childScope);
                $(element).append(compiledNode);
            }
            function addProperty(id, property) {
                var propTypeName = property.type;
                var propSchema = Forms.lookupDefinition(propTypeName, schema);
                if(!propSchema) {
                    propSchema = Forms.lookupDefinition(propTypeName, fullSchema);
                }
                if(propSchema && Forms.isObjectType(propSchema)) {
                    console.log("type name " + propTypeName + " has nested object type " + JSON.stringify(propSchema, null, "  "));
                    angular.forEach(propSchema.properties, function (childProp, childId) {
                        var newId = id + "." + childId;
                        addProperty(newId, childProp);
                    });
                } else {
                    var input = $('<div></div>');
                    input.attr(Forms.normalize(propTypeName, property, schema), '');
                    angular.forEach(property, function (value, key) {
                        if(angular.isString(value) && key.indexOf("$") < 0) {
                            var html = Core.escapeHtml(value);
                            input.attr(key, html);
                        }
                    });
                    input.attr('name', id);
                    input.attr('entity', config.getEntity());
                    input.attr('mode', config.getMode());
                    var fullSchemaName = config.schemaName;
                    if(fullSchemaName) {
                        input.attr('schema', fullSchemaName);
                    }
                    if(configScopeName) {
                        input.attr('data', configScopeName);
                    }
                    if(tabs.use) {
                        if(tabs.locations[id]) {
                            tabs.elements[tabs.locations[id]].append(input);
                        } else {
                            tabs.elements[tabs.locations['*']].append(input);
                        }
                    } else {
                        fieldset.append(input);
                    }
                }
            }
            function maybeGet(scope, func) {
                if(scope !== null) {
                    return scope[func];
                }
                return null;
            }
        };
        SimpleForm.prototype.createForm = function (config) {
            var form = $('<form class="' + config.formclass + '"><fieldset></fieldset></form>');
            form.attr('name', config.name);
            form.attr('action', config.action);
            form.attr('method', config.method);
            form.find('fieldset').append(this.getLegend(config));
            return form;
        };
        SimpleForm.prototype.getLegend = function (config) {
            var description = Core.pathGet(config, "data.description");
            if(description) {
                return '<legend>' + description + '</legend>';
            }
            return '';
        };
        return SimpleForm;
    })();
    Forms.SimpleForm = SimpleForm;    
})(Forms || (Forms = {}));
var Forms;
(function (Forms) {
    var SubmitForm = (function () {
        function SubmitForm() {
            var _this = this;
            this.restrict = 'A';
            this.scope = true;
            this.link = function (scope, element, attrs) {
                return _this.doLink(scope, element, attrs);
            };
        }
        SubmitForm.prototype.doLink = function (scope, element, attrs) {
            var el = $(element);
            var target = 'form[name=' + attrs['hawtioSubmit'] + ']';
            el.click(function () {
                $(target).submit();
                return false;
            });
        };
        return SubmitForm;
    })();
    Forms.SubmitForm = SubmitForm;    
})(Forms || (Forms = {}));
var Forms;
(function (Forms) {
    function FormTestController($scope, workspace) {
        $scope.editing = false;
        $scope.toggleEdit = function () {
            $scope.editing = !$scope.editing;
        };
        $scope.view = function () {
            if(!$scope.editing) {
                return "view";
            }
            return "edit";
        };
        $scope.setVMOption = {
            properties: {
                'key': {
                    description: 'Argument key',
                    type: 'java.lang.String'
                },
                'value': {
                    description: 'Argument Value',
                    type: 'java.lang.String'
                },
                'longArg': {
                    description: 'Long argument',
                    type: 'Long',
                    minimum: '5',
                    maximum: '10'
                },
                'intArg': {
                    description: 'Int argument',
                    type: 'Integer'
                },
                'objectArg': {
                    description: 'some object',
                    type: 'object'
                },
                'booleanArg': {
                    description: 'Some boolean value',
                    type: 'java.lang.Boolean'
                }
            },
            description: 'Show some stuff in a form',
            type: 'java.lang.String',
            tabs: {
                'Tab One': [
                    'key', 
                    'value'
                ],
                'Tab Two': [
                    '*'
                ],
                'Tab Three': [
                    'booleanArg'
                ]
            }
        };
        $scope.config = {
            name: 'form-with-config-object',
            action: "/some/url",
            method: "post",
            data: 'setVMOption',
            showtypes: 'false'
        };
        $scope.cheese = {
            key: "keyABC",
            value: "valueDEF",
            intArg: 999
        };
        $scope.onCancel = function (form) {
            notification('success', 'Cancel clicked on form "' + form.get(0).name + '"');
        };
        $scope.onSubmit = function (json, form) {
            notification('success', 'Form "' + form.get(0).name + '" submitted... (well not really), data:' + JSON.stringify(json));
        };
        $scope.derp = function (json, form) {
            notification('error', 'derp with json ' + JSON.stringify(json));
        };
        $scope.inputTableSchema = {
            properties: {
                'id': {
                    description: 'Object ID',
                    type: 'java.lang.String'
                }
            },
            description: 'Some objects'
        };
        $scope.inputTableData = [
            {
                id: "object1",
                name: 'foo'
            }, 
            {
                id: "object2",
                name: 'bar'
            }
        ];
        $scope.inputTableConfig = {
            data: 'inputTableData',
            displayFooter: false,
            showFilter: false,
            columnDefs: [
                {
                    field: 'id',
                    displayName: 'ID'
                }, 
                {
                    field: 'name',
                    displayName: 'Name'
                }
            ]
        };
    }
    Forms.FormTestController = FormTestController;
})(Forms || (Forms = {}));
var Git;
(function (Git) {
    var JolokiaGit = (function () {
        function JolokiaGit(mbean, jolokia, localStorage, branch) {
            if (typeof branch === "undefined") { branch = "master"; }
            this.mbean = mbean;
            this.jolokia = jolokia;
            this.localStorage = localStorage;
            this.branch = branch;
        }
        JolokiaGit.prototype.read = function (branch, path, fn) {
            this.jolokia.execute(this.mbean, "read", branch, path, onSuccess(fn));
        };
        JolokiaGit.prototype.write = function (branch, path, commitMessage, contents, fn) {
            var authorName = this.getUserName();
            var authorEmail = this.getUserEmail();
            this.jolokia.execute(this.mbean, "write", this.branch, path, commitMessage, authorName, authorEmail, contents, onSuccess(fn));
        };
        JolokiaGit.prototype.revertTo = function (objectId, blobPath, commitMessage, fn) {
            var authorName = this.getUserName();
            var authorEmail = this.getUserEmail();
            this.jolokia.execute(this.mbean, "revertTo", this.branch, objectId, blobPath, commitMessage, authorName, authorEmail, onSuccess(fn));
        };
        JolokiaGit.prototype.remove = function (path, commitMessage, fn) {
            var authorName = this.getUserName();
            var authorEmail = this.getUserEmail();
            this.jolokia.execute(this.mbean, "remove", this.branch, path, commitMessage, authorName, authorEmail, onSuccess(fn));
        };
        JolokiaGit.prototype.history = function (objectId, path, limit, fn) {
            this.jolokia.execute(this.mbean, "history", objectId, path, limit, onSuccess(fn));
        };
        JolokiaGit.prototype.diff = function (objectId, baseObjectId, path, fn) {
            this.jolokia.execute(this.mbean, "diff", objectId, baseObjectId, path, onSuccess(fn));
        };
        JolokiaGit.prototype.getContent = function (objectId, blobPath, fn) {
            this.jolokia.execute(this.mbean, "getContent", objectId, blobPath, onSuccess(fn));
        };
        JolokiaGit.prototype.readJsonChildContent = function (path, nameWildcard, search, fn) {
            this.jolokia.execute(this.mbean, "readJsonChildContent", this.branch, path, nameWildcard, search, onSuccess(fn));
        };
        JolokiaGit.prototype.getUserName = function () {
            return this.localStorage["gitUserName"] || "anonymous";
        };
        JolokiaGit.prototype.getUserEmail = function () {
            return this.localStorage["gitUserEmail"] || "anonymous@gmail.com";
        };
        return JolokiaGit;
    })();
    Git.JolokiaGit = JolokiaGit;    
})(Git || (Git = {}));
var Git;
(function (Git) {
    function createGitRepository(workspace, jolokia, localStorage) {
        var mbean = getGitMBean(workspace);
        if(mbean && jolokia) {
            return new Git.JolokiaGit(mbean, jolokia, localStorage);
        }
        return null;
    }
    Git.createGitRepository = createGitRepository;
    Git.jmxDomain = "io.hawt.git";
    Git.mbeanType = "GitFacade";
    function getGitMBean(workspace) {
        return Core.getMBeanTypeObjectName(workspace, Git.jmxDomain, Git.mbeanType);
    }
    Git.getGitMBean = getGitMBean;
    function getGitMBeanFolder(workspace) {
        return Core.getMBeanTypeFolder(workspace, Git.jmxDomain, Git.mbeanType);
    }
    Git.getGitMBeanFolder = getGitMBeanFolder;
    function isGitMBeanFabric(workspace) {
        var folder = getGitMBeanFolder(workspace);
        return folder && folder.entries["repo"] === "fabric";
    }
    Git.isGitMBeanFabric = isGitMBeanFabric;
})(Git || (Git = {}));
var Health;
(function (Health) {
    function HealthController($scope, workspace) {
        $scope.widget = new TableWidget($scope, workspace, [
            {
                "mDataProp": null,
                "sClass": "control center",
                "mData": null,
                "sDefaultContent": '<i class="icon-plus"></i>'
            }, 
            {
                "mDataProp": "level",
                "sDefaultContent": "",
                "mData": null
            }, 
            {
                "mDataProp": "domain",
                "sDefaultContent": "",
                "mData": null
            }, 
            {
                "mDataProp": "kind",
                "sDefaultContent": "",
                "mData": null
            }, 
            {
                "mDataProp": "message",
                "sDefaultContent": "",
                "mData": null,
                "sWidth": "60%"
            }
        ], {
            rowDetailTemplateId: 'healthEventTemplate',
            disableAddColumns: true
        });
        $scope.widget.dataTableConfig["fnRowCallback"] = function (nRow, aData, iDisplayIndex, iDisplayIndexFull) {
            var level = aData["level"];
            var style = logLevelClass(level);
            if(style) {
                $(nRow).addClass(style);
            }
        };
        $scope.results = [];
        $scope.$on("$routeChangeSuccess", function (event, current, previous) {
            setTimeout(updateTableContents, 50);
        });
        $scope.$watch('workspace.selection', function () {
            if(workspace.moveIfViewInvalid()) {
                return;
            }
            updateTableContents();
        });
        function updateTableContents() {
            var objects = Health.getHealthMBeans(workspace);
            if(objects) {
                var jolokia = workspace.jolokia;
                $scope.firstResult = true;
                if(angular.isArray(objects)) {
                    var args = [];
                    var onSuccessArray = [];
                    function callback(response, object) {
                        if($scope.firstResult) {
                            $scope.results = [];
                            $scope.firstResult = false;
                        }
                        var value = response.value;
                        if(value) {
                            if(angular.isArray(value)) {
                                if(value.length > 0) {
                                    angular.forEach(value, function (item) {
                                        $scope.results.push(item);
                                    });
                                } else {
                                    $scope.results.push(createOKStatus(object));
                                }
                            } else {
                                $scope.results.push(value);
                            }
                        } else {
                            $scope.results.push(createOKStatus(object));
                        }
                    }
                    angular.forEach(objects, function (mbean) {
                        args.push(asHealthQuery(mbean));
                        onSuccessArray.push(function (response) {
                            return callback(response, mbean);
                        });
                    });
                    onSuccessArray[onSuccessArray.length - 1] = function (response) {
                        callback(response, objects.last);
                        $scope.widget.populateTable(defaultValues($scope.results));
                        $scope.$apply();
                    };
                    jolokia.request(args, onSuccess(onSuccessArray));
                } else {
                    function populateTable(response) {
                        var values = response.value;
                        if(!values || values.length === 0) {
                            values = [
                                createOKStatus(objects)
                            ];
                        }
                        var data = defaultValues(values);
                        $scope.widget.populateTable(data);
                        $scope.$apply();
                    }
                    jolokia.request(asHealthQuery(objects), onSuccess(populateTable));
                }
            }
        }
        function defaultValues(values) {
            angular.forEach(values, function (aData) {
                var domain = aData["domain"];
                if(!domain) {
                    var id = aData["healthId"];
                    if(id) {
                        var idx = id.lastIndexOf('.');
                        if(idx > 0) {
                            domain = id.substring(0, idx);
                            var alias = Health.healthDomains[domain];
                            if(alias) {
                                domain = alias;
                            }
                            var kind = aData["kind"];
                            if(!kind) {
                                kind = humanizeValue(id.substring(idx + 1));
                                aData["kind"] = kind;
                            }
                        }
                    }
                    aData["domain"] = domain;
                }
            });
            return values;
        }
        function asHealthQuery(meanInfo) {
            return {
                type: 'exec',
                mbean: meanInfo.objectName,
                operation: 'healthList()'
            };
        }
        function createOKStatus(object) {
            return {
                healthId: object.domain + ".status",
                level: "INFO",
                message: object.title + " is OK"
            };
        }
    }
    Health.HealthController = HealthController;
})(Health || (Health = {}));
var Health;
(function (Health) {
    var pluginName = 'health';
    angular.module(pluginName, [
        'bootstrap', 
        'ngResource', 
        'hawtioCore'
    ]).config(function ($routeProvider) {
        $routeProvider.when('/health', {
            templateUrl: 'app/health/html/health.html'
        });
    }).run(function ($location, workspace, viewRegistry, layoutFull) {
        viewRegistry['health'] = layoutFull;
        workspace.topLevelTabs.push({
            content: "Health",
            title: "View the health of the various sub systems",
            isValid: function (workspace) {
                return Health.hasHealthMBeans(workspace);
            },
            href: function () {
                return "#/health";
            }
        });
    });
    hawtioPluginLoader.addModule(pluginName);
})(Health || (Health = {}));
var Health;
(function (Health) {
    Health.healthDomains = {
        "org.apache.activemq": "ActiveMQ",
        "org.apache.camel": "Camel",
        "org.fusesource.fabric": "Fabric"
    };
    function hasHealthMBeans(workspace) {
        var beans = getHealthMBeans(workspace);
        if(beans) {
            if(angular.isArray(beans)) {
                return beans.length >= 1;
            }
            return true;
        }
        return false;
    }
    Health.hasHealthMBeans = hasHealthMBeans;
    function getHealthMBeans(workspace) {
        if(workspace) {
            var healthMap = workspace.mbeanServicesToDomain["Health"] || {
            };
            var selection = workspace.selection;
            if(selection) {
                var domain = selection.domain;
                if(domain) {
                    var mbean = healthMap[domain];
                    if(mbean) {
                        return mbean;
                    }
                }
            }
            if(healthMap) {
                var answer = [];
                angular.forEach(healthMap, function (value) {
                    if(angular.isArray(value)) {
                        answer = answer.concat(value);
                    } else {
                        answer.push(value);
                    }
                });
                return answer;
            } else {
                return null;
            }
        }
    }
    Health.getHealthMBeans = getHealthMBeans;
})(Health || (Health = {}));
var Infinispan;
(function (Infinispan) {
    var CLI = (function () {
        function CLI(workspace, jolokia) {
            this.workspace = workspace;
            this.jolokia = jolokia;
            this.cacheName = null;
            this.sessionId = null;
            this.useSessionIds = true;
        }
        CLI.prototype.setCacheName = function (name) {
            if(name) {
                name = trimQuotes(name);
                var postfix = "(local)";
                if(name.endsWith(postfix)) {
                    name = name.substring(0, name.length - postfix.length);
                }
            }
            if(!this.cacheName || this.cacheName !== name) {
                if(this.sessionId) {
                    this.deleteSession(this.sessionId);
                }
                this.cacheName = name;
                this.createSession();
            }
        };
        CLI.prototype.createSession = function () {
            var _this = this;
            if(this.useSessionIds) {
                var mbean = Infinispan.getInterpreterMBean(this.workspace);
                if(mbean) {
                    var cli = this;
                    this.jolokia.execute(mbean, "createSessionId", this.cacheName, onSuccess(function (value) {
                        console.log("Has session ID: " + value);
                        _this.sessionId = value;
                    }));
                } else {
                    this.warnMissingMBean();
                }
            }
        };
        CLI.prototype.execute = function (sql, handler) {
            if(sql) {
                sql = sql.trim();
                if(!sql.endsWith(";")) {
                    sql += ";";
                }
                var sessionId = (this.useSessionIds) ? this.sessionId : null;
                if(!this.useSessionIds) {
                    sql = "cache " + this.cacheName + "; " + sql;
                }
                if(sessionId || !this.useSessionIds) {
                    var mbean = Infinispan.getInterpreterMBean(this.workspace);
                    if(mbean) {
                        this.jolokia.execute(mbean, "execute", sessionId, sql, onSuccess(handler));
                    } else {
                        this.warnMissingMBean();
                    }
                } else {
                    notification("warning", "Cannot evaluate SQL as we don't have a sessionId yet!");
                }
            }
        };
        CLI.prototype.deleteSession = function (sessionId) {
        };
        CLI.prototype.warnMissingMBean = function () {
            notification("error", "No Interpreter MBean available");
        };
        return CLI;
    })();
    Infinispan.CLI = CLI;    
})(Infinispan || (Infinispan = {}));
var Infinispan;
(function (Infinispan) {
    function infinispanCacheName(entity) {
        if(entity) {
            var id = entity._id;
            if(id) {
                var prefix = 'name="';
                var idx = id.indexOf(prefix);
                if(idx > 0) {
                    idx += prefix.length;
                    var lastIdx = id.indexOf('"', idx + 1);
                    if(lastIdx > 0) {
                        return id.substring(idx, lastIdx);
                    } else {
                        return id.substring(idx);
                    }
                }
            }
            return id;
        }
        return null;
    }
    Infinispan.infinispanCacheName = infinispanCacheName;
    function getInterpreterMBean(workspace) {
        if(workspace) {
            var folder = workspace.findMBeanWithProperties(Infinispan.jmxDomain, {
                component: "Interpreter",
                type: "CacheManager"
            });
            if(folder) {
                return folder.objectName;
            }
        }
        return null;
    }
    Infinispan.getInterpreterMBean = getInterpreterMBean;
    function getSelectedCacheName(workspace) {
        var selection = workspace.selection;
        if(selection && selection.domain === Infinispan.jmxDomain) {
            return selection.entries["name"];
        }
        return null;
    }
    Infinispan.getSelectedCacheName = getSelectedCacheName;
})(Infinispan || (Infinispan = {}));
var Infinispan;
(function (Infinispan) {
    var pluginName = 'infinispan';
    Infinispan.jmxDomain = 'Infinispan';
    var toolBar = "app/infinispan/html/attributeToolBar.html";
    angular.module(pluginName, [
        'bootstrap', 
        'ngResource', 
        'hawtioCore'
    ]).config(function ($routeProvider) {
        $routeProvider.when('/infinispan/query', {
            templateUrl: 'app/infinispan/html/query.html'
        });
    }).filter('infinispanCacheName', function () {
        return Infinispan.infinispanCacheName;
    }).run(function (workspace, viewRegistry) {
        viewRegistry['infinispan'] = 'app/infinispan/html/layoutCacheTree.html';
        var nameTemplate = '<div class="ngCellText" title="Infinispan Cache">{{row.entity | infinispanCacheName}}</div>';
        var attributes = workspace.attributeColumnDefs;
        attributes[Infinispan.jmxDomain + "/Caches/folder"] = [
            {
                field: '_id',
                displayName: 'Name',
                cellTemplate: nameTemplate,
                width: "**"
            }, 
            {
                field: 'numberOfEntries',
                displayName: 'Entries'
            }, 
            {
                field: 'hits',
                displayName: 'Hits'
            }, 
            {
                field: 'hitRatio',
                displayName: 'Hit Ratio'
            }, 
            {
                field: 'stores',
                displayName: 'Stores'
            }, 
            {
                field: 'averageReadTime',
                displayName: 'Avg Read Time'
            }, 
            {
                field: 'averageWriteTime',
                displayName: 'Avg Write Time'
            }
        ];
        workspace.topLevelTabs.push({
            content: "Infinispan",
            title: "View your distributed data",
            isValid: function (workspace) {
                return workspace.treeContainsDomainAndProperties(Infinispan.jmxDomain);
            },
            href: function () {
                return "#/jmx/attributes?tab=infinispan";
            },
            isActive: function (workspace) {
                return workspace.isTopTabActive("infinispan");
            }
        });
        workspace.subLevelTabs.push({
            content: '<i class="icon-pencil"></i> Query',
            title: "Perform InSQL commands on the cache",
            isValid: function (workspace) {
                return Infinispan.getSelectedCacheName(workspace) && Infinispan.getInterpreterMBean(workspace);
            },
            href: function () {
                return "#/infinispan/query";
            }
        });
    });
    hawtioPluginLoader.addModule(pluginName);
})(Infinispan || (Infinispan = {}));
var Infinispan;
(function (Infinispan) {
    function QueryController($scope, $location, workspace, jolokia) {
        var interpreter = new Infinispan.CLI(workspace, jolokia);
        $scope.logs = [];
        $scope.filteredLogs = [];
        $scope.selectedItems = [];
        $scope.searchText = "";
        $scope.filter = {
            logLevelQuery: "",
            logLevelExactMatch: false
        };
        var columnDefs = [
            {
                field: 'key',
                displayName: 'Key'
            }, 
            {
                field: 'value',
                displayName: 'Value'
            }
        ];
        $scope.gridOptions = {
            selectedItems: $scope.selectedItems,
            data: 'filteredLogs',
            displayFooter: false,
            showFilter: false,
            filterOptions: {
                filterText: "searchText"
            },
            columnDefs: columnDefs,
            rowDetailTemplateId: "logDetailTemplate"
        };
        $scope.$on("$routeChangeSuccess", function (event, current, previous) {
            setTimeout(refreshCacheName, 50);
        });
        $scope.$watch('workspace.selection', function () {
            refreshCacheName();
        });
        $scope.doQuery = function () {
            if($scope.sql) {
                interpreter.execute($scope.sql, handleResults);
            }
        };
        function handleResults(results) {
            $scope.output = null;
            if(!results) {
                console.log("no output...");
            } else {
                var error = results["ERROR"] || "";
                var stackTrace = results["STACKTRACE"] || "";
                if(error || stackTrace) {
                    if(stackTrace) {
                        error += "\n" + stackTrace;
                    }
                    notification("error", error);
                } else {
                    var output = results["OUTPUT"];
                    if(!output) {
                        notification("error", "No results!");
                    } else {
                        $scope.output = output;
                        console.log("==== output: " + output);
                        Core.$apply($scope);
                    }
                }
            }
        }
        function refreshCacheName() {
            var cacheName = Infinispan.getSelectedCacheName(workspace);
            console.log("selected cacheName is: " + cacheName);
            if(cacheName) {
                interpreter.setCacheName(cacheName);
            }
        }
    }
    Infinispan.QueryController = QueryController;
})(Infinispan || (Infinispan = {}));
var Infinispan;
(function (Infinispan) {
    function TreeController($scope, $location, workspace) {
        $scope.$on("$routeChangeSuccess", function (event, current, previous) {
            setTimeout(updateSelectionFromURL, 50);
        });
        $scope.$watch('workspace.tree', function () {
            if(workspace.moveIfViewInvalid()) {
                return;
            }
            var children = [];
            var tree = workspace.tree;
            if(tree) {
                var domainName = Infinispan.jmxDomain;
                var folder = tree.get(domainName);
                if(folder) {
                    var cachesFolder = new Folder("Caches");
                    cachesFolder.domain = domainName;
                    cachesFolder.key = "root-Infinispan-Caches";
                    cachesFolder.typeName = "Caches";
                    children.push(cachesFolder);
                    addAllCacheStatistics(folder, cachesFolder);
                }
                var treeElement = $("#infinispantree");
                Jmx.enableTree($scope, $location, workspace, treeElement, children);
                setTimeout(updateSelectionFromURL, 50);
            }
        });
        function addAllCacheStatistics(folder, answer) {
            if(folder) {
                var children = folder.children;
                if(children) {
                    angular.forEach(folder.children, function (value, key) {
                        if(value.objectName && value.title === "Statistics") {
                            var cacheName = value.parent.parent.title || value.title;
                            var name = humanizeValue(cacheName);
                            var cacheFolder = new Folder(name);
                            cacheFolder.addClass = "org-infinispn-cache";
                            cacheFolder.typeName = "Cache";
                            cacheFolder.key = answer.key + "-" + cacheName;
                            cacheFolder.objectName = value.objectName;
                            cacheFolder.domain = value.domain;
                            cacheFolder.entries = value.entries;
                            answer.children.push(cacheFolder);
                        } else {
                            addAllCacheStatistics(value, answer);
                        }
                    });
                }
            }
        }
        function updateSelectionFromURL() {
            Jmx.updateTreeSelectionFromURL($location, $("#infinispantree"), true);
        }
    }
    Infinispan.TreeController = TreeController;
})(Infinispan || (Infinispan = {}));
var Insight;
(function (Insight) {
    function AllController($scope, jolokia, localStorage) {
        $scope.result = null;
        $scope.containers = [];
        $scope.profiles = [
            Insight.allContainers
        ];
        $scope.versions = [];
        $scope.profile = Insight.allContainers;
        $scope.time_options = [
            '1m', 
            '5m', 
            '15m', 
            '1h', 
            '6h', 
            '12h'
        ];
        $scope.timespan = '1m';
        $scope.updateRate = parseInt(localStorage['updateRate']);
        $scope.chartsMeta = [];
        Core.register(jolokia, $scope, {
            type: 'exec',
            mbean: Insight.managerMBean,
            operation: 'containers()',
            arguments: []
        }, onSuccess(onContainers));
        function onContainers(response) {
            if(!Object.equal($scope.result, response.value)) {
                $scope.result = response.value;
                $scope.containers = [];
                $scope.profiles = [
                    Insight.allContainers
                ];
                $scope.versions = [];
                $scope.result.forEach(function (container) {
                    $scope.profiles = $scope.profiles.union(container.profileIds.map(function (id) {
                        return {
                            id: id
                        };
                    }));
                    $scope.versions = $scope.versions.union([
                        container.versionId
                    ]);
                    $scope.containers.push({
                        name: container.id,
                        alive: container.alive,
                        version: container.versionId,
                        profileIds: container.profileIds
                    });
                });
                $scope.$apply();
            }
        }
        $scope.metrics = jQuery.parseJSON(jolokia.getAttribute("org.fusesource.insight:type=MetricsCollector", "Metrics"));
        var jreq = {
            type: 'exec',
            mbean: 'org.elasticsearch:service=restjmx',
            operation: 'exec',
            arguments: [
                'GET', 
                '/_all/_mapping', 
                null
            ]
        };
        jolokia.request(jreq, {
            success: function (response) {
                var data = jQuery.parseJSON(response.value);
                var roots = {
                };
                var children = [];
                for(var index in data) {
                    if(index.startsWith("insight-")) {
                        for(var mapping in data[index]) {
                            if(mapping.startsWith("sta-")) {
                                var name = mapping.substring(4);
                                if(!roots[name]) {
                                    roots[name] = true;
                                    children.push({
                                        title: name,
                                        expand: true,
                                        children: getChildren(data[index][mapping], name, "", data[index][mapping]["properties"]["host"] !== undefined)
                                    });
                                }
                            }
                        }
                    }
                }
                $("#insighttree").dynatree({
                    checkbox: true,
                    selectMode: 2,
                    onSelect: onSelect,
                    onClick: onClick,
                    onKeydown: onKeydown,
                    children: children
                });
            }
        });
        $scope.set_timespan = function (t) {
            $scope.timespan = t;
            rebuildCharts();
        };
        $scope.profile_changed = function () {
            rebuildCharts();
        };
        function onSelect(flag, node) {
            var selNodes = node.tree.getSelectedNodes();
            $scope.chartsMeta = selNodes.map(function (node) {
                var data = node.data;
                return {
                    name: data["field"],
                    field: data["field"],
                    type: data["type"],
                    host: data["hasHost"]
                };
            });
            rebuildCharts();
        }
        function onClick(node, event) {
            if(node.getEventTargetType(event) === "title") {
                node.toggleSelect();
            }
        }
        function onKeydown(node, event) {
            if(event.which === 32) {
                node.toggleSelect();
                return false;
            }
        }
        function rebuildCharts() {
            var chartsDef = [];
            $scope.chartsMeta.forEach(function (meta) {
                var metadata = $scope.metrics[meta.type] !== undefined ? $scope.metrics[meta.type][meta.field] : undefined;
                if(meta.host) {
                    $scope.containers.forEach(function (container) {
                        if($scope.profile === Insight.allContainers || $.inArray($scope.profile.id, container.profileIds) >= 0) {
                            chartsDef.push({
                                name: (metadata !== undefined ? metadata['description'] : meta.name) + " [" + container.name + "]",
                                type: "sta-" + meta.type,
                                field: meta.field,
                                query: "host: \"" + container.name + "\"",
                                meta: metadata
                            });
                        }
                    });
                } else {
                    chartsDef.push({
                        name: metadata !== undefined ? metadata['description'] : meta.name,
                        type: "sta-" + meta.type,
                        field: meta.field,
                        meta: metadata
                    });
                }
            });
            Insight.createCharts($scope, chartsDef, "#charts", jolokia);
        }
    }
    Insight.AllController = AllController;
    function getChildren(node, type, field, hasHost) {
        var children = [];
        for(var p in node["properties"]) {
            var obj = node["properties"][p];
            if(obj["type"] === 'long' || obj["type"] === 'double') {
                children.push({
                    title: p,
                    field: field + p,
                    type: type,
                    hasHost: hasHost
                });
            } else {
                if(obj["properties"]) {
                    children.push({
                        title: p,
                        isFolder: true,
                        children: getChildren(obj, type, field + p + ".", hasHost)
                    });
                }
            }
        }
        return children;
    }
})(Insight || (Insight = {}));
var Insight;
(function (Insight) {
    function ElasticSearchController($scope, jolokia, localStorage) {
        $scope.time_options = [
            '1m', 
            '5m', 
            '15m', 
            '1h', 
            '6h', 
            '12h'
        ];
        $scope.timespan = '1m';
        $scope.metrics = [];
        $scope.updateRate = parseInt(localStorage['updateRate']);
        $scope.data = [];
        var chartsDef = [
            {
                name: "active primary shards",
                type: "sta-elasticsearch",
                field: "active_primary_shards"
            }, 
            {
                name: "active shards",
                type: "sta-elasticsearch",
                field: "active_shards"
            }, 
            {
                name: "relocating shards",
                type: "sta-elasticsearch",
                field: "relocating_shards"
            }, 
            {
                name: "initializing shards",
                type: "sta-elasticsearch",
                field: "initializing_shards"
            }, 
            {
                name: "unassigned shards",
                type: "sta-elasticsearch",
                field: "unassigned_shards"
            }
        ];
        var mainDiv = "#charts";
        $scope.set_timespan = function (t) {
            $scope.timespan = t;
            rebuildCharts();
        };
        rebuildCharts();
        function rebuildCharts() {
            Insight.createCharts($scope, chartsDef, mainDiv, jolokia);
        }
    }
    Insight.ElasticSearchController = ElasticSearchController;
})(Insight || (Insight = {}));
var Insight;
(function (Insight) {
    Insight.managerMBean = "org.fusesource.fabric:type=Fabric";
    Insight.allContainers = {
        id: '-- all --'
    };
    function createCharts($scope, chartsDef, element, jolokia) {
        var chartsDiv = $(element);
        var width = chartsDiv.width();
        var context = cubism.context().serverDelay(interval_to_seconds('1m') * 1000).clientDelay($scope.updateRate).step(interval_to_seconds($scope.timespan) * 1000).size(width);
        var d3Selection = d3.select(chartsDiv[0]);
        d3Selection.html("");
        d3Selection.selectAll(".axis").data([
            "top", 
            "bottom"
        ]).enter().append("div").attr("class", function (d) {
            return d + " axis";
        }).each(function (d) {
            d3.select(this).call(context.axis().ticks(12).orient(d));
        });
        d3Selection.append("div").attr("class", "rule").call(context.rule());
        context.on("focus", function (i) {
            d3Selection.selectAll(".value").style("right", i === null ? null : context.size() - i + "px");
        });
        chartsDef.forEach(function (chartDef) {
            d3Selection.call(function (div) {
                div.append("div").data([
                    chart(context, chartDef, jolokia)
                ]).attr("class", "horizon").call(context.horizon());
            });
        });
    }
    Insight.createCharts = createCharts;
    function chart(context, chartDef, jolokia) {
        return context.metric(function (start, stop, step, callback) {
            var values = [], value = 0, start = +start, stop = +stop;
            var range = {
                range: {
                    timestamp: {
                        from: new Date(start).toISOString(),
                        to: new Date(stop).toISOString()
                    }
                }
            };
            var filter;
            if(chartDef.query) {
                filter = {
                    fquery: {
                        query: {
                            filtered: {
                                query: {
                                    query_string: {
                                        query: chartDef.query
                                    }
                                },
                                filter: range
                            }
                        }
                    }
                };
            } else {
                filter = range;
            }
            var request = {
                size: 0,
                facets: {
                    histo: {
                        date_histogram: {
                            value_field: chartDef.field,
                            key_field: "timestamp",
                            interval: step + "ms"
                        },
                        facet_filter: filter
                    }
                }
            };
            var jreq = {
                type: 'exec',
                mbean: 'org.elasticsearch:service=restjmx',
                operation: 'exec',
                arguments: [
                    'POST', 
                    '/_all/' + chartDef.type + '/_search', 
                    JSON.stringify(request)
                ]
            };
            jolokia.request(jreq, {
                success: function (response) {
                    var map = {
                    };
                    var data = jQuery.parseJSON(response.value)["facets"]["histo"]["entries"];
                    data.forEach(function (entry) {
                        map[entry.time] = entry.max;
                    });
                    var delta = 0;
                    if(chartDef.meta !== undefined) {
                        if(chartDef.meta['type'] === 'trends-up' || chartDef.meta['type'] === 'peak') {
                            delta = 1;
                        } else {
                            if(chartDef.meta['type'] === 'trends-down') {
                                delta = -1;
                            }
                        }
                    }
                    while(start < stop) {
                        var v = 0;
                        if(delta !== 0) {
                            if(map[start - step] !== undefined) {
                                var d = (map[start] - map[start - step]) * delta;
                                v = d > 0 ? d : 0;
                            }
                        } else {
                            if(map[start] !== undefined) {
                                v = map[start];
                            }
                        }
                        values.push(v);
                        start += step;
                    }
                    callback(null, values);
                }
            });
        }, chartDef.name);
    }
    function interval_to_seconds(string) {
        var matches = string.match(/(\d+)([Mwdhms])/);
        switch(matches[2]) {
            case 'M': {
                return matches[1] * 2592000;
                ; ;

            }
            case 'w': {
                return matches[1] * 604800;
                ; ;

            }
            case 'd': {
                return matches[1] * 86400;
                ; ;

            }
            case 'h': {
                return matches[1] * 3600;
                ; ;

            }
            case 'm': {
                return matches[1] * 60;
                ; ;

            }
            case 's': {
                return matches[1];

            }
        }
    }
    function time_ago(string) {
        return new Date(new Date().getTime() - (interval_to_seconds(string) * 1000));
    }
})(Insight || (Insight = {}));
var Insight;
(function (Insight) {
    var insightPlugin = angular.module('insight', [
        'hawtioCore'
    ]).config(function ($routeProvider) {
        $routeProvider.when('/insight/all', {
            templateUrl: 'app/insight/html/all.html'
        }).when('/insight/jvms', {
            templateUrl: 'app/insight/html/jvms.html'
        }).when('/insight/elasticsearch', {
            templateUrl: 'app/insight/html/elasticsearch.html'
        });
    });
    insightPlugin.run(function (workspace, viewRegistry, layoutFull) {
        viewRegistry["insight"] = "app/insight/html/layoutInsight.html";
        workspace.topLevelTabs.push({
            content: "Insight",
            title: "View Insight metrics",
            isValid: function (workspace) {
                return workspace.treeContainsDomainAndProperties('org.elasticsearch', {
                    service: 'restjmx'
                });
            },
            href: function () {
                return "#/insight/all";
            }
        });
    });
    hawtioPluginLoader.addModule('insight');
})(Insight || (Insight = {}));
var Insight;
(function (Insight) {
    function JVMsController($scope, jolokia, localStorage) {
        $scope.time_options = [
            '1m', 
            '5m', 
            '15m', 
            '1h', 
            '6h', 
            '12h'
        ];
        $scope.timespan = '1m';
        $scope.containers = [];
        $scope.profiles = [
            Insight.allContainers
        ];
        $scope.versions = [];
        $scope.profile = Insight.allContainers;
        $scope.metrics = [];
        $scope.updateRate = parseInt(localStorage['updateRate']);
        $scope.data = [];
        var chartsMeta = [
            {
                name: "threads",
                type: "sta-jvm",
                field: "threads.count"
            }, 
            {
                name: "mem",
                type: "sta-jvm",
                field: "mem.heap_used"
            }
        ];
        var mainDiv = "#charts";
        $scope.set_timespan = function (t) {
            $scope.timespan = t;
            rebuildCharts();
        };
        $scope.profile_changed = function () {
            rebuildCharts();
        };
        Core.register(jolokia, $scope, {
            type: 'exec',
            mbean: Insight.managerMBean,
            operation: 'containers()',
            arguments: []
        }, onSuccess(onContainers));
        function onContainers(response) {
            if(!Object.equal($scope.result, response.value)) {
                $scope.result = response.value;
                $scope.containers = [];
                $scope.profiles = [
                    Insight.allContainers
                ];
                $scope.versions = [];
                $scope.result.forEach(function (container) {
                    $scope.profiles = $scope.profiles.union(container.profileIds.map(function (id) {
                        return {
                            id: id
                        };
                    }));
                    $scope.versions = $scope.versions.union([
                        container.versionId
                    ]);
                    $scope.containers.push({
                        name: container.id,
                        alive: container.alive,
                        version: container.versionId,
                        profileIds: container.profileIds
                    });
                });
                $scope.$apply();
                rebuildCharts();
            }
        }
        function rebuildCharts() {
            var chartsDef = [];
            chartsMeta.forEach(function (meta) {
                $scope.containers.forEach(function (container) {
                    if($scope.profile === Insight.allContainers || $.inArray($scope.profile.id, container.profileIds) >= 0) {
                        chartsDef.push({
                            name: meta.name + " [" + container.name + "]",
                            type: meta.type,
                            field: meta.field,
                            query: "host: \"" + container.name + "\""
                        });
                    }
                });
            });
            Insight.createCharts($scope, chartsDef, mainDiv, jolokia);
        }
    }
    Insight.JVMsController = JVMsController;
})(Insight || (Insight = {}));
var JBoss;
(function (JBoss) {
    function ConnectorsController($scope, $location, workspace, jolokia) {
        var stateTemplate = '<div class="ngCellText pagination-centered" title="{{row.getProperty(col.field)}}"><i class="{{row.getProperty(col.field) | jbossIconClass}}"></i></div>';
        $scope.connectors = [];
        var columnDefs = [
            {
                field: 'bound',
                displayName: 'State',
                cellTemplate: stateTemplate,
                width: 56,
                minWidth: 56,
                maxWidth: 56,
                resizable: false
            }, 
            {
                field: 'name',
                displayName: 'Name',
                cellFilter: null,
                width: "*",
                resizable: true
            }, 
            {
                field: 'port',
                displayName: 'Port',
                cellFilter: null,
                width: "*",
                resizable: true
            }, 
            
        ];
        $scope.gridOptions = {
            data: 'connectors',
            displayFooter: false,
            displaySelectionCheckbox: false,
            canSelectRows: false,
            columnDefs: columnDefs,
            filterOptions: {
                filterText: ''
            }
        };
        function render(response) {
            $scope.connectors = [];
            function onAttributes(response) {
                var obj = response.value;
                if(obj) {
                    obj.mbean = response.request.mbean;
                    if(!obj.port) {
                        obj.port = obj.boundPort;
                    }
                    if(!obj.name) {
                        obj.name = "mail-smtp";
                    }
                    $scope.connectors.push(obj);
                    Core.$apply($scope);
                }
            }
            angular.forEach(response, function (value, key) {
                var mbean = value;
                if(mbean.toString() !== "jboss.as:socket-binding-group=standard-sockets") {
                    if(mbean.toString().lastIndexOf("management") > 0) {
                        jolokia.request({
                            type: "read",
                            mbean: mbean,
                            attribute: [
                                "boundPort", 
                                "name", 
                                "bound"
                            ]
                        }, onSuccess(onAttributes));
                    } else {
                        if(mbean.toString().lastIndexOf("mail-smtp") > 0) {
                            jolokia.request({
                                type: "read",
                                mbean: mbean,
                                attribute: [
                                    "port"
                                ]
                            }, onSuccess(onAttributes));
                        } else {
                            jolokia.request({
                                type: "read",
                                mbean: mbean,
                                attribute: [
                                    "port", 
                                    "name", 
                                    "bound"
                                ]
                            }, onSuccess(onAttributes));
                        }
                    }
                }
            });
            Core.$apply($scope);
        }
        ; ;
        $scope.$on('jmxTreeUpdated', reloadFunction);
        $scope.$watch('workspace.tree', reloadFunction);
        function reloadFunction() {
            setTimeout(loadData, 50);
        }
        function loadData() {
            console.log("Loading JBoss connector data...");
            jolokia.search("jboss.as:socket-binding-group=standard-sockets,*", onSuccess(render));
        }
    }
    JBoss.ConnectorsController = ConnectorsController;
})(JBoss || (JBoss = {}));
var JBoss;
(function (JBoss) {
    function DmrController($scope, $location, workspace) {
        var search = $location.search();
        var url = "/hawtio/proxy/localhost/9990/management";
        var user = search["_user"] || "";
        var pwd = search["_pwd"] || "";
        if(user) {
            url += "?_user=" + user;
            if(pwd) {
                url += "&_pwd=" + pwd;
            }
        }
        var isDmr = "dmr" === search["_format"];
        var data = null;
        var format = "application/dmr-encoded";
        if(isDmr) {
            var op = new dmr.ModelNode();
            op.get("operation").set("read-attribute");
            op.get("address").setEmptyList();
            op.get("name").set("release-version");
            data = op.toBase64String();
        } else {
            format = "application/json";
            var request = {
                "operation": "read-resource"
            };
            data = JSON.stringify(request);
        }
        console.log("Using dmr: " + isDmr + " with content type: " + format + " and data " + data);
        $.ajax({
            url: url,
            data: data,
            processData: false,
            type: "POST",
            dataType: "text",
            contentType: format,
            accepts: format,
            headers: {
                "Content-type": format,
                "Accept": format
            }
        }).done(onData);
        function onData(data) {
            if(data) {
                var json = null;
                if(isDmr) {
                    var response = dmr.ModelNode.fromBase64(data);
                    var jsonText = response.toJSONString();
                    json = JSON.parse(jsonText);
                } else {
                    json = JSON.parse(data);
                    json = json.result;
                }
                $scope.row = json;
                Core.$apply($scope);
                console.log("Response: " + JSON.stringify(json, null, "  "));
            }
        }
    }
    JBoss.DmrController = DmrController;
})(JBoss || (JBoss = {}));
var JBoss;
(function (JBoss) {
    function cleanWebAppName(name) {
        if(name && name.lastIndexOf(".war") > -1) {
            return name.replace(".war", "");
        } else {
            return name;
        }
    }
    JBoss.cleanWebAppName = cleanWebAppName;
    function cleanContextPath(contextPath) {
        if(contextPath) {
            return "/" + cleanWebAppName(contextPath);
        } else {
            return "";
        }
    }
    JBoss.cleanContextPath = cleanContextPath;
    function iconClass(state) {
        if(state) {
            switch(state.toString().toLowerCase()) {
                case 'started': {
                    return "green icon-play-circle";

                }
                case 'ok': {
                    return "green icon-play-circle";

                }
                case 'true': {
                    return "green icon-play-circle";

                }
            }
        }
        return "orange icon-off";
    }
    JBoss.iconClass = iconClass;
})(JBoss || (JBoss = {}));
var JBoss;
(function (JBoss) {
    function JBossController($scope, $location, jolokia) {
        var stateTemplate = '<div class="ngCellText pagination-centered" title="{{row.getProperty(col.field)}}"><i class="{{row.getProperty(col.field) | jbossIconClass}}"></i></div>';
        $scope.uninstallDialog = new Core.Dialog();
        $scope.webapps = [];
        $scope.selected = [];
        var columnDefs = [
            {
                field: 'status',
                displayName: 'State',
                cellTemplate: stateTemplate,
                width: 56,
                minWidth: 56,
                maxWidth: 56,
                resizable: false
            }, 
            {
                field: 'name',
                displayName: 'Name',
                cellFilter: null,
                width: "*",
                resizable: true
            }, 
            {
                field: 'contextPath',
                displayName: 'Context-Path',
                cellFilter: null,
                width: "*",
                resizable: true
            }, 
            
        ];
        $scope.gridOptions = {
            data: 'webapps',
            displayFooter: true,
            selectedItems: $scope.selected,
            selectWithCheckboxOnly: true,
            columnDefs: columnDefs,
            filterOptions: {
                filterText: ''
            }
        };
        function render(response) {
            $scope.webapps = [];
            $scope.mbeanIndex = {
            };
            $scope.selected.length = 0;
            function onAttributes(response) {
                var obj = response.value;
                if(obj) {
                    obj.mbean = response.request.mbean;
                    var mbean = obj.mbean;
                    if(mbean) {
                        obj.name = JBoss.cleanWebAppName(obj.name);
                        obj.contextPath = JBoss.cleanContextPath(obj.name);
                        var idx = $scope.mbeanIndex[mbean];
                        if(angular.isDefined(idx)) {
                            $scope.webapps[mbean] = obj;
                        } else {
                            $scope.mbeanIndex[mbean] = $scope.webapps.length;
                            $scope.webapps.push(obj);
                        }
                        Core.$apply($scope);
                    }
                }
            }
            angular.forEach(response, function (value, key) {
                var mbean = value;
                jolokia.request({
                    type: "read",
                    mbean: mbean,
                    attribute: [
                        "name", 
                        "status"
                    ]
                }, onSuccess(onAttributes));
            });
            Core.$apply($scope);
        }
        ; ;
        $scope.controlWebApps = function (op) {
            var mbeanNames = $scope.selected.map(function (b) {
                return b.mbean;
            });
            if(!angular.isArray(mbeanNames)) {
                mbeanNames = [
                    mbeanNames
                ];
            }
            var lastIndex = (mbeanNames.length || 1) - 1;
            angular.forEach(mbeanNames, function (mbean, idx) {
                var onResponse = (idx >= lastIndex) ? $scope.onLastResponse : $scope.onResponse;
                jolokia.request({
                    type: 'exec',
                    mbean: mbean,
                    operation: op,
                    arguments: null
                }, onSuccess(onResponse, {
                    error: onResponse
                }));
            });
        };
        $scope.start = function () {
            $scope.controlWebApps('deploy');
        };
        $scope.stop = function () {
            $scope.controlWebApps('undeploy');
        };
        $scope.reload = function () {
            $scope.controlWebApps('redeploy');
        };
        $scope.uninstall = function () {
            $scope.controlWebApps('remove');
            $scope.uninstallDialog.close();
        };
        $scope.onLastResponse = function (response) {
            $scope.onResponse(response);
            loadData();
        };
        $scope.onResponse = function (response) {
        };
        $scope.$on('jmxTreeUpdated', reloadFunction);
        $scope.$watch('workspace.tree', reloadFunction);
        function reloadFunction() {
            setTimeout(loadData, 50);
        }
        function loadData() {
            console.log("Loading JBoss webapp data...");
            jolokia.search("jboss.as:deployment=*", onSuccess(render));
        }
        $scope.jbossServerVersion = "";
        $scope.jbossServerName = "";
        $scope.jbossServerLaunchType = "";
        var servers = jolokia.search("jboss.as:management-root=server");
        if(servers && servers.length === 1) {
            $scope.jbossServerVersion = jolokia.getAttribute(servers[0], "releaseVersion");
            $scope.jbossServerName = jolokia.getAttribute(servers[0], "name");
            $scope.jbossServerLaunchType = jolokia.getAttribute(servers[0], "launchType");
        } else {
            console.log("Cannot find JBoss server or there was more than one server. response is: " + servers);
        }
    }
    JBoss.JBossController = JBossController;
})(JBoss || (JBoss = {}));
var JBoss;
(function (JBoss) {
    var pluginName = 'jboss';
    angular.module(pluginName, [
        'bootstrap', 
        'ngResource', 
        'ui.bootstrap.dialog', 
        'hawtioCore'
    ]).config(function ($routeProvider) {
        $routeProvider.when('/jboss/server', {
            templateUrl: 'app/jboss/html/server.html'
        }).when('/jboss/applications', {
            templateUrl: 'app/jboss/html/applications.html'
        }).when('/jboss/dmr', {
            templateUrl: 'app/jboss/html/dmr.html'
        }).when('/jboss/connectors', {
            templateUrl: 'app/jboss/html/connectors.html'
        }).when('/jboss/mbeans', {
            templateUrl: 'app/jboss/html/mbeans.html'
        });
    }).filter('jbossIconClass', function () {
        return JBoss.iconClass;
    }).run(function ($location, workspace, viewRegistry, layoutFull) {
        viewRegistry['jboss'] = "app/jboss/html/layoutJBossTabs.html";
        viewRegistry['jbossTree'] = "app/jboss/html/layoutJBossTree.html";
        workspace.topLevelTabs.push({
            content: "JBoss",
            title: "Manage your JBoss container",
            isValid: function (workspace) {
                return workspace.treeContainsDomainAndProperties("jboss.as") || workspace.treeContainsDomainAndProperties("jboss.jta") || workspace.treeContainsDomainAndProperties("jboss.modules");
            },
            href: function () {
                return "#/jboss/applications";
            },
            isActive: function (workspace) {
                return workspace.isTopTabActive("jboss");
            }
        });
    });
    hawtioPluginLoader.addModule(pluginName);
})(JBoss || (JBoss = {}));
var JBoss;
(function (JBoss) {
    function TreeController($scope, $location, workspace) {
        $scope.$on("$routeChangeSuccess", function (event, current, previous) {
            setTimeout(updateSelectionFromURL, 50);
        });
        $scope.$watch('workspace.tree', function () {
            console.log("workspace tree has changed, lets reload!!");
            if(workspace.moveIfViewInvalid()) {
                return;
            }
            var children = [];
            var tree = workspace.tree;
            if(tree) {
                var nodes = tree.children;
                angular.forEach(nodes, function (node) {
                    var nodeChildren = node.children;
                    if(node.title.startsWith("jboss") && nodeChildren) {
                        children = children.concat(nodeChildren);
                    }
                });
            }
            var treeElement = $("#jbossTree");
            Jmx.enableTree($scope, $location, workspace, treeElement, children, true);
            setTimeout(updateSelectionFromURL, 50);
        });
        function updateSelectionFromURL() {
            Jmx.updateTreeSelectionFromURL($location, $("#jbossTree"), true);
        }
    }
    JBoss.TreeController = TreeController;
})(JBoss || (JBoss = {}));
var Jclouds;
(function (Jclouds) {
    function ApiListController($scope, $location, workspace, jolokia) {
        $scope.result = {
        };
        $scope.apis = [];
        $scope.type = "";
        $scope.types = [
            "", 
            "blobstore", 
            "compute", 
            "loadbalancer"
        ];
        var key = $location.search()['type'];
        if(key) {
            $scope.type = key;
        }
        $scope.selectedApis = [];
        $scope.apiTable = {
            data: 'apis',
            showFilter: false,
            showColumnMenu: false,
            filterOptions: {
                useExternalFilter: true
            },
            selectedItems: $scope.selectedApis,
            rowHeight: 32,
            selectWithCheckboxOnly: true,
            columnDefs: [
                {
                    field: 'id',
                    displayName: 'Id',
                    cellTemplate: '<div class="ngCellText"><a href="#/jclouds/api/{{row.getProperty(col.field)}}{{hash}}">{{row.getProperty(col.field)}}</a></div>',
                    width: 200,
                    resizable: false
                }, 
                {
                    field: 'name',
                    displayName: 'Name',
                    cellTemplate: '<div class="ngCellText">{{row.getProperty(col.field)}}</div>',
                    width: 350
                }, 
                {
                    field: 'type',
                    displayName: 'Type',
                    cellTemplate: '<div class="ngCellText">{{row.getProperty(col.field)}}</div>',
                    width: 100
                }
            ]
        };
        Core.register(jolokia, $scope, {
            type: 'read',
            mbean: Jclouds.getSelectionJcloudsMBean(workspace)
        }, onSuccess(render));
        function render(response) {
            if(!Object.equal($scope.result, response.value)) {
                $scope.result = response.value;
                $scope.apis = $scope.result["Apis"];
                Jclouds.populateTypeForApis($scope.apis);
                $scope.$apply();
            }
        }
    }
    Jclouds.ApiListController = ApiListController;
})(Jclouds || (Jclouds = {}));
var Jclouds;
(function (Jclouds) {
    function ApiController($scope, $filter, workspace, $routeParams) {
        $scope.apiId = $routeParams.apiId;
        updateTableContents();
        function setApi(api) {
            Jclouds.populateTypeForApi(api);
            $scope.row = api;
            $scope.$apply();
        }
        ; ;
        function updateTableContents() {
            var jcloudsCoreMbean = Jclouds.getSelectionJcloudsMBean(workspace);
            var jolokia = workspace.jolokia;
            if(jcloudsCoreMbean) {
                setApi(jolokia.request({
                    type: 'exec',
                    mbean: Jclouds.getSelectionJcloudsMBean(workspace),
                    operation: 'findApiById(java.lang.String)',
                    arguments: [
                        $scope.apiId
                    ]
                }).value);
            }
        }
    }
    Jclouds.ApiController = ApiController;
})(Jclouds || (Jclouds = {}));
var Jclouds;
(function (Jclouds) {
    function BlobstoreNavigationController($scope, $routeParams, workspace) {
        $scope.blobstoreId = $routeParams.blobstoreId;
        $scope.isActive = function (nav) {
            if(angular.isString(nav)) {
                return workspace.isLinkActive(nav);
            }
            var fn = nav.isActive;
            if(fn) {
                return fn(workspace);
            }
            return workspace.isLinkActive(nav.href());
        };
    }
    Jclouds.BlobstoreNavigationController = BlobstoreNavigationController;
})(Jclouds || (Jclouds = {}));
var Jclouds;
(function (Jclouds) {
    function BlobstoreListController($scope, $location, workspace, jolokia) {
        $scope.result = {
        };
        $scope.blobstoreServiceIds = [];
        $scope.blobstoreServices = [];
        $scope.blobstoreTable = {
            plugins: [],
            data: 'blobstoreServices',
            showFilter: false,
            showColumnMenu: false,
            filterOptions: {
                useExternalFilter: true
            },
            selectedItems: $scope.selectedBlobstoreServices,
            rowHeight: 32,
            selectWithCheckboxOnly: true,
            columnDefs: [
                {
                    field: 'name',
                    displayName: 'Service Name',
                    cellTemplate: '<div class="ngCellText"><a href="#/jclouds/blobstore/service/{{row.getProperty(col.field)}}{{hash}}">{{row.getProperty(col.field)}}</a></div>',
                    width: 200,
                    resizable: false
                }, 
                {
                    field: 'providerId',
                    displayName: 'Proivder',
                    cellTemplate: '<div class="ngCellText">{{row.getProperty(col.field)}}</div>',
                    width: 200,
                    resizable: false
                }, 
                {
                    field: 'identity',
                    displayName: 'Identity',
                    cellTemplate: '<div class="ngCellText">{{row.getProperty(col.field)}}</div>',
                    width: 200,
                    resizable: false
                }
            ]
        };
        render(Jclouds.listJcloudsMBeanNameOfType(workspace, "blobstore"));
        function render(response) {
            if(!Object.equal($scope.result, response)) {
                $scope.result = response;
                $scope.blobstoreServiceIds = $scope.result;
                var blobstoreServices = [];
                angular.forEach($scope.blobstoreServiceIds, function (id) {
                    blobstoreServices.push(Jclouds.findContextByName(workspace, id));
                });
                $scope.blobstoreServices = blobstoreServices;
                $scope.$apply();
            }
        }
    }
    Jclouds.BlobstoreListController = BlobstoreListController;
})(Jclouds || (Jclouds = {}));
var Jclouds;
(function (Jclouds) {
    function BlobstoreContainerListController($scope, $location, workspace, jolokia, $routeParams) {
        $scope.blobstoreId = $routeParams.blobstoreId;
        $scope.result = {
        };
        $scope.containers = [];
        $scope.selectedContainers = [];
        $scope.containerTable = {
            plugins: [],
            data: 'containers',
            showFilter: false,
            showColumnMenu: false,
            filterOptions: {
                useExternalFilter: true
            },
            selectedItems: $scope.selectedContainers,
            rowHeight: 32,
            selectWithCheckboxOnly: true,
            columnDefs: [
                {
                    field: 'name',
                    displayName: 'Name',
                    cellTemplate: '<div class="ngCellText"><a href="#/jclouds/blobstore/container/{{blobstoreId}}/{{row.getProperty(col.field)}}{{hash}}">{{row.getProperty(col.field)}}</a></div>',
                    width: 200,
                    resizable: false
                }, 
                {
                    field: 'creationDate',
                    displayName: 'Created',
                    cellTemplate: '<div class="ngCellText">{{row.getProperty(col.field)}}</div>',
                    width: 200,
                    resizable: false
                }
            ]
        };
        Core.register(jolokia, $scope, {
            type: 'exec',
            mbean: Jclouds.getSelectionJcloudsBlobstoreMBean(workspace, $scope.blobstoreId),
            operation: 'list()'
        }, onSuccess(render));
        function render(response) {
            if(!Object.equal($scope.result, response.value)) {
                $scope.result = response.value;
                $scope.containers = $scope.result;
                $scope.$apply();
            }
        }
    }
    Jclouds.BlobstoreContainerListController = BlobstoreContainerListController;
})(Jclouds || (Jclouds = {}));
var Jclouds;
(function (Jclouds) {
    function BlobstoreContainerController($scope, $filter, workspace, $routeParams) {
        $scope.blobstoreId = $routeParams.blobstoreId;
        $scope.containerId = $routeParams.containerId;
        $scope.directory = $routeParams.directory;
        $scope.contents = [];
        $scope.breadcrumbs = loadBreadcrumbs($scope.blobstoreId, $scope.containerId, $scope.directory);
        $scope.contentTable = {
            data: 'contents',
            displayFooter: false,
            columnDefs: [
                {
                    field: 'name',
                    displayName: 'Content',
                    cellTemplate: '<div class="ngCellText"><a href="#/jclouds/blobstore/container/{{blobstoreId}}/{{containerId}}/{{row.entity.fullpath}}{{hash}}">{{row.getProperty(col.field)}}</a></div>',
                    cellFilter: ""
                }, 
                {
                    field: 'createdDate',
                    displayName: 'Created',
                    cellFilter: "date:'EEE, MMM d, y : hh:mm:ss a'"
                }, 
                {
                    field: 'lastModifiedDate',
                    displayName: 'Modified',
                    cellFilter: "date:'EEE, MMM d, y : hh:mm:ss a'"
                }
            ]
        };
        updateTableContents();
        function setContainers(containers) {
            $scope.contents = populatePathAndName(filterContainers(containers, $scope.directory), $scope.directory);
            $scope.$apply();
        }
        ; ;
        function updateTableContents() {
            var jolokia = workspace.jolokia;
            var blobstoreMbean = Jclouds.getSelectionJcloudsBlobstoreMBean(workspace, $scope.blobstoreId);
            if(blobstoreMbean) {
                if($scope.directory) {
                    setContainers(jolokia.request({
                        type: 'exec',
                        mbean: blobstoreMbean,
                        operation: 'list(java.lang.String, java.lang.String)',
                        arguments: [
                            $scope.containerId, 
                            $scope.directory
                        ]
                    }).value);
                } else {
                    setContainers(jolokia.request({
                        type: 'exec',
                        mbean: blobstoreMbean,
                        operation: 'list(java.lang.String)',
                        arguments: [
                            $scope.containerId
                        ]
                    }).value);
                }
            }
        }
        function filterContainers(containers, directory) {
            return containers.filter(function (container) {
                return container.name !== directory;
            });
        }
        function populatePathAndName(containers, directory) {
            var updatedContainers = [];
            angular.forEach(containers, function (container) {
                var updateContainer = container;
                updateContainer.fullpath = container.name;
                if(updateContainer.name.startsWith(directory)) {
                    updateContainer.name = updateContainer.name.substring(directory.length + 1);
                }
                updatedContainers.push(updateContainer);
            });
            return updatedContainers;
        }
        $scope.isBlob = function (container) {
            return container.type === 'BLOB';
        };
        function loadBreadcrumbs(blobstore, container, directory) {
            var href = "#/jclouds/blobstore/container/" + blobstore + "/" + container;
            var breadcrumbs = [
                {
                    href: href,
                    name: "/" + container
                }
            ];
            var array = directory ? directory.split("/") : [];
            angular.forEach(array, function (name) {
                if(!name.startsWith("/") && !href.endsWith("/")) {
                    href += "/";
                }
                href += name;
                breadcrumbs.push({
                    href: href,
                    name: name
                });
            });
            return breadcrumbs;
        }
    }
    Jclouds.BlobstoreContainerController = BlobstoreContainerController;
})(Jclouds || (Jclouds = {}));
var Jclouds;
(function (Jclouds) {
    function BlobstoreLocationListController($scope, $location, workspace, jolokia, $routeParams) {
        $scope.blobstoreId = $routeParams.blobstoreId;
        $scope.result = {
        };
        $scope.locations = [];
        $scope.selectedLocations = [];
        $scope.locationTable = {
            plugins: [],
            data: 'locations',
            showFilter: false,
            showColumnMenu: false,
            filterOptions: {
                useExternalFilter: true
            },
            selectedItems: $scope.selectedLocations,
            rowHeight: 32,
            selectWithCheckboxOnly: true,
            columnDefs: [
                {
                    field: 'id',
                    displayName: 'Id',
                    cellTemplate: '<div class="ngCellText"><a href="#/jclouds/blobstore/location/{{blobstoreId}}/{{row.getProperty(col.field)}}{{hash}}">{{row.getProperty(col.field)}}</a></div>',
                    width: 200,
                    resizable: false
                }, 
                {
                    field: 'description',
                    displayName: 'Description',
                    cellTemplate: '<div class="ngCellText">{{row.getProperty(col.field)}}</div>',
                    width: 200,
                    resizable: false
                }
            ]
        };
        Core.register(jolokia, $scope, {
            type: 'exec',
            mbean: Jclouds.getSelectionJcloudsBlobstoreMBean(workspace, $scope.blobstoreId),
            operation: 'listAssignableLocations()'
        }, onSuccess(render));
        function render(response) {
            if(!Object.equal($scope.result, response.value)) {
                $scope.result = response.value;
                $scope.locations = $scope.result;
                $scope.$apply();
            }
        }
    }
    Jclouds.BlobstoreLocationListController = BlobstoreLocationListController;
})(Jclouds || (Jclouds = {}));
var Jclouds;
(function (Jclouds) {
    function BlobstoreLocationController($scope, $filter, workspace, $routeParams) {
        $scope.blobstoreId = $routeParams.blobstoreId;
        $scope.locationId = $routeParams.locationId;
        updateTableContents();
        function setLocationProfiles(locationProfiles) {
            $scope.row = findLocationById(locationProfiles, $scope.locationId);
            $scope.$apply();
        }
        ; ;
        function updateTableContents() {
            var jolokia = workspace.jolokia;
            var blobstoreMbean = Jclouds.getSelectionJcloudsBlobstoreMBean(workspace, $scope.blobstoreId);
            if(blobstoreMbean) {
                setLocationProfiles(jolokia.request({
                    type: 'exec',
                    mbean: blobstoreMbean,
                    operation: 'listAssignableLocations()'
                }).value);
            }
        }
        function findLocationById(locationProfiles, id) {
            return locationProfiles.find(function (location) {
                return location.id === id;
            });
        }
    }
    Jclouds.BlobstoreLocationController = BlobstoreLocationController;
})(Jclouds || (Jclouds = {}));
var Jclouds;
(function (Jclouds) {
    function ComputeNavigationController($scope, $routeParams, workspace) {
        $scope.computeId = $routeParams.computeId;
        $scope.isActive = function (nav) {
            if(angular.isString(nav)) {
                return workspace.isLinkActive(nav);
            }
            var fn = nav.isActive;
            if(fn) {
                return fn(workspace);
            }
            return workspace.isLinkActive(nav.href());
        };
    }
    Jclouds.ComputeNavigationController = ComputeNavigationController;
})(Jclouds || (Jclouds = {}));
var Jclouds;
(function (Jclouds) {
    function ComputeListController($scope, $location, workspace, jolokia) {
        $scope.result = {
        };
        $scope.computeServiceIds = [];
        $scope.computeServices = [];
        $scope.computeTable = {
            plugins: [],
            data: 'computeServices',
            showFilter: false,
            showColumnMenu: false,
            filterOptions: {
                useExternalFilter: true
            },
            selectedItems: $scope.selectedComputeServices,
            rowHeight: 32,
            selectWithCheckboxOnly: true,
            columnDefs: [
                {
                    field: 'name',
                    displayName: 'Service Name',
                    cellTemplate: '<div class="ngCellText"><a href="#/jclouds/compute/service/{{row.getProperty(col.field)}}{{hash}}">{{row.getProperty(col.field)}}</a></div>',
                    width: 200,
                    resizable: false
                }, 
                {
                    field: 'providerId',
                    displayName: 'Proivder',
                    cellTemplate: '<div class="ngCellText">{{row.getProperty(col.field)}}</div>',
                    width: 200,
                    resizable: false
                }, 
                {
                    field: 'identity',
                    displayName: 'Identity',
                    cellTemplate: '<div class="ngCellText">{{row.getProperty(col.field)}}</div>',
                    width: 200,
                    resizable: false
                }
            ]
        };
        render(Jclouds.listJcloudsMBeanNameOfType(workspace, "compute"));
        function render(response) {
            if(!Object.equal($scope.result, response)) {
                $scope.result = response;
                $scope.computeServiceIds = $scope.result;
                var computeServices = [];
                angular.forEach($scope.computeServiceIds, function (id) {
                    computeServices.push(Jclouds.findContextByName(workspace, id));
                });
                $scope.computeServices = computeServices;
                $scope.$apply();
            }
        }
    }
    Jclouds.ComputeListController = ComputeListController;
})(Jclouds || (Jclouds = {}));
var Jclouds;
(function (Jclouds) {
    function HardwareListController($scope, $location, workspace, jolokia, $routeParams) {
        $scope.computeId = $routeParams.computeId;
        $scope.result = {
        };
        $scope.hardwares = [];
        $scope.selectedHardwares = [];
        $scope.hardwareTable = {
            plugins: [],
            data: 'hardwares',
            showFilter: false,
            showColumnMenu: false,
            filterOptions: {
                useExternalFilter: true
            },
            selectedItems: $scope.selectedHardwares,
            rowHeight: 32,
            selectWithCheckboxOnly: true,
            columnDefs: [
                {
                    field: 'id',
                    displayName: 'Id',
                    cellTemplate: '<div class="ngCellText"><a href="#/jclouds/compute/hardware/{{computeId}}/{{row.getProperty(col.field)}}{{hash}}">{{row.getProperty(col.field)}}</a></div>',
                    width: 200,
                    resizable: false
                }, 
                {
                    field: 'name',
                    displayName: 'Name',
                    cellTemplate: '<div class="ngCellText">{{row.getProperty(col.field)}}</div>',
                    width: 200,
                    resizable: false
                }, 
                {
                    field: 'ram',
                    displayName: 'Ram',
                    cellTemplate: '<div class="ngCellText">{{row.getProperty(col.field)}}</div>',
                    width: 200,
                    resizable: false
                }, 
                {
                    field: 'hypervisor',
                    displayName: 'Hypervisor',
                    cellTemplate: '<div class="ngCellText">{{row.getProperty(col.field)}}</div>',
                    width: 200,
                    resizable: false
                }
            ]
        };
        Core.register(jolokia, $scope, {
            type: 'exec',
            mbean: Jclouds.getSelectionJcloudsComputeMBean(workspace, $scope.computeId),
            operation: 'listHardwareProfiles()'
        }, onSuccess(render));
        function render(response) {
            if(!Object.equal($scope.result, response.value)) {
                $scope.result = response.value;
                $scope.hardwares = $scope.result;
                $scope.$apply();
            }
        }
        $scope.is64BitIcon = function (is64bit) {
            if(is64bit) {
                return 'icon-thumbs-up';
            } else {
                return 'icon-thumbs-down';
            }
        };
    }
    Jclouds.HardwareListController = HardwareListController;
})(Jclouds || (Jclouds = {}));
var Jclouds;
(function (Jclouds) {
    function HardwareController($scope, $filter, workspace, $routeParams) {
        $scope.computeId = $routeParams.computeId;
        $scope.hardwareId = $routeParams.hardwareId;
        updateTableContents();
        $scope.processorsTable = {
            plugins: [],
            data: 'processors',
            showFilter: false,
            displayFooter: false,
            displaySelectionCheckbox: false,
            showColumnMenu: false,
            rowHeight: 32,
            columnDefs: [
                {
                    field: 'cores',
                    displayName: 'Cores',
                    cellTemplate: '<div class="ngCellText">{{row.getProperty(col.field)}}</div>',
                    width: 50,
                    resizable: false
                }, 
                {
                    field: 'speed',
                    displayName: 'Speed',
                    cellTemplate: '<div class="ngCellText">{{row.getProperty(col.field)}}</div>',
                    width: 100,
                    resizable: false
                }
            ]
        };
        $scope.volumesTable = {
            plugins: [],
            data: 'volumes',
            showFilter: false,
            displayFooter: false,
            displaySelectionCheckbox: false,
            showColumnMenu: false,
            rowHeight: 32,
            columnDefs: [
                {
                    field: 'id',
                    displayName: 'Id',
                    cellTemplate: '<div class="ngCellText">{{row.getProperty(col.field)}}</div>',
                    width: 100,
                    resizable: false
                }, 
                {
                    field: 'type',
                    displayName: 'Type',
                    cellTemplate: '<div class="ngCellText">{{row.getProperty(col.field)}}</div>',
                    width: 100,
                    resizable: false
                }, 
                {
                    field: 'device',
                    displayName: 'Device',
                    cellTemplate: '<div class="ngCellText">{{row.getProperty(col.field)}}</div>',
                    width: 100,
                    resizable: false
                }, 
                {
                    field: 'size',
                    displayName: 'Size',
                    cellTemplate: '<div class="ngCellText">{{row.getProperty(col.field)}}</div>',
                    width: 100,
                    resizable: false
                }, 
                {
                    field: 'bootDevice',
                    displayName: 'Boot Device',
                    cellTemplate: '<div class="ngCellText">{{row.getProperty(col.field)}}</div>',
                    width: 100,
                    resizable: false
                }, 
                {
                    field: 'durable',
                    displayName: 'Durable',
                    cellTemplate: '<div class="ngCellText">{{row.getProperty(col.field)}}</div>',
                    width: 100,
                    resizable: false
                }
            ]
        };
        function setHardwareProfiles(hardwareProfiles) {
            $scope.row = findHardwareById(hardwareProfiles, $scope.hardwareId);
            $scope.processors = $scope.row["processors"];
            $scope.volumes = $scope.row["volumes"];
            $scope.$apply();
        }
        ; ;
        function updateTableContents() {
            var jolokia = workspace.jolokia;
            var computeMbean = Jclouds.getSelectionJcloudsComputeMBean(workspace, $scope.computeId);
            if(computeMbean) {
                setHardwareProfiles(jolokia.request({
                    type: 'exec',
                    mbean: computeMbean,
                    operation: 'listHardwareProfiles()'
                }).value);
            }
        }
        function findHardwareById(hardwareProfiles, id) {
            return hardwareProfiles.find(function (hardware) {
                return hardware.id === id;
            });
        }
    }
    Jclouds.HardwareController = HardwareController;
})(Jclouds || (Jclouds = {}));
var Jclouds;
(function (Jclouds) {
    function ImageListController($scope, $location, workspace, jolokia, $routeParams) {
        $scope.computeId = $routeParams.computeId;
        $scope.result = {
        };
        $scope.images = [];
        $scope.operatingSystemFamily = "";
        $scope.operatingSystemFamilies = [];
        var os = $location.search()['os'];
        if(os) {
            $scope.operatingSystemFamily = os;
        }
        $scope.selectedImages = [];
        $scope.imageTable = {
            data: 'images',
            showFilter: false,
            showColumnMenu: false,
            filterOptions: {
                useExternalFilter: true
            },
            selectedItems: $scope.selectedImages,
            rowHeight: 32,
            selectWithCheckboxOnly: true,
            columnDefs: [
                {
                    field: 'id',
                    displayName: 'Id',
                    cellTemplate: '<div class="ngCellText"><a href="#/jclouds/compute/image/{{computeId}}/{{row.getProperty(col.field)}}{{hash}}">{{row.getProperty(col.field)}}</a></div>',
                    width: 200,
                    resizable: false
                }, 
                {
                    field: 'name',
                    displayName: 'Name',
                    cellTemplate: '<div class="ngCellText">{{row.getProperty(col.field)}}</div>',
                    width: 200,
                    resizable: false
                }, 
                {
                    field: 'operatingSystem.family',
                    displayName: 'Operating System',
                    cellTemplate: '<div class="ngCellText">{{row.getProperty(col.field)}}</div>',
                    width: 200
                }, 
                {
                    field: 'operatingSystem.is64Bit',
                    displayName: '64 bit',
                    cellTemplate: '<div class="ngCellText pagination-centered"><i class="icon1point5x {{is64BitIcon(row.getProperty(col.field))}}"></i></div>',
                    width: 200
                }, 
                {
                    field: 'status',
                    displayName: 'Status',
                    cellTemplate: '<div class="ngCellText">{{row.getProperty(col.field)}}</div>',
                    width: 300
                }
            ]
        };
        Core.register(jolokia, $scope, {
            type: 'exec',
            mbean: Jclouds.getSelectionJcloudsComputeMBean(workspace, $scope.computeId),
            operation: 'listImages()'
        }, onSuccess(render));
        function render(response) {
            if(!Object.equal($scope.result, response.value)) {
                $scope.result = response.value;
                $scope.images = $scope.result;
                $scope.operatingSystemFamilies = extractOperatingSystemFamilies($scope.images);
                $scope.$apply();
            }
        }
        function extractOperatingSystemFamilies(images) {
            var operatingSystemFamilies = [];
            operatingSystemFamilies.push("");
            angular.forEach(images, function (image) {
                var operatingSystemFamily = image["operatingSystem"]["family"];
                operatingSystemFamilies.push(operatingSystemFamily);
            });
            return operatingSystemFamilies.unique();
        }
        $scope.is64BitIcon = function (is64bit) {
            if(is64bit) {
                return 'icon-thumbs-up';
            } else {
                return 'icon-thumbs-down';
            }
        };
    }
    Jclouds.ImageListController = ImageListController;
})(Jclouds || (Jclouds = {}));
var Jclouds;
(function (Jclouds) {
    function ImageController($scope, $filter, workspace, $routeParams) {
        $scope.computeId = $routeParams.computeId;
        $scope.imageId = $routeParams.imageId;
        updateTableContents();
        function setImage(api) {
            $scope.row = api;
            $scope.$apply();
        }
        ; ;
        function updateTableContents() {
            var jolokia = workspace.jolokia;
            var computeMbean = Jclouds.getSelectionJcloudsComputeMBean(workspace, $scope.computeId);
            if(computeMbean) {
                setImage(jolokia.request({
                    type: 'exec',
                    mbean: computeMbean,
                    operation: 'getImage(java.lang.String)',
                    arguments: [
                        $scope.imageId
                    ]
                }).value);
            }
        }
    }
    Jclouds.ImageController = ImageController;
})(Jclouds || (Jclouds = {}));
var Jclouds;
(function (Jclouds) {
    function ComputeLocationListController($scope, $location, workspace, jolokia, $routeParams) {
        $scope.computeId = $routeParams.computeId;
        $scope.result = {
        };
        $scope.locations = [];
        $scope.selectedLocations = [];
        $scope.locationTable = {
            plugins: [],
            data: 'locations',
            showFilter: false,
            showColumnMenu: false,
            filterOptions: {
                useExternalFilter: true
            },
            selectedItems: $scope.selectedLocations,
            rowHeight: 32,
            selectWithCheckboxOnly: true,
            columnDefs: [
                {
                    field: 'id',
                    displayName: 'Id',
                    cellTemplate: '<div class="ngCellText"><a href="#/jclouds/compute/location/{{computeId}}/{{row.getProperty(col.field)}}{{hash}}">{{row.getProperty(col.field)}}</a></div>',
                    width: 200,
                    resizable: false
                }, 
                {
                    field: 'description',
                    displayName: 'Description',
                    cellTemplate: '<div class="ngCellText">{{row.getProperty(col.field)}}</div>',
                    width: 200,
                    resizable: false
                }
            ]
        };
        Core.register(jolokia, $scope, {
            type: 'exec',
            mbean: Jclouds.getSelectionJcloudsComputeMBean(workspace, $scope.computeId),
            operation: 'listAssignableLocations()'
        }, onSuccess(render));
        function render(response) {
            if(!Object.equal($scope.result, response.value)) {
                $scope.result = response.value;
                $scope.locations = $scope.result;
                $scope.$apply();
            }
        }
    }
    Jclouds.ComputeLocationListController = ComputeLocationListController;
})(Jclouds || (Jclouds = {}));
var Jclouds;
(function (Jclouds) {
    function ComputeLocationController($scope, $filter, workspace, $routeParams) {
        $scope.computeId = $routeParams.computeId;
        $scope.locationId = $routeParams.locationId;
        updateTableContents();
        function setLocationProfiles(locationProfiles) {
            $scope.row = findLocationById(locationProfiles, $scope.locationId);
            $scope.$apply();
        }
        ; ;
        function updateTableContents() {
            var jolokia = workspace.jolokia;
            var computeMbean = Jclouds.getSelectionJcloudsComputeMBean(workspace, $scope.computeId);
            if(computeMbean) {
                setLocationProfiles(jolokia.request({
                    type: 'exec',
                    mbean: computeMbean,
                    operation: 'listAssignableLocations()'
                }).value);
            }
        }
        function findLocationById(locationProfiles, id) {
            return locationProfiles.find(function (location) {
                return location.id === id;
            });
        }
    }
    Jclouds.ComputeLocationController = ComputeLocationController;
})(Jclouds || (Jclouds = {}));
var Jclouds;
(function (Jclouds) {
    function NodeListController($scope, $location, workspace, jolokia, $routeParams) {
        $scope.computeId = $routeParams.computeId;
        $scope.result = {
        };
        $scope.nodes = [];
        $scope.group = "";
        $scope.groups = [];
        $scope.location = "";
        $scope.locations = [];
        var grp = $location.search()['group'];
        if(grp) {
            $scope.group = grp;
        }
        var loc = $location.search()['location'];
        if(loc) {
            $scope.location = loc;
        }
        $scope.selectedNodes = [];
        $scope.nodeTable = {
            data: 'nodes',
            showFilter: false,
            showColumnMenu: false,
            filterOptions: {
                useExternalFilter: true
            },
            selectedItems: $scope.selectedNodes,
            rowHeight: 32,
            selectWithCheckboxOnly: true,
            columnDefs: [
                {
                    field: 'id',
                    displayName: 'Id',
                    cellTemplate: '<div class="ngCellText"><a href="#/jclouds/compute/node/{{computeId}}/{{row.getProperty(col.field)}}{{hash}}">{{row.getProperty(col.field)}}</a></div>',
                    width: 200,
                    resizable: false
                }, 
                {
                    field: 'group',
                    displayName: 'Group',
                    cellTemplate: '<div class="ngCellText"><a href="#/jclouds/compute/node/{{row.getProperty(col.field)}}{{hash}}">{{row.getProperty(col.field)}}</a></div>',
                    width: 200,
                    resizable: false
                }, 
                {
                    field: 'operatingSystem.family',
                    displayName: 'Operating System',
                    cellTemplate: '<div class="ngCellText">{{row.getProperty(col.field)}}</div>',
                    width: 200
                }, 
                {
                    field: 'locationId',
                    displayName: 'Location',
                    cellTemplate: '<div class="ngCellText">{{row.getProperty(col.field)}}</div>',
                    width: 200
                }, 
                {
                    field: 'hostname',
                    displayName: 'Host Name',
                    cellTemplate: '<div class="ngCellText">{{row.getProperty(col.field)}}</div>',
                    width: 300
                }
            ]
        };
        Core.register(jolokia, $scope, {
            type: 'exec',
            mbean: Jclouds.getSelectionJcloudsComputeMBean(workspace, $scope.computeId),
            operation: 'listNodes()'
        }, onSuccess(render));
        function render(response) {
            if(!Object.equal($scope.result, response.value)) {
                $scope.result = response.value;
                $scope.nodes = $scope.result;
                $scope.locations = extractLocations($scope.nodes);
                $scope.groups = extractGroups($scope.nodes);
                $scope.$apply();
            }
        }
        function extractGroups(nodes) {
            var groups = [];
            groups.push("");
            angular.forEach(nodes, function (node) {
                var group = node["group"];
                groups.push(group);
            });
            return groups.unique();
        }
        function extractLocations(nodes) {
            var locations = [];
            locations.push("");
            angular.forEach(nodes, function (node) {
                var location = node["locationId"];
                locations.push(location);
            });
            return locations.unique();
        }
        $scope.resume = function () {
            $scope.selectedNodes.forEach(function (node) {
                Jclouds.resumeNode(workspace, jolokia, $scope.computeId, node.id, function () {
                    console.log("Resumed!");
                }, function () {
                    console.log("Failed to resume!");
                });
            });
        };
        $scope.suspend = function () {
            $scope.selectedNodes.forEach(function (node) {
                Jclouds.suspendNode(workspace, jolokia, $scope.computeId, node.id, function () {
                    console.log("Suspended!");
                }, function () {
                    console.log("Failed to suspend!");
                });
            });
        };
        $scope.reboot = function () {
            $scope.selectedNodes.forEach(function (node) {
                Jclouds.rebootNode(workspace, jolokia, $scope.computeId, node.id, function () {
                    console.log("Rebooted!");
                }, function () {
                    console.log("Failed to reboot!");
                });
            });
        };
        $scope.destroy = function () {
            $scope.selectedNodes.forEach(function (node) {
                Jclouds.destroyNode(workspace, jolokia, $scope.computeId, node.id, function () {
                    console.log("Destroyed!");
                }, function () {
                    console.log("Failed to destroy!");
                });
            });
        };
    }
    Jclouds.NodeListController = NodeListController;
})(Jclouds || (Jclouds = {}));
var Jclouds;
(function (Jclouds) {
    function NodeController($scope, $filter, workspace, $routeParams) {
        $scope.computeId = $routeParams.computeId;
        $scope.nodeId = $routeParams.nodeId;
        updateTableContents();
        function setNode(api) {
            $scope.row = api;
            $scope.$apply();
        }
        ; ;
        function updateTableContents() {
            var computeMbean = Jclouds.getSelectionJcloudsComputeMBean(workspace, $scope.computeId);
            var jolokia = workspace.jolokia;
            if(computeMbean) {
                setNode(jolokia.request({
                    type: 'exec',
                    mbean: computeMbean,
                    operation: 'getNode(java.lang.String)',
                    arguments: [
                        $scope.nodeId
                    ]
                }).value);
            }
        }
        $scope.resume = function () {
            Jclouds.resumeNode(workspace, workspace.jolokia, $scope.computeId, $scope.nodeId, function () {
                console.log("Resumed!");
            }, function () {
                console.log("Failed to resume!");
            });
        };
        $scope.suspend = function () {
            Jclouds.suspendNode(workspace, workspace.jolokia, $scope.computeId, $scope.nodeId, function () {
                console.log("Suspended!");
            }, function () {
                console.log("Failed to suspend!");
            });
        };
        $scope.reboot = function () {
            Jclouds.rebootNode(workspace, workspace.jolokia, $scope.computeId, $scope.nodeId, function () {
                console.log("Rebooted!");
            }, function () {
                console.log("Failed to reboot!");
            });
        };
        $scope.destroy = function () {
            Jclouds.destroyNode(workspace, workspace.jolokia, $scope.computeId, $scope.nodeId, function () {
                console.log("Destroyed!");
            }, function () {
                console.log("Failed to destroy!");
            });
        };
    }
    Jclouds.NodeController = NodeController;
})(Jclouds || (Jclouds = {}));
var Jclouds;
(function (Jclouds) {
    Array.prototype.unique = function () {
        var a = [], l = this.length;
        for(var i = 0; i < l; i++) {
            for(var j = i + 1; j < l; j++) {
                if(this[i] === this[j]) {
                    j = ++i;
                }
            }
            a.push(this[i]);
        }
        return a;
    };
    function setSelect(selection, group) {
        if(!angular.isDefined(selection)) {
            return group[0];
        }
        var answer = group.findIndex(function (item) {
            return item === selection;
        });
        if(answer !== -1) {
            return group[answer];
        } else {
            return group[0];
        }
    }
    Jclouds.setSelect = setSelect;
    function findContextByName(workspace, name) {
        var jcloudsMBean = getSelectionJcloudsMBean(workspace);
        var response = workspace.jolokia.request({
            type: 'read',
            mbean: jcloudsMBean
        });
        return response.value["Contexts"].find(function (context) {
            return context.name === name;
        });
    }
    Jclouds.findContextByName = findContextByName;
    function populateTypeForApis(apis) {
        angular.forEach(apis, function (api) {
            populateTypeForApi(api);
        });
    }
    Jclouds.populateTypeForApis = populateTypeForApis;
    function populateTypeForApi(api) {
        var views = api["views"];
        var found = false;
        angular.forEach(views, function (view) {
            if(!found) {
                if(view.has("blob")) {
                    api["type"] = "blobstore";
                    found = true;
                } else {
                    if(view.has("compute")) {
                        api["type"] = "compute";
                        found = true;
                    }
                }
            }
        });
    }
    Jclouds.populateTypeForApi = populateTypeForApi;
    function filterImages(images, operatingSystemFamily) {
        if(operatingSystemFamily === "") {
            return images;
        } else {
            return images.findAll(function (image) {
                return image["operatingSystem"]["family"] === operatingSystemFamily;
            });
        }
    }
    Jclouds.filterImages = filterImages;
    function filterNodes(nodes, group, location) {
        var filteredNodes = [];
        if(group === "") {
            filteredNodes = nodes;
        } else {
            filteredNodes = nodes.findAll(function (node) {
                return node.group === group;
            });
        }
        if(location === "") {
            return filteredNodes;
        } else {
            return filteredNodes.findAll(function (node) {
                return node.locationId === location;
            });
        }
    }
    Jclouds.filterNodes = filterNodes;
    function resumeNode(workspace, jolokia, compute, id, success, error) {
        jolokia.request({
            type: 'exec',
            mbean: getSelectionJcloudsComputeMBean(workspace, compute),
            operation: 'resumeNode(java.lang.String)',
            arguments: [
                id
            ]
        }, onSuccess(success, {
            error: error
        }));
    }
    Jclouds.resumeNode = resumeNode;
    function suspendNode(workspace, jolokia, compute, id, success, error) {
        jolokia.request({
            type: 'exec',
            mbean: getSelectionJcloudsComputeMBean(workspace, compute),
            operation: 'suspendNode(java.lang.String)',
            arguments: [
                id
            ]
        }, onSuccess(success, {
            error: error
        }));
    }
    Jclouds.suspendNode = suspendNode;
    function rebootNode(workspace, jolokia, compute, id, success, error) {
        jolokia.request({
            type: 'exec',
            mbean: getSelectionJcloudsComputeMBean(workspace, compute),
            operation: 'rebootNode(java.lang.String)',
            arguments: [
                id
            ]
        }, onSuccess(success, {
            error: error
        }));
    }
    Jclouds.rebootNode = rebootNode;
    function destroyNode(workspace, jolokia, compute, id, success, error) {
        jolokia.request({
            type: 'exec',
            mbean: getSelectionJcloudsComputeMBean(workspace, compute),
            operation: 'destroyNode(java.lang.String)',
            arguments: [
                id
            ]
        }, onSuccess(success, {
            error: error
        }));
    }
    Jclouds.destroyNode = destroyNode;
    function apisOfType(apis, type) {
        if(type === "") {
            return apis;
        }
        return apis.findAll(function (api) {
            return api.type === type;
        });
    }
    Jclouds.apisOfType = apisOfType;
    function populateTypeForProviders(providers) {
        angular.forEach(providers, function (provider) {
            populateTypeForProvider(provider);
        });
    }
    Jclouds.populateTypeForProviders = populateTypeForProviders;
    function populateTypeForProvider(provider) {
        var views = provider["api"]["views"];
        var found = false;
        angular.forEach(views, function (view) {
            if(!found) {
                if(view.has("blob")) {
                    provider["type"] = "blobstore";
                    found = true;
                } else {
                    if(view.has("compute")) {
                        provider["type"] = "compute";
                        found = true;
                    }
                }
            }
        });
    }
    Jclouds.populateTypeForProvider = populateTypeForProvider;
    function providersOfType(providers, type) {
        if(type === "") {
            return providers;
        }
        return providers.findAll(function (provider) {
            return provider.type === type;
        });
    }
    Jclouds.providersOfType = providersOfType;
    function findFirstObjectName(node) {
        if(node) {
            var answer = node.objectName;
            if(answer) {
                return answer;
            } else {
                var children = node.children;
                if(children && children.length) {
                    return findFirstObjectName(children[0]);
                }
            }
        }
        return null;
    }
    Jclouds.findFirstObjectName = findFirstObjectName;
    function childsOfType(node) {
        var types = [];
        angular.forEach(node.children, function (child) {
            types.push(child.title);
        });
        return types;
    }
    Jclouds.childsOfType = childsOfType;
    function listJcloudsMBeanNameOfType(workspace, type) {
        if(workspace) {
            var folder = workspace.tree.navigate("org.jclouds", type);
            return childsOfType(folder);
        }
        return null;
    }
    Jclouds.listJcloudsMBeanNameOfType = listJcloudsMBeanNameOfType;
    function getSelectionJcloudsMBean(workspace) {
        if(workspace) {
            var folder = workspace.tree.navigate("org.jclouds", "management", "core");
            return findFirstObjectName(folder);
        }
        return null;
    }
    Jclouds.getSelectionJcloudsMBean = getSelectionJcloudsMBean;
    function getSelectionJcloudsComputeMBean(workspace, name) {
        if(workspace) {
            var folder = workspace.tree.navigate("org.jclouds", "compute", name);
            return findFirstObjectName(folder);
        }
        return null;
    }
    Jclouds.getSelectionJcloudsComputeMBean = getSelectionJcloudsComputeMBean;
    function getSelectionJcloudsBlobstoreMBean(workspace, name) {
        if(workspace) {
            var folder = workspace.tree.navigate("org.jclouds", "blobstore", name);
            return findFirstObjectName(folder);
        }
        return null;
    }
    Jclouds.getSelectionJcloudsBlobstoreMBean = getSelectionJcloudsBlobstoreMBean;
})(Jclouds || (Jclouds = {}));
var Jclouds;
(function (Jclouds) {
    var pluginName = 'jclouds';
    angular.module(pluginName, [
        'bootstrap', 
        'ngResource', 
        'ngGrid', 
        'hawtioCore'
    ]).config(function ($routeProvider) {
        $routeProvider.when('/jclouds/api', {
            templateUrl: 'app/jclouds/html/api-list.html'
        }).when('/jclouds/api/:apiId', {
            templateUrl: 'app/jclouds/html/api.html'
        }).when('/jclouds/provider', {
            templateUrl: 'app/jclouds/html/provider-list.html'
        }).when('/jclouds/provider/:providerId', {
            templateUrl: 'app/jclouds/html/provider.html'
        }).when('/jclouds/compute/service', {
            templateUrl: 'app/jclouds/html/compute/compute-service-list.html'
        }).when('/jclouds/compute/service/:computeId', {
            templateUrl: 'app/jclouds/html/compute/compute-service.html'
        }).when('/jclouds/compute/node/:computeId', {
            templateUrl: 'app/jclouds/html/compute/node-list.html'
        }).when('/jclouds/compute/node/:computeId/*nodeId', {
            templateUrl: 'app/jclouds/html/compute/node.html'
        }).when('/jclouds/compute/image/:computeId', {
            templateUrl: 'app/jclouds/html/compute/image-list.html'
        }).when('/jclouds/compute/image/:computeId/*imageId', {
            templateUrl: 'app/jclouds/html/compute/image.html'
        }).when('/jclouds/compute/hardware/:computeId', {
            templateUrl: 'app/jclouds/html/compute/hardware-list.html'
        }).when('/jclouds/compute/hardware/:computeId/*hardwareId', {
            templateUrl: 'app/jclouds/html/compute/hardware.html'
        }).when('/jclouds/compute/location/:computeId', {
            templateUrl: 'app/jclouds/html/compute/location-list.html'
        }).when('/jclouds/compute/location/:computeId/*locationId', {
            templateUrl: 'app/jclouds/html/compute/location.html'
        }).when('/jclouds/blobstore/service', {
            templateUrl: 'app/jclouds/html/blobstore/blobstore-service-list.html'
        }).when('/jclouds/blobstore/service/:blobstoreId', {
            templateUrl: 'app/jclouds/html/blobstore/blobstore-service.html'
        }).when('/jclouds/blobstore/location/:blobstoreId', {
            templateUrl: 'app/jclouds/html/blobstore/location-list.html'
        }).when('/jclouds/blobstore/location/:blobstoreId/*locationId', {
            templateUrl: 'app/jclouds/html/blobstore/location.html'
        }).when('/jclouds/blobstore/container/:blobstoreId', {
            templateUrl: 'app/jclouds/html/blobstore/container-list.html'
        }).when('/jclouds/blobstore/container/:blobstoreId/:containerId', {
            templateUrl: 'app/jclouds/html/blobstore/container.html'
        }).when('/jclouds/blobstore/container/:blobstoreId/:containerId/*directory', {
            templateUrl: 'app/jclouds/html/blobstore/container.html'
        });
    }).run(function (workspace, viewRegistry) {
        viewRegistry['jclouds'] = "app/jclouds/html/layoutJclouds.html";
        workspace.topLevelTabs.push({
            content: "jclouds",
            title: "Visualise and manage the Jclouds Compute/BlobStore providers and apis",
            isValid: function (workspace) {
                return workspace.treeContainsDomainAndProperties("org.jclouds");
            },
            href: function () {
                return "#/jclouds/api";
            },
            isActive: function (workspace) {
                return workspace.isLinkActive("jclouds");
            }
        });
    });
    hawtioPluginLoader.addModule(pluginName);
})(Jclouds || (Jclouds = {}));
var Jclouds;
(function (Jclouds) {
    function ProviderListController($scope, $location, workspace, jolokia) {
        $scope.result = {
        };
        $scope.providers = [];
        $scope.type = "";
        $scope.types = [
            "", 
            "blobstore", 
            "compute", 
            "loadbalancer"
        ];
        var key = $location.search()['type'];
        if(key) {
            $scope.type = key;
        }
        $scope.selectedProviders = [];
        $scope.providerTable = {
            data: 'providers',
            showFilter: false,
            showColumnMenu: false,
            filterOptions: {
                useExternalFilter: true
            },
            selectedItems: $scope.selectedProviders,
            rowHeight: 32,
            selectWithCheckboxOnly: true,
            columnDefs: [
                {
                    field: 'id',
                    displayName: 'Id',
                    cellTemplate: '<div class="ngCellText"><a href="#/jclouds/provider/{{row.getProperty(col.field)}}{{hash}}">{{row.getProperty(col.field)}}</a></div>',
                    width: 200,
                    resizable: false
                }, 
                {
                    field: 'name',
                    displayName: 'Name',
                    cellTemplate: '<div class="ngCellText">{{row.getProperty(col.field)}}</div>',
                    width: 350
                }, 
                {
                    field: 'type',
                    displayName: 'Type',
                    cellTemplate: '<div class="ngCellText">{{row.getProperty(col.field)}}</div>',
                    width: 100
                }
            ]
        };
        Core.register(jolokia, $scope, {
            type: 'read',
            mbean: Jclouds.getSelectionJcloudsMBean(workspace)
        }, onSuccess(render));
        function render(response) {
            if(!Object.equal($scope.result, response.value)) {
                $scope.result = response.value;
                $scope.providers = $scope.result["Providers"];
                Jclouds.populateTypeForProviders($scope.providers);
                $scope.$apply();
            }
        }
    }
    Jclouds.ProviderListController = ProviderListController;
})(Jclouds || (Jclouds = {}));
var Jclouds;
(function (Jclouds) {
    function ProviderController($scope, $filter, workspace, $routeParams) {
        $scope.providerId = $routeParams.providerId;
        updateTableContents();
        function setProvider(provider) {
            Jclouds.populateTypeForProvider(provider);
            $scope.row = provider;
            $scope.$apply();
        }
        ; ;
        function updateTableContents() {
            var jcloudsCoreMbean = Jclouds.getSelectionJcloudsMBean(workspace);
            var jolokia = workspace.jolokia;
            if(jcloudsCoreMbean) {
                setProvider(jolokia.request({
                    type: 'exec',
                    mbean: Jclouds.getSelectionJcloudsMBean(workspace),
                    operation: 'findProviderById(java.lang.String)',
                    arguments: [
                        $scope.providerId
                    ]
                }).value);
            }
        }
    }
    Jclouds.ProviderController = ProviderController;
})(Jclouds || (Jclouds = {}));
var Jetty;
(function (Jetty) {
    function ConnectorsController($scope, $location, workspace, jolokia) {
        var stateTemplate = '<div class="ngCellText pagination-centered" title="{{row.getProperty(col.field)}}"><i class="{{row.getProperty(col.field) | jettyIconClass}}"></i></div>';
        $scope.connectors = [];
        var columnDefs = [
            {
                field: 'running',
                displayName: 'State',
                cellTemplate: stateTemplate,
                width: 56,
                minWidth: 56,
                maxWidth: 56,
                resizable: false
            }, 
            {
                field: 'port',
                displayName: 'Port',
                cellFilter: null,
                width: "*",
                resizable: true
            }, 
            {
                field: 'scheme',
                displayName: 'Scheme',
                cellFilter: null,
                width: "*",
                resizable: true
            }, 
            
        ];
        $scope.gridOptions = {
            data: 'connectors',
            displayFooter: false,
            displaySelectionCheckbox: false,
            canSelectRows: false,
            columnDefs: columnDefs,
            filterOptions: {
                filterText: ''
            }
        };
        function render(response) {
            $scope.connectors = [];
            function onAttributes(response) {
                var obj = response.value;
                if(obj) {
                    obj.mbean = response.request.mbean;
                    obj.scheme = "http";
                    obj.port = obj.port;
                    obj.running = obj['running'] !== undefined ? obj['running'] : true;
                    $scope.connectors.push(obj);
                    if(obj.confidentialPort) {
                        var copyObj = {
                            scheme: "https",
                            port: obj.confidentialPort,
                            running: obj.running,
                            mbean: obj.mbean
                        };
                        $scope.connectors.push(copyObj);
                    }
                    Core.$apply($scope);
                }
            }
            angular.forEach(response, function (value, key) {
                var mbean = value;
                jolokia.request({
                    type: "read",
                    mbean: mbean,
                    attribute: []
                }, onSuccess(onAttributes));
            });
            Core.$apply($scope);
        }
        ; ;
        $scope.onResponse = function (response) {
            loadData();
        };
        $scope.$on('jmxTreeUpdated', reloadFunction);
        $scope.$watch('workspace.tree', reloadFunction);
        function reloadFunction() {
            setTimeout(loadData, 50);
        }
        function loadData() {
            console.log("Loading Jetty connector data...");
            var tree = workspace.tree;
            jolokia.search("org.eclipse.jetty.server.nio:type=selectchannelconnector,*", onSuccess(render));
        }
    }
    Jetty.ConnectorsController = ConnectorsController;
})(Jetty || (Jetty = {}));
var Jetty;
(function (Jetty) {
    function iconClass(state) {
        if(state) {
            switch(state.toString().toLowerCase()) {
                case 'started': {
                    return "green icon-play-circle";

                }
                case 'true': {
                    return "green icon-play-circle";

                }
            }
        }
        return "orange icon-off";
    }
    Jetty.iconClass = iconClass;
    function isState(item, state) {
        var value = (item.state || "").toLowerCase();
        if(angular.isArray(state)) {
            return state.any(function (stateText) {
                return value.startsWith(stateText);
            });
        } else {
            return value.startsWith(state);
        }
    }
    Jetty.isState = isState;
})(Jetty || (Jetty = {}));
var Jetty;
(function (Jetty) {
    function JettyController($scope, $location, workspace, jolokia) {
        var stateTemplate = '<div class="ngCellText pagination-centered" title="{{row.getProperty(col.field)}}"><i class="{{row.getProperty(col.field) | jettyIconClass}}"></i></div>';
        $scope.uninstallDialog = new Core.Dialog();
        $scope.webapps = [];
        $scope.selected = [];
        var columnDefs = [
            {
                field: 'state',
                displayName: 'State',
                cellTemplate: stateTemplate,
                width: 56,
                minWidth: 56,
                maxWidth: 56,
                resizable: false
            }, 
            {
                field: 'displayName',
                displayName: 'Name',
                cellFilter: null,
                width: "*",
                resizable: true
            }, 
            {
                field: 'contextPath',
                displayName: 'Context-Path',
                cellFilter: null,
                width: "*",
                resizable: true
            }, 
            
        ];
        $scope.gridOptions = {
            data: 'webapps',
            displayFooter: true,
            selectedItems: $scope.selected,
            selectWithCheckboxOnly: true,
            columnDefs: columnDefs,
            filterOptions: {
                filterText: ''
            },
            title: "Web applications"
        };
        $scope.controlWebApps = function (op) {
            var mbeanNames = $scope.selected.map(function (b) {
                return b.mbean;
            });
            if(!angular.isArray(mbeanNames)) {
                mbeanNames = [
                    mbeanNames
                ];
            }
            var lastIndex = (mbeanNames.length || 1) - 1;
            angular.forEach(mbeanNames, function (mbean, idx) {
                var onResponse = (idx >= lastIndex) ? $scope.onLastResponse : $scope.onResponse;
                jolokia.request({
                    type: 'exec',
                    mbean: mbean,
                    operation: op,
                    arguments: null
                }, onSuccess(onResponse, {
                    error: onResponse
                }));
            });
        };
        $scope.stop = function () {
            $scope.controlWebApps('stop');
        };
        $scope.start = function () {
            $scope.controlWebApps('start');
        };
        $scope.uninstall = function () {
            $scope.controlWebApps('destroy');
            $scope.uninstallDialog.close();
        };
        $scope.anySelectionHasState = function (state) {
            var selected = $scope.selected || [];
            return selected.length && selected.any(function (s) {
                return Jetty.isState(s, state);
            });
        };
        $scope.everySelectionHasState = function (state) {
            var selected = $scope.selected || [];
            return selected.length && selected.every(function (s) {
                return Jetty.isState(s, state);
            });
        };
        $scope.onLastResponse = function (response) {
            $scope.onResponse(response);
            loadData();
        };
        $scope.onResponse = function (response) {
        };
        $scope.$on('jmxTreeUpdated', reloadFunction);
        $scope.$watch('workspace.tree', reloadFunction);
        $scope.jettyServerVersion = "";
        $scope.jettyServerStartupTime = "";
        var servers = jolokia.search("org.eclipse.jetty.server:type=server,*");
        if(servers && servers.length === 1) {
            $scope.jettyServerVersion = jolokia.getAttribute(servers[0], "version");
            $scope.jettyServerStartupTime = jolokia.getAttribute(servers[0], "startupTime");
        } else {
            console.log("Cannot find jetty server or there was more than one server. response is: " + servers);
        }
        function reloadFunction() {
            setTimeout(loadData, 50);
        }
        function loadData() {
            console.log("Loading Jetty webapp data...");
            jolokia.search("org.mortbay.jetty.plugin:type=jettywebappcontext,*", onSuccess(render));
            jolokia.search("org.eclipse.jetty.webapp:type=webappcontext,*", onSuccess(render));
            jolokia.search("org.eclipse.jetty.servlet:type=servletcontexthandler,*", onSuccess(render));
        }
        function render(response) {
            $scope.webapps = [];
            $scope.mbeanIndex = {
            };
            $scope.selected.length = 0;
            function onAttributes(response) {
                var obj = response.value;
                if(obj) {
                    obj.mbean = response.request.mbean;
                    if(!obj.state) {
                        obj.state = obj['running'] === undefined || obj['running'] ? "started" : "stopped";
                    }
                    var mbean = obj.mbean;
                    if(mbean) {
                        var idx = $scope.mbeanIndex[mbean];
                        if(angular.isDefined(idx)) {
                            $scope.webapps[mbean] = obj;
                        } else {
                            $scope.mbeanIndex[mbean] = $scope.webapps.length;
                            $scope.webapps.push(obj);
                        }
                        Core.$apply($scope);
                    }
                }
            }
            angular.forEach(response, function (value, key) {
                var mbean = value;
                jolokia.request({
                    type: "read",
                    mbean: mbean,
                    attribute: []
                }, onSuccess(onAttributes));
            });
            $scope.$apply();
        }
    }
    Jetty.JettyController = JettyController;
})(Jetty || (Jetty = {}));
var Jetty;
(function (Jetty) {
    var pluginName = 'jetty';
    angular.module(pluginName, [
        'bootstrap', 
        'ngResource', 
        'ui.bootstrap.dialog', 
        'hawtioCore'
    ]).config(function ($routeProvider) {
        $routeProvider.when('/jetty/server', {
            templateUrl: 'app/jetty/html/server.html'
        }).when('/jetty/applications', {
            templateUrl: 'app/jetty/html/applications.html'
        }).when('/jetty/connectors', {
            templateUrl: 'app/jetty/html/connectors.html'
        }).when('/jetty/mbeans', {
            templateUrl: 'app/jetty/html/mbeans.html'
        });
    }).filter('jettyIconClass', function () {
        return Jetty.iconClass;
    }).run(function ($location, workspace, viewRegistry, layoutFull) {
        viewRegistry['jetty'] = "app/jetty/html/layoutJettyTabs.html";
        viewRegistry['jettyTree'] = "app/jetty/html/layoutJettyTree.html";
        workspace.topLevelTabs.push({
            content: "Jetty",
            title: "Manage your Jetty container",
            isValid: function (workspace) {
                return workspace.treeContainsDomainAndProperties("org.eclipse.jetty.server");
            },
            href: function () {
                return "#/jetty/applications";
            },
            isActive: function (workspace) {
                return workspace.isTopTabActive("jetty");
            }
        });
    });
    hawtioPluginLoader.addModule(pluginName);
})(Jetty || (Jetty = {}));
var Jetty;
(function (Jetty) {
    function TreeController($scope, $location, workspace) {
        $scope.$on("$routeChangeSuccess", function (event, current, previous) {
            setTimeout(updateSelectionFromURL, 50);
        });
        $scope.$watch('workspace.tree', function () {
            console.log("workspace tree has changed, lets reload!!");
            if(workspace.moveIfViewInvalid()) {
                return;
            }
            var children = [];
            var tree = workspace.tree;
            if(tree) {
                var nodes = tree.children;
                angular.forEach(nodes, function (node) {
                    var nodeChildren = node.children;
                    if(node.title.startsWith("org.eclipse.jetty") && nodeChildren) {
                        children = children.concat(nodeChildren);
                    }
                });
            }
            var treeElement = $("#jettyTree");
            Jmx.enableTree($scope, $location, workspace, treeElement, children, true);
            setTimeout(updateSelectionFromURL, 50);
        });
        function updateSelectionFromURL() {
            Jmx.updateTreeSelectionFromURL($location, $("#jettyTree"), true);
        }
    }
    Jetty.TreeController = TreeController;
})(Jetty || (Jetty = {}));
var Jmx;
(function (Jmx) {
    function AttributeController($scope, jolokia) {
        $scope.init = function (mbean, attribute) {
            $scope.mbean = mbean;
            $scope.attribute = attribute;
            if(angular.isDefined($scope.mbean) && angular.isDefined($scope.attribute)) {
                Core.register(jolokia, $scope, {
                    type: 'read',
                    mbean: $scope.mbean,
                    attribute: $scope.attribute
                }, onSuccess(render));
            }
        };
        function render(response) {
            if(!Object.equal($scope.data, response.value)) {
                $scope.data = response.value;
                $scope.$apply();
            }
        }
    }
    Jmx.AttributeController = AttributeController;
    function AttributeChartController($scope, jolokia, $document) {
        $scope.init = function (mbean, attribute) {
            $scope.mbean = mbean;
            $scope.attribute = attribute;
            if(angular.isDefined($scope.mbean) && angular.isDefined($scope.attribute)) {
                Core.register(jolokia, $scope, {
                    type: 'read',
                    mbean: $scope.mbean,
                    attribute: $scope.attribute
                }, onSuccess(render));
            }
        };
        function render(response) {
            if(!angular.isDefined($scope.chart)) {
                $scope.chart = $($document.find("#" + $scope.attribute)[0]);
                if($scope.chart) {
                    $scope.width = $scope.chart.width();
                }
            }
            if(!angular.isDefined($scope.context)) {
                console.log("Got: ", response);
                $scope.context = cubism.context().serverDelay(0).clientDelay(0).step(1000).size($scope.width);
                $scope.jcontext = $scope.context.jolokia(jolokia);
                $scope.metrics = [];
                Object.extended(response.value).keys(function (key, value) {
                    $scope.metrics.push($scope.jcontext.metric({
                        type: 'read',
                        mbean: $scope.mbean,
                        attribute: $scope.attribute,
                        path: key
                    }, $scope.attribute));
                });
                d3.select("#" + $scope.attribute).call(function (div) {
                    div.append("div").data($scope.metrics).call($scope.context.horizon());
                });
                Core.unregister(jolokia, $scope);
                $scope.$apply();
            }
        }
    }
    Jmx.AttributeChartController = AttributeChartController;
})(Jmx || (Jmx = {}));
var Jmx;
(function (Jmx) {
    Jmx.propertiesColumnDefs = [
        {
            field: 'name',
            displayName: 'Property',
            width: "27%"
        }, 
        {
            field: 'value',
            displayName: 'Value',
            width: "70%",
            cellTemplate: '<div class="ngCellText" ng-click="openDetailView(row.entity)" ng-bind-html-unsafe="row.entity.summary"></div>'
        }
    ];
    Jmx.foldersColumnDefs = [
        {
            displayName: 'Name',
            cellTemplate: '<div class="ngCellText"><a href="{{folderHref(row)}}"><i class="{{folderIconClass(row)}}"></i> {{row.getProperty("title")}}</a></div>'
        }
    ];
    function AttributesController($scope, $location, workspace, jolokia) {
        $scope.searchText = '';
        $scope.columnDefs = [];
        $scope.selectedItems = [];
        $scope.selectCheckBox = true;
        $scope.valueDetails = new Core.Dialog();
        $scope.gridOptions = {
            selectedItems: $scope.selectedItems,
            showFilter: false,
            canSelectRows: false,
            showColumnMenu: true,
            displaySelectionCheckbox: false,
            filterOptions: {
                filterText: ''
            },
            data: 'gridData',
            columnDefs: 'columnDefs'
        };
        $scope.$on("$routeChangeSuccess", function (event, current, previous) {
            setTimeout(updateTableContents, 50);
        });
        $scope.$watch('workspace.selection', function () {
            if(workspace.moveIfViewInvalid()) {
                Core.unregister(jolokia, $scope);
                return;
            }
            updateTableContents();
        });
        $scope.toolBarTemplate = function () {
            var answer = Jmx.getAttributeToolBar(workspace.selection);
            return answer;
        };
        $scope.invokeSelectedMBeans = function (operationName, completeFunction) {
            if (typeof completeFunction === "undefined") { completeFunction = null; }
            var queries = [];
            angular.forEach($scope.selectedItems || [], function (item) {
                var mbean = item["_id"];
                if(mbean) {
                    var opName = operationName;
                    if(angular.isFunction(operationName)) {
                        opName = operationName(item);
                    }
                    queries.push({
                        type: "exec",
                        operation: opName,
                        mbean: mbean
                    });
                }
            });
            if(queries.length) {
                var callback = function () {
                    if(completeFunction) {
                        completeFunction();
                    } else {
                        operationComplete();
                    }
                };
                jolokia.request(queries, onSuccess(callback, {
                    error: callback
                }));
            }
        };
        $scope.folderHref = function (row) {
            var key = row.getProperty("key");
            if(key) {
                return Core.createHref($location, "#" + $location.path() + "?nid=" + key, [
                    "nid"
                ]);
            } else {
                return "";
            }
        };
        $scope.folderIconClass = function (row) {
            return row.getProperty("objectName") ? "icon-cog" : "icon-folder-close";
        };
        $scope.openDetailView = function (entity) {
            $scope.row = entity;
            if(entity.detailHtml) {
                $scope.valueDetails.open();
            }
        };
        function operationComplete() {
            updateTableContents();
        }
        function updateTableContents() {
            Core.unregister(jolokia, $scope);
            $scope.gridData = [];
            $scope.mbeanIndex = null;
            var mbean = workspace.getSelectedMBeanName();
            var request = null;
            var node = workspace.selection;
            if(mbean) {
                request = {
                    type: 'read',
                    mbean: mbean
                };
                if(node.key !== $scope.lastKey) {
                    $scope.columnDefs = Jmx.propertiesColumnDefs;
                }
            } else {
                if(node) {
                    if(node.key !== $scope.lastKey) {
                        $scope.columnDefs = [];
                    }
                    var children = node.children;
                    if(children) {
                        var childNodes = children.map(function (child) {
                            return child.objectName;
                        });
                        var mbeans = childNodes.filter(function (mbean) {
                            return mbean;
                        });
                        if(mbeans) {
                            var typeNames = Jmx.getUniqueTypeNames(children);
                            if(typeNames.length <= 1) {
                                var query = mbeans.map(function (mbean) {
                                    return {
                                        type: "READ",
                                        mbean: mbean,
                                        ignoreErrors: true
                                    };
                                });
                                if(query.length > 0) {
                                    request = query;
                                    $scope.mbeanIndex = {
                                    };
                                    $scope.mbeanRowCounter = 0;
                                    $scope.mbeanCount = mbeans.length;
                                }
                            } else {
                                console.log("Too many type names " + typeNames);
                            }
                        }
                    }
                }
            }
            var callback = onSuccess(render);
            if(request) {
                $scope.request = request;
                Core.register(jolokia, $scope, request, callback);
            } else {
                if(node) {
                    if(node.key !== $scope.lastKey) {
                        $scope.columnDefs = Jmx.foldersColumnDefs;
                    }
                    $scope.gridData = node.children;
                }
            }
            if(node) {
                $scope.lastKey = node.key;
            }
        }
        function render(response) {
            var data = response.value;
            var mbeanIndex = $scope.mbeanIndex;
            var mbean = response.request.mbean;
            if(mbean) {
                data["_id"] = mbean;
            }
            if(mbeanIndex) {
                if(mbean) {
                    var idx = mbeanIndex[mbean];
                    if(!angular.isDefined(idx)) {
                        idx = $scope.mbeanRowCounter;
                        mbeanIndex[mbean] = idx;
                        $scope.mbeanRowCounter += 1;
                    }
                    if(idx === 0) {
                        $scope.selectedIndices = $scope.selectedItems.map(function (item) {
                            return $scope.gridData.indexOf(item);
                        });
                        $scope.gridData = [];
                        if(!$scope.columnDefs.length) {
                            var key = workspace.selectionConfigKey();
                            var defaultDefs = workspace.attributeColumnDefs[key] || [];
                            var defaultSize = defaultDefs.length;
                            var map = {
                            };
                            angular.forEach(defaultDefs, function (value, key) {
                                var field = value.field;
                                if(field) {
                                    map[field] = value;
                                }
                            });
                            angular.forEach(data, function (value, key) {
                                if(includePropertyValue(key, value)) {
                                    if(!map[key]) {
                                        defaultDefs.push({
                                            field: key,
                                            displayName: humanizeValue(key),
                                            visible: defaultSize === 0
                                        });
                                    }
                                }
                            });
                            $scope.columnDefs = defaultDefs;
                        }
                    }
                    $scope.gridData[idx] = data;
                    var count = $scope.mbeanCount;
                    if(!count || idx + 1 >= count) {
                        var newSelections = $scope.selectedIndices.map(function (idx) {
                            return $scope.gridData[idx];
                        }).filter(function (row) {
                            return row;
                        });
                        $scope.selectedItems.splice(0, $scope.selectedItems.length);
                        $scope.selectedItems.push.apply($scope.selectedItems, newSelections);
                        $scope.$apply();
                    }
                } else {
                    console.log("No mbean name in request " + JSON.stringify(response.request));
                }
            } else {
                $scope.columnDefs = Jmx.propertiesColumnDefs;
                var showAllAttributes = true;
                if(angular.isObject(data)) {
                    var properties = [];
                    angular.forEach(data, function (value, key) {
                        if(showAllAttributes || includePropertyValue(key, value)) {
                            if(!key.startsWith("_")) {
                                if(key === "ObjectName") {
                                    value = unwrapObjectName(value);
                                }
                                var data = {
                                    key: key,
                                    name: humanizeValue(key),
                                    value: value
                                };
                                generateSummaryAndDetail(data);
                                properties.push(data);
                            }
                        }
                    });
                    properties = properties.sortBy("name");
                    $scope.selectedItems = [
                        data
                    ];
                    data = properties;
                }
                $scope.gridData = data;
                $scope.$apply();
            }
        }
        function unwrapObjectName(value) {
            var keys = Object.keys(value);
            if(keys.length === 1 && keys[0] === "objectName") {
                return value["objectName"];
            }
            return value;
        }
        function generateSummaryAndDetail(data) {
            var value = data.value;
            if(!angular.isArray(value) && angular.isObject(value)) {
                var detailHtml = "<table class='table table-striped'>";
                var summary = "";
                var object = value;
                var keys = Object.keys(value).sort();
                angular.forEach(keys, function (key) {
                    var value = object[key];
                    detailHtml += "<tr><td>" + humanizeValue(key) + "</td><td>" + value + "</td></tr>";
                    summary += "" + humanizeValue(key) + ": " + value + "  ";
                });
                detailHtml += "</table>";
                data.summary = summary;
                data.detailHtml = detailHtml;
            } else {
                var text = value;
                data.summary = "" + text + "";
                data.detailHtml = "<pre>" + text + "</pre>";
            }
        }
        function includePropertyValue(key, value) {
            return !angular.isObject(value);
        }
    }
    Jmx.AttributesController = AttributesController;
})(Jmx || (Jmx = {}));
var Jmx;
(function (Jmx) {
    function AttributesOldController($scope, $routeParams, workspace, $rootScope) {
        $scope.routeParams = $routeParams;
        $scope.workspace = workspace;
        $scope.isTable = function (value) {
            return value instanceof Table;
        };
        $scope.getAttributes = function (value) {
            if(angular.isArray(value) && angular.isObject(value[0])) {
                return value;
            }
            if(angular.isObject(value) && !angular.isArray(value)) {
                return [
                    value
                ];
            }
            return null;
        };
        $scope.rowValues = function (row, col) {
            return [
                row[col]
            ];
        };
        var asQuery = function (mbeanName) {
            return {
                type: "READ",
                mbean: mbeanName,
                ignoreErrors: true
            };
        };
        var tidyAttributes = function (attributes) {
            var objectName = attributes['ObjectName'];
            if(objectName) {
                var name = objectName['objectName'];
                if(name) {
                    attributes['ObjectName'] = name;
                }
            }
        };
        $scope.$watch('workspace.selection', function () {
            if(workspace.moveIfViewInvalid()) {
                return;
            }
            var node = $scope.workspace.selection;
            closeHandle($scope, $scope.workspace.jolokia);
            var mbean = null;
            if(node) {
                mbean = node.objectName;
            }
            var query = null;
            var jolokia = workspace.jolokia;
            var updateValues = function (response) {
                var attributes = response.value;
                if(attributes) {
                    tidyAttributes(attributes);
                    $scope.attributes = attributes;
                    $scope.$apply();
                } else {
                    console.log("Failed to get a response! " + response);
                }
            };
            if(mbean) {
                query = asQuery(mbean);
            } else {
                if(node) {
                    var children = node.children;
                    if(children) {
                        var childNodes = children.map(function (child) {
                            return child.objectName;
                        });
                        var mbeans = childNodes.filter(function (mbean) {
                            return mbean;
                        });
                        var typeNames = Jmx.getUniqueTypeNames(children);
                        if(mbeans && typeNames.length <= 1) {
                            query = mbeans.map(function (mbean) {
                                return asQuery(mbean);
                            });
                            if(query.length === 1) {
                                query = query[0];
                            } else {
                                if(query.length === 0) {
                                    query = null;
                                } else {
                                    $scope.attributes = new Table();
                                    updateValues = function (response) {
                                        var attributes = response.value;
                                        if(attributes) {
                                            tidyAttributes(attributes);
                                            var mbean = attributes['ObjectName'];
                                            var request = response.request;
                                            if(!mbean && request) {
                                                mbean = request['mbean'];
                                            }
                                            if(mbean) {
                                                var table = $scope.attributes;
                                                if(!($scope.isTable(table))) {
                                                    table = new Table();
                                                    $scope.attributes = table;
                                                }
                                                table.setRow(mbean, attributes);
                                                $scope.$apply();
                                            } else {
                                                console.log("no ObjectName in attributes " + Object.keys(attributes));
                                            }
                                        } else {
                                            console.log("Failed to get a response! " + JSON.stringify(response));
                                        }
                                    };
                                }
                            }
                        }
                    }
                }
            }
            if(query) {
                jolokia.request(query, onSuccess(updateValues));
                var callback = onSuccess(updateValues, {
                    error: function (response) {
                        updateValues(response);
                    }
                });
                if(angular.isArray(query)) {
                    if(query.length >= 1) {
                        var args = [
                            callback
                        ].concat(query);
                        var fn = jolokia.register;
                        scopeStoreJolokiaHandle($scope, jolokia, fn.apply(jolokia, args));
                    }
                } else {
                    scopeStoreJolokiaHandle($scope, jolokia, jolokia.register(callback, query));
                }
            }
        });
    }
    Jmx.AttributesOldController = AttributesOldController;
})(Jmx || (Jmx = {}));
var Table = (function () {
    function Table() {
        this.columns = {
        };
        this.rows = {
        };
    }
    Table.prototype.values = function (row, columns) {
        var answer = [];
        if(columns) {
            for(name in columns) {
                answer.push(row[name]);
            }
        }
        return answer;
    };
    Table.prototype.setRow = function (key, data) {
        var _this = this;
        this.rows[key] = data;
        Object.keys(data).forEach(function (key) {
            var columns = _this.columns;
            if(!columns[key]) {
                columns[key] = {
                    name: key
                };
            }
        });
    };
    return Table;
})();
var Jmx;
(function (Jmx) {
    function ChartEditController($scope, $location, workspace, jolokia) {
        $scope.selectedAttributes = [];
        $scope.selectedMBeans = [];
        $scope.metrics = {
        };
        $scope.mbeans = {
        };
        $scope.size = function (value) {
            if(angular.isObject(value)) {
                return Object.size(value);
            } else {
                if(angular.isArray(value)) {
                    return value.length;
                } else {
                    return 1;
                }
            }
        };
        $scope.canViewChart = function () {
            return $scope.selectedAttributes.length && $scope.selectedMBeans.length && $scope.size($scope.mbeans) > 0 && $scope.size($scope.metrics) > 0;
        };
        $scope.showAttributes = function () {
            return $scope.canViewChart() && $scope.size($scope.metrics) > 1;
        };
        $scope.showElements = function () {
            return $scope.canViewChart() && $scope.size($scope.mbeans) > 1;
        };
        $scope.viewChart = function () {
            var search = $location.search();
            if($scope.selectedAttributes.length === $scope.size($scope.metrics)) {
                delete search["att"];
            } else {
                search["att"] = $scope.selectedAttributes;
            }
            if($scope.selectedMBeans.length === $scope.size($scope.mbeans) && $scope.size($scope.mbeans) === 1) {
                delete search["el"];
            } else {
                search["el"] = $scope.selectedMBeans;
            }
            $location.search(search);
            $location.path("jmx/charts");
        };
        $scope.$watch('workspace.selection', render);
        $scope.$on("$routeChangeSuccess", function (event, current, previous) {
            setTimeout(render, 50);
        });
        function render() {
            var node = workspace.selection;
            if(!angular.isDefined(node)) {
                return;
            }
            $scope.selectedAttributes = [];
            $scope.selectedMBeans = [];
            $scope.metrics = {
            };
            $scope.mbeans = {
            };
            var mbeanCounter = 0;
            var resultCounter = 0;
            var children = node.children;
            if(!children || !children.length || node.objectName) {
                children = [
                    node
                ];
            }
            if(children) {
                children.forEach(function (mbeanNode) {
                    var mbean = mbeanNode.objectName;
                    var name = mbeanNode.title;
                    if(name && mbean) {
                        mbeanCounter++;
                        $scope.mbeans[name] = name;
                        var listKey = escapeMBeanPath(mbean);
                        jolokia.list(listKey, onSuccess(function (meta) {
                            var attributes = meta.attr;
                            if(attributes) {
                                for(var key in attributes) {
                                    var value = attributes[key];
                                    if(value) {
                                        var typeName = value['type'];
                                        if(isNumberTypeName(typeName)) {
                                            if(!$scope.metrics[key]) {
                                                $scope.metrics[key] = key;
                                            }
                                        }
                                    }
                                }
                                if(++resultCounter >= mbeanCounter) {
                                    var search = $location.search();
                                    var attributeNames = toSearchArgumentArray(search["att"]);
                                    var elementNames = toSearchArgumentArray(search["el"]);
                                    if(attributeNames && attributeNames.length) {
                                        attributeNames.forEach(function (name) {
                                            if($scope.metrics[name]) {
                                                $scope.selectedAttributes.push(name);
                                            }
                                        });
                                    }
                                    if(elementNames && elementNames.length) {
                                        elementNames.forEach(function (name) {
                                            if($scope.mbeans[name]) {
                                                $scope.selectedMBeans.push(name);
                                            }
                                        });
                                    }
                                    if($scope.selectedMBeans.length < 1) {
                                        $scope.selectedMBeans = Object.keys($scope.mbeans);
                                    }
                                    if($scope.selectedAttributes.length < 1) {
                                        var attrKeys = Object.keys($scope.metrics).sort();
                                        if($scope.selectedMBeans.length > 1) {
                                            $scope.selectedAttributes = [
                                                attrKeys.first()
                                            ];
                                        } else {
                                            $scope.selectedAttributes = attrKeys;
                                        }
                                    }
                                    $("#attributes").attr("size", Object.size($scope.metrics));
                                    $("#mbeans").attr("size", Object.size($scope.mbeans));
                                    $scope.$apply();
                                }
                            }
                        }));
                    }
                });
            }
        }
    }
    Jmx.ChartEditController = ChartEditController;
})(Jmx || (Jmx = {}));
var Jmx;
(function (Jmx) {
    function ChartController($scope, $element, $location, workspace, jolokia, localStorage) {
        $scope.metrics = [];
        $scope.updateRate = parseInt(localStorage['updateRate']);
        var watchRouteChange = false;
        $scope.$on('$destroy', function () {
            if(watchRouteChange) {
                $scope.deregRouteChange();
            }
            $scope.dereg();
            if($scope.context) {
                $scope.context.stop();
                $scope.context = null;
            }
            $($element).children().remove();
        });
        $scope.errorMessage = function () {
            if($scope.updateRate === 0) {
                return "updateRate";
            }
            if($scope.metrics.length === 0) {
                return "metrics";
            }
        };
        if(watchRouteChange) {
            $scope.deregRouteChange = $scope.$on("$routeChangeSuccess", function (event, current, previous) {
                setTimeout(render, 50);
            });
        }
        $scope.dereg = $scope.$watch('workspace.selection', function () {
            if(workspace.moveIfViewInvalid()) {
                return;
            }
            render();
        });
        function render() {
            var node = workspace.selection;
            if(!angular.isDefined(node) || !angular.isDefined($scope.updateRate) || $scope.updateRate === 0) {
                return;
            }
            var width = 594;
            var charts = $($element);
            if(charts) {
                width = charts.width();
            } else {
                return;
            }
            var mbean = node.objectName;
            $scope.metrics = [];
            var context = cubism.context().serverDelay($scope.updateRate).clientDelay($scope.updateRate).step($scope.updateRate).size(width);
            $scope.context = context;
            $scope.jolokiaContext = context.jolokia(jolokia);
            var search = $location.search();
            var attributeNames = toSearchArgumentArray(search["att"]);
            if(mbean) {
                var listKey = encodeMBeanPath(mbean);
                var meta = jolokia.list(listKey);
                if(meta) {
                    var attributes = meta.attr;
                    if(attributes) {
                        var foundNames = [];
                        for(var key in attributes) {
                            var value = attributes[key];
                            if(value) {
                                var typeName = value['type'];
                                if(isNumberTypeName(typeName)) {
                                    foundNames.push(key);
                                }
                            }
                        }
                        if(attributeNames.length) {
                            var filtered = foundNames.filter(function (key) {
                                return attributeNames.indexOf(key) >= 0;
                            });
                            if(filtered.length) {
                                foundNames = filtered;
                            }
                        }
                        angular.forEach(foundNames, function (key) {
                            var metric = $scope.jolokiaContext.metric({
                                type: 'read',
                                mbean: mbean,
                                attribute: key
                            }, humanizeValue(key));
                            if(metric) {
                                $scope.metrics.push(metric);
                            }
                        });
                    }
                }
            } else {
                var elementNames = toSearchArgumentArray(search["el"]);
                if(attributeNames && attributeNames.length && elementNames && elementNames.length) {
                    var mbeans = {
                    };
                    elementNames.forEach(function (elementName) {
                        var child = node.get(elementName);
                        if(!child && node.children) {
                            child = node.children.find(function (n) {
                                return elementName === n["title"];
                            });
                        }
                        if(child) {
                            var mbean = child.objectName;
                            if(mbean) {
                                mbeans[elementName] = mbean;
                            }
                        }
                    });
                    attributeNames.forEach(function (key) {
                        angular.forEach(mbeans, function (mbean, name) {
                            var attributeTitle = humanizeValue(key);
                            var title = name + ": " + attributeTitle;
                            var metric = $scope.jolokiaContext.metric({
                                type: 'read',
                                mbean: mbean,
                                attribute: key
                            }, title);
                            if(metric) {
                                $scope.metrics.push(metric);
                            }
                        });
                    });
                }
                if(node.children.length && !$scope.metrics.length) {
                    $location.path("jmx/chartEdit");
                }
            }
            var d3Selection = d3.select($element[0]);
            if($scope.metrics.length > 0) {
                d3Selection.selectAll(".axis").data([
                    "top", 
                    "bottom"
                ]).enter().append("div").attr("class", function (d) {
                    return d + " axis";
                }).each(function (d) {
                    d3.select(this).call(context.axis().ticks(12).orient(d));
                });
                d3Selection.append("div").attr("class", "rule").call(context.rule());
                context.on("focus", function (i) {
                    d3Selection.selectAll(".value").style("right", i === null ? null : context.size() - i + "px");
                });
                $scope.metrics.forEach(function (metric) {
                    d3Selection.call(function (div) {
                        div.append("div").data([
                            metric
                        ]).attr("class", "horizon").call(context.horizon());
                    });
                });
            }
        }
        ; ;
    }
    Jmx.ChartController = ChartController;
})(Jmx || (Jmx = {}));
var Jmx;
(function (Jmx) {
    var pluginName = 'jmx';
    angular.module(pluginName, [
        'bootstrap', 
        'ui.bootstrap', 
        'ui.bootstrap.modal', 
        'ngResource', 
        'ngGrid', 
        'hawtioCore'
    ]).config(function ($routeProvider) {
        $routeProvider.when('/jmx/attributes', {
            templateUrl: 'app/jmx/html/attributes.html'
        }).when('/jmx/operations', {
            templateUrl: 'app/jmx/html/operations.html'
        }).when('/jmx/charts', {
            templateUrl: 'app/jmx/html/charts.html'
        }).when('/jmx/chartEdit', {
            templateUrl: 'app/jmx/html/chartEdit.html'
        }).when('/jmx/help/:tabName', {
            templateUrl: 'app/core/html/help.html'
        });
    }).factory('jmxTreeLazyLoadRegistry', function () {
        return Jmx.lazyLoaders;
    }).run(function ($location, workspace, viewRegistry, layoutTree, jolokia, pageTitle) {
        viewRegistry['jmx'] = layoutTree;
        try  {
            var id = jolokia.getAttribute('java.lang:type=Runtime', 'Name');
            if(id) {
                pageTitle.push(id);
            }
        } catch (e) {
        }
        workspace.topLevelTabs.push({
            content: "JMX",
            title: "View the JMX MBeans in this process",
            isValid: function (workspace) {
                return true;
            },
            href: function () {
                return "#/jmx/attributes";
            },
            isActive: function (workspace) {
                return workspace.isTopTabActive("jmx");
            }
        });
        workspace.subLevelTabs.push({
            content: '<i class="icon-list"></i> Attributes',
            title: "View the attribute values on your selection",
            isValid: function (workspace) {
                return true;
            },
            href: function () {
                return "#/jmx/attributes";
            }
        });
        workspace.subLevelTabs.push({
            content: '<i class="icon-leaf"></i> Operations',
            title: "Execute operations on your selection",
            isValid: function (workspace) {
                return true;
            },
            href: function () {
                return "#/jmx/operations";
            }
        });
        workspace.subLevelTabs.push({
            content: '<i class="icon-bar-chart"></i> Chart',
            title: "View a chart of the metrics on your selection",
            isValid: function (workspace) {
                return true;
            },
            href: function () {
                return "#/jmx/charts";
            }
        });
        workspace.subLevelTabs.push({
            content: '<i class="icon-cog"></i> Edit Chart',
            title: "Edit the chart configuration",
            isValid: function (workspace) {
                return workspace.isLinkActive("jmx/chart");
            },
            href: function () {
                return "#/jmx/chartEdit";
            }
        });
    });
    hawtioPluginLoader.addModule(pluginName);
})(Jmx || (Jmx = {}));
var Jmx;
(function (Jmx) {
    function MBeansController($scope, $location, workspace) {
        $scope.$on("$routeChangeSuccess", function (event, current, previous) {
            setTimeout(updateSelectionFromURL, 50);
        });
        $scope.select = function (node) {
            $scope.workspace.updateSelectionNode(node);
            $scope.$apply();
        };
        function updateSelectionFromURL() {
            Jmx.updateTreeSelectionFromURL($location, $("#jmxtree"));
        }
        $scope.populateTree = function () {
            var treeElement = $("#jmxtree");
            $scope.tree = workspace.tree;
            Jmx.enableTree($scope, $location, workspace, treeElement, $scope.tree.children, true);
            setTimeout(updateSelectionFromURL, 50);
        };
        $scope.$on('jmxTreeUpdated', $scope.populateTree);
        $scope.populateTree();
    }
    Jmx.MBeansController = MBeansController;
})(Jmx || (Jmx = {}));
var Jmx;
(function (Jmx) {
    function OperationController($scope, workspace, jolokia, $document) {
        $scope.title = $scope.item.humanReadable;
        $scope.desc = $scope.item.desc;
        $scope.operationResult = "";
        $scope.executeIcon = "icon-ok";
        var sanitize = function (args) {
            if(args) {
                args.forEach(function (arg) {
                    switch(arg.type) {
                        case "int":
                        case "long": {
                            arg.formType = "number";
                            break;

                        }
                        default: {
                            arg.formType = "text";

                        }
                    }
                });
            }
            return args;
        };
        $scope.args = sanitize($scope.item.args);
        $scope.dump = function (data) {
            console.log(data);
        };
        $scope.ok = function () {
            $scope.operationResult = '';
        };
        $scope.reset = function () {
            if($scope.item.args) {
                $scope.item.args.forEach(function (arg) {
                    arg.value = "";
                });
            }
            $scope.ok();
        };
        $scope.resultIsArray = function () {
            return angular.isArray($scope.operationResult);
        };
        $scope.resultIsString = function () {
            return angular.isString($scope.operationResult);
        };
        $scope.typeOf = function (data) {
            if(angular.isArray(data)) {
                return "array";
            } else {
                if(angular.isObject(data)) {
                    return "object";
                } else {
                    return "string";
                }
            }
        };
        $scope.execute = function () {
            var node = workspace.selection;
            if(!node) {
                return;
            }
            var objectName = node.objectName;
            if(!objectName) {
                return;
            }
            var get_response = function (response) {
                $scope.executeIcon = "icon-ok";
                $scope.operationStatus = "success";
                if(response === null || 'null' === response) {
                    $scope.operationResult = "Operation Succeeded!";
                } else {
                    if(typeof response === 'number' || typeof response === 'boolean') {
                        $scope.operationResult = "" + response;
                    } else {
                        if(angular.isArray(response) && response.length === 0) {
                            $scope.operationResult = "Operation succeeded and returned an empty array";
                        } else {
                            if(angular.isObject(response) && Object.keys(response).length === 0) {
                                $scope.operationResult = "Operation succeeded and returned an empty object";
                            } else {
                                $scope.operationResult = response;
                            }
                        }
                    }
                }
                $scope.$apply();
            };
            var args = [
                objectName, 
                $scope.item.name
            ];
            if($scope.item.args) {
                $scope.item.args.forEach(function (arg) {
                    args.push(arg.value);
                });
            }
            args.push(onSuccess(get_response, {
                error: function (response) {
                    $scope.executeIcon = "icon-ok";
                    $scope.operationStatus = "error";
                    var error = response.error;
                    $scope.operationResult = error;
                    var stacktrace = response.stacktrace;
                    if(stacktrace) {
                        $scope.operationResult = stacktrace;
                    }
                    $scope.$apply();
                }
            }));
            $scope.executeIcon = "icon-spinner icon-spin";
            var fn = jolokia.execute;
            fn.apply(jolokia, args);
        };
    }
    Jmx.OperationController = OperationController;
    function OperationsController($scope, $routeParams, workspace, jolokia) {
        $scope.operations = {
        };
        var sanitize = function (value) {
            for(var item in value) {
                item = "" + item;
                value[item].name = item;
                value[item].humanReadable = humanizeValue(item);
            }
            return value;
        };
        var asQuery = function (node) {
            var path = escapeMBeanPath(node);
            var query = {
                type: "LIST",
                method: "post",
                path: path,
                ignoreErrors: true
            };
            return query;
        };
        $scope.isOperationsEmpty = function () {
            return $.isEmptyObject($scope.operations);
        };
        $scope.$on("$routeChangeSuccess", function (event, current, previous) {
            setTimeout(render, 50);
        });
        $scope.$watch('workspace.selection', function () {
            if(workspace.moveIfViewInvalid()) {
                return;
            }
            render();
        });
        function render() {
            var node = workspace.selection;
            if(!node) {
                return;
            }
            var objectName = node.objectName;
            if(!objectName) {
                return;
            }
            var query = asQuery(objectName);
            var update_values = function (response) {
                var ops = response.value.op;
                var answer = {
                };
                var getArgs = function (args) {
                    return "(" + args.map(function (arg) {
                        return arg.type;
                    }).join() + ")";
                };
                angular.forEach(ops, function (value, key) {
                    if(angular.isArray(value)) {
                        angular.forEach(value, function (value, index) {
                            answer[key + getArgs(value.args)] = value;
                        });
                    } else {
                        answer[key + getArgs(value.args)] = value;
                    }
                });
                $scope.operations = sanitize(answer);
                $scope.$apply();
            };
            jolokia.request(query, onSuccess(update_values, {
                error: function (response) {
                    notification('error', 'Failed to query available operations: ' + response.error);
                }
            }));
        }
        render();
    }
    Jmx.OperationsController = OperationsController;
})(Jmx || (Jmx = {}));
var JVM;
(function (JVM) {
    function ConnectController($scope, $location, localStorage, workspace) {
        JVM.configureScope($scope, $location, workspace);
        $scope.host = "localhost";
        $scope.path = "jolokia";
        $scope.useProxy = true;
        var key = "jvmConnect";
        var config = {
        };
        var configJson = localStorage[key];
        if(configJson) {
            try  {
                config = JSON.parse(configJson);
            } catch (e) {
            }
        }
        $scope.port = config["port"] || 8181;
        $scope.userName = config["userName"];
        $scope.password = config["password"];
        angular.forEach([
            "userName", 
            "password", 
            "port"
        ], function (name) {
            $scope.$watch(name, function () {
                var value = $scope[name];
                if(value) {
                    config[name] = value;
                    localStorage[key] = JSON.stringify(config);
                }
            });
        });
        $scope.gotoServer = function () {
            var host = $scope.host || "localhost";
            var port = $scope.port;
            var path = Core.trimLeading($scope.path || "jolokia", "/");
            path = Core.trimTrailing(path, "/");
            host += "/";
            if(port > 0) {
                host += "" + port;
            }
            var url = host + "/" + path;
            if($scope.useProxy) {
                url = "/hawtio/proxy/" + url;
            } else {
                if(url.indexOf("://") < 0) {
                    url = "http://" + url;
                }
            }
            console.log("going to server: " + url + " as user " + $scope.userName);
            var full = "?url=" + encodeURIComponent(url);
            if($scope.userName) {
                full += "&_user=" + $scope.userName;
            }
            if($scope.password) {
                full += "&_pwd=" + $scope.password;
            }
            window.open(full);
        };
    }
    JVM.ConnectController = ConnectController;
})(JVM || (JVM = {}));
var JVM;
(function (JVM) {
    function configureScope($scope, $location, workspace) {
        $scope.isActive = function (href) {
            var tidy = Core.trimLeading(href, "#");
            var loc = $location.path();
            return loc === tidy;
        };
        $scope.isValid = function (link) {
            return link && link.isValid(workspace);
        };
        $scope.breadcrumbs = [
            {
                content: '<i class=" icon-signin"></i> Remote',
                title: "Connect to a remote JVM running Jolokia",
                isValid: function (workspace) {
                    return true;
                },
                href: "#/jvm/connect"
            }, 
            {
                content: '<i class="icon-list-ul"></i> Local',
                title: "View a diagram of the route",
                isValid: function (workspace) {
                    return workspace.treeContainsDomainAndProperties('io.hawt.jvm.local', {
                        type: 'JVMList'
                    });
                },
                href: "#/jvm/local"
            }
        ];
    }
    JVM.configureScope = configureScope;
})(JVM || (JVM = {}));
var Jvm;
(function (Jvm) {
    var pluginName = 'jvm';
    angular.module(pluginName, [
        'bootstrap', 
        'ngResource', 
        'datatable', 
        'hawtioCore'
    ]).config(function ($routeProvider) {
        $routeProvider.when('/jvm/connect', {
            templateUrl: 'app/jvm/html/connect.html'
        }).when('/jvm/local', {
            templateUrl: 'app/jvm/html/local.html'
        });
    }).constant('mbeanName', 'io.hawt.jvm.local:type=JVMList').run(function ($location, workspace, viewRegistry, layoutFull) {
        viewRegistry[pluginName] = layoutFull;
        workspace.topLevelTabs.push({
            content: "Connect",
            title: "Connect to other JVMs",
            isValid: function (workspace) {
                return true;
            },
            href: function () {
                return '#/jvm/connect';
            },
            isActive: function (workspace) {
                return workspace.isLinkActive("jvm");
            }
        });
    });
    hawtioPluginLoader.addModule(pluginName);
})(Jvm || (Jvm = {}));
var JVM;
(function (JVM) {
    function JVMsController($scope, $window, $location, workspace, jolokia, mbeanName) {
        JVM.configureScope($scope, $location, workspace);
        $scope.data = [];
        $scope.deploying = false;
        $scope.status = '';
        $scope.fetch = function () {
            notification('info', 'Discovering local JVM processes, please wait...');
            jolokia.request({
                type: 'exec',
                mbean: mbeanName,
                operation: 'listLocalJVMs()',
                arguments: []
            }, {
                success: render,
                error: function (response) {
                    $scope.data = [];
                    $scope.status = 'Could not discover local JVM processes: ' + response.error;
                    $scope.$apply();
                }
            });
        };
        $scope.stopAgent = function (pid) {
            notification('info', "Attempting to detach agent from PID " + pid);
            jolokia.request({
                type: 'exec',
                mbean: mbeanName,
                operation: 'stopAgent(java.lang.String)',
                arguments: [
                    pid
                ]
            }, onSuccess(function () {
                notification('success', "Detached agent from PID " + pid);
                $scope.fetch();
            }));
        };
        $scope.startAgent = function (pid) {
            notification('info', "Attempting to attach agent to PID " + pid);
            jolokia.request({
                type: 'exec',
                mbean: mbeanName,
                operation: 'startAgent(java.lang.String)',
                arguments: [
                    pid
                ]
            }, onSuccess(function () {
                notification('success', "Attached agent to PID " + pid);
                $scope.fetch();
            }));
        };
        $scope.connectTo = function (url) {
            $window.open("?url=" + encodeURIComponent(url));
        };
        function render(response) {
            $scope.data = response.value;
            if($scope.data.length === 0) {
                $scope.status = 'Could not discover local JVM processes';
            }
            $scope.$apply();
        }
        $scope.fetch();
    }
    JVM.JVMsController = JVMsController;
})(JVM || (JVM = {}));
var Karaf;
(function (Karaf) {
    function FeatureController($scope, $filter, workspace, $routeParams) {
        $scope.name = $routeParams.name;
        $scope.version = $routeParams.version;
        $scope.bundlesByLocation = {
        };
        updateTableContents();
        function populateTable(response) {
            angular.forEach(response.value["Features"], function (feature) {
                angular.forEach(feature, function (entry) {
                    if(entry["Name"] === $scope.name && entry["Version"] === $scope.version) {
                        $scope.row = Karaf.extractFeature(response.value, entry["Name"], entry["Version"]);
                        addBundleDetails($scope.row);
                    }
                });
            });
            $scope.$apply();
        }
        ; ;
        function setBundles(response) {
            var bundleMap = {
            };
            Osgi.defaultBundleValues(workspace, $scope, response.values);
            angular.forEach(response.value, function (bundle) {
                var location = bundle["Location"];
                $scope.bundlesByLocation[location] = bundle;
            });
        }
        ; ;
        function updateTableContents() {
            var featureMbean = Karaf.getSelectionFeaturesMBean(workspace);
            var bundleMbean = Osgi.getSelectionBundleMBean(workspace);
            var jolokia = workspace.jolokia;
            if(bundleMbean) {
                setBundles(jolokia.request({
                    type: 'exec',
                    mbean: bundleMbean,
                    operation: 'listBundles()'
                }));
            }
            if(featureMbean) {
                jolokia.request({
                    type: 'read',
                    mbean: featureMbean
                }, onSuccess(populateTable));
            }
        }
        function addBundleDetails(feature) {
            var bundleDetails = [];
            angular.forEach(feature["Bundles"], function (bundleLocation) {
                var bundle = $scope.bundlesByLocation[bundleLocation];
                if(bundle) {
                    bundle["Installed"] = true;
                    bundleDetails.push(bundle);
                } else {
                    bundleDetails.push({
                        "Location": bundleLocation,
                        "Installed": false
                    });
                }
            });
            feature["BundleDetails"] = bundleDetails;
        }
    }
    Karaf.FeatureController = FeatureController;
})(Karaf || (Karaf = {}));
var Karaf;
(function (Karaf) {
    function FeaturesController($scope, $location, workspace, jolokia) {
        $scope.feature = empty();
        var key = $location.search()['repo'];
        if(key) {
            $scope.repository = {
                id: key
            };
        }
        $scope.result = [];
        $scope.features = [];
        $scope.repositories = [];
        $scope.selectedFeatures = [];
        $scope.featureOptions = {
            data: 'features',
            showFilter: false,
            showColumnMenu: false,
            filterOptions: {
                useExternalFilter: true
            },
            selectedItems: $scope.selectedFeatures,
            rowHeight: 32,
            selectWithCheckboxOnly: true,
            columnDefs: [
                {
                    field: 'Name',
                    displayName: 'Name',
                    cellTemplate: '<div class="ngCellText">{{row.getProperty(col.field)}}</div>',
                    width: 200
                }, 
                {
                    field: 'Version',
                    displayName: 'Version',
                    cellTemplate: '<div class="ngCellText"><a href="#/karaf/feature/{{row.entity.Name}}/{{row.entity.Version}}">{{row.getProperty(col.field)}}</a></div>',
                    width: 200
                }
            ]
        };
        var featuresMBean = Karaf.getSelectionFeaturesMBean(workspace);
        if(featuresMBean) {
            Core.register(jolokia, $scope, {
                type: 'read',
                mbean: featuresMBean
            }, onSuccess(render));
        }
        $scope.install = function () {
            $scope.selectedFeatures.forEach(function (feature) {
                Karaf.installFeature(workspace, jolokia, feature.name, feature.version, function () {
                    console.log("Installed!");
                }, function () {
                    console.log("Failed to install!");
                });
            });
        };
        $scope.uninstall = function () {
            $scope.selectedFeatures.forEach(function (feature) {
                Karaf.uninstallFeature(workspace, jolokia, feature.name, feature.version, function () {
                    console.log("Uninstalled!");
                }, function () {
                    console.log("Failed to uninstall!");
                });
            });
        };
        $scope.statusIcon = function (row) {
            if(row) {
                if(row.alive) {
                    switch(row.provisionResult) {
                        case 'success': {
                            return "icon-thumbs-up";

                        }
                        case 'downloading': {
                            return "icon-download-alt";

                        }
                        case 'installing': {
                            return "icon-hdd";

                        }
                        case 'analyzing':
                        case 'finalizing': {
                            return "icon-refresh icon-spin";

                        }
                        case 'resolving': {
                            return "icon-sitemap";

                        }
                        case 'error': {
                            return "red icon-warning-sign";

                        }
                    }
                } else {
                    return "icon-off";
                }
            }
            return "icon-refresh icon-spin";
        };
        function empty() {
            return [
                {
                    id: ""
                }
            ];
        }
        function render(response) {
            if(!Object.equal($scope.result, response.value)) {
                $scope.result = response.value;
                $scope.features = [];
                $scope.repositories = empty();
                Karaf.populateFeaturesAndRepos($scope.result, $scope.features, $scope.repositories);
                $scope.repository = Karaf.setSelect($scope.repository, $scope.repositories);
                $scope.$apply();
            }
        }
        function featuresOfRepo(repository, features) {
            if(repository === "") {
                return features;
            }
            return features.findAll(function (feature) {
                return feature.repository === repository;
            });
        }
    }
    Karaf.FeaturesController = FeaturesController;
})(Karaf || (Karaf = {}));
var Karaf;
(function (Karaf) {
    function setSelect(selection, group) {
        if(!angular.isDefined(selection)) {
            return group[0];
        }
        var answer = group.findIndex(function (item) {
            return item.id === selection.id;
        });
        if(answer !== -1) {
            return group[answer];
        } else {
            return group[0];
        }
    }
    Karaf.setSelect = setSelect;
    function installFeature(workspace, jolokia, feature, version, success, error) {
        jolokia.request({
            type: 'exec',
            mbean: getSelectionFeaturesMBean(workspace),
            operation: 'installFeature(java.lang.String, java.lang.String)',
            arguments: [
                feature, 
                version
            ]
        }, onSuccess(success, {
            error: error
        }));
    }
    Karaf.installFeature = installFeature;
    function uninstallFeature(workspace, jolokia, feature, version, success, error) {
        jolokia.request({
            type: 'exec',
            mbean: getSelectionFeaturesMBean(workspace),
            operation: 'uninstallFeature(java.lang.String, java.lang.String)',
            arguments: [
                feature, 
                version
            ]
        }, onSuccess(success, {
            error: error
        }));
    }
    Karaf.uninstallFeature = uninstallFeature;
    function toCollection(values) {
        var collection = values;
        if(!angular.isArray(values)) {
            collection = [
                values
            ];
        }
        return collection;
    }
    Karaf.toCollection = toCollection;
    function featureLinks(workspace, name, version) {
        return "<a href='" + url("#/karaf/feature/" + name + "/" + version + workspace.hash()) + "'>" + version + "</a>";
    }
    Karaf.featureLinks = featureLinks;
    function extractFeature(attributes, name, version) {
        var f = {
        };
        angular.forEach(attributes["Features"], function (feature) {
            angular.forEach(feature, function (entry) {
                if(entry["Name"] === name && entry["Version"] === version) {
                    var deps = [];
                    populateDependencies(attributes, entry["Dependencies"], deps);
                    f["Name"] = entry["Name"];
                    f["Version"] = entry["Version"];
                    f["Bundles"] = entry["Bundles"];
                    f["Dependencies"] = deps;
                    f["Installed"] = entry["Installed"];
                    f["Configurations"] = entry["Configurations"];
                    f["Configuration Files"] = entry["Configuration Files"];
                    f["Files"] = entry["Configuration Files"];
                }
            });
        });
        return f;
    }
    Karaf.extractFeature = extractFeature;
    function populateFeaturesAndRepos(attributes, features, repositories) {
        angular.forEach(attributes["Repositories"], function (repo) {
            repositories.push({
                id: repo["Name"],
                uri: repo["Uri"]
            });
            angular.forEach(repo["Features"], function (feature) {
                angular.forEach(feature, function (entry) {
                    var f = {
                    };
                    f["Id"] = entry["Name"] + "/" + entry["Version"];
                    f["Name"] = entry["Name"];
                    f["Version"] = entry["Version"];
                    f["Installed"] = entry["Installed"];
                    f["Repository"] = repo["Name"];
                    features.push(f);
                });
            });
        });
    }
    Karaf.populateFeaturesAndRepos = populateFeaturesAndRepos;
    function populateDependencies(attributes, dependencies, features) {
        angular.forEach(dependencies, function (feature) {
            angular.forEach(feature, function (entry) {
                var enhancedFeature = extractFeature(attributes, entry["Name"], entry["Version"]);
                enhancedFeature["id"] = entry["Name"] + "/" + entry["Version"];
                features.push(enhancedFeature);
            });
        });
    }
    Karaf.populateDependencies = populateDependencies;
    function getSelectionFeaturesMBean(workspace) {
        if(workspace) {
            var featuresStuff = workspace.mbeanTypesToDomain["features"] || {
            };
            var karaf = featuresStuff["org.apache.karaf"] || {
            };
            var mbean = karaf.objectName;
            if(mbean) {
                return mbean;
            }
            var folder = workspace.tree.navigate("org.apache.karaf", "features");
            if(!folder) {
                folder = workspace.tree.navigate("org.apache.karaf");
                var children = folder.children;
                folder = null;
                angular.forEach(children, function (child) {
                    if(!folder) {
                        folder = child.navigate("features");
                    }
                });
            }
            if(folder) {
                var children = folder.children;
                if(children) {
                    var node = children[0];
                    if(node) {
                        return node.objectName;
                    }
                }
                return folder.objectName;
            }
        }
        return null;
    }
    Karaf.getSelectionFeaturesMBean = getSelectionFeaturesMBean;
})(Karaf || (Karaf = {}));
var Karaf;
(function (Karaf) {
    var pluginName = 'karaf';
    angular.module(pluginName, [
        'bootstrap', 
        'ngResource', 
        'hawtioCore'
    ]).config(function ($routeProvider) {
        $routeProvider.when('/karaf/server', {
            templateUrl: 'app/karaf/html/server.html'
        }).when('/karaf/features', {
            templateUrl: 'app/karaf/html/features.html'
        }).when('/karaf/feature/:name/:version', {
            templateUrl: 'app/karaf/html/feature.html'
        });
    }).run(function (workspace, viewRegistry) {
        viewRegistry['karaf'] = "app/karaf/html/layoutKaraf.html";
        workspace.topLevelTabs.push({
            content: "Karaf",
            title: "Visualise and manage the bundles and services in this OSGi container",
            isValid: function (workspace) {
                return workspace.treeContainsDomainAndProperties("org.apache.karaf");
            },
            href: function () {
                return "#/karaf/server?tab=karafTab";
            },
            isActive: function (workspace) {
                return workspace.isTopTabActive("karafTab");
            }
        });
    });
    hawtioPluginLoader.addModule(pluginName);
})(Karaf || (Karaf = {}));
var Karaf;
(function (Karaf) {
    function NavBarController($scope, $location, workspace, jolokia) {
        $scope.isFeaturesEnabled = Karaf.getSelectionFeaturesMBean(workspace);
        $scope.isActive = function (nav) {
            return workspace.isLinkActive(nav);
        };
    }
    Karaf.NavBarController = NavBarController;
})(Karaf || (Karaf = {}));
var Karaf;
(function (Karaf) {
    function ServerController($scope, $location, workspace, jolokia) {
        $scope.data = {
            name: "",
            version: "",
            state: "",
            root: "",
            startLevel: "",
            framework: "",
            frameworkVersion: "",
            location: "",
            sshPort: "",
            rmiRegistryPort: "",
            rmiServerPort: "",
            pid: ""
        };
        $scope.$on('jmxTreeUpdated', reloadFunction);
        $scope.$watch('workspace.tree', reloadFunction);
        function reloadFunction() {
            setTimeout(loadData, 50);
        }
        function loadData() {
            console.log("Loading Karaf data...");
            jolokia.search("org.apache.karaf:type=admin,*", onSuccess(render));
        }
        function render(response) {
            if(angular.isArray(response)) {
                var mbean = response[0];
                if(mbean) {
                    jolokia.getAttribute(mbean, "Instances", onSuccess(onInstances));
                }
            }
        }
        function onInstances(instances) {
            if(instances) {
                var rootInstance = instances['root'];
                $scope.data.name = rootInstance.Name;
                $scope.data.state = rootInstance.State;
                $scope.data.root = rootInstance["Is Root"];
                $scope.data.location = rootInstance.Location;
                $scope.data.sshPort = rootInstance["SSH Port"];
                $scope.data.rmiRegistryPort = rootInstance["RMI Registry Port"];
                $scope.data.rmiServerPort = rootInstance["RMI Server Port"];
                $scope.data.pid = rootInstance.Pid;
                $scope.data.version = "?";
                $scope.data.startLevel = "?";
                $scope.data.framework = "?";
                $scope.data.frameworkVersion = "?";
                var systemMbean = "org.apache.karaf:type=system,name=" + rootInstance.Name;
                var response = jolokia.request({
                    type: "read",
                    mbean: systemMbean,
                    attribute: [
                        "StartLevel", 
                        "Framework", 
                        "Version"
                    ]
                }, onSuccess(null));
                var obj = response.value;
                if(obj) {
                    $scope.data.version = obj.Version;
                    $scope.data.startLevel = obj.StartLevel;
                    $scope.data.framework = obj.Framework;
                }
                var response2 = jolokia.search("osgi.core:type=bundleState,*", onSuccess(null));
                if(angular.isArray(response2)) {
                    var mbean = response2[0];
                    if(mbean) {
                        var response3 = jolokia.request({
                            type: 'exec',
                            mbean: mbean,
                            operation: 'getVersion(long)',
                            arguments: [
                                0
                            ]
                        }, onSuccess(null));
                        var obj3 = response3.value;
                        if(obj3) {
                            $scope.data.frameworkVersion = obj3;
                        }
                    }
                }
            }
            Core.$apply($scope);
        }
    }
    Karaf.ServerController = ServerController;
})(Karaf || (Karaf = {}));
var Log;
(function (Log) {
    function logSourceHref(row) {
        var log = row.entity;
        var fileName = Log.removeQuestion(log.fileName);
        var className = Log.removeQuestion(log.className);
        var properties = log.properties;
        var mavenCoords = "";
        if(properties) {
            mavenCoords = properties["maven.coordinates"];
        }
        if(mavenCoords && fileName) {
            var link = "#/source/view/" + mavenCoords + "/class/" + className + "/" + fileName;
            var line = log.lineNumber;
            if(line) {
                link += "?line=" + line;
            }
            return link;
        } else {
            return "";
        }
    }
    Log.logSourceHref = logSourceHref;
    function removeQuestion(text) {
        return (!text || text === "?") ? null : text;
    }
    Log.removeQuestion = removeQuestion;
    var _stackRegex = /\s*at\s+([\w\.$_]+(\.([\w$_]+))*)\((.*)?:(\d+)\).*\[(.*)\]/;
    function formatStackLine(line) {
        var match = _stackRegex.exec(line);
        if(match && match.length > 6) {
            var classAndMethod = match[1];
            var fileName = match[4];
            var line = match[5];
            var mvnCoords = match[6];
            if(classAndMethod && fileName && mvnCoords) {
                var className = classAndMethod;
                var idx = classAndMethod.lastIndexOf('.');
                if(idx > 0) {
                    className = classAndMethod.substring(0, idx);
                }
                var link = "#/source/view/" + mvnCoords + "/class/" + className + "/" + fileName;
                if(angular.isDefined(line)) {
                    link += "?line=" + line;
                }
                return "at <a href='" + link + "'>" + classAndMethod + "</a>(<span class='fileName'>" + fileName + "</span>:<span class='lineNumber'>" + line + "</span>)[<span class='mavenCoords'>" + mvnCoords + "</span>]";
            }
        }
        return line;
    }
    Log.formatStackLine = formatStackLine;
    function getLogCacheSize(localStorage) {
        var text = localStorage['logCacheSize'];
        if(text) {
            return parseInt(text);
        }
        return 1000;
    }
    Log.getLogCacheSize = getLogCacheSize;
})(Log || (Log = {}));
var Log;
(function (Log) {
    var pluginName = 'log';
    angular.module(pluginName, [
        'bootstrap', 
        'ngResource', 
        'ngGrid', 
        'datatable', 
        'hawtioCore'
    ]).config(function ($routeProvider) {
        $routeProvider.when('/logs', {
            templateUrl: 'app/log/html/logs.html'
        });
    }).run(function ($location, workspace, viewRegistry, layoutFull) {
        viewRegistry['log'] = layoutFull;
        workspace.topLevelTabs.push({
            content: "Logs",
            title: "View and search the logs of this container",
            isValid: function (workspace) {
                return workspace.treeContainsDomainAndProperties('org.fusesource.insight', {
                    type: 'LogQuery'
                });
            },
            href: function () {
                return "#/logs";
            }
        });
        workspace.subLevelTabs.push({
            content: '<i class="icon-list-alt"></i> Log',
            title: "View the logs in this process",
            isValid: function (workspace) {
                return workspace.hasDomainAndProperties('org.fusesource.insight', {
                    type: 'LogQuery'
                });
            },
            href: function () {
                return "#/logs";
            }
        });
    }).filter('logDateFilter', function ($filter) {
        var standardDateFilter = $filter('date');
        return function (dateToFormat) {
            return standardDateFilter(dateToFormat, 'yyyy-MM-dd HH:mm:ss');
        }
    });
    hawtioPluginLoader.addModule(pluginName);
})(Log || (Log = {}));
var Log;
(function (Log) {
    function LogController($scope, $location, localStorage, workspace) {
        $scope.logs = [];
        $scope.filteredLogs = [];
        $scope.selectedItems = [];
        $scope.searchText = "";
        $scope.filter = {
            logLevelQuery: "",
            logLevelExactMatch: false
        };
        $scope.toTime = 0;
        $scope.queryJSON = {
            type: "EXEC",
            mbean: logQueryMBean,
            operation: "logResultsSince",
            arguments: [
                $scope.toTime
            ],
            ignoreErrors: true
        };
        $scope.logClass = function (log) {
            return logLevelClass(log['level']);
        };
        $scope.logIcon = function (log) {
            var style = $scope.logClass(log);
            if(style === "error") {
                return "red icon-warning-sign";
            }
            if(style === "warning") {
                return "orange icon-exclamation-sign";
            }
            if(style === "info") {
                return "icon-info-sign";
            }
            return "icon-cog";
        };
        $scope.logSourceHref = Log.logSourceHref;
        $scope.hasLogSourceHref = function (row) {
            return Log.logSourceHref(row) ? true : false;
        };
        $scope.dateFormat = 'yyyy-MM-dd HH:mm:ss';
        $scope.formatException = function (line) {
            return Log.formatStackLine(line);
        };
        $scope.getSupport = function () {
            if($scope.selectedItems.length) {
                var log = $scope.selectedItems[0];
                var text = log["message"];
                var uri = "https://access.redhat.com/knowledge/solutions?logger=" + log["logger"] + "&text=" + text;
                window.location.href = uri;
            }
        };
        var columnDefs = [
            {
                field: 'timestamp',
                displayName: 'Timestamp',
                cellFilter: "logDateFilter",
                width: 146
            }, 
            {
                field: 'level',
                displayName: 'Level',
                cellTemplate: '<div class="ngCellText"><span class="text-{{logClass(row.entity)}}"><i class="{{logIcon(row.entity)}}"></i> {{row.entity.level}}</span></div>',
                cellFilter: null,
                width: 74,
                resizable: false
            }, 
            {
                field: 'logger',
                displayName: 'Logger',
                cellTemplate: '<div class="ngCellText" ng-switch="hasLogSourceHref(row)" title="{{row.entity.logger}}"><a ng-href="{{logSourceHref(row)}}" ng-switch-when="true">{{row.entity.logger}}</a><div ng-switch-default>{{row.entity.logger}}</div></div>',
                cellFilter: null,
                width: "20%"
            }, 
            {
                field: 'message',
                displayName: 'Message',
                width: "60%"
            }
        ];
        $scope.gridOptions = {
            selectedItems: $scope.selectedItems,
            data: 'filteredLogs',
            displayFooter: false,
            showFilter: false,
            sortInfo: {
                field: 'timestamp',
                direction: 'DESC'
            },
            filterOptions: {
                filterText: "searchText"
            },
            columnDefs: columnDefs,
            rowDetailTemplateId: "logDetailTemplate"
        };
        $scope.$watch('filter.logLevelExactMatch', function () {
            checkIfFilterChanged();
        });
        $scope.$watch('filter.logLevelQuery', function () {
            checkIfFilterChanged();
        });
        var updateValues = function (response) {
            var logs = response.events;
            var toTime = response.toTimestamp;
            if(toTime && angular.isNumber(toTime)) {
                if(toTime < 0) {
                    console.log("ignoring dodgy value of toTime: " + toTime);
                } else {
                    $scope.toTime = toTime;
                    $scope.queryJSON.arguments = [
                        toTime
                    ];
                }
            }
            if(logs) {
                var maxSize = Log.getLogCacheSize(localStorage);
                var counter = 0;
                logs.forEach(function (log) {
                    if(log) {
                        if(!$scope.logs.any(function (key, item) {
                            return item.message === log.message && item.seq === log.message && item.timestamp === log.timestamp;
                        })) {
                            counter += 1;
                            $scope.logs.push(log);
                        }
                    }
                });
                if(maxSize > 0) {
                    var size = $scope.logs.length;
                    if(size > maxSize) {
                        var count = size - maxSize;
                        $scope.logs.splice(0, count);
                    }
                }
                if(counter) {
                    refilter();
                    $scope.$apply();
                }
            }
        };
        var jolokia = workspace.jolokia;
        jolokia.execute(logQueryMBean, "allLogResults", onSuccess(updateValues));
        var asyncUpdateValues = function (response) {
            var value = response.value;
            if(value) {
                updateValues(value);
            } else {
                notification("error", "Failed to get a response! " + JSON.stringify(response, null, 4));
            }
        };
        var callback = onSuccess(asyncUpdateValues, {
            error: function (response) {
                asyncUpdateValues(response);
            }
        });
        scopeStoreJolokiaHandle($scope, jolokia, jolokia.register(callback, $scope.queryJSON));
        var logLevels = [
            "TRACE", 
            "DEBUG", 
            "INFO", 
            "WARN", 
            "ERROR"
        ];
        var logLevelMap = {
        };
        angular.forEach(logLevels, function (name, idx) {
            logLevelMap[name] = idx;
            logLevelMap[name.toLowerCase()] = idx;
        });
        function checkIfFilterChanged() {
            if($scope.logLevelExactMatch !== $scope.filter.logLevelExactMatch || $scope.logLevelQuery !== $scope.filter.logLevelExactMatch) {
                refilter();
            }
        }
        function refilter() {
            var logLevelExactMatch = $scope.filter.logLevelExactMatch;
            var logLevelQuery = $scope.filter.logLevelQuery;
            var logLevelQueryOrdinal = (logLevelExactMatch) ? 0 : logLevelMap[logLevelQuery];
            $scope.logLevelExactMatch = logLevelExactMatch;
            $scope.logLevelQuery = logLevelQuery;
            $scope.filteredLogs = $scope.logs.filter(function (log) {
                if(logLevelQuery) {
                    if(logLevelExactMatch) {
                        return log.level === logLevelQuery;
                    } else {
                        var idx = logLevelMap[log.level];
                        return idx >= logLevelQueryOrdinal || idx < 0;
                    }
                }
                return true;
            });
            Core.$apply($scope);
        }
    }
    Log.LogController = LogController;
})(Log || (Log = {}));
var Maven;
(function (Maven) {
    function ArtifactController($scope, $routeParams, workspace, jolokia) {
        $scope.row = {
            groupId: $routeParams["group"] || "",
            artifactId: $routeParams["artifact"] || "",
            version: $routeParams["version"] || "",
            classifier: $routeParams["classifier"] || "",
            packaging: $routeParams["packaging"] || ""
        };
        var row = $scope.row;
        $scope.id = Maven.getName(row);
        Maven.addMavenFunctions($scope, workspace);
        $scope.$on("$routeChangeSuccess", function (event, current, previous) {
            setTimeout(updateTableContents, 50);
        });
        $scope.$watch('workspace.selection', function () {
            if(workspace.moveIfViewInvalid()) {
                return;
            }
            updateTableContents();
        });
        function updateTableContents() {
            var mbean = Maven.getMavenIndexerMBean(workspace);
            if(mbean) {
                jolokia.execute(mbean, "search", row.groupId, row.artifactId, row.version, row.packaging, row.classifier, "", onSuccess(render));
            } else {
                console.log("No MavenIndexerMBean!");
            }
        }
        function render(response) {
            if(response && response.length) {
                var first = response[0];
                row.name = first.name;
                row.description = first.description;
            }
            Core.$apply($scope);
        }
    }
    Maven.ArtifactController = ArtifactController;
})(Maven || (Maven = {}));
var Maven;
(function (Maven) {
    function DependenciesController($scope, $routeParams, $location, workspace, jolokia) {
        $scope.artifacts = [];
        $scope.group = $routeParams["group"] || "";
        $scope.artifact = $routeParams["artifact"] || "";
        $scope.version = $routeParams["version"] || "";
        $scope.classifier = $routeParams["classifier"] || "";
        $scope.packaging = $routeParams["packaging"] || "";
        $scope.dependencyTree = null;
        Maven.addMavenFunctions($scope, workspace);
        $scope.$on("$routeChangeSuccess", function (event, current, previous) {
            setTimeout(updateTableContents, 50);
        });
        $scope.$watch('workspace.selection', function () {
            updateTableContents();
        });
        $scope.onSelectNode = function (node) {
            $scope.selected = node;
        };
        $scope.onRootNode = function (rootNode) {
        };
        $scope.validSelection = function () {
            return $scope.selected && $scope.selected !== $scope.rootDependency;
        };
        $scope.viewDetails = function () {
            var dependency = Core.pathGet($scope.selected, [
                "dependency"
            ]);
            var link = $scope.detailLink(dependency);
            if(link) {
                var path = Core.trimLeading(link, "#");
                console.log("going to view " + path);
                $location.path(path);
            }
        };
        function updateTableContents() {
            var mbean = Maven.getAetherMBean(workspace);
            if(mbean) {
                jolokia.execute(mbean, "resolveJson(java.lang.String,java.lang.String,java.lang.String,java.lang.String,java.lang.String)", $scope.group, $scope.artifact, $scope.version, $scope.packaging, $scope.classifier, onSuccess(render));
            } else {
                console.log("No AetherMBean!");
            }
        }
        function render(response) {
            if(response) {
                var json = JSON.parse(response);
                if(json) {
                    $scope.dependencyTree = new Folder("Dependencies");
                    $scope.dependencyActivations = [];
                    addChildren($scope.dependencyTree, json);
                    $scope.dependencyActivations.reverse();
                    $scope.rootDependency = $scope.dependencyTree.children[0];
                }
            }
            Core.$apply($scope);
        }
        function addChildren(folder, dependency) {
            var name = Maven.getName(dependency);
            var node = new Folder(name);
            node.key = name.replace(/\//g, '_');
            node["dependency"] = dependency;
            $scope.dependencyActivations.push(node.key);
            folder.children.push(node);
            var children = dependency["children"];
            angular.forEach(children, function (child) {
                addChildren(node, child);
            });
        }
    }
    Maven.DependenciesController = DependenciesController;
})(Maven || (Maven = {}));
var Maven;
(function (Maven) {
    function getMavenIndexerMBean(workspace) {
        if(workspace) {
            var mavenStuff = workspace.mbeanTypesToDomain["Indexer"] || {
            };
            var object = mavenStuff["io.hawt.maven"] || {
            };
            return object.objectName;
        } else {
            return null;
        }
    }
    Maven.getMavenIndexerMBean = getMavenIndexerMBean;
    function getAetherMBean(workspace) {
        if(workspace) {
            var mavenStuff = workspace.mbeanTypesToDomain["AetherFacade"] || {
            };
            var object = mavenStuff["io.hawt.aether"] || {
            };
            return object.objectName;
        } else {
            return null;
        }
    }
    Maven.getAetherMBean = getAetherMBean;
    function getName(row) {
        var id = (row.group || row.groupId) + "/" + (row.artifact || row.artifactId);
        if(row.version) {
            id += "/" + row.version;
        }
        if(row.classifier) {
            id += "/" + row.classifier;
        }
        if(row.packaging) {
            id += "/" + row.packaging;
        }
        return id;
    }
    Maven.getName = getName;
    function addMavenFunctions($scope, workspace) {
        $scope.detailLink = function (row) {
            var group = row.groupId;
            var artifact = row.artifactId;
            var version = row.version || "";
            var classifier = row.classifier || "";
            var packaging = row.packaging || "";
            if(group && artifact) {
                return "#/maven/artifact/" + group + "/" + artifact + "/" + version + "/" + classifier + "/" + packaging;
            }
            return "";
        };
        $scope.javadocLink = function (row) {
            var group = row.groupId;
            var artifact = row.artifactId;
            var version = row.version;
            if(group && artifact && version) {
                return "javadoc/" + group + ":" + artifact + ":" + version + "/";
            }
            return "";
        };
        $scope.versionsLink = function (row) {
            var group = row.groupId;
            var artifact = row.artifactId;
            var classifier = row.classifier || "";
            var packaging = row.packaging || "";
            if(group && artifact) {
                return "#/maven/versions/" + group + "/" + artifact + "/" + classifier + "/" + packaging;
            }
            return "";
        };
        $scope.dependenciesLink = function (row) {
            var group = row.groupId;
            var artifact = row.artifactId;
            var classifier = row.classifier || "";
            var packaging = row.packaging || "";
            var version = row.version;
            if(group && artifact) {
                return "#/maven/dependencies/" + group + "/" + artifact + "/" + version + "/" + classifier + "/" + packaging;
            }
            return "";
        };
        $scope.hasDependencyMBean = function () {
            var mbean = Maven.getAetherMBean(workspace);
            return angular.isDefined(mbean);
        };
        $scope.sourceLink = function (row) {
            var group = row.groupId;
            var artifact = row.artifactId;
            var version = row.version;
            if(group && artifact && version) {
                return "#/source/index/" + group + ":" + artifact + ":" + version + "/";
            }
            return "";
        };
    }
    Maven.addMavenFunctions = addMavenFunctions;
})(Maven || (Maven = {}));
var Maven;
(function (Maven) {
    var pluginName = 'maven';
    angular.module(pluginName, [
        'bootstrap', 
        'ngResource', 
        'datatable', 
        'tree', 
        'hawtioCore'
    ]).config(function ($routeProvider) {
        $routeProvider.when('/maven/search', {
            templateUrl: 'app/maven/html/search.html'
        }).when('/maven/advancedSearch', {
            templateUrl: 'app/maven/html/advancedSearch.html'
        }).when('/maven/artifact/:group/:artifact/:version/:classifier/:packaging', {
            templateUrl: 'app/maven/html/artifact.html'
        }).when('/maven/artifact/:group/:artifact/:version', {
            templateUrl: 'app/maven/html/artifact.html'
        }).when('/maven/dependencies/:group/:artifact/:version/:classifier/:packaging', {
            templateUrl: 'app/maven/html/dependencies.html'
        }).when('/maven/dependencies/:group/:artifact/:version', {
            templateUrl: 'app/maven/html/dependencies.html'
        }).when('/maven/versions/:group/:artifact/:classifier/:packaging', {
            templateUrl: 'app/maven/html/versions.html'
        }).when('/maven/view/:group/:artifact/:version/:classifier/:packaging', {
            templateUrl: 'app/maven/html/view.html'
        });
    }).run(function ($location, workspace, viewRegistry, jolokia, localStorage, layoutFull) {
        viewRegistry['maven'] = "app/maven/html/layoutMaven.html";
        workspace.topLevelTabs.push({
            content: "Maven",
            title: "Search maven repositories for artifacts",
            isValid: function (workspace) {
                return Maven.getMavenIndexerMBean(workspace);
            },
            href: function () {
                return "#/maven/search";
            },
            isActive: function (workspace) {
                return workspace.isLinkActive("/maven");
            }
        });
    });
    hawtioPluginLoader.addModule(pluginName);
})(Maven || (Maven = {}));
var Maven;
(function (Maven) {
    function PomXmlController($scope) {
        $scope.mavenPomXml = "\n" + "  <dependency>\n" + "    <groupId>" + orBlank($scope.row.groupId) + "</groupId>\n" + "    <artifactId>" + orBlank($scope.row.artifactId) + "</artifactId>\n" + "    <version>" + orBlank($scope.row.version) + "</version>\n" + "  </dependency>\n";
        function orBlank(text) {
            return text || "";
        }
    }
    Maven.PomXmlController = PomXmlController;
})(Maven || (Maven = {}));
var Maven;
(function (Maven) {
    function SearchController($scope, $location, workspace, jolokia) {
        $scope.artifacts = [];
        $scope.selected = [];
        $scope.done = false;
        $scope.form = {
            searchText: ""
        };
        $scope.search = "";
        $scope.searchForm = 'app/maven/html/searchForm.html';
        Maven.addMavenFunctions($scope, workspace);
        var columnDefs = [
            {
                field: 'groupId',
                displayName: 'Group'
            }, 
            {
                field: 'artifactId',
                displayName: 'Artifact',
                cellTemplate: '<div class="ngCellText" title="Name: {{row.entity.name}}">{{row.entity.artifactId}}</div>'
            }, 
            {
                field: 'version',
                displayName: 'Version',
                cellTemplate: '<div class="ngCellText" title="Name: {{row.entity.name}}"><a ng-href="{{detailLink(row.entity)}}">{{row.entity.version}}</a</div>'
            }
        ];
        $scope.gridOptions = {
            data: 'artifacts',
            displayFooter: true,
            selectedItems: $scope.selected,
            selectWithCheckboxOnly: true,
            columnDefs: columnDefs,
            rowDetailTemplateId: "artifactDetailTemplate",
            filterOptions: {
                filterText: 'search'
            }
        };
        $scope.hasAdvancedSearch = function (form) {
            return form.searchGroup || form.searchArtifact || form.searchVersion || form.searchPackaging || form.searchClassifier || form.searchClassName;
        };
        $scope.doSearch = function () {
            $scope.done = false;
            var mbean = Maven.getMavenIndexerMBean(workspace);
            var form = $scope.form;
            if(mbean) {
                var searchText = form.searchText;
                var kind = form.artifactType;
                if(kind) {
                    if(kind === "className") {
                        jolokia.execute(mbean, "searchClasses", searchText, onSuccess(render));
                    } else {
                        var paths = kind.split('/');
                        var packaging = paths[0];
                        var classifier = paths[1];
                        console.log("Search for: " + form.searchText + " packaging " + packaging + " classifier " + classifier);
                        jolokia.execute(mbean, "searchTextAndPackaging", searchText, packaging, classifier, onSuccess(render));
                    }
                } else {
                    if(searchText) {
                        console.log("Search text is: " + form.searchText);
                        jolokia.execute(mbean, "searchText", form.searchText, onSuccess(render));
                    } else {
                        if($scope.hasAdvancedSearch(form)) {
                            console.log("Searching for " + form.searchGroup + "/" + form.searchArtifact + "/" + form.searchVersion + "/" + form.searchPackaging + "/" + form.searchClassifier + "/" + form.searchClassName);
                            jolokia.execute(mbean, "search", form.searchGroup || "", form.searchArtifact || "", form.searchVersion || "", form.searchPackaging || "", form.searchClassifier || "", form.searchClassName || "", onSuccess(render));
                        }
                    }
                }
            } else {
                notification("error", "Could not find the Maven Indexer MBean!");
            }
        };
        function render(response) {
            $scope.done = true;
            $scope.artifacts = response;
            Core.$apply($scope);
        }
    }
    Maven.SearchController = SearchController;
})(Maven || (Maven = {}));
var Maven;
(function (Maven) {
    function VersionsController($scope, $routeParams, workspace, jolokia) {
        $scope.artifacts = [];
        $scope.group = $routeParams["group"] || "";
        $scope.artifact = $routeParams["artifact"] || "";
        $scope.version = "";
        $scope.classifier = $routeParams["classifier"] || "";
        $scope.packaging = $routeParams["packaging"] || "";
        var id = $scope.group + "/" + $scope.artifact;
        if($scope.classifier) {
            id += "/" + $scope.classifier;
        }
        if($scope.packaging) {
            id += "/" + $scope.packaging;
        }
        var columnTitle = id + " versions";
        var columnDefs = [
            {
                field: 'versionNumber',
                displayName: columnTitle,
                cellTemplate: '<div class="ngCellText">{{row.entity.version}}</div>'
            }
        ];
        $scope.gridOptions = {
            data: 'artifacts',
            displayFooter: true,
            selectedItems: $scope.selected,
            selectWithCheckboxOnly: true,
            columnDefs: columnDefs,
            rowDetailTemplateId: "artifactDetailTemplate",
            sortInfo: {
                field: 'versionNumber',
                direction: 'DESC'
            },
            filterOptions: {
                filterText: 'search'
            }
        };
        Maven.addMavenFunctions($scope, workspace);
        $scope.$on("$routeChangeSuccess", function (event, current, previous) {
            setTimeout(updateTableContents, 50);
        });
        $scope.$watch('workspace.selection', function () {
            if(workspace.moveIfViewInvalid()) {
                return;
            }
            updateTableContents();
        });
        function updateTableContents() {
            var mbean = Maven.getMavenIndexerMBean(workspace);
            if(mbean) {
                jolokia.execute(mbean, "versionComplete", $scope.group, $scope.artifact, $scope.version, $scope.packaging, $scope.classifier, onSuccess(render));
            } else {
                console.log("No MavenIndexerMBean!");
            }
        }
        function render(response) {
            $scope.artifacts = [];
            angular.forEach(response, function (version) {
                var versionNumberArray = Core.parseVersionNumbers(version);
                var versionNumber = 0;
                for(var i = 0; i <= 4; i++) {
                    var num = (i >= versionNumberArray.length) ? 0 : versionNumberArray[i];
                    versionNumber *= 1000;
                    versionNumber += num;
                }
                $scope.artifacts.push({
                    groupId: $scope.group,
                    artifactId: $scope.artifact,
                    packaging: $scope.packaging,
                    classifier: $scope.classifier,
                    version: version,
                    versionNumber: versionNumber
                });
            });
            Core.$apply($scope);
        }
    }
    Maven.VersionsController = VersionsController;
})(Maven || (Maven = {}));
var Maven;
(function (Maven) {
    function ViewController($scope, $location, workspace, jolokia) {
        $scope.$watch('workspace.tree', function () {
            setTimeout(loadData, 50);
        });
        $scope.$on("$routeChangeSuccess", function (event, current, previous) {
            setTimeout(loadData, 50);
        });
        function loadData() {
        }
    }
    Maven.ViewController = ViewController;
})(Maven || (Maven = {}));
var OpenEJB;
(function (OpenEJB) {
    var pluginName = 'openejb';
    angular.module(pluginName, [
        'bootstrap', 
        'ngResource', 
        'hawtioCore'
    ]).config(function ($routeProvider) {
    }).run(function ($location, workspace, viewRegistry) {
        viewRegistry['openojb'] = "app/openejb/html/layoutOpenEJBTree.html";
        workspace.topLevelTabs.push({
            content: "OpenEJB",
            title: "Manage your OpenEJB resources",
            isValid: function (workspace) {
                return workspace.treeContainsDomainAndProperties("openejb");
            },
            href: function () {
                return "#/jmx/attributes?tab=openejb";
            },
            isActive: function (workspace) {
                return workspace.isTopTabActive("openejb");
            }
        });
    });
    hawtioPluginLoader.addModule(pluginName);
})(OpenEJB || (OpenEJB = {}));
var OpenEJB;
(function (OpenEJB) {
    function TreeController($scope, $location, workspace) {
        $scope.$on("$routeChangeSuccess", function (event, current, previous) {
            setTimeout(updateSelectionFromURL, 50);
        });
        $scope.$watch('workspace.tree', function () {
            if(workspace.moveIfViewInvalid()) {
                return;
            }
            var children = [];
            var tree = workspace.tree;
            if(tree) {
                var nodes = tree.children;
                angular.forEach(nodes, function (node) {
                    var nodeChildren = node.children;
                    if(node.title.startsWith("openejb") && nodeChildren) {
                        children = children.concat(nodeChildren);
                    }
                });
            }
            var treeElement = $("#openejbTree");
            Jmx.enableTree($scope, $location, workspace, treeElement, children, true);
            setTimeout(updateSelectionFromURL, 50);
        });
        function updateSelectionFromURL() {
            Jmx.updateTreeSelectionFromURL($location, $("#openejbTree"), true);
        }
    }
    OpenEJB.TreeController = TreeController;
})(OpenEJB || (OpenEJB = {}));
var Osgi;
(function (Osgi) {
    function BundleListController($scope, workspace, jolokia) {
        $scope.result = {
        };
        $scope.bundles = [];
        $scope.bundleUrl = "";
        $scope.display = {
            bundleField: "Name",
            sortField: "Identifier",
            bundleFilter: "",
            startLevelFilter: undefined
        };
        $scope.installDisabled = function () {
            return $scope.bundleUrl === "";
        };
        $scope.install = function () {
            jolokia.request({
                type: 'exec',
                mbean: Osgi.getSelectionFrameworkMBean(workspace),
                operation: "installBundle(java.lang.String)",
                arguments: [
                    $scope.bundleUrl
                ]
            }, {
                success: function (response) {
                    var bundleID = response.value;
                    jolokia.request({
                        type: 'exec',
                        mbean: Osgi.getSelectionBundleMBean(workspace),
                        operation: "isFragment(long)",
                        arguments: [
                            bundleID
                        ]
                    }, {
                        success: function (response) {
                            var isFragment = response.value;
                            if(isFragment) {
                                notification("success", "Fragment installed succesfully.");
                                $scope.bundleUrl = "";
                                $scope.$apply();
                            } else {
                                jolokia.request({
                                    type: 'exec',
                                    mbean: Osgi.getSelectionFrameworkMBean(workspace),
                                    operation: "startBundle(long)",
                                    arguments: [
                                        bundleID
                                    ]
                                }, {
                                    success: function (response) {
                                        notification("success", "Bundle installed and started successfully.");
                                        $scope.bundleUrl = "";
                                        $scope.$apply();
                                    },
                                    error: function (response) {
                                        notification("error", response.error);
                                    }
                                });
                            }
                        },
                        error: function (response) {
                            notification("error", response.error);
                        }
                    });
                },
                error: function (response) {
                    notification("error", response.error);
                }
            });
        };
        $scope.$watch("display.sortField", function () {
            $scope.bundles = $scope.bundles.sortBy(function (n) {
                switch($scope.display.sortField) {
                    case "Name": {
                        return n.Name;

                    }
                    case "SymbolicName": {
                        return n.SymbolicName;

                    }
                    default: {
                        return n.Identifier;

                    }
                }
            });
            render();
        });
        $scope.$watch("display.bundleField", function () {
            render();
        });
        $scope.$watch("display.bundleFilter", function () {
            render();
        });
        $scope.$watch("display.startLevelFilter", function () {
            render();
        });
        function addRow(bundleObject, labelText) {
            var labelClass = "badge " + Osgi.getStateStyle("badge", bundleObject.State);
            var table = document.getElementById("bundleTable");
            var numRows = table.rows.length;
            var curRow = table.rows[numRows - 1];
            var numCols = typeof curRow === 'undefined' ? 999 : curRow.cells.length;
            var newCell;
            if(numCols < 3) {
                newCell = curRow.insertCell(numCols);
            } else {
                var newRow = table.insertRow(numRows);
                newCell = newRow.insertCell(0);
            }
            var placement = (numCols === 2) ? 'left' : 'right';
            newCell.innerHTML = "<a href='#/osgi/bundle/" + bundleObject.Identifier + "' id=" + bundleObject.Identifier + " rel='popover'><span class='" + labelClass + "'>" + labelText + "</span></a>";
            var po = "<small><table>" + "<tr><td><strong class='muted'>ID</strong> " + bundleObject.Identifier + (bundleObject.Fragment === true ? " (fragment) " : "") + "</td></tr>" + "<tr><td><strong class='muted'>Name</strong> " + bundleObject.Name + "</td></tr>" + "<tr><td><strong class='muted'>Version</strong> " + bundleObject.Version + "</td></tr>" + "<tr><td><strong class='muted'>State</strong> <div class='label " + Osgi.getStateStyle("label", bundleObject.State) + "'>" + bundleObject.State + "</div></td></tr>" + "<tr><td><strong class='muted'>Start Level</strong> " + bundleObject.StartLevel + "</td></tr>" + "</table></small>";
            $("#" + bundleObject.Identifier).popover({
                title: bundleObject.SymbolicName,
                trigger: 'hover',
                html: true,
                content: po,
                delay: 100,
                placement: placement
            });
        }
        function createTable() {
            var table = document.getElementById("bundleTable");
            table.parentNode.removeChild(table);
            var div = document.getElementById("bundleTableHolder");
            var newTable = document.createElement("table");
            newTable.id = "bundleTable";
            document.getElementById("bundleTableHolder").appendChild(newTable);
        }
        function render() {
            createTable();
            var filterString = $scope.display.bundleFilter === undefined ? undefined : $scope.display.bundleFilter.toLowerCase();
            for(var i = 0; i < $scope.bundles.length; i++) {
                var bundleObject = $scope.bundles[i];
                var labelText;
                if($scope.display.bundleField === "Name") {
                    labelText = bundleObject.Name;
                    if(labelText === "") {
                        labelText = bundleObject.SymbolicName;
                    }
                } else {
                    labelText = bundleObject.SymbolicName;
                }
                if(filterString !== undefined) {
                    if(labelText.toLowerCase().indexOf(filterString) === -1) {
                        continue;
                    }
                }
                if($scope.display.startLevelFilter > 0) {
                    if(bundleObject.StartLevel < $scope.display.startLevelFilter) {
                        continue;
                    }
                }
                addRow(bundleObject, labelText);
            }
        }
        function processResponse(response) {
            if(!Object.equal($scope.result, response.value)) {
                $scope.result = response.value;
                $scope.bundles = [];
                angular.forEach($scope.result, function (value, key) {
                    var obj = {
                        Identifier: value.Identifier,
                        Name: "",
                        SymbolicName: value.SymbolicName,
                        Fragment: value.Fragment,
                        State: value.State,
                        Version: value.Version,
                        LastModified: new Date(Number(value.LastModified)),
                        Location: value.Location,
                        StartLevel: undefined
                    };
                    if(value.Headers['Bundle-Name']) {
                        obj.Name = value.Headers['Bundle-Name']['Value'];
                    }
                    $scope.bundles.push(obj);
                });
                for(var i = 0; i < $scope.bundles.length; i++) {
                    var b = $scope.bundles[i];
                    jolokia.request({
                        type: 'exec',
                        mbean: Osgi.getSelectionBundleMBean(workspace),
                        operation: 'getStartLevel(long)',
                        arguments: [
                            $scope.bundles[i].Identifier
                        ]
                    }, onSuccess((function (bundle, last) {
                        return function (response) {
                            bundle.StartLevel = response.value;
                            if(last) {
                                render();
                            }
                        }
                    })(b, i === ($scope.bundles.length - 1))));
                }
                render();
            }
        }
        Core.register(jolokia, $scope, {
            type: 'exec',
            mbean: Osgi.getSelectionBundleMBean(workspace),
            operation: 'listBundles()'
        }, onSuccess(processResponse));
    }
    Osgi.BundleListController = BundleListController;
})(Osgi || (Osgi = {}));
var Osgi;
(function (Osgi) {
    function BundleController($scope, $location, workspace, $routeParams, jolokia) {
        $scope.bundleId = $routeParams.bundleId;
        updateTableContents();
        $scope.showValue = function (key) {
            switch(key) {
                case "Bundle-Name":
                case "Bundle-SymbolicName":
                case "Bundle-Version":
                case "Export-Package":
                case "Import-Package": {
                    return false;

                }
                default: {
                    return true;

                }
            }
        };
        $scope.executeLoadClass = function (clazz) {
            var mbean = Osgi.getHawtioOSGiMBean(workspace);
            if(mbean) {
                jolokia.request({
                    type: 'exec',
                    mbean: mbean,
                    operation: 'getLoadClassOrigin',
                    arguments: [
                        $scope.bundleId, 
                        clazz
                    ]
                }, {
                    success: function (response) {
                        var divEl = document.getElementById("loadClassResult");
                        var resultBundle = response.value;
                        var style;
                        var resultTxt;
                        if(resultBundle === -1) {
                            style = "";
                            resultTxt = "Class can not be loaded from this bundle.";
                        } else {
                            style = "alert-success";
                            resultTxt = "Class is served from Bundle " + Osgi.bundleLinks(workspace, resultBundle);
                        }
                        divEl.innerHTML += "<div class='alert " + style + "'>" + "<button type='button' class='close' data-dismiss='alert'>&times;</button>" + "Loading class <strong>" + clazz + "</strong> in Bundle " + $scope.bundleId + ". " + resultTxt + "</div>";
                    },
                    error: function (response) {
                        inspectReportError(response);
                    }
                });
            } else {
                inspectReportNoMBeanFound();
            }
        };
        $scope.executeFindResource = function (resource) {
            var mbean = Osgi.getHawtioOSGiMBean(workspace);
            if(mbean) {
                jolokia.request({
                    type: 'exec',
                    mbean: mbean,
                    operation: 'getResourceURL',
                    arguments: [
                        $scope.bundleId, 
                        resource
                    ]
                }, {
                    success: function (response) {
                        var divEl = document.getElementById("loadClassResult");
                        var resultURL = response.value;
                        var style;
                        var resultTxt;
                        if(resultURL === null) {
                            style = "";
                            resultTxt = "Resource can not be found from this bundle.";
                        } else {
                            style = "alert-success";
                            resultTxt = "Resource is available from: " + resultURL;
                        }
                        divEl.innerHTML += "<div class='alert " + style + "'>" + "<button type='button' class='close' data-dismiss='alert'>&times;</button>" + "Finding resource <strong>" + resource + "</strong> in Bundle " + $scope.bundleId + ". " + resultTxt + "</div>";
                    },
                    error: function (response) {
                        inspectReportError(response);
                    }
                });
            } else {
                inspectReportNoMBeanFound();
            }
        };
        $scope.mavenLink = function (row) {
            var loc = row.Location;
            if(loc && loc.startsWith("mvn:")) {
                return "#/maven/artifact/" + loc.substring(4);
            }
            return "";
        };
        $scope.startBundle = function (bundleId) {
            jolokia.request([
                {
                    type: 'exec',
                    mbean: Osgi.getSelectionFrameworkMBean(workspace),
                    operation: 'startBundle',
                    arguments: [
                        bundleId
                    ]
                }
            ], onSuccess(updateTableContents));
        };
        $scope.stopBundle = function (bundleId) {
            jolokia.request([
                {
                    type: 'exec',
                    mbean: Osgi.getSelectionFrameworkMBean(workspace),
                    operation: 'stopBundle',
                    arguments: [
                        bundleId
                    ]
                }
            ], onSuccess(updateTableContents));
        };
        $scope.updatehBundle = function (bundleId) {
            jolokia.request([
                {
                    type: 'exec',
                    mbean: Osgi.getSelectionFrameworkMBean(workspace),
                    operation: 'updateBundle',
                    arguments: [
                        bundleId
                    ]
                }
            ], onSuccess(updateTableContents));
        };
        $scope.refreshBundle = function (bundleId) {
            jolokia.request([
                {
                    type: 'exec',
                    mbean: Osgi.getSelectionFrameworkMBean(workspace),
                    operation: 'refreshBundle',
                    arguments: [
                        bundleId
                    ]
                }
            ], onSuccess(updateTableContents));
        };
        $scope.uninstallBundle = function (bundleId) {
            jolokia.request([
                {
                    type: 'exec',
                    mbean: Osgi.getSelectionFrameworkMBean(workspace),
                    operation: 'uninstallBundle',
                    arguments: [
                        bundleId
                    ]
                }
            ], onSuccess($location.path("/osgi/bundle-list")));
        };
        function inspectReportNoMBeanFound() {
            var divEl = document.getElementById("loadClassResult");
            divEl.innerHTML += "<div class='alert alert-error'>" + "<button type='button' class='close' data-dismiss='alert'>&times;</button>" + "The io.hawt.osgi.OSGiTools MBean is not available. Please contact technical support." + "</div>";
        }
        function inspectReportError(response) {
            var divEl = document.getElementById("loadClassResult");
            divEl.innerHTML += "<div class='alert alert-error'>" + "<button type='button' class='close' data-dismiss='alert'>&times;</button>" + "Problem invoking io.hawt.osgi.OSGiTools MBean. " + response + "</div>";
        }
        function populateTable(response) {
            var values = response.value;
            $scope.bundles = values;
            Osgi.defaultBundleValues(workspace, $scope, values);
            $scope.row = Osgi.findBundle($scope.bundleId, values);
            $scope.$apply();
            $('.accordion-body.collapse').hover(function () {
                $(this).css('overflow', 'visible');
            }, function () {
                $(this).css('overflow', 'hidden');
            });
            $("#bsn").tooltip({
                title: readBSNHeaderData($scope.row.Headers["Bundle-SymbolicName"].Value),
                placement: "right"
            });
            createImportPackageSection();
            createExportPackageSection();
            populateServicesSection();
        }
        function createImportPackageSection() {
            var importPackageHeaders = Osgi.parseManifestHeader($scope.row.Headers, "Import-Package");
            for(var pkg in $scope.row.ImportData) {
                var data = importPackageHeaders[pkg];
                var po = "<small><table>" + "<tr><td><strong>Imported Version=</strong>" + $scope.row.ImportData[pkg].ReportedVersion + "</td></tr>";
                if(data !== undefined) {
                    po += formatAttributesAndDirectivesForPopover(data, false);
                    if(importPackageHeaders[pkg]["Dresolution"] !== "optional") {
                        $(document.getElementById("import." + pkg)).addClass("badge-info");
                    }
                } else {
                    $(document.getElementById("import." + pkg)).addClass("badge-important");
                    var reason = $scope.row.Headers["DynamicImport-Package"];
                    if(reason !== undefined) {
                        reason = reason.Value;
                        po += "<tr><td>Dynamic Import. Imported due to:</td></tr>";
                        po += "<tr><td><strong>DynamicImport-Package=</strong>" + reason + "</td></tr>";
                    }
                }
                po += "</table></small>";
                $(document.getElementById("import." + pkg)).popover({
                    title: "attributes and directives",
                    content: po,
                    trigger: "hover",
                    html: true
                });
                importPackageHeaders[pkg] = undefined;
            }
            var unsatisfied = "";
            for(var pkg in importPackageHeaders) {
                if(importPackageHeaders[pkg] === undefined) {
                    continue;
                }
                if($scope.row.ExportData[pkg] !== undefined) {
                    continue;
                }
                unsatisfied += "<tr><td><div class='less-big badge badge-warning' id='unsatisfied." + pkg + "'>" + pkg + "</div></td></tr>";
            }
            if(unsatisfied !== "") {
                unsatisfied = "<p/><p class='text-warning'>The following optional imports were not satisfied:<table>" + unsatisfied + "</table></p>";
                document.getElementById("unsatisfiedOptionalImports").innerHTML = unsatisfied;
            }
            for(var pkg in importPackageHeaders) {
                if(importPackageHeaders[pkg] === undefined) {
                    continue;
                }
                var po = "<small><table>";
                po += formatAttributesAndDirectivesForPopover(importPackageHeaders[pkg], false);
                po += "</table></small>";
                $(document.getElementById("unsatisfied." + pkg)).popover({
                    title: "attributes and directives",
                    content: po,
                    trigger: "hover",
                    html: true
                });
            }
        }
        function createExportPackageSection() {
            var exportPackageHeaders = Osgi.parseManifestHeader($scope.row.Headers, "Export-Package");
            for(var pkg in $scope.row.ExportData) {
                var po = "<small><table>" + "<tr><td><strong>Exported Version=</strong>" + $scope.row.ExportData[pkg].ReportedVersion + "</td></tr>";
                po += formatAttributesAndDirectivesForPopover(exportPackageHeaders[pkg], true);
                po += "</table></small>";
                $(document.getElementById("export." + pkg)).popover({
                    title: "attributes and directives",
                    content: po,
                    trigger: "hover",
                    html: true
                });
            }
        }
        function populateServicesSection() {
            if(($scope.row.RegisteredServices === undefined || $scope.row.RegisteredServices.length === 0) && ($scope.row.ServicesInUse === undefined || $scope.row.ServicesInUse === 0)) {
                return;
            }
            var mbean = Osgi.getSelectionServiceMBean(workspace);
            if(mbean) {
                jolokia.request({
                    type: 'exec',
                    mbean: mbean,
                    operation: 'listServices()'
                }, onSuccess(updateServices));
            }
        }
        function updateServices(result) {
            var data = result.value;
            for(var id in data) {
                var reg = document.getElementById("registers.service." + id);
                var uses = document.getElementById("uses.service." + id);
                if((reg === undefined || reg === null) && (uses === undefined || uses === null)) {
                    continue;
                }
                jolokia.request({
                    type: 'exec',
                    mbean: Osgi.getSelectionServiceMBean(workspace),
                    operation: 'getProperties',
                    arguments: [
                        id
                    ]
                }, onSuccess((function (svcId, regEl, usesEl) {
                    return function (resp) {
                        var props = resp.value;
                        var sortedKeys = Object.keys(props).sort();
                        var po = "<small><table>";
                        for(var i = 0; i < sortedKeys.length; i++) {
                            var value = props[sortedKeys[i]];
                            if(value !== undefined) {
                                var fval = value.Value;
                                if(fval.length > 15) {
                                    fval = fval.replace(/[,]/g, ",<br/>&nbsp;&nbsp;");
                                }
                                po += "<tr><td valign='top'>" + sortedKeys[i] + "</td><td>" + fval + "</td></tr>";
                            }
                        }
                        var regBID = data[svcId].BundleIdentifier;
                        po += "<tr><td>Registered&nbsp;by</td><td>Bundle " + regBID + " <div class='less-big label'>" + $scope.bundles[regBID].SymbolicName + "</div></td></tr>";
                        po += "</table></small>";
                        if(regEl !== undefined && regEl !== null) {
                            regEl.innerText = " " + formatServiceName(data[svcId].objectClass);
                            $(regEl).popover({
                                title: "service properties",
                                content: po,
                                trigger: "hover",
                                html: true
                            });
                        }
                        if(usesEl !== undefined && usesEl !== null) {
                            usesEl.innerText = " " + formatServiceName(data[svcId].objectClass);
                            $(usesEl).popover({
                                title: "service properties",
                                content: po,
                                trigger: "hover",
                                html: true
                            });
                        }
                    }
                })(id, reg, uses)));
            }
        }
        function updateTableContents() {
            var mbean = Osgi.getSelectionBundleMBean(workspace);
            if(mbean) {
                jolokia.request({
                    type: 'exec',
                    mbean: mbean,
                    operation: 'listBundles()'
                }, onSuccess(populateTable));
            }
        }
    }
    Osgi.BundleController = BundleController;
    function readBSNHeaderData(header) {
        var idx = header.indexOf(";");
        if(idx <= 0) {
            return "";
        }
        return header.substring(idx + 1).trim();
    }
    Osgi.readBSNHeaderData = readBSNHeaderData;
    function formatAttributesAndDirectivesForPopover(data, skipVersion) {
        var str = "";
        var sortedKeys = Object.keys(data).sort();
        for(var i = 0; i < sortedKeys.length; i++) {
            var da = sortedKeys[i];
            var type = da.charAt(0);
            var separator = "";
            var txtClass;
            if(type === "A") {
                separator = "=";
                txtClass = "text-info";
            }
            if(type === "D") {
                separator = ":=";
                txtClass = "muted";
            }
            if(separator !== "") {
                if(skipVersion) {
                    if(da === "Aversion") {
                        continue;
                    }
                }
                var value = data[da];
                if(value.length > 15) {
                    value = value.replace(/[,]/g, ",<br/>&nbsp;&nbsp;");
                }
                str += "<tr><td><strong class='" + txtClass + "'>" + da.substring(1) + "</strong>" + separator + value + "</td></tr>";
            }
        }
        return str;
    }
    Osgi.formatAttributesAndDirectivesForPopover = formatAttributesAndDirectivesForPopover;
    function formatServiceName(objClass) {
        if(Object.isArray(objClass)) {
            return formatServiceNameArray(objClass);
        }
        var name = objClass.toString();
        var idx = name.lastIndexOf('.');
        return name.substring(idx + 1);
    }
    Osgi.formatServiceName = formatServiceName;
    function formatServiceNameArray(objClass) {
        var rv = [];
        for(var i = 0; i < objClass.length; i++) {
            rv.add(formatServiceName(objClass[i]));
        }
        rv = rv.filter(function (elem, pos, self) {
            return self.indexOf(elem) === pos;
        });
        rv.sort();
        return rv.toString();
    }
})(Osgi || (Osgi = {}));
var Osgi;
(function (Osgi) {
    function BundlesController($scope, workspace, jolokia) {
        $scope.result = {
        };
        $scope.bundles = [];
        $scope.selected = [];
        $scope.loading = true;
        $scope.bundleUrl = "";
        $scope.installDisabled = function () {
            return $scope.bundleUrl === "";
        };
        var columnDefs = [
            {
                field: 'Identifier',
                displayName: 'Identifier',
                width: "48",
                headerCellTemplate: '<div ng-click="col.sort()" class="ngHeaderSortColumn {{col.headerClass}}" ng-style="{\'cursor\': col.cursor}" ng-class="{ \'ngSorted\': !noSortVisible }"><div class="ngHeaderText colt{{$index}} pagination-centered" title="Identifier"><i class="icon-tag"></i></div><div class="ngSortButtonDown" ng-show="col.showSortButtonDown()"></div><div class="ngSortButtonUp" ng-show="col.showSortButtonUp()"></div></div>'
            }, 
            {
                field: 'State',
                displayName: 'Bundle State',
                width: "24",
                headerCellTemplate: '<div ng-click="col.sort()" class="ngHeaderSortColumn {{col.headerClass}}" ng-style="{\'cursor\': col.cursor}" ng-class="{ \'ngSorted\': !noSortVisible }"><div class="ngHeaderText colt{{$index}} pagination-centered" title="State"><i class="icon-tasks"></i></div><div class="ngSortButtonDown" ng-show="col.showSortButtonDown()"></div><div class="ngSortButtonUp" ng-show="col.showSortButtonUp()"></div></div>',
                cellTemplate: '<div class="ngCellText" title="{{row.getProperty(col.field)}}"><i class="{{row.getProperty(col.field)}}"></i></div>'
            }, 
            {
                field: 'Name',
                displayName: 'Name',
                width: "***",
                cellTemplate: '<div class="ngCellText"><a href="#/osgi/bundle/{{row.entity.Identifier}}">{{row.getProperty(col.field)}}</a></div>'
            }, 
            {
                field: 'SymbolicName',
                displayName: 'Symbolic Name',
                width: "***",
                cellTemplate: '<div class="ngCellText"><a href="#/osgi/bundle/{{row.entity.Identifier}}">{{row.getProperty(col.field)}}</a></div>'
            }, 
            {
                field: 'Version',
                displayName: 'Version',
                width: "**"
            }, 
            {
                field: 'Location',
                displayName: 'Update Location',
                width: "***"
            }
        ];
        $scope.gridOptions = {
            data: 'bundles',
            showFilter: false,
            selectedItems: $scope.selected,
            selectWithCheckboxOnly: true,
            columnDefs: columnDefs,
            filterOptions: {
                filterText: ''
            }
        };
        $scope.onResponse = function () {
            jolokia.request({
                type: 'exec',
                mbean: Osgi.getSelectionBundleMBean(workspace),
                operation: 'listBundles()'
            }, {
                success: render,
                error: render
            });
        };
        $scope.controlBundles = function (op) {
            var startBundle = function (response) {
            };
            var ids = $scope.selected.map(function (b) {
                return b.Identifier;
            });
            if(!angular.isArray(ids)) {
                ids = [
                    ids
                ];
            }
            jolokia.request({
                type: 'exec',
                mbean: Osgi.getSelectionFrameworkMBean(workspace),
                operation: op,
                arguments: [
                    ids
                ]
            }, {
                success: $scope.onResponse,
                error: $scope.onResponse
            });
        };
        $scope.stop = function () {
            $scope.controlBundles('stopBundles([J)');
        };
        $scope.start = function () {
            $scope.controlBundles('startBundles([J)');
        };
        $scope.update = function () {
            $scope.controlBundles('updateBundles([J)');
        };
        $scope.refresh = function () {
            $scope.controlBundles('refreshBundles([J)');
        };
        $scope.uninstall = function () {
            $scope.controlBundles('uninstallBundles([J)');
        };
        $scope.install = function () {
            jolokia.request({
                type: 'exec',
                mbean: Osgi.getSelectionFrameworkMBean(workspace),
                operation: "installBundle(java.lang.String)",
                arguments: [
                    $scope.bundleUrl
                ]
            }, {
                success: function (response) {
                    console.log("Got: ", response);
                    $scope.bundleUrl = "";
                    jolokia.request({
                        type: 'exec',
                        mbean: Osgi.getSelectionFrameworkMBean(workspace),
                        operation: "startBundle(long)",
                        arguments: [
                            response.value
                        ]
                    }, {
                        success: $scope.onResponse,
                        error: $scope.onResponse
                    });
                },
                error: function (response) {
                    $scope.bundleUrl = "";
                    $scope.onResponse();
                }
            });
        };
        function render(response) {
            if(!Object.equal($scope.result, response.value)) {
                $scope.selected.length = 0;
                $scope.result = response.value;
                $scope.bundles = [];
                angular.forEach($scope.result, function (value, key) {
                    var obj = {
                        Identifier: value.Identifier,
                        Name: "",
                        SymbolicName: value.SymbolicName,
                        State: value.State,
                        Version: value.Version,
                        LastModified: value.LastModified,
                        Location: value.Location
                    };
                    if(value.Headers['Bundle-Name']) {
                        obj.Name = value.Headers['Bundle-Name']['Value'];
                    }
                    $scope.bundles.push(obj);
                });
                $scope.loading = false;
                $scope.$apply();
            }
        }
        Core.register(jolokia, $scope, {
            type: 'exec',
            mbean: Osgi.getSelectionBundleMBean(workspace),
            operation: 'listBundles()'
        }, onSuccess(render));
    }
    Osgi.BundlesController = BundlesController;
})(Osgi || (Osgi = {}));
var Osgi;
(function (Osgi) {
    function ConfigurationsController($scope, $filter, workspace, $templateCache, $compile) {
        var dateFilter = $filter('date');
        $scope.widget = new TableWidget($scope, workspace, [
            {
                "mDataProp": "PidLink"
            }
        ], {
            rowDetailTemplateId: 'configAdminPidTemplate',
            disableAddColumns: true
        });
        $scope.$on("$routeChangeSuccess", function (event, current, previous) {
            setTimeout(updateTableContents, 50);
        });
        $scope.$watch('workspace.selection', function () {
            updateTableContents();
        });
        function populateTable(response) {
            var configurations = Osgi.defaultConfigurationValues(workspace, $scope, response.value);
            $scope.widget.populateTable(configurations);
            $scope.$apply();
        }
        function updateTableContents() {
            var mbean = Osgi.getSelectionConfigAdminMBean(workspace);
            if(mbean) {
                var jolokia = workspace.jolokia;
                jolokia.request({
                    type: 'exec',
                    mbean: mbean,
                    operation: 'getConfigurations',
                    arguments: [
                        '(service.pid=*)'
                    ]
                }, onSuccess(populateTable));
            }
        }
    }
    Osgi.ConfigurationsController = ConfigurationsController;
})(Osgi || (Osgi = {}));
var Osgi;
(function (Osgi) {
    function defaultBundleValues(workspace, $scope, values) {
        var allValues = values;
        angular.forEach(values, function (row) {
            row["ImportData"] = parseActualPackages(row["ImportedPackages"]);
            row["ExportData"] = parseActualPackages(row["ExportedPackages"]);
            row["IdentifierLink"] = bundleLinks(workspace, row["Identifier"]);
            row["Hosts"] = labelBundleLinks(workspace, row["Hosts"], allValues);
            row["Fragments"] = labelBundleLinks(workspace, row["Fragments"], allValues);
            row["ImportedPackages"] = row["ImportedPackages"].union([]);
            row["StateStyle"] = getStateStyle("label", row["State"]);
            row["RequiringBundles"] = labelBundleLinks(workspace, row["RequiringBundles"], allValues);
        });
        return values;
    }
    Osgi.defaultBundleValues = defaultBundleValues;
    function getStateStyle(prefix, state) {
        switch(state) {
            case "INSTALLED": {
                return prefix + "-important";

            }
            case "RESOLVED": {
                return prefix + "-inverse";

            }
            case "STARTING": {
                return prefix + "-warning";

            }
            case "ACTIVE": {
                return prefix + "-success";

            }
            case "STOPPING": {
                return prefix + "-info";

            }
            case "UNINSTALLED": {
                return "";

            }
            default: {
                return prefix + "-important";

            }
        }
    }
    Osgi.getStateStyle = getStateStyle;
    function defaultServiceValues(workspace, $scope, values) {
        angular.forEach(values, function (row) {
            row["BundleIdentifier"] = bundleLinks(workspace, row["BundleIdentifier"]);
        });
        return values;
    }
    Osgi.defaultServiceValues = defaultServiceValues;
    function defaultPackageValues(workspace, $scope, values) {
        var packages = [];
        angular.forEach(values, function (row) {
            angular.forEach(row, function (version) {
                angular.forEach(version, function (packageEntry) {
                    var name = packageEntry["Name"];
                    var version = packageEntry["Version"];
                    if(!name.startsWith("#")) {
                        packageEntry["VersionLink"] = "<a href='" + url("#/osgi/package/" + name + "/" + version + workspace.hash()) + "'>" + version + "</a>";
                        packageEntry["ImportingBundleLinks"] = bundleLinks(workspace, row["ImportingBundles"]);
                        packageEntry["ImportingBundleLinks"] = bundleLinks(workspace, row["ImportingBundles"]);
                        packageEntry["ExportingBundleLinks"] = bundleLinks(workspace, row["ExportingBundles"]);
                        packages.push(packageEntry);
                    }
                });
            });
        });
        return packages;
    }
    Osgi.defaultPackageValues = defaultPackageValues;
    function defaultConfigurationValues(workspace, $scope, values) {
        var array = [];
        angular.forEach(values, function (row) {
            var map = {
            };
            map["Pid"] = row[0];
            map["PidLink"] = "<a href='" + url("#/osgi/pid/" + row[0] + workspace.hash()) + "'>" + row[0] + "</a>";
            map["Bundle"] = row[1];
            array.push(map);
        });
        return array;
    }
    Osgi.defaultConfigurationValues = defaultConfigurationValues;
    function parseActualPackages(packages) {
        var result = {
        };
        for(var i = 0; i < packages.length; i++) {
            var pkg = packages[i];
            var idx = pkg.indexOf(";");
            if(idx > 0) {
                var name = pkg.substring(0, idx);
                var ver = pkg.substring(idx + 1);
                var data = result[name];
                if(data === undefined) {
                    data = {
                    };
                    result[name] = data;
                }
                data["ReportedVersion"] = ver;
            }
        }
        return result;
    }
    Osgi.parseActualPackages = parseActualPackages;
    function parseManifestHeader(headers, name) {
        var result = {
        };
        var data = {
        };
        var hdr = headers[name];
        if(hdr === undefined) {
            return result;
        }
        var ephdr = hdr.Value;
        var inPkg = true;
        var inQuotes = false;
        var pkgName = "";
        var daDecl = "";
        for(var i = 0; i < ephdr.length; i++) {
            var c = ephdr[i];
            if(c === '"') {
                inQuotes = !inQuotes;
                continue;
            }
            if(inQuotes) {
                daDecl += c;
                continue;
            }
            if(c === ';') {
                if(inPkg) {
                    inPkg = false;
                } else {
                    handleDADecl(data, daDecl);
                    daDecl = "";
                }
                continue;
            }
            if(c === ',') {
                handleDADecl(data, daDecl);
                result[pkgName] = data;
                data = {
                };
                pkgName = "";
                daDecl = "";
                inPkg = true;
                continue;
            }
            if(inPkg) {
                pkgName += c;
            } else {
                daDecl += c;
            }
        }
        handleDADecl(data, daDecl);
        result[pkgName] = data;
        return result;
    }
    Osgi.parseManifestHeader = parseManifestHeader;
    function handleDADecl(data, daDecl) {
        var didx = daDecl.indexOf(":=");
        if(didx > 0) {
            data["D" + daDecl.substring(0, didx)] = daDecl.substring(didx + 2);
            return;
        }
        var aidx = daDecl.indexOf("=");
        if(aidx > 0) {
            data["A" + daDecl.substring(0, aidx)] = daDecl.substring(aidx + 1);
            return;
        }
    }
    function toCollection(values) {
        var collection = values;
        if(!angular.isArray(values)) {
            collection = [
                values
            ];
        }
        return collection;
    }
    Osgi.toCollection = toCollection;
    function labelBundleLinks(workspace, values, allValues) {
        var answer = "";
        var sorted = toCollection(values).sort(function (a, b) {
            return a - b;
        });
        angular.forEach(sorted, function (value, key) {
            var prefix = "";
            if(answer.length > 0) {
                prefix = " ";
            }
            var labelText = allValues[value].SymbolicName;
            answer += prefix + "<a class='label' href='" + url("#/osgi/bundle/" + value + workspace.hash()) + "'>" + labelText + "</a>";
        });
        return answer;
    }
    Osgi.labelBundleLinks = labelBundleLinks;
    function bundleLinks(workspace, values) {
        var answer = "";
        var sorted = toCollection(values).sort(function (a, b) {
            return a - b;
        });
        angular.forEach(sorted, function (value, key) {
            var prefix = "";
            if(answer.length > 0) {
                prefix = " ";
            }
            answer += prefix + "<a class='label' href='" + url("#/osgi/bundle/" + value + workspace.hash()) + "'>" + value + "</a>";
        });
        return answer;
    }
    Osgi.bundleLinks = bundleLinks;
    function pidLinks(workspace, values) {
        var answer = "";
        angular.forEach(toCollection(values), function (value, key) {
            var prefix = "";
            if(answer.length > 0) {
                prefix = " ";
            }
            answer += prefix + "<a href='" + url("#/osgi/bundle/" + value + workspace.hash()) + "'>" + value + "</a>";
        });
        return answer;
    }
    Osgi.pidLinks = pidLinks;
    function findBundle(bundleId, values) {
        var answer = "";
        angular.forEach(values, function (row) {
            var id = row["Identifier"];
            if(bundleId === id.toString()) {
                answer = row;
                return answer;
            }
        });
        return answer;
    }
    Osgi.findBundle = findBundle;
    function getSelectionBundleMBean(workspace) {
        if(workspace) {
            var folder = workspace.tree.navigate("osgi.core", "bundleState");
            return Osgi.findFirstObjectName(folder);
        }
        return null;
    }
    Osgi.getSelectionBundleMBean = getSelectionBundleMBean;
    function findFirstObjectName(node) {
        if(node) {
            var answer = node.objectName;
            if(answer) {
                return answer;
            } else {
                var children = node.children;
                if(children && children.length) {
                    return findFirstObjectName(children[0]);
                }
            }
        }
        return null;
    }
    Osgi.findFirstObjectName = findFirstObjectName;
    function getSelectionFrameworkMBean(workspace) {
        if(workspace) {
            var folder = workspace.tree.navigate("osgi.core", "framework");
            return Osgi.findFirstObjectName(folder);
        }
        return null;
    }
    Osgi.getSelectionFrameworkMBean = getSelectionFrameworkMBean;
    function getSelectionServiceMBean(workspace) {
        if(workspace) {
            var folder = workspace.tree.navigate("osgi.core", "serviceState");
            return Osgi.findFirstObjectName(folder);
        }
        return null;
    }
    Osgi.getSelectionServiceMBean = getSelectionServiceMBean;
    function getSelectionPackageMBean(workspace) {
        if(workspace) {
            var folder = workspace.tree.navigate("osgi.core", "packageState");
            return Osgi.findFirstObjectName(folder);
        }
        return null;
    }
    Osgi.getSelectionPackageMBean = getSelectionPackageMBean;
    function getSelectionConfigAdminMBean(workspace) {
        if(workspace) {
            var folder = workspace.tree.navigate("osgi.compendium", "cm");
            return Osgi.findFirstObjectName(folder);
        }
        return null;
    }
    Osgi.getSelectionConfigAdminMBean = getSelectionConfigAdminMBean;
    function getHawtioOSGiMBean(workspace) {
        if(workspace) {
            var mbeanTypesToDomain = workspace.mbeanTypesToDomain || {
            };
            var gitFacades = mbeanTypesToDomain["OSGiTools"] || {
            };
            var hawtioFolder = gitFacades["io.hawt.osgi"] || {
            };
            return hawtioFolder["objectName"];
        }
        return null;
    }
    Osgi.getHawtioOSGiMBean = getHawtioOSGiMBean;
})(Osgi || (Osgi = {}));
var Osgi;
(function (Osgi) {
    var pluginName = 'osgi';
    angular.module(pluginName, [
        'bootstrap', 
        'ngResource', 
        'ngGrid', 
        'hawtioCore'
    ]).config(function ($routeProvider) {
        $routeProvider.when('/osgi/bundle-list', {
            templateUrl: 'app/osgi/html/bundle-list.html'
        }).when('/osgi/bundles', {
            templateUrl: 'app/osgi/html/bundles.html'
        }).when('/osgi/bundle/:bundleId', {
            templateUrl: 'app/osgi/html/bundle.html'
        }).when('/osgi/services', {
            templateUrl: 'app/osgi/html/services.html'
        }).when('/osgi/packages', {
            templateUrl: 'app/osgi/html/packages.html'
        }).when('/osgi/package/:package/:version', {
            templateUrl: 'app/osgi/html/package.html'
        }).when('/osgi/configurations', {
            templateUrl: 'app/osgi/html/configurations.html'
        }).when('/osgi/pid/:pid', {
            templateUrl: 'app/osgi/html/pid.html'
        });
    }).run(function (workspace, viewRegistry) {
        viewRegistry['osgi'] = "app/osgi/html/layoutOsgi.html";
        workspace.topLevelTabs.push({
            content: "OSGi",
            title: "Visualise and manage the bundles and services in this OSGi container",
            isValid: function (workspace) {
                return workspace.treeContainsDomainAndProperties("osgi.core");
            },
            href: function () {
                return "#/osgi/bundle-list";
            },
            isActive: function (workspace) {
                return workspace.isLinkActive("osgi");
            }
        });
    });
    hawtioPluginLoader.addModule(pluginName);
})(Osgi || (Osgi = {}));
var Osgi;
(function (Osgi) {
    function PackageController($scope, $filter, workspace, $routeParams) {
        $scope.package = $routeParams.package;
        $scope.version = $routeParams.version;
        updateTableContents();
        function populateTable(response) {
            var packages = Osgi.defaultPackageValues(workspace, $scope, response.value);
            $scope.row = packages.filter({
                "Name": $scope.package,
                "Version": $scope.version
            })[0];
            $scope.$apply();
        }
        ; ;
        function updateTableContents() {
            var mbean = Osgi.getSelectionPackageMBean(workspace);
            if(mbean) {
                var jolokia = workspace.jolokia;
                jolokia.request({
                    type: 'exec',
                    mbean: mbean,
                    operation: 'listPackages'
                }, onSuccess(populateTable));
            }
        }
    }
    Osgi.PackageController = PackageController;
})(Osgi || (Osgi = {}));
var Osgi;
(function (Osgi) {
    function PackagesController($scope, $filter, workspace, $templateCache, $compile) {
        var dateFilter = $filter('date');
        $scope.widget = new TableWidget($scope, workspace, [
            {
                "mDataProp": null,
                "sClass": "control center",
                "sDefaultContent": '<i class="icon-plus"></i>'
            }, 
            {
                "mDataProp": "Name"
            }, 
            {
                "mDataProp": "VersionLink"
            }, 
            {
                "mDataProp": "RemovalPending"
            }
        ], {
            rowDetailTemplateId: 'packageBundlesTemplate',
            disableAddColumns: true
        });
        $scope.$watch('workspace.selection', function () {
            updateTableContents();
        });
        function populateTable(response) {
            var packages = Osgi.defaultPackageValues(workspace, $scope, response.value);
            $scope.widget.populateTable(packages);
            $scope.$apply();
        }
        function updateTableContents() {
            var mbean = Osgi.getSelectionPackageMBean(workspace);
            if(mbean) {
                var jolokia = workspace.jolokia;
                jolokia.request({
                    type: 'exec',
                    mbean: mbean,
                    operation: 'listPackages'
                }, onSuccess(populateTable));
            }
        }
    }
    Osgi.PackagesController = PackagesController;
})(Osgi || (Osgi = {}));
var Osgi;
(function (Osgi) {
    function PidController($scope, $filter, workspace, $routeParams) {
        $scope.pid = $routeParams.pid;
        updateTableContents();
        function populateTable(response) {
            $scope.row = response.value;
            $scope.$apply();
        }
        ; ;
        function updateTableContents() {
            var mbean = Osgi.getSelectionConfigAdminMBean(workspace);
            if(mbean) {
                var jolokia = workspace.jolokia;
                jolokia.request({
                    type: 'exec',
                    mbean: mbean,
                    operation: 'getProperties',
                    arguments: [
                        $scope.pid
                    ]
                }, onSuccess(populateTable));
            }
        }
    }
    Osgi.PidController = PidController;
})(Osgi || (Osgi = {}));
var Osgi;
(function (Osgi) {
    function ServiceController($scope, $filter, workspace, $templateCache, $compile) {
        var dateFilter = $filter('date');
        $scope.widget = new TableWidget($scope, workspace, [
            {
                "mDataProp": null,
                "sClass": "control center",
                "sDefaultContent": '<i class="icon-plus"></i>'
            }, 
            {
                "mDataProp": "Identifier"
            }, 
            {
                "mDataProp": "BundleIdentifier"
            }, 
            {
                "mDataProp": "objectClass"
            }
        ], {
            rowDetailTemplateId: 'osgiServiceTemplate',
            disableAddColumns: true
        });
        $scope.$watch('workspace.selection', function () {
            var mbean = Osgi.getSelectionServiceMBean(workspace);
            if(mbean) {
                var jolokia = workspace.jolokia;
                jolokia.request({
                    type: 'exec',
                    mbean: mbean,
                    operation: 'listServices()'
                }, onSuccess(populateTable));
            }
        });
        var populateTable = function (response) {
            Osgi.defaultServiceValues(workspace, $scope, response.value);
            $scope.widget.populateTable(response.value);
            $scope.$apply();
        };
    }
    Osgi.ServiceController = ServiceController;
})(Osgi || (Osgi = {}));
; ;
var Source;
(function (Source) {
    function getInsightMBean(workspace) {
        var mavenStuff = workspace.mbeanTypesToDomain["LogQuery"] || {
        };
        var insight = mavenStuff["org.fusesource.insight"] || {
        };
        var mbean = insight.objectName;
        return mbean;
    }
    Source.getInsightMBean = getInsightMBean;
    function createBreadcrumbLinks(mavenCoords, pathName) {
        var linkPrefix = "#/source/index/" + mavenCoords;
        var answer = [
            {
                href: linkPrefix,
                name: "/"
            }
        ];
        if(pathName) {
            var pathNames = pathName.split("/");
            var fullPath = "";
            angular.forEach(pathNames, function (path) {
                fullPath += "/" + path;
                var href = linkPrefix + fullPath;
                answer.push({
                    href: href,
                    name: path || "/",
                    fileName: "/" + fullPath
                });
            });
        }
        return answer;
    }
    Source.createBreadcrumbLinks = createBreadcrumbLinks;
})(Source || (Source = {}));
var Source;
(function (Source) {
    function IndexController($scope, $location, $routeParams, workspace, jolokia) {
        $scope.pageId = Wiki.pageId($routeParams, $location);
        $scope.mavenCoords = $routeParams["mavenCoords"];
        var fileName = $scope.pageId;
        $scope.loadingMessage = "Loading source code from artifacts <b>" + $scope.mavenCoords + "</b>";
        createBreadcrumbs();
        $scope.setFileName = function (breadcrumb) {
            fileName = Core.trimLeading(breadcrumb.fileName, "/");
            fileName = Core.trimLeading(fileName, "/");
            console.log("selected fileName '" + fileName + "'");
            createBreadcrumbs();
            filterFileNames();
        };
        $scope.$watch('workspace.tree', function () {
            if(!$scope.git && Git.getGitMBean(workspace)) {
                setTimeout(updateView, 50);
            }
        });
        $scope.$on("$routeChangeSuccess", function (event, current, previous) {
            setTimeout(updateView, 50);
        });
        function filterFileNames() {
            if(fileName) {
                $scope.sourceFiles = $scope.allSourceFiles.filter(function (n) {
                    return n && n.startsWith(fileName);
                }).map(function (n) {
                    return n.substring(fileName.length + 1);
                }).filter(function (n) {
                    return n;
                });
            } else {
                $scope.sourceFiles = $scope.allSourceFiles;
            }
        }
        $scope.sourceLinks = function (aFile) {
            var name = aFile;
            var paths = null;
            var idx = aFile.lastIndexOf('/');
            if(idx > 0) {
                name = aFile.substring(idx + 1);
                paths = aFile.substring(0, idx);
            }
            var answer = "";
            var fullName = fileName || "";
            if(paths) {
                angular.forEach(paths.split("/"), function (path) {
                    if(fullName) {
                        fullName += "/";
                    }
                    fullName += path;
                    answer += "<a href='#/source/index/" + $scope.mavenCoords + "/" + fullName + "'>" + path + "</a>/";
                });
            }
            answer += "<a href='#/source/view/" + $scope.mavenCoords + "/" + fullName + "/" + name + "'>" + name + "</a>";
            return answer;
        };
        function createBreadcrumbs() {
            $scope.breadcrumbs = Source.createBreadcrumbLinks($scope.mavenCoords, fileName);
            angular.forEach($scope.breadcrumbs, function (breadcrumb) {
                breadcrumb.active = false;
            });
            $scope.breadcrumbs.last().active = true;
        }
        function viewContents(response) {
            if(response) {
                $scope.allSourceFiles = response.split("\n").map(function (n) {
                    return n.trim();
                }).filter(function (n) {
                    return n;
                });
            } else {
                $scope.allSourceFiles = [];
            }
            filterFileNames();
            $scope.loadingMessage = null;
            if(!response) {
                var time = new Date().getTime();
                if(!$scope.lastErrorTime || time - $scope.lastErrorTime > 3000) {
                    $scope.lastErrorTime = time;
                    notification("error", "Could not download the source code for the maven artifacts: " + $scope.mavenCoords);
                }
            }
            Core.$apply($scope);
        }
        function updateView() {
            var mbean = Source.getInsightMBean(workspace);
            if(mbean) {
                jolokia.execute(mbean, "getSource", $scope.mavenCoords, null, "/", onSuccess(viewContents));
            }
        }
    }
    Source.IndexController = IndexController;
})(Source || (Source = {}));
var Source;
(function (Source) {
    function JavaDocController($scope, $location, $routeParams, workspace, fileExtensionTypeRegistry, jolokia) {
        $scope.pageId = Wiki.pageId($routeParams, $location);
        var mavenCoords = $routeParams["mavenCoords"];
        var fileName = $scope.pageId;
        $scope.loadingMessage = "Loading javadoc code for file <b>" + fileName + "</b> from artifacts <b>" + mavenCoords + "</b>";
        $scope.breadcrumbs = [];
        $scope.$watch('workspace.tree', function () {
            if(!$scope.git && Git.getGitMBean(workspace)) {
                setTimeout(updateView, 50);
            }
        });
        $scope.$on("$routeChangeSuccess", function (event, current, previous) {
            setTimeout(updateView, 50);
        });
        function viewContents(response) {
            $scope.source = response;
            $scope.loadingMessage = null;
            if(!response) {
                var time = new Date().getTime();
                if(!$scope.lastErrorTime || time - $scope.lastErrorTime > 3000) {
                    $scope.lastErrorTime = time;
                    notification("error", "Could not download the source code for the maven artifacts: " + mavenCoords);
                }
            }
            Core.$apply($scope);
        }
        function updateView() {
            var mbean = Source.getInsightMBean(workspace);
            if(mbean) {
                jolokia.execute(mbean, "getJavaDoc", mavenCoords, fileName, onSuccess(viewContents));
            }
        }
    }
    Source.JavaDocController = JavaDocController;
})(Source || (Source = {}));
var Source;
(function (Source) {
    function SourceController($scope, $location, $routeParams, workspace, fileExtensionTypeRegistry, jolokia) {
        $scope.pageId = Wiki.pageId($routeParams, $location);
        $scope.format = Wiki.fileFormat($scope.pageId, fileExtensionTypeRegistry);
        var lineNumber = $location.search()["line"] || 1;
        var mavenCoords = $routeParams["mavenCoords"];
        var className = $routeParams["className"] || "";
        var fileName = $scope.pageId || "/";
        var classNamePath = className.replace(/\./g, '/');
        $scope.loadingMessage = "Loading source code for class <b>" + className + "</b> from artifacts <b>" + mavenCoords + "</b>";
        $scope.breadcrumbs = [];
        var idx = fileName.lastIndexOf('/');
        var path = "/";
        var name = fileName;
        if(idx > 0) {
            path = fileName.substring(0, idx);
            name = fileName.substring(idx + 1);
        } else {
            if(className && className.indexOf('.') > 0) {
                path = classNamePath;
                idx = path.lastIndexOf('/');
                if(idx > 0) {
                    name = path.substring(idx + 1);
                    path = path.substring(0, idx);
                }
            }
        }
        $scope.breadcrumbs = Source.createBreadcrumbLinks(mavenCoords, path);
        $scope.breadcrumbs.push({
            href: $location.url(),
            name: name,
            active: true
        });
        $scope.javaDocLink = function () {
            var path = classNamePath;
            if(!path && fileName && fileName.endsWith(".java")) {
                path = fileName.substring(0, fileName.length - 5);
            }
            if(path) {
                return "javadoc/" + mavenCoords + "/" + path + ".html";
            }
            return null;
        };
        var options = {
            readOnly: true,
            mode: $scope.format,
            lineNumbers: true,
            onChange: function (codeMirror) {
                if(codeMirror) {
                    if(!$scope.codeMirror) {
                        lineNumber -= 1;
                        var lineText = codeMirror.getLine(lineNumber);
                        var endChar = (lineText) ? lineText.length : 1000;
                        var start = {
                            line: lineNumber,
                            ch: 0
                        };
                        var end = {
                            line: lineNumber,
                            ch: endChar
                        };
                        codeMirror.scrollIntoView(start);
                        codeMirror.setCursor(start);
                        codeMirror.setSelection(start, end);
                        codeMirror.refresh();
                        codeMirror.focus();
                    }
                    $scope.codeMirror = codeMirror;
                }
            }
        };
        $scope.codeMirrorOptions = CodeEditor.createEditorSettings(options);
        $scope.$watch('workspace.tree', function () {
            if(!$scope.git && Git.getGitMBean(workspace)) {
                setTimeout(updateView, 50);
            }
        });
        $scope.$on("$routeChangeSuccess", function (event, current, previous) {
            setTimeout(updateView, 50);
        });
        function viewContents(response) {
            $scope.source = response;
            $scope.loadingMessage = null;
            if(!response) {
                var time = new Date().getTime();
                if(!$scope.lastErrorTime || time - $scope.lastErrorTime > 3000) {
                    $scope.lastErrorTime = time;
                    notification("error", "Could not download the source code for the maven artifacts: " + mavenCoords);
                }
            }
            Core.$apply($scope);
        }
        function updateView() {
            var mbean = Source.getInsightMBean(workspace);
            if(mbean) {
                jolokia.execute(mbean, "getSource", mavenCoords, className, fileName, onSuccess(viewContents));
            }
        }
    }
    Source.SourceController = SourceController;
})(Source || (Source = {}));
var Source;
(function (Source) {
    var pluginName = 'source';
    angular.module(pluginName, [
        'bootstrap', 
        'ngResource', 
        'hawtioCore', 
        'wiki'
    ]).config(function ($routeProvider) {
        $routeProvider.when('/source/index/:mavenCoords', {
            templateUrl: 'app/source/html/index.html'
        }).when('/source/index/:mavenCoords/*page', {
            templateUrl: 'app/source/html/index.html'
        }).when('/source/view/:mavenCoords/class/:className/*page', {
            templateUrl: 'app/source/html/source.html'
        }).when('/source/view/:mavenCoords/*page', {
            templateUrl: 'app/source/html/source.html'
        }).when('/source/javadoc/:mavenCoords/*page', {
            templateUrl: 'app/source/html/javadoc.html'
        });
    }).run(function ($location, workspace, viewRegistry, jolokia, localStorage, layoutFull) {
        viewRegistry['source'] = layoutFull;
    });
    hawtioPluginLoader.addModule(pluginName);
})(Source || (Source = {}));
var Tomcat;
(function (Tomcat) {
    function ConnectorsController($scope, $location, workspace, jolokia) {
        var stateTemplate = '<div class="ngCellText pagination-centered" title="{{row.getProperty(col.field)}}"><i class="{{row.getProperty(col.field) | tomcatIconClass}}"></i></div>';
        $scope.connectors = [];
        $scope.selected = [];
        var columnDefs = [
            {
                field: 'stateName',
                displayName: 'State',
                cellTemplate: stateTemplate,
                width: 56,
                minWidth: 56,
                maxWidth: 56,
                resizable: false
            }, 
            {
                field: 'port',
                displayName: 'Port',
                cellFilter: null,
                width: "*",
                resizable: true
            }, 
            {
                field: 'scheme',
                displayName: 'Scheme',
                cellFilter: null,
                width: "*",
                resizable: true
            }, 
            {
                field: 'protocol',
                displayName: 'Protocol',
                cellFilter: null,
                width: "*",
                resizable: true
            }, 
            {
                field: 'secure',
                displayName: 'Secure',
                cellFilter: null,
                width: "*",
                resizable: true
            }, 
            {
                field: 'connectionLinger',
                displayName: 'Connection Linger',
                cellFilter: null,
                width: "*",
                resizable: true
            }, 
            {
                field: 'connectionTimeout',
                displayName: 'Connection Timeout',
                cellFilter: null,
                width: "*",
                resizable: true
            }, 
            {
                field: 'keepAliveTimeout',
                displayName: 'Keep Alive Timeout',
                cellFilter: null,
                width: "*",
                resizable: true
            }, 
            {
                field: 'minSpareThreads',
                displayName: 'Minimum Threads',
                cellFilter: null,
                width: "*",
                resizable: true
            }, 
            {
                field: 'maxThreads',
                displayName: 'Maximum Threads',
                cellFilter: null,
                width: "*",
                resizable: true
            }, 
            
        ];
        $scope.gridOptions = {
            data: 'connectors',
            displayFooter: true,
            selectedItems: $scope.selected,
            selectWithCheckboxOnly: true,
            columnDefs: columnDefs,
            filterOptions: {
                filterText: ''
            }
        };
        function render(response) {
            response = Tomcat.filerTomcatOrCatalina(response);
            $scope.connectors = [];
            $scope.selected.length = 0;
            function onAttributes(response) {
                var obj = response.value;
                if(obj) {
                    obj.mbean = response.request.mbean;
                    $scope.connectors.push(obj);
                    Core.$apply($scope);
                }
            }
            angular.forEach(response, function (value, key) {
                var mbean = value;
                jolokia.request({
                    type: "read",
                    mbean: mbean,
                    attribute: [
                        "scheme", 
                        "port", 
                        "protocol", 
                        "secure", 
                        "connectionLinger", 
                        "connectionTimeout", 
                        "keepAliveTimeout", 
                        "minSpareThreads", 
                        "maxThreads", 
                        "stateName"
                    ]
                }, onSuccess(onAttributes));
            });
            Core.$apply($scope);
        }
        ; ;
        $scope.controlConnector = function (op) {
            var ids = $scope.selected.map(function (b) {
                return b.mbean;
            });
            if(!angular.isArray(ids)) {
                ids = [
                    ids
                ];
            }
            ids.forEach(function (id) {
                jolokia.request({
                    type: 'exec',
                    mbean: id,
                    operation: op,
                    arguments: null
                }, onSuccess($scope.onResponse, {
                    error: $scope.onResponse
                }));
            });
        };
        $scope.stop = function () {
            $scope.controlConnector('stop');
        };
        $scope.start = function () {
            $scope.controlConnector('start');
        };
        $scope.destroy = function () {
            $scope.controlConnector('destroy');
        };
        $scope.onResponse = function (response) {
            loadData();
        };
        $scope.$on('jmxTreeUpdated', reloadFunction);
        $scope.$watch('workspace.tree', reloadFunction);
        function reloadFunction() {
            setTimeout(loadData, 50);
        }
        function loadData() {
            console.log("Loading tomcat connector data...");
            jolokia.search("Catalina:type=Connector,*", onSuccess(render));
        }
    }
    Tomcat.ConnectorsController = ConnectorsController;
})(Tomcat || (Tomcat = {}));
var Tomcat;
(function (Tomcat) {
    function filerTomcatOrCatalina(response) {
        if(response) {
            response = response.filter(function (name) {
                return name.startsWith("Catalina") || name.startsWith("Tomcat");
            });
        }
        return response;
    }
    Tomcat.filerTomcatOrCatalina = filerTomcatOrCatalina;
    ; ;
    function iconClass(state) {
        if(state) {
            switch(state.toString().toLowerCase()) {
                case '1': {
                    return "green icon-play-circle";

                }
                case 'started': {
                    return "green icon-play-circle";

                }
                case '0': {
                    return "orange icon-off";

                }
                case 'stopped': {
                    return "orange icon-off";

                }
            }
        }
        if(angular.isNumber(state)) {
            if(state.toString() === '0') {
                return "orange icon-off";
            }
        }
        return "icon-question-sign";
    }
    Tomcat.iconClass = iconClass;
    function millisToDateFormat(time) {
        if(time) {
            var date = new Date(time);
            return date.toLocaleDateString() + " " + date.toLocaleTimeString();
        } else {
            return "";
        }
    }
    Tomcat.millisToDateFormat = millisToDateFormat;
    function isTomcat5(name) {
        return name.toString().indexOf("Apache Tomcat/5") !== -1;
    }
    Tomcat.isTomcat5 = isTomcat5;
    function isTomcat6(name) {
        return name.toString().indexOf("Apache Tomcat/6") !== -1;
    }
    Tomcat.isTomcat6 = isTomcat6;
})(Tomcat || (Tomcat = {}));
var Tomcat;
(function (Tomcat) {
    function SessionsController($scope, $location, workspace, jolokia) {
        var stateTemplate = '<div class="ngCellText pagination-centered" title="{{row.getProperty(col.field)}}"><i class="{{row.getProperty(col.field) | tomcatIconClass}}"></i></div>';
        $scope.sessions = [];
        $scope.search = "";
        var columnDefs = [
            {
                field: 'stateName',
                displayName: 'State',
                cellTemplate: stateTemplate,
                width: 56,
                minWidth: 56,
                maxWidth: 56,
                resizable: false
            }, 
            {
                field: 'path',
                displayName: 'Context-Path',
                cellFilter: null,
                width: "*",
                resizable: true
            }, 
            {
                field: 'activeSessions',
                displayName: 'Active Sessions',
                cellFilter: null,
                width: "*",
                resizable: true
            }, 
            {
                field: 'expiredSessions',
                displayName: 'Expired Sessions',
                cellFilter: null,
                width: "*",
                resizable: true
            }, 
            {
                field: 'rejectedSessions',
                displayName: 'Rejected Sessions',
                cellFilter: null,
                width: "*",
                resizable: true
            }, 
            {
                field: 'maxActive',
                displayName: 'Max Active Sessions',
                cellFilter: null,
                width: "*",
                resizable: true
            }, 
            {
                field: 'maxActiveSessions',
                displayName: 'Max Active Sessions Allowed',
                cellFilter: null,
                width: "*",
                resizable: true
            }, 
            {
                field: 'maxInactiveInterval',
                displayName: 'Max Inactive Interval',
                cellFilter: null,
                width: "*",
                resizable: true
            }, 
            {
                field: 'sessionCounter',
                displayName: 'Session Counter',
                cellFilter: null,
                width: "*",
                resizable: true
            }, 
            {
                field: 'sessionCreateRate',
                displayName: 'Session Create Rate',
                cellFilter: null,
                width: "*",
                resizable: true
            }, 
            {
                field: 'sessionExpireRate',
                displayName: 'Session Expire Rate',
                cellFilter: null,
                width: "*",
                resizable: true
            }
        ];
        $scope.gridOptions = {
            data: 'sessions',
            displayFooter: false,
            displaySelectionCheckbox: false,
            canSelectRows: false,
            columnDefs: columnDefs,
            filterOptions: {
                filterText: ''
            }
        };
        function render(response) {
            response = Tomcat.filerTomcatOrCatalina(response);
            $scope.sessions = [];
            function onAttributes(response) {
                var obj = response.value;
                if(obj) {
                    obj.mbean = response.request.mbean;
                    var mbean = obj.mbean;
                    if(mbean) {
                        var context = mbean.toString().split(",")[1];
                        if(context) {
                            if(context.toString().indexOf("path=") !== -1) {
                                obj.path = context.toString().substr(5);
                            } else {
                                obj.path = context.toString().substr(9);
                            }
                        } else {
                            obj.path = "";
                        }
                        $scope.sessions.push(obj);
                        Core.$apply($scope);
                    }
                }
            }
            angular.forEach(response, function (value, key) {
                var mbean = value;
                jolokia.request({
                    type: "read",
                    mbean: mbean
                }, onSuccess(onAttributes));
            });
            Core.$apply($scope);
        }
        ; ;
        $scope.$on('jmxTreeUpdated', reloadFunction);
        $scope.$watch('workspace.tree', reloadFunction);
        function reloadFunction() {
            setTimeout(loadData, 50);
        }
        function loadData() {
            console.log("Loading tomcat session data...");
            jolokia.search("*:type=Manager,*", onSuccess(render));
        }
    }
    Tomcat.SessionsController = SessionsController;
})(Tomcat || (Tomcat = {}));
var Tomcat;
(function (Tomcat) {
    function TomcatController($scope, $location, workspace, jolokia) {
        var stateTemplate = '<div class="ngCellText pagination-centered" title="{{row.getProperty(col.field)}}"><i class="{{row.getProperty(col.field) | tomcatIconClass}}"></i></div>';
        $scope.uninstallDialog = new Core.Dialog();
        $scope.webapps = [];
        $scope.selected = [];
        var columnDefsTomcat5 = [
            {
                field: 'state',
                displayName: 'State',
                cellTemplate: stateTemplate,
                width: 56,
                minWidth: 56,
                maxWidth: 56,
                resizable: false
            }, 
            {
                field: 'path',
                displayName: 'Context-Path',
                cellFilter: null,
                width: "*",
                resizable: true
            }, 
            {
                field: 'startTime',
                displayName: 'Start Time',
                cellFilter: null,
                width: "*",
                resizable: true
            }
        ];
        var columnDefsTomcat6 = [
            {
                field: 'stateName',
                displayName: 'State',
                cellTemplate: stateTemplate,
                width: 56,
                minWidth: 56,
                maxWidth: 56,
                resizable: false
            }, 
            {
                field: 'path',
                displayName: 'Context-Path',
                cellFilter: null,
                width: "*",
                resizable: true
            }, 
            {
                field: 'startTime',
                displayName: 'Start Time',
                cellFilter: null,
                width: "*",
                resizable: true
            }
        ];
        var columnDefsTomcat7 = [
            {
                field: 'stateName',
                displayName: 'State',
                cellTemplate: stateTemplate,
                width: 56,
                minWidth: 56,
                maxWidth: 56,
                resizable: false
            }, 
            {
                field: 'path',
                displayName: 'Context-Path',
                cellFilter: null,
                width: "*",
                resizable: true
            }, 
            {
                field: 'displayName',
                displayName: 'Display Name',
                cellFilter: null,
                width: "*",
                resizable: true
            }, 
            {
                field: 'startTime',
                displayName: 'Start Time',
                cellFilter: null,
                width: "*",
                resizable: true
            }
        ];
        $scope.gridOptions = {
            data: 'webapps',
            displayFooter: true,
            selectedItems: $scope.selected,
            selectWithCheckboxOnly: true,
            filterOptions: {
                filterText: ''
            }
        };
        function render(response) {
            response = Tomcat.filerTomcatOrCatalina(response);
            $scope.webapps = [];
            $scope.mbeanIndex = {
            };
            $scope.selected.length = 0;
            function onAttributes(response) {
                var obj = response.value;
                if(obj) {
                    obj.mbean = response.request.mbean;
                    var mbean = obj.mbean;
                    if(mbean) {
                        obj.startTime = Tomcat.millisToDateFormat(obj.startTime);
                        var idx = $scope.mbeanIndex[mbean];
                        if(angular.isDefined(idx)) {
                            $scope.webapps[mbean] = obj;
                        } else {
                            $scope.mbeanIndex[mbean] = $scope.webapps.length;
                            $scope.webapps.push(obj);
                        }
                        Core.$apply($scope);
                    }
                }
            }
            angular.forEach(response, function (value, key) {
                var mbean = value;
                if(Tomcat.isTomcat5($scope.tomcatServerVersion)) {
                    jolokia.request({
                        type: "read",
                        mbean: mbean,
                        attribute: [
                            "path", 
                            "state", 
                            "startTime"
                        ]
                    }, onSuccess(onAttributes));
                } else {
                    if(Tomcat.isTomcat6($scope.tomcatServerVersion)) {
                        jolokia.request({
                            type: "read",
                            mbean: mbean,
                            attribute: [
                                "path", 
                                "stateName", 
                                "startTime"
                            ]
                        }, onSuccess(onAttributes));
                    } else {
                        jolokia.request({
                            type: "read",
                            mbean: mbean,
                            attribute: [
                                "displayName", 
                                "path", 
                                "stateName", 
                                "startTime"
                            ]
                        }, onSuccess(onAttributes));
                    }
                }
            });
            Core.$apply($scope);
        }
        ; ;
        $scope.controlWebApps = function (op) {
            var mbeanNames = $scope.selected.map(function (b) {
                return b.mbean;
            });
            if(!angular.isArray(mbeanNames)) {
                mbeanNames = [
                    mbeanNames
                ];
            }
            var lastIndex = (mbeanNames.length || 1) - 1;
            angular.forEach(mbeanNames, function (mbean, idx) {
                var onResponse = (idx >= lastIndex) ? $scope.onLastResponse : $scope.onResponse;
                jolokia.request({
                    type: 'exec',
                    mbean: mbean,
                    operation: op,
                    arguments: null
                }, onSuccess(onResponse, {
                    error: onResponse
                }));
            });
        };
        $scope.stop = function () {
            $scope.controlWebApps('stop');
        };
        $scope.start = function () {
            $scope.controlWebApps('start');
        };
        $scope.reload = function () {
            $scope.controlWebApps('reload');
        };
        $scope.uninstall = function () {
            $scope.controlWebApps('destroy');
            $scope.uninstallDialog.close();
        };
        $scope.onLastResponse = function (response) {
            $scope.onResponse(response);
            loadData();
        };
        $scope.onResponse = function (response) {
        };
        $scope.$on('jmxTreeUpdated', reloadFunction);
        $scope.$watch('workspace.tree', reloadFunction);
        function reloadFunction() {
            setTimeout(loadData, 50);
        }
        function loadData() {
            console.log("Loading tomcat webapp data...");
            jolokia.search("*:j2eeType=WebModule,*", onSuccess(render));
        }
        $scope.tomcatServerVersion = "";
        var servers = jolokia.search("*:type=Server");
        servers = Tomcat.filerTomcatOrCatalina(servers);
        if(servers && servers.length === 1) {
            $scope.tomcatServerVersion = jolokia.getAttribute(servers[0], "serverInfo");
        } else {
            console.log("Cannot find Tomcat server or there was more than one server. response is: " + servers);
        }
        if(Tomcat.isTomcat5($scope.tomcatServerVersion)) {
            console.log("Using Tomcat 5");
            $scope.gridOptions.columnDefs = columnDefsTomcat5;
        } else {
            if(Tomcat.isTomcat6($scope.tomcatServerVersion)) {
                console.log("Using Tomcat 6");
                $scope.gridOptions.columnDefs = columnDefsTomcat6;
            } else {
                console.log("Using Tomcat 7");
                $scope.gridOptions.columnDefs = columnDefsTomcat7;
            }
        }
    }
    Tomcat.TomcatController = TomcatController;
})(Tomcat || (Tomcat = {}));
var Tomcat;
(function (Tomcat) {
    var pluginName = 'tomcat';
    angular.module(pluginName, [
        'bootstrap', 
        'ngResource', 
        'ui.bootstrap.dialog', 
        'hawtioCore'
    ]).config(function ($routeProvider) {
        $routeProvider.when('/tomcat/server', {
            templateUrl: 'app/tomcat/html/server.html'
        }).when('/tomcat/applications', {
            templateUrl: 'app/tomcat/html/applications.html'
        }).when('/tomcat/connectors', {
            templateUrl: 'app/tomcat/html/connectors.html'
        }).when('/tomcat/sessions', {
            templateUrl: 'app/tomcat/html/sessions.html'
        }).when('/tomcat/mbeans', {
            templateUrl: 'app/tomcat/html/mbeans.html'
        });
    }).filter('tomcatIconClass', function () {
        return Tomcat.iconClass;
    }).run(function ($location, workspace, viewRegistry, layoutFull) {
        viewRegistry['tomcat'] = "app/tomcat/html/layoutTomcatTabs.html";
        viewRegistry['tomcatTree'] = "app/tomcat/html/layoutTomcatTree.html";
        workspace.topLevelTabs.push({
            content: "Tomcat",
            title: "Manage your Tomcat container",
            isValid: function (workspace) {
                return workspace.treeContainsDomainAndProperties("Tomcat") || workspace.treeContainsDomainAndProperties("Catalina");
            },
            href: function () {
                return "#/tomcat/applications";
            },
            isActive: function (workspace) {
                return workspace.isTopTabActive("tomcat");
            }
        });
    });
    hawtioPluginLoader.addModule(pluginName);
})(Tomcat || (Tomcat = {}));
var Tomcat;
(function (Tomcat) {
    function TreeController($scope, $location, workspace) {
        $scope.$on("$routeChangeSuccess", function (event, current, previous) {
            setTimeout(updateSelectionFromURL, 50);
        });
        $scope.$watch('workspace.tree', function () {
            console.log("workspace tree has changed, lets reload!!");
            if(workspace.moveIfViewInvalid()) {
                return;
            }
            var children = [];
            var tree = workspace.tree;
            if(tree) {
                var folder = tree.get("Tomcat");
                if(!folder) {
                    folder = tree.get("Catalina");
                }
                if(folder) {
                    children = folder.children;
                }
            }
            var treeElement = $("#tomcatTree");
            Jmx.enableTree($scope, $location, workspace, treeElement, children, true);
            setTimeout(updateSelectionFromURL, 50);
        });
        function updateSelectionFromURL() {
            Jmx.updateTreeSelectionFromURL($location, $("#tomcatTree"), true);
        }
    }
    Tomcat.TreeController = TreeController;
})(Tomcat || (Tomcat = {}));
var Tree;
(function (Tree) {
    var pluginName = 'tree';
    angular.module(pluginName, [
        'bootstrap', 
        'ngResource', 
        'hawtioCore'
    ]).directive('hawtioTree', function (workspace, $timeout, $location, $filter, $compile) {
        return function (scope, element, attrs) {
            var tree = null;
            var data = null;
            var widget = null;
            var timeoutId = null;
            var onSelectFn = lookupFunction("onselect");
            var onDragStartFn = lookupFunction("ondragstart");
            var onDragEnterFn = lookupFunction("ondragenter");
            var onDropFn = lookupFunction("ondrop");
            function lookupFunction(attrName) {
                var answer = null;
                var fnName = attrs[attrName];
                if(fnName) {
                    answer = Core.pathGet(scope, fnName);
                    if(!angular.isFunction(answer)) {
                        answer = null;
                    }
                }
                return answer;
            }
            var data = attrs.hawtioTree;
            var queryParam = data;
            scope.$watch(data, onWidgetDataChange);
            scope.$on("hawtio.tree." + data, function (args) {
                var value = Core.pathGet(scope, data);
                onWidgetDataChange(value);
            });
            element.bind('$destroy', function () {
                $timeout.cancel(timeoutId);
            });
            updateLater();
            function updateWidget() {
                Core.$applyNowOrLater(scope);
            }
            function onWidgetDataChange(value) {
                tree = value;
                if(tree && !widget) {
                    var treeElement = $(element);
                    var children = Core.asArray(tree);
                    var hideRoot = attrs["hideroot"];
                    if("true" === hideRoot) {
                        children = tree.children;
                    }
                    var config = {
                        clickFolderMode: 3,
                        onActivate: function (node) {
                            var data = node.data;
                            if(onSelectFn) {
                                onSelectFn(data, node);
                            } else {
                                workspace.updateSelectionNode(data);
                            }
                            Core.$apply(scope);
                        },
                        onClick: function (node, event) {
                            if(event["metaKey"]) {
                                event.preventDefault();
                                var url = $location.absUrl();
                                if(node && node.data) {
                                    var key = node.data["key"];
                                    if(key) {
                                        var hash = $location.search();
                                        hash[queryParam] = key;
                                        var idx = url.indexOf('?');
                                        if(idx <= 0) {
                                            url += "?";
                                        } else {
                                            url = url.substring(0, idx + 1);
                                        }
                                        url += $.param(hash);
                                    }
                                }
                                window.open(url, '_blank');
                                window.focus();
                                return false;
                            }
                            return true;
                        },
                        persist: false,
                        debugLevel: 0,
                        children: children,
                        dnd: {
                            onDragStart: onDragStartFn ? onDragStartFn : function (node) {
                                console.log("onDragStart!");
                                return true;
                            },
                            onDragEnter: onDragEnterFn ? onDragEnterFn : function (node, sourceNode) {
                                console.log("onDragEnter!");
                                return true;
                            },
                            onDrop: onDropFn ? onDropFn : function (node, sourceNode, hitMode) {
                                console.log("onDrop!");
                                sourceNode.move(node, hitMode);
                                return true;
                            }
                        }
                    };
                    if(!onDropFn && !onDragEnterFn && !onDragStartFn) {
                        delete config["dnd"];
                    }
                    widget = treeElement.dynatree(config);
                    var activatedNode = false;
                    var activateNodeName = attrs["activatenodes"];
                    if(activateNodeName) {
                        var values = scope[activateNodeName];
                        var tree = treeElement.dynatree("getTree");
                        if(values && tree) {
                            angular.forEach(Core.asArray(values), function (value) {
                                tree.activateKey(value);
                                activatedNode = true;
                            });
                        }
                    }
                    var root = treeElement.dynatree("getRoot");
                    if(root) {
                        var onRootName = attrs["onroot"];
                        if(onRootName) {
                            var fn = scope[onRootName];
                            if(fn) {
                                fn(root);
                            }
                        }
                        if(!activatedNode) {
                            var children = root.getChildren();
                            if(children && children.length) {
                                var child = children[0];
                                child.expand(true);
                                child.activate(true);
                            }
                        }
                    }
                }
                updateWidget();
            }
            function updateLater() {
                timeoutId = $timeout(function () {
                    updateWidget();
                }, 300);
            }
        }
    }).run(function (helpRegistry) {
        helpRegistry.addDevDoc(pluginName, 'app/tree/doc/developer.md');
    });
    hawtioPluginLoader.addModule(pluginName);
})(Tree || (Tree = {}));
var UI;
(function (UI) {
    UI.selected = "selected";
    UI.unselected = "unselected";
    UI.colors = [
        "#5484ED", 
        "#A4BDFC", 
        "#46D6DB", 
        "#7AE7BF", 
        "#51B749", 
        "#FBD75B", 
        "#FFB878", 
        "#FF887C", 
        "#DC2127", 
        "#DBADFF", 
        "#E1E1E1"
    ];
    var ColorPicker = (function () {
        function ColorPicker() {
            this.restrict = 'A';
            this.replace = true;
            this.scope = {
                property: '=hawtioColorPicker'
            };
            this.templateUrl = UI.templatePath + "colorPicker.html";
            this.compile = function (tElement, tAttrs, transclude) {
                return {
                    post: function postLink(scope, iElement, iAttrs, controller) {
                        scope.colorList = [];
                        angular.forEach(UI.colors, function (color) {
                            var select = UI.unselected;
                            if(scope.property === color) {
                                select = UI.selected;
                            }
                            scope.colorList.push({
                                color: color,
                                select: select
                            });
                        });
                    }
                };
            };
            this.controller = function ($scope, $element, $timeout) {
                $scope.popout = false;
                $scope.$watch('popout', function () {
                    $element.find('.color-picker-popout').toggleClass('popout-open', $scope.popout);
                });
                $scope.selectColor = function (color) {
                    for(var i = 0; i < $scope.colorList.length; i++) {
                        $scope.colorList[i].select = UI.unselected;
                        if($scope.colorList[i] === color) {
                            $scope.property = color.color;
                            $scope.colorList[i].select = UI.selected;
                        }
                    }
                };
            };
        }
        return ColorPicker;
    })();
    UI.ColorPicker = ColorPicker;    
})(UI || (UI = {}));
var UI;
(function (UI) {
    var ConfirmDialog = (function () {
        function ConfirmDialog() {
            this.restrict = 'A';
            this.replace = true;
            this.transclude = true;
            this.templateUrl = UI.templatePath + 'confirmDialog.html';
            this.scope = {
                show: '=hawtioConfirmDialog',
                title: '@',
                okButtonText: '@',
                cancelButtonText: '@',
                onCancel: '&',
                onOk: '&',
                onClose: '&'
            };
            this.controller = function ($scope, $element, $attrs, $transclude, $compile) {
                $scope.clone = null;
                $transclude(function (clone) {
                    $scope.clone = $(clone).filter('.dialog-body');
                });
                $scope.$watch('show', function () {
                    if($scope.show) {
                        setTimeout(function () {
                            $scope.body = $('.modal-body');
                            $scope.body.html($compile($scope.clone.html())($scope.$parent));
                            $scope.$apply();
                        }, 50);
                    }
                });
                $attrs.$observe('okButtonText', function (value) {
                    if(!angular.isDefined(value)) {
                        $scope.okButtonText = "Ok";
                    }
                });
                $attrs.$observe('cancelButtonText', function (value) {
                    if(!angular.isDefined(value)) {
                        $scope.cancelButtonText = "Cancel";
                    }
                });
                $attrs.$observe('title', function (value) {
                    if(!angular.isDefined(value)) {
                        $scope.title = "Are you sure?";
                    }
                });
                $scope.cancel = function () {
                    $scope.show = false;
                    $scope.$parent.$eval($scope.onCancel);
                };
                $scope.submit = function () {
                    $scope.show = false;
                    $scope.$parent.$eval($scope.onOk);
                };
                $scope.close = function () {
                    $scope.$parent.$eval($scope.onClose);
                };
            };
        }
        return ConfirmDialog;
    })();
    UI.ConfirmDialog = ConfirmDialog;    
})(UI || (UI = {}));
var UI;
(function (UI) {
    var Editor = (function () {
        function Editor() {
            this.restrict = 'A';
            this.replace = true;
            this.templateUrl = UI.templatePath + "editor.html";
            this.scope = {
                text: '=hawtioEditor',
                mode: '=',
                dirty: '=',
                name: '@'
            };
            this.controller = function ($scope, $element, $attrs) {
                $scope.codeMirror = null;
                $scope.doc = null;
                $scope.options = [];
                UI.observe($scope, $attrs, 'name', 'editor');
                $scope.applyOptions = function () {
                    if($scope.codeMirror) {
                        $scope.options.each(function (option) {
                            $scope.codeMirror.setOption(option.key, option['value']);
                        });
                        $scope.options = [];
                    }
                };
                $scope.$watch('doc', function () {
                    if($scope.doc) {
                        $scope.codeMirror.on('change', function (changeObj) {
                            var phase = $scope.$parent.$$phase;
                            if(!phase) {
                                $scope.text = $scope.doc.getValue();
                                $scope.dirty = !$scope.doc.isClean();
                                Core.$applyNowOrLater($scope);
                            }
                        });
                    }
                });
                $scope.$watch('codeMirror', function () {
                    if($scope.codeMirror) {
                        $scope.doc = $scope.codeMirror.getDoc();
                    }
                });
                $scope.$watch('text', function (oldValue, newValue) {
                    if($scope.codeMirror && $scope.doc) {
                        if(!$scope.codeMirror.hasFocus()) {
                            $scope.doc.setValue($scope.text);
                        }
                    }
                });
            };
            this.link = function ($scope, $element, $attrs) {
                var config = Object.extended($attrs).clone();
                delete config['$$element'];
                delete config['$attr'];
                delete config['class'];
                delete config['hawtioEditor'];
                delete config['mode'];
                delete config['dirty'];
                angular.forEach(config, function (value, key) {
                    $scope.options.push({
                        key: key,
                        'value': value
                    });
                });
                $scope.$watch('mode', function () {
                    if($scope.mode) {
                        if(!$scope.codeMirror) {
                            $scope.options.push({
                                key: 'mode',
                                'value': $scope.mode
                            });
                        } else {
                            $scope.codeMirror.setOption('mode', $scope.mode);
                        }
                    }
                });
                $scope.$watch('dirty', function () {
                    if($scope.dirty && !$scope.doc.isClean()) {
                        $scope.doc.markClean();
                    }
                });
                $scope.$watch('text', function () {
                    if(!$scope.codeMirror) {
                        var options = {
                            value: $scope.text
                        };
                        options = CodeEditor.createEditorSettings(options);
                        $scope.codeMirror = CodeMirror.fromTextArea($element.find('textarea').get(0), options);
                        $scope.applyOptions();
                    }
                });
            };
        }
        return Editor;
    })();
    UI.Editor = Editor;    
})(UI || (UI = {}));
var UI;
(function (UI) {
    function observe($scope, $attrs, key, defValue, callbackFunc) {
        if (typeof callbackFunc === "undefined") { callbackFunc = null; }
        $attrs.$observe(key, function (value) {
            if(!angular.isDefined(value)) {
                $scope[key] = defValue;
            } else {
                $scope[key] = value;
            }
            if(angular.isDefined(callbackFunc) && callbackFunc) {
                callbackFunc($scope[key]);
            }
        });
    }
    UI.observe = observe;
})(UI || (UI = {}));
var UI;
(function (UI) {
    var SlideOut = (function () {
        function SlideOut() {
            this.restrict = 'A';
            this.replace = true;
            this.transclude = true;
            this.templateUrl = UI.templatePath + 'slideout.html';
            this.scope = {
                show: '=hawtioSlideout',
                direction: '@',
                top: '@',
                height: '@',
                title: '@'
            };
            this.controller = function ($scope, $element, $attrs, $transclude, $compile) {
                $scope.clone = null;
                $transclude(function (clone) {
                    $scope.clone = $(clone).filter('.dialog-body');
                });
                UI.observe($scope, $attrs, 'direction', 'right');
                UI.observe($scope, $attrs, 'top', '10%', function (value) {
                    $element.css('top', value);
                });
                UI.observe($scope, $attrs, 'height', '80%', function (value) {
                    $element.css('height', value);
                });
                UI.observe($scope, $attrs, 'title', '');
                $scope.$watch('show', function () {
                    if($scope.show) {
                        $scope.body = $element.find('.slideout-body');
                        $scope.body.html($compile($scope.clone.html())($scope.$parent));
                    }
                });
            };
            this.link = function ($scope, $element, $attrs) {
                $scope.element = $($element);
                $scope.element.blur(function () {
                    $scope.show = false;
                    $scope.$apply();
                    return false;
                });
                $scope.$watch('show', function () {
                    if($scope.show) {
                        $scope.element.addClass('out');
                        $scope.element.focus();
                    } else {
                        $scope.element.removeClass('out');
                    }
                });
            };
        }
        return SlideOut;
    })();
    UI.SlideOut = SlideOut;    
})(UI || (UI = {}));
var UI;
(function (UI) {
    var TablePager = (function () {
        function TablePager() {
            var _this = this;
            this.restrict = 'A';
            this.scope = true;
            this.templateUrl = UI.templatePath + 'tablePager.html';
            this.$scope = null;
            this.element = null;
            this.attrs = null;
            this.tableName = null;
            this.setRowIndexName = null;
            this.rowIndexName = null;
            this.link = function (scope, element, attrs) {
                return _this.doLink(scope, element, attrs);
            };
        }
        TablePager.prototype.doLink = function (scope, element, attrs) {
            var _this = this;
            this.$scope = scope;
            this.element = element;
            this.attrs = attrs;
            this.tableName = attrs["hawtioPager"] || attrs["array"] || "data";
            this.setRowIndexName = attrs["onIndexChange"] || "onIndexChange";
            this.rowIndexName = attrs["rowIndex"] || "rowIndex";
            scope.first = function () {
                _this.goToIndex(0);
            };
            scope.last = function () {
                _this.goToIndex(scope.tableLength() - 1);
            };
            scope.previous = function () {
                _this.goToIndex(scope.rowIndex() - 1);
            };
            scope.next = function () {
                _this.goToIndex(scope.rowIndex() + 1);
            };
            scope.isEmptyOrFirst = function () {
                var idx = scope.rowIndex();
                var length = scope.tableLength();
                return length <= 0 || idx <= 0;
            };
            scope.isEmptyOrLast = function () {
                var idx = scope.rowIndex();
                var length = scope.tableLength();
                return length < 1 || idx + 1 >= length;
            };
            scope.rowIndex = function () {
                return scope.$parent[_this.rowIndexName];
            };
            scope.tableLength = function () {
                var data = _this.tableData();
                return data ? data.length : 0;
            };
        };
        TablePager.prototype.tableData = function () {
            return this.$scope.$parent[this.tableName] || [];
        };
        TablePager.prototype.goToIndex = function (idx) {
            var name = this.setRowIndexName;
            var fn = this.$scope[name];
            if(angular.isFunction(fn)) {
                fn(idx);
            } else {
                console.log("No function defined in scope for " + name + " but was " + fn);
                this.$scope[this.rowIndexName] = idx;
            }
        };
        return TablePager;
    })();
    UI.TablePager = TablePager;    
})(UI || (UI = {}));
var UI;
(function (UI) {
    function UITestController($scope, workspace) {
        $scope.showDeleteOne = false;
        $scope.showDeleteTwo = false;
        $scope.transcludedValue = "and this is transcluded";
        $scope.onCancelled = function (number) {
            notification('info', 'cancelled ' + number);
        };
        $scope.onOk = function (number) {
            notification('info', number + ' ok!');
        };
        $scope.showSlideoutRight = false;
        $scope.showSlideoutLeft = false;
        $scope.dirty = false;
        $scope.mode = 'javascript';
        $scope.someText = "var someValue = 0;\n" + "var someFunc = function() {\n" + "  return \"Hello World!\";\n" + "}\n";
        $scope.myColor = "#FF887C";
        $scope.showColorDialog = false;
    }
    UI.UITestController = UITestController;
})(UI || (UI = {}));
var UI;
(function (UI) {
    UI.pluginName = 'hawtio-ui';
    UI.templatePath = 'app/ui/html/';
    angular.module(UI.pluginName, [
        'bootstrap', 
        'ngResource', 
        'hawtioCore', 
        'ui', 
        'ui.bootstrap'
    ]).config(function ($routeProvider) {
        $routeProvider.when('/ui/test', {
            templateUrl: UI.templatePath + 'test.html'
        });
    }).directive('hawtioConfirmDialog', function () {
        return new UI.ConfirmDialog();
    }).directive('hawtioSlideout', function () {
        return new UI.SlideOut();
    }).directive('hawtioPager', function () {
        return new UI.TablePager();
    }).directive('hawtioEditor', function () {
        return new UI.Editor();
    }).directive('hawtioColorPicker', [
        function () {
            return new UI.ColorPicker();
        }    ]);
    hawtioPluginLoader.addModule(UI.pluginName);
})(UI || (UI = {}));
var Wiki;
(function (Wiki) {
    function CamelController($scope, $location, $routeParams, workspace, wikiRepository, jolokia) {
        Wiki.initScope($scope, $routeParams, $location);
        Camel.initEndpointChooserScope($scope, workspace, jolokia);
        $scope.schema = Camel.getConfiguredCamelModel();
        $scope.findProfileCamelContext = true;
        $scope.isValid = function (nav) {
            return nav && nav.isValid(workspace);
        };
        $scope.camelSubLevelTabs = [
            {
                content: '<i class="icon-picture"></i> Canvas',
                title: "Edit the diagram in a draggy droppy way",
                isValid: function (workspace) {
                    return true;
                },
                href: function () {
                    return Wiki.startLink($scope.branch) + "/camel/canvas/" + $scope.pageId;
                }
            }, 
            {
                content: '<i class=" icon-sitemap"></i> Tree',
                title: "View the routes as a tree",
                isValid: function (workspace) {
                    return true;
                },
                href: function () {
                    return Wiki.startLink($scope.branch) + "/camel/properties/" + $scope.pageId;
                }
            }, 
            
        ];
        var routeModel = _apacheCamelModel.definitions.route;
        routeModel["_id"] = "route";
        $scope.addDialog = new Core.Dialog();
        $scope.addDialog.options["dialogClass"] = "modal-large";
        $scope.addDialog.options["cssClass"] = "modal-large";
        $scope.paletteItemSearch = "";
        $scope.paletteTree = new Folder("Palette");
        $scope.paletteActivations = [
            "Routing_aggregate"
        ];
        angular.forEach(_apacheCamelModel.definitions, function (value, key) {
            if(value.group) {
                var group = (key === "route") ? $scope.paletteTree : $scope.paletteTree.getOrElse(value.group);
                if(!group.key) {
                    group.key = value.group1;
                }
                value["_id"] = key;
                var title = value["title"] || key;
                var node = new Folder(title);
                node.key = group.key + "_" + key;
                node["nodeModel"] = value;
                var imageUrl = Camel.getRouteNodeIcon(value);
                node.icon = imageUrl;
                node.tooltip = tooltip;
                var tooltip = value["tooltip"] || value["description"] || label;
                group.children.push(node);
            }
        });
        $scope.componentTree = new Folder("Endpoints");
        $scope.$watch("componentNames", function () {
            var componentNames = $scope.componentNames;
            if(componentNames && componentNames.length) {
                $scope.componentTree = new Folder("Endpoints");
                angular.forEach($scope.componentNames, function (endpointName) {
                    var category = Camel.getEndpointCategory(endpointName);
                    var groupName = category.label || "Core";
                    var groupKey = category.id || groupName;
                    var group = $scope.componentTree.getOrElse(groupName);
                    var value = Camel.getEndpointConfig(endpointName, category);
                    var key = endpointName;
                    var label = value["label"] || endpointName;
                    var node = new Folder(label);
                    node.key = groupKey + "_" + key;
                    node.key = key;
                    node["nodeModel"] = value;
                    var tooltip = value["tooltip"] || value["description"] || label;
                    var imageUrl = url(value["icon"] || Camel.endpointIcon);
                    node.icon = imageUrl;
                    node.tooltip = tooltip;
                    group.children.push(node);
                });
            }
        });
        $scope.componentActivations = [
            "bean"
        ];
        $scope.$watch('addDialog.show', function () {
            if($scope.addDialog.show) {
                setTimeout(function () {
                    $('#submit').focus();
                }, 50);
            }
        });
        $scope.$on("hawtio.form.modelChange", onModelChangeEvent);
        $scope.onRootTreeNode = function (rootTreeNode) {
            $scope.rootTreeNode = rootTreeNode;
            rootTreeNode.data = $scope.camelContextTree;
        };
        $scope.addNode = function () {
            if($scope.nodeXmlNode) {
                $scope.addDialog.open();
            } else {
                addNewNode(routeModel);
            }
        };
        $scope.onPaletteSelect = function (node) {
            $scope.selectedPaletteNode = (node && node["nodeModel"]) ? node : null;
            if($scope.selectedPaletteNode) {
                $scope.selectedComponentNode = null;
            }
            console.log("Selected " + $scope.selectedPaletteNode + " : " + $scope.selectedComponentNode);
        };
        $scope.onComponentSelect = function (node) {
            $scope.selectedComponentNode = (node && node["nodeModel"]) ? node : null;
            if($scope.selectedComponentNode) {
                $scope.selectedPaletteNode = null;
                var nodeName = node.key;
                console.log("loading endpoint schema for node " + nodeName);
                $scope.loadEndpointSchema(nodeName);
                $scope.selectedComponentName = nodeName;
            }
            console.log("Selected " + $scope.selectedPaletteNode + " : " + $scope.selectedComponentNode);
        };
        $scope.selectedNodeModel = function () {
            var nodeModel = null;
            if($scope.selectedPaletteNode) {
                nodeModel = $scope.selectedPaletteNode["nodeModel"];
            } else {
                if($scope.selectedComponentNode) {
                    var endpointConfig = $scope.selectedComponentNode["nodeModel"];
                    var endpointSchema = $scope.endpointSchema;
                    nodeModel = $scope.schema.definitions.endpoint;
                }
            }
            return nodeModel;
        };
        $scope.addAndCloseDialog = function () {
            var nodeModel = $scope.selectedNodeModel();
            if(nodeModel) {
                addNewNode(nodeModel);
            } else {
                console.log("WARNING: no nodeModel!");
            }
            $scope.addDialog.close();
        };
        $scope.removeNode = function () {
            if($scope.selectedFolder && $scope.treeNode) {
                $scope.selectedFolder.detach();
                $scope.treeNode.remove();
                $scope.selectedFolder = null;
                $scope.treeNode = null;
            }
        };
        $scope.canDelete = function () {
            return $scope.selectedFolder ? true : false;
        };
        $scope.isActive = function (nav) {
            if(angular.isString(nav)) {
                return workspace.isLinkActive(nav);
            }
            var fn = nav.isActive;
            if(fn) {
                return fn(workspace);
            }
            return workspace.isLinkActive(nav.href());
        };
        $scope.save = function () {
            if($scope.rootTreeNode) {
                var xmlNode = Camel.generateXmlFromFolder($scope.rootTreeNode);
                if(xmlNode) {
                    var text = Core.xmlNodeToString(xmlNode);
                    if(text) {
                        var commitMessage = $scope.commitMessage || "Updated page " + $scope.pageId;
                        wikiRepository.putPage($scope.branch, $scope.pageId, text, commitMessage, function (status) {
                            Wiki.onComplete(status);
                            goToView();
                            Core.$apply($scope);
                        });
                    }
                }
            }
        };
        $scope.cancel = function () {
            console.log("cancelling...");
        };
        $scope.$watch('workspace.tree', function () {
            if(!$scope.git) {
                setTimeout(updateView, 50);
            }
        });
        $scope.$on("$routeChangeSuccess", function (event, current, previous) {
            setTimeout(updateView, 50);
        });
        function getFolderXmlNode(treeNode) {
            var routeXmlNode = Camel.createFolderXmlTree(treeNode, null);
            if(routeXmlNode) {
                $scope.nodeXmlNode = routeXmlNode;
            }
            return routeXmlNode;
        }
        $scope.onNodeSelect = function (folder, treeNode) {
            $scope.selectedFolder = folder;
            $scope.treeNode = treeNode;
            $scope.propertiesTemplate = null;
            $scope.diagramTemplate = null;
            $scope.nodeXmlNode = null;
            if(folder) {
                $scope.nodeData = Camel.getRouteFolderJSON(folder);
                $scope.nodeDataChangedFields = {
                };
            }
            var nodeName = Camel.getFolderCamelNodeId(folder);
            var routeXmlNode = getFolderXmlNode(treeNode);
            if(nodeName) {
                $scope.nodeModel = Camel.getCamelSchema(nodeName);
                if($scope.nodeModel) {
                    $scope.propertiesTemplate = "app/wiki/html/camelPropertiesEdit.html";
                }
                $scope.diagramTemplate = "app/camel/html/routes.html";
                Core.$apply($scope);
            }
        };
        $scope.onNodeDragEnter = function (node, sourceNode) {
            var nodeFolder = node.data;
            var sourceFolder = sourceNode.data;
            if(nodeFolder && sourceFolder) {
                var nodeId = Camel.getFolderCamelNodeId(nodeFolder);
                var sourceId = Camel.getFolderCamelNodeId(sourceFolder);
                if(nodeId && sourceId) {
                    if(sourceId === "route") {
                        return nodeId === "route";
                    }
                    return true;
                }
            }
            return false;
        };
        $scope.onNodeDrop = function (node, sourceNode, hitMode, ui, draggable) {
            var nodeFolder = node.data;
            var sourceFolder = sourceNode.data;
            if(nodeFolder && sourceFolder) {
                var nodeId = Camel.getFolderCamelNodeId(nodeFolder);
                var sourceId = Camel.getFolderCamelNodeId(sourceFolder);
                if(nodeId === "route") {
                    if(sourceId === "route") {
                        if(hitMode === "over") {
                            hitMode = "after";
                        }
                    } else {
                        hitMode = "over";
                    }
                } else {
                    if(Camel.acceptOutput(nodeId)) {
                        hitMode = "over";
                    } else {
                        if(hitMode !== "before") {
                            hitMode = "after";
                        }
                    }
                }
                console.log("nodeDrop nodeId: " + nodeId + " sourceId: " + sourceId + " hitMode: " + hitMode);
                sourceNode.move(node, hitMode);
            }
        };
        updateView();
        function addNewNode(nodeModel) {
            var doc = $scope.doc || document;
            var parentFolder = $scope.selectedFolder || $scope.camelContextTree;
            var key = nodeModel["_id"];
            var beforeNode = null;
            if(!key) {
                console.log("WARNING: no id for model " + JSON.stringify(nodeModel));
            } else {
                var treeNode = $scope.treeNode;
                if(key === "route") {
                    treeNode = $scope.rootTreeNode;
                } else {
                    if(!treeNode) {
                        var root = $scope.rootTreeNode;
                        var children = root.getChildren();
                        if(!children || !children.length) {
                            addNewNode(Camel.getCamelSchema("route"));
                            children = root.getChildren();
                        }
                        if(children && children.length) {
                            treeNode = children[children.length - 1];
                        } else {
                            console.log("Could not add a new route to the empty tree!");
                            return;
                        }
                    }
                    var parentId = Camel.getFolderCamelNodeId(treeNode.data);
                    if(!Camel.acceptOutput(parentId)) {
                        beforeNode = treeNode.getNextSibling();
                        treeNode = treeNode.getParent() || treeNode;
                    }
                }
                if(treeNode) {
                    var node = doc.createElement(key);
                    parentFolder = treeNode.data;
                    var addedNode = Camel.addRouteChild(parentFolder, node);
                    if(addedNode) {
                        var added = treeNode.addChild(addedNode, beforeNode);
                        if(added) {
                            getFolderXmlNode(added);
                            added.expand(true);
                            added.select(true);
                            added.activate(true);
                        }
                    }
                }
            }
        }
        function onModelChangeEvent(event, name) {
            if($scope.nodeData) {
                var fieldMap = $scope.nodeDataChangedFields;
                if(fieldMap) {
                    if(fieldMap[name]) {
                        onNodeDataChanged();
                    } else {
                        fieldMap[name] = true;
                    }
                }
            }
        }
        function onNodeDataChanged() {
            var selectedFolder = $scope.selectedFolder;
            if($scope.treeNode && selectedFolder) {
                var routeXmlNode = getFolderXmlNode($scope.treeNode);
                if(routeXmlNode) {
                    var nodeName = routeXmlNode.localName;
                    var nodeSettings = Camel.getCamelSchema(nodeName);
                    if(nodeSettings) {
                        Camel.updateRouteNodeLabelAndTooltip(selectedFolder, routeXmlNode, nodeSettings);
                        $scope.treeNode.render(false, false);
                    }
                }
                selectedFolder["camelNodeData"] = $scope.nodeData;
            }
        }
        function onResults(response) {
            var text = response.text;
            if(text) {
                var tree = Camel.loadCamelTree(text, $scope.pageId);
                if(tree) {
                    $scope.camelContextTree = tree;
                }
            } else {
                console.log("No XML found for page " + $scope.pageId);
            }
            Core.$applyLater($scope);
        }
        function updateView() {
            $scope.loadEndpointNames();
            $scope.pageId = Wiki.pageId($routeParams, $location);
            console.log("Has page id: " + $scope.pageId + " with $routeParams " + JSON.stringify($routeParams));
            if(Git.getGitMBean(workspace)) {
                $scope.git = wikiRepository.getPage($scope.branch, $scope.pageId, $scope.objectId, onResults);
            }
        }
        function goToView() {
        }
    }
    Wiki.CamelController = CamelController;
})(Wiki || (Wiki = {}));
var Wiki;
(function (Wiki) {
    function CamelCanvasController($scope, $element, workspace, jolokia, wikiRepository) {
        $scope.addDialog = new Core.Dialog();
        $scope.propertiesDialog = new Core.Dialog();
        $scope.$watch("camelContextTree", function () {
            var tree = $scope.camelContextTree;
            $scope.rootFolder = tree;
            $scope.folders = Camel.addFoldersToIndex($scope.rootFolder);
            var doc = Core.pathGet(tree, [
                "xmlDocument"
            ]);
            if(doc) {
                $scope.doc = doc;
                reloadRouteIds();
                onRouteSelectionChanged();
            }
        });
        $scope.addAndCloseDialog = function () {
            var nodeModel = $scope.selectedNodeModel();
            if(nodeModel) {
                addNewNode(nodeModel);
            }
            $scope.addDialog.close();
        };
        $scope.removeNode = function () {
            var folder = getSelectedOrRouteFolder();
            if(folder) {
                var nodeName = Camel.getFolderCamelNodeId(folder);
                folder.detach();
                if("route" === nodeName) {
                    $scope.selectedRouteId = null;
                }
                updateSelection(null);
                treeModified();
            }
        };
        $scope.doLayout = function () {
            $scope.drawnRouteId = null;
            onRouteSelectionChanged();
        };
        $scope.updatePropertiesAndCloseDialog = function () {
            var selectedFolder = $scope.selectedFolder;
            if(selectedFolder) {
                var nodeName = Camel.getFolderCamelNodeId(selectedFolder);
                if(nodeName) {
                    var nodeSettings = Camel.getCamelSchema(nodeName);
                    if(nodeSettings) {
                        Camel.updateRouteNodeLabelAndTooltip(selectedFolder, selectedFolder["routeXmlNode"], nodeSettings);
                    }
                }
                selectedFolder["camelNodeData"] = $scope.nodeData;
            }
            $scope.propertiesDialog.close();
            Core.$apply($scope);
            treeModified();
        };
        $scope.save = function () {
            if($scope.rootFolder) {
                var xmlNode = Camel.generateXmlFromFolder($scope.rootFolder);
                if(xmlNode) {
                    var text = Core.xmlNodeToString(xmlNode);
                    if(text) {
                        var commitMessage = $scope.commitMessage || "Updated page " + $scope.pageId;
                        wikiRepository.putPage($scope.branch, $scope.pageId, text, commitMessage, function (status) {
                            Wiki.onComplete(status);
                            goToView();
                            Core.$apply($scope);
                        });
                    }
                }
            }
        };
        $scope.cancel = function () {
            console.log("cancelling...");
        };
        $scope.$watch("selectedRouteId", onRouteSelectionChanged);
        function goToView() {
        }
        function addNewNode(nodeModel) {
            var doc = $scope.doc || document;
            var parentFolder = $scope.selectedFolder || $scope.rootFolder;
            var key = nodeModel["_id"];
            if(!key) {
                console.log("WARNING: no id for model " + JSON.stringify(nodeModel));
            } else {
                var treeNode = $scope.selectedFolder;
                if(key === "route") {
                    treeNode = $scope.rootFolder;
                } else {
                    if(!treeNode) {
                        var root = $scope.rootFolder;
                        var children = root.children;
                        if(!children || !children.length) {
                            addNewNode(Camel.getCamelSchema("route"));
                            children = root.children;
                        }
                        if(children && children.length) {
                            treeNode = getRouteFolder($scope.rootFolder, $scope.selectedRouteId) || children[children.length - 1];
                        } else {
                            console.log("Could not add a new route to the empty tree!");
                            return;
                        }
                    }
                    var parentTypeName = Camel.getFolderCamelNodeId(treeNode);
                    if(!Camel.acceptOutput(parentTypeName)) {
                        treeNode = treeNode.parent || treeNode;
                    }
                }
                if(treeNode) {
                    var node = doc.createElement(key);
                    parentFolder = treeNode;
                    var addedNode = Camel.addRouteChild(parentFolder, node);
                    if(key === "route") {
                        var count = $scope.routeIds.length;
                        var nodeId = null;
                        while(true) {
                            nodeId = "route" + (++count);
                            if(!$scope.routeIds.find(nodeId)) {
                                break;
                            }
                        }
                        addedNode["routeXmlNode"].setAttribute("id", nodeId);
                        $scope.selectedRouteId = nodeId;
                    }
                }
            }
            treeModified();
        }
        function treeModified() {
            var newDoc = Camel.generateXmlFromFolder($scope.rootFolder);
            var tree = Camel.loadCamelTree(newDoc, $scope.pageId);
            if(tree) {
                $scope.rootFolder = tree;
                $scope.doc = Core.pathGet(tree, [
                    "xmlDocument"
                ]);
            }
            reloadRouteIds();
            $scope.doLayout();
            Core.$apply($scope);
        }
        function reloadRouteIds() {
            $scope.routeIds = [];
            $($scope.doc).find("route").each(function (idx, route) {
                var id = route.getAttribute("id");
                if(id) {
                    $scope.routeIds.push(id);
                }
            });
        }
        function onRouteSelectionChanged() {
            if($scope.doc) {
                if(!$scope.selectedRouteId && $scope.routeIds && $scope.routeIds.length) {
                    $scope.selectedRouteId = $scope.routeIds[0];
                }
                if($scope.selectedRouteId && $scope.selectedRouteId !== $scope.drawnRouteId) {
                    var nodes = [];
                    var links = [];
                    Camel.loadRouteXmlNodes($scope, $scope.doc, $scope.selectedRouteId, nodes, links, getWidth());
                    updateSelection($scope.selectedRouteId);
                    $scope.folders = Camel.addFoldersToIndex($scope.rootFolder);
                    showGraph(nodes, links);
                    $scope.drawnRouteId = $scope.selectedRouteId;
                }
            }
        }
        function showGraph(nodes, links) {
            var width = getWidth();
            var height = Camel.getCanvasHeight($($element));
            layoutGraph(nodes, links, width, height);
            return width;
        }
        function getNodeId(node) {
            if(angular.isNumber(node)) {
                var idx = node;
                node = $scope.nodeStates[idx];
                if(!node) {
                    console.log("Cant find node at " + idx);
                    return "node-" + idx;
                }
            }
            return node.cid || "node-" + node.id;
        }
        function getSelectedOrRouteFolder() {
            return $scope.selectedFolder || getRouteFolder($scope.rootFolder, $scope.selectedRouteId);
        }
        function layoutGraph(nodes, links, width, height) {
            var transitions = [];
            var states = Core.createGraphStates(nodes, links, transitions);
            $scope.nodeStates = states;
            var rootElement = $($element);
            var containerElement = rootElement.find(".canvas");
            if(!containerElement || !containerElement.length) {
                containerElement = rootElement;
            }
            try  {
                jsPlumb.detachEveryConnection();
            } catch (e) {
            }
            try  {
                jsPlumb.deleteEveryEndpoint();
            } catch (e) {
            }
            containerElement.find("div.component").remove();
            var endpointStyle = [
                "Dot", 
                {
                    radius: 2
                }
            ];
            var labelStyles = [
                "Label"
            ];
            var arrowStyles = [
                "Arrow", 
                {
                    location: 1,
                    id: "arrow",
                    length: 8,
                    width: 8,
                    foldback: 0.8
                }
            ];
            jsPlumb.importDefaults({
                Endpoint: endpointStyle,
                HoverPaintStyle: {
                    strokeStyle: "#42a62c",
                    lineWidth: 4
                },
                ConnectionOverlays: [
                    arrowStyles, 
                    labelStyles
                ]
            });
            var offset = containerElement.offset();
            var left = Core.pathGet(offset, [
                "left"
            ]) || 0;
            var top = Core.pathGet(offset, [
                "top"
            ]) || 0;
            angular.forEach(states, function (node) {
                var id = getNodeId(node);
                $("<div class='component window' id='" + id + "' title='" + node.tooltip + "'" + "><img class='nodeIcon' src='" + node.imageUrl + "'>" + "<span class='nodeText'>" + node.label + "</span></div>").appendTo(containerElement);
                var div = $("#" + id);
                var height = div.height();
                var width = div.width();
                if(height || width) {
                    node.width = width;
                    node.height = height;
                }
            });
            dagre.layout().nodeSep(50).edgeSep(10).rankSep(50).nodes(states).edges(transitions).debugLevel(1).run();
            angular.forEach(states, function (node) {
                var id = getNodeId(node);
                var dagre = node.dagre || node;
                var x = dagre.x || 0;
                var y = dagre.y || dagre["y:"] || 0;
                if(top) {
                    y += top;
                }
                var div = $("#" + id);
                div.css({
                    top: y,
                    left: x
                });
            });
            var nodes = containerElement.find("div.component");
            var connectorStyle = [
                "StateMachine", 
                {
                    curviness: 20
                }
            ];
            nodes.each(function (i, e) {
                var endpoint = $(e);
                jsPlumb.makeSource(endpoint, {
                    filter: "img.nodeIcon",
                    anchor: "Continuous",
                    connector: connectorStyle,
                    connectorStyle: {
                        strokeStyle: "#666",
                        lineWidth: 2
                    },
                    maxConnections: -1
                });
            });
            containerElement.dblclick(function () {
                $scope.propertiesDialog.open();
            });
            nodes.click(function () {
                var thisNode = $(this);
                var newFlag = !thisNode.hasClass("selected");
                nodes.toggleClass("selected", false);
                thisNode.toggleClass("selected", newFlag);
                var id = thisNode.attr("id");
                updateSelection(newFlag ? id : null);
                Core.$apply($scope);
            });
            nodes.dblclick(function () {
                var id = $(this).attr("id");
                updateSelection(id);
                $scope.propertiesDialog.open();
                Core.$apply($scope);
            });
            jsPlumb.makeTarget(nodes, {
                dropOptions: {
                    hoverClass: "dragHover"
                },
                anchor: "Continuous"
            });
            angular.forEach(links, function (link) {
                jsPlumb.connect({
                    source: getNodeId(link.source),
                    target: getNodeId(link.target)
                });
            });
            jsPlumb.draggable(nodes);
            jsPlumb.bind("dblclick", function (connection, originalEvent) {
                alert("double click on connection from " + connection.sourceId + " to " + connection.targetId);
            });
            jsPlumb.bind("click", function (c) {
                jsPlumb.detach(c);
            });
            jsPlumb.bind("contextmenu", function (component, originalEvent) {
                alert("context menu on component " + component.id);
                originalEvent.preventDefault();
                return false;
            });
            return states;
        }
        function updateSelection(folderOrId) {
            var folder = null;
            if(angular.isString(folderOrId)) {
                var id = folderOrId;
                folder = (id && $scope.folders) ? $scope.folders[id] : null;
            } else {
                folder = folderOrId;
            }
            $scope.selectedFolder = folder;
            folder = getSelectedOrRouteFolder();
            $scope.nodeXmlNode = null;
            $scope.propertiesTemplate = null;
            if(folder) {
                var nodeName = Camel.getFolderCamelNodeId(folder);
                $scope.nodeData = Camel.getRouteFolderJSON(folder);
                $scope.nodeDataChangedFields = {
                };
                $scope.nodeModel = Camel.getCamelSchema(nodeName);
                if($scope.nodeModel) {
                    $scope.propertiesTemplate = "app/wiki/html/camelPropertiesEdit.html";
                }
            }
        }
        function getWidth() {
            var canvasDiv = $($element);
            return canvasDiv.width();
        }
        function getFolderIdAttribute(route) {
            var id = null;
            if(route) {
                var xmlNode = route["routeXmlNode"];
                if(xmlNode) {
                    id = xmlNode.getAttribute("id");
                }
            }
            return id;
        }
        function getRouteFolder(tree, routeId) {
            var answer = null;
            if(tree) {
                angular.forEach(tree.children, function (route) {
                    if(!answer) {
                        var id = getFolderIdAttribute(route);
                        if(routeId === id) {
                            answer = route;
                        }
                    }
                });
            }
            return answer;
        }
    }
    Wiki.CamelCanvasController = CamelCanvasController;
})(Wiki || (Wiki = {}));
var Wiki;
(function (Wiki) {
    function EditController($scope, $location, $routeParams, fileExtensionTypeRegistry, wikiRepository) {
        Wiki.initScope($scope, $routeParams, $location);
        $scope.entity = {
            source: null
        };
        var format = Wiki.fileFormat($scope.pageId, fileExtensionTypeRegistry);
        var form = null;
        if((format && format === "javascript") || isCreate()) {
            form = $location.search()["form"];
        }
        var options = {
            mode: {
                name: format
            }
        };
        $scope.codeMirrorOptions = CodeEditor.createEditorSettings(options);
        $scope.isValid = function () {
            return $scope.fileName;
        };
        $scope.viewLink = function () {
            return Wiki.viewLink($scope.branch, $scope.pageId, $location, $scope.fileName);
        };
        $scope.cancel = function () {
            goToView();
        };
        $scope.save = function () {
            saveTo($scope["pageId"]);
        };
        $scope.create = function () {
            var path = $scope.pageId + "/" + $scope.fileName;
            console.log("creating new file at " + path);
            saveTo(path);
        };
        $scope.onSubmit = function (json, form) {
            if(isCreate()) {
                $scope.create();
            } else {
                $scope.save();
            }
        };
        $scope.onCancel = function (form) {
            setTimeout(function () {
                goToView();
                Core.$apply($scope);
            }, 50);
        };
        updateView();
        function isCreate() {
            return $location.path().startsWith("/wiki/create");
        }
        function updateView() {
            if(isCreate()) {
                updateSourceView();
            } else {
                wikiRepository.getPage($scope.branch, $scope.pageId, $scope.objectId, onFileContents);
            }
        }
        function onFileContents(details) {
            var contents = details.text;
            $scope.entity.source = contents;
            updateSourceView();
            Core.$apply($scope);
        }
        function updateSourceView() {
            if(form) {
                if(isCreate()) {
                    if(!$scope.fileName) {
                        $scope.fileName = "" + Core.getUUID() + ".json";
                    }
                }
                $scope.sourceView = null;
                if(form === "/") {
                    onFormSchema(_jsonSchema);
                } else {
                    $scope.git = wikiRepository.getPage($scope.branch, form, $scope.objectId, function (details) {
                        onFormSchema(Wiki.parseJson(details.text));
                    });
                }
            } else {
                $scope.sourceView = "app/wiki/html/sourceEdit.html";
            }
        }
        function onFormSchema(json) {
            $scope.formDefinition = json;
            if($scope.entity.source) {
                $scope.formEntity = Wiki.parseJson($scope.entity.source);
            }
            $scope.sourceView = "app/wiki/html/formEdit.html";
            Core.$apply($scope);
        }
        function goToView() {
            var path = Core.trimLeading($scope.viewLink(), "#");
            console.log("going to view " + path);
            $location.path(path);
            console.log("location is now " + $location.path());
        }
        function saveTo(path) {
            var commitMessage = $scope.commitMessage || "Updated page " + $scope.pageId;
            var contents = $scope.entity.source;
            if($scope.formEntity) {
                contents = JSON.stringify($scope.formEntity, null, "  ");
            }
            wikiRepository.putPage($scope.branch, path, contents, commitMessage, function (status) {
                Wiki.onComplete(status);
                goToView();
                Core.$apply($scope);
            });
        }
    }
    Wiki.EditController = EditController;
})(Wiki || (Wiki = {}));
var Wiki;
(function (Wiki) {
    function FormTableController($scope, $location, $routeParams, workspace, wikiRepository) {
        Wiki.initScope($scope, $routeParams, $location);
        $scope.columnDefs = [];
        $scope.viewLink = function (row) {
            return childLink(row, "/view");
        };
        $scope.editLink = function (row) {
            return childLink(row, "/edit");
        };
        function childLink(child, prefix) {
            var start = Wiki.startLink($scope.branch);
            var childId = (child) ? child["_id"] || "" : "";
            return Core.createHref($location, start + prefix + "/" + $scope.pageId + "/" + childId);
        }
        var linksColumn = {
            field: '_id',
            displayName: 'Actions',
            cellTemplate: '<div class="ngCellText""><a ng-href="{{viewLink(row.entity)}}" class="btn">View</a> <a ng-href="{{editLink(row.entity)}}" class="btn">Edit</a></div>'
        };
        $scope.$watch('workspace.tree', function () {
            if(!$scope.git && Git.getGitMBean(workspace)) {
                setTimeout(updateView, 50);
            }
        });
        $scope.$on("$routeChangeSuccess", function (event, current, previous) {
            setTimeout(updateView, 50);
        });
        var form = $location.search()["form"];
        if(form) {
            wikiRepository.getPage($scope.branch, form, $scope.objectId, onFormData);
        }
        updateView();
        function onResults(response) {
            var list = [];
            var map = Wiki.parseJson(response);
            angular.forEach(map, function (value, key) {
                value["_id"] = key;
                list.push(value);
            });
            $scope.list = list;
            Core.$apply($scope);
        }
        function updateView() {
            $scope.git = wikiRepository.jsonChildContents($scope.pageId, "*.json", $scope.gridOptions.filterOptions.filterText, onResults);
        }
        function onFormData(details) {
            var text = details.text;
            if(text) {
                $scope.formDefinition = Wiki.parseJson(text);
                var columnDefs = [];
                var schema = $scope.formDefinition;
                angular.forEach(schema.properties, function (property, name) {
                    if(name) {
                        if(!Forms.isArrayOrNestedObject(property, schema)) {
                            var colDef = {
                                field: name,
                                displayName: property.description || name,
                                visible: true
                            };
                            columnDefs.push(colDef);
                        }
                    }
                });
                columnDefs.push(linksColumn);
                $scope.gridOptions = {
                    data: 'list',
                    displayFooter: false,
                    showFilter: false,
                    filterOptions: {
                        filterText: ''
                    },
                    columnDefs: columnDefs
                };
                $scope.tableView = "app/wiki/html/formTableDatatable.html";
            }
        }
        Core.$apply($scope);
    }
    Wiki.FormTableController = FormTableController;
})(Wiki || (Wiki = {}));
var Wiki;
(function (Wiki) {
    Wiki.camelNamespaces = [
        "http://camel.apache.org/schema/spring", 
        "http://camel.apache.org/schema/blueprint"
    ];
    Wiki.springNamespaces = [
        "http://www.springframework.org/schema/beans"
    ];
    Wiki.droolsNamespaces = [
        "http://drools.org/schema/drools-spring"
    ];
    function startLink(branch) {
        var start = "#/wiki";
        if(branch) {
            start += "/branch/" + branch;
        }
        return start;
    }
    Wiki.startLink = startLink;
    function viewLink(branch, pageId, $location, fileName) {
        if (typeof fileName === "undefined") { fileName = null; }
        var link = null;
        var start = startLink(branch);
        if(pageId) {
            link = start + "/view/" + pageId;
        } else {
            var path = $location.path();
            link = "#" + path.replace(/(edit|create)/, "view");
        }
        if(fileName) {
            if(!link.endsWith("/")) {
                link += "/";
            }
            link += fileName;
        }
        return link;
    }
    Wiki.viewLink = viewLink;
    function editLink(branch, pageId, $location) {
        var link = null;
        var start = startLink(branch);
        if(pageId) {
            link = start + "/edit/" + pageId;
        } else {
            var path = $location.path();
            link = "#" + path.replace(/(view|create)/, "edit");
        }
        return link;
    }
    Wiki.editLink = editLink;
    function createLink(branch, pageId, $location, $scope) {
        var path = $location.path();
        var start = startLink(branch);
        var link = null;
        if(pageId) {
            link = start + "/create/" + pageId;
        } else {
            link = "#" + path.replace(/(view|edit|formTable)/, "create");
        }
        var idx = link.lastIndexOf("/");
        if(idx > 0 && !$scope.children && !path.startsWith("/wiki/formTable")) {
            link = link.substring(0, idx + 1);
        }
        return link;
    }
    Wiki.createLink = createLink;
    function fileFormat(name, fileExtensionTypeRegistry) {
        var extension = fileExtension(name);
        var answer = null;
        angular.forEach(fileExtensionTypeRegistry, function (array, key) {
            if(array.indexOf(extension) >= 0) {
                answer = key;
            }
        });
        return answer;
    }
    Wiki.fileFormat = fileFormat;
    function iconClass(row) {
        var name = row.getProperty("name");
        var extension = fileExtension(name);
        var directory = row.getProperty("directory");
        if(directory) {
            return "icon-folder-close";
        }
        if("xml" === extension) {
            return "icon-cog";
        }
        return "icon-file-alt";
    }
    Wiki.iconClass = iconClass;
    function initScope($scope, $routeParams, $location) {
        $scope.pageId = Wiki.pageId($routeParams, $location);
        $scope.branch = $routeParams["branch"] || $location.search()["branch"];
        $scope.objectId = $routeParams["objectId"];
        $scope.startLink = Wiki.startLink($scope.branch);
    }
    Wiki.initScope = initScope;
    function pageId($routeParams, $location) {
        var pageId = $routeParams['page'];
        if(!pageId) {
            for(var i = 0; i < 100; i++) {
                var value = $routeParams['path' + i];
                if(angular.isDefined(value)) {
                    if(!pageId) {
                        pageId = value;
                    } else {
                        pageId += "/" + value;
                    }
                } else {
                    break;
                }
            }
            return pageId || "/";
        }
        if(!pageId) {
            pageId = pageIdFromURI($location.path());
        }
        return pageId;
    }
    Wiki.pageId = pageId;
    function pageIdFromURI(url) {
        var wikiPrefix = "/wiki/";
        if(url && url.startsWith(wikiPrefix)) {
            var idx = url.indexOf("/", wikiPrefix.length + 1);
            if(idx > 0) {
                return url.substring(idx + 1, url.length);
            }
        }
        return null;
    }
    Wiki.pageIdFromURI = pageIdFromURI;
    function fileExtension(name) {
        return Core.fileExtension(name, "markdown");
    }
    Wiki.fileExtension = fileExtension;
    function onComplete(status) {
        console.log("Completed operation with status: " + JSON.stringify(status));
    }
    Wiki.onComplete = onComplete;
    function parseJson(text) {
        if(text) {
            try  {
                return JSON.parse(text);
            } catch (e) {
                notification("error", "Failed to parse JSON: " + e);
            }
        }
        return null;
    }
    Wiki.parseJson = parseJson;
})(Wiki || (Wiki = {}));
var Wiki;
(function (Wiki) {
    function HistoryController($scope, $location, $routeParams, workspace, marked, fileExtensionTypeRegistry, wikiRepository) {
        $scope.pageId = Wiki.pageId($routeParams, $location);
        $scope.selectedItems = [];
        $scope.dateFormat = 'EEE, MMM d, y : hh:mm:ss a';
        $scope.gridOptions = {
            data: 'logs',
            showFilter: false,
            selectedItems: $scope.selectedItems,
            filterOptions: {
                filterText: ''
            },
            columnDefs: [
                {
                    field: 'commitHashText',
                    displayName: 'Version',
                    cellTemplate: '<div class="ngCellText"><a ng-href="#/wiki/version/{{pageId}}/{{row.getProperty(' + "'name'" + ')}}{{hash}}">{{row.getProperty(col.field)}}</a></div>',
                    cellFilter: ""
                }, 
                {
                    field: 'date',
                    displayName: 'Modified',
                    cellFilter: "date: dateFormat"
                }, 
                {
                    field: 'author',
                    displayName: 'Author',
                    cellFilter: ""
                }, 
                {
                    field: 'shortMessage',
                    displayName: 'Message',
                    cellFilter: ""
                }
            ]
        };
        $scope.$on("$routeChangeSuccess", function (event, current, previous) {
            setTimeout(updateView, 50);
        });
        $scope.$watch('workspace.tree', function () {
            if(!$scope.git && Git.getGitMBean(workspace)) {
                setTimeout(updateView, 50);
            }
        });
        $scope.canRevert = function () {
            return $scope.selectedItems.length === 1 && $scope.selectedItems[0] !== $scope.logs[0];
        };
        $scope.revert = function () {
            if($scope.selectedItems.length > 0) {
                var objectId = $scope.selectedItems[0].name;
                if(objectId) {
                    var commitMessage = "Reverting file " + $scope.pageId + " to previous version " + objectId;
                    wikiRepository.revertTo(objectId, $scope.pageId, commitMessage, function (result) {
                        Wiki.onComplete(result);
                        updateView();
                    });
                }
            }
        };
        $scope.diff = function () {
            var defaultValue = " ";
            var objectId = defaultValue;
            if($scope.selectedItems.length > 0) {
                objectId = $scope.selectedItems[0].name || defaultValue;
            }
            var baseObjectId = defaultValue;
            if($scope.selectedItems.length > 1) {
                baseObjectId = $scope.selectedItems[1].name || defaultValue;
            }
            var path = "/wiki/diff/" + $scope.pageId + "/" + objectId + "/" + baseObjectId;
            $location.path(path);
        };
        updateView();
        function updateView() {
            var objectId = "";
            var limit = 0;
            $scope.git = wikiRepository.history(objectId, $scope.pageId, limit, function (logArray) {
                $scope.logs = logArray;
                Core.$apply($scope);
            });
        }
    }
    Wiki.HistoryController = HistoryController;
})(Wiki || (Wiki = {}));
var Wiki;
(function (Wiki) {
    function NavBarController($scope, $location, $routeParams, workspace, wikiRepository) {
        var customViewLinks = [
            "/wiki/formTable", 
            "/wiki/camel/diagram", 
            "/wiki/camel/properties"
        ];
        $scope.createLink = function () {
            var pageId = Wiki.pageId($routeParams, $location);
            return Wiki.createLink($scope.branch, pageId, $location, $scope);
        };
        $scope.sourceLink = function () {
            var path = $location.path();
            var answer = null;
            angular.forEach(customViewLinks, function (link) {
                if(path.startsWith(link)) {
                    answer = Core.createHref($location, Wiki.startLink($scope.branch) + "/view" + path.substring(link.length));
                }
            });
            return (!answer && $location.search()["form"]) ? Core.createHref($location, "#" + path, [
                "form"
            ]) : answer;
        };
        $scope.isActive = function (href) {
            var tidy = Core.trimLeading(href, "#");
            var loc = $location.path();
            if(loc === tidy) {
                return true;
            }
            if(loc.startsWith("/wiki/view") || loc.startsWith("/wiki/edit")) {
                var p1 = Wiki.pageIdFromURI(tidy);
                var p2 = Wiki.pageIdFromURI(loc);
                return p1 === p2;
            }
            return false;
        };
        $scope.$on("$routeChangeSuccess", function (event, current, previous) {
            setTimeout(loadBreadcrumbs, 50);
        });
        loadBreadcrumbs();
        function switchFromViewToCustomLink(breadcrumb, link) {
            var href = breadcrumb.href;
            if(href) {
                breadcrumb.href = href.replace("wiki/view", link);
            }
        }
        function loadBreadcrumbs() {
            var start = Wiki.startLink($scope.branch);
            var href = start + "/view/";
            $scope.breadcrumbs = [
                {
                    href: href,
                    name: "/"
                }
            ];
            var path = Wiki.pageId($routeParams, $location);
            var array = path ? path.split("/") : [];
            angular.forEach(array, function (name) {
                if(!name.startsWith("/") && !href.endsWith("/")) {
                    href += "/";
                }
                href += name;
                $scope.breadcrumbs.push({
                    href: href,
                    name: name
                });
            });
            var loc = $location.path();
            if($scope.breadcrumbs.length) {
                var swizzled = false;
                angular.forEach(customViewLinks, function (link) {
                    if(!swizzled && loc.startsWith(link)) {
                        switchFromViewToCustomLink($scope.breadcrumbs.last(), Core.trimLeading(link, "/"));
                        swizzled = true;
                    }
                });
                if(!swizzled && $location.search()["form"]) {
                    var lastName = $scope.breadcrumbs.last().name;
                    if(lastName && lastName.endsWith(".json")) {
                        switchFromViewToCustomLink($scope.breadcrumbs[$scope.breadcrumbs.length - 2], "wiki/formTable");
                    }
                }
            }
            if(loc.startsWith("/wiki/history") || loc.startsWith("/wiki/version") || loc.startsWith("/wiki/diff")) {
                $scope.breadcrumbs.push({
                    href: "#/wiki/history/" + path,
                    name: "History"
                });
            }
            if(loc.startsWith("/wiki/version")) {
                var name = ($routeParams["objectId"] || "").substring(0, 6) || "Version";
                $scope.breadcrumbs.push({
                    href: "#" + loc,
                    name: name
                });
            }
            if(loc.startsWith("/wiki/diff")) {
                var v1 = ($routeParams["objectId"] || "").substring(0, 6);
                var v2 = ($routeParams["baseObjectId"] || "").substring(0, 6);
                var name = "Diff";
                if(v1) {
                    if(v2) {
                        name += " " + v1 + " " + v2;
                    } else {
                        name += " " + v1;
                    }
                }
                $scope.breadcrumbs.push({
                    href: "#" + loc,
                    name: name
                });
            }
            Core.$apply($scope);
        }
    }
    Wiki.NavBarController = NavBarController;
})(Wiki || (Wiki = {}));
var Wiki;
(function (Wiki) {
    function ViewController($scope, $location, $routeParams, workspace, marked, fileExtensionTypeRegistry, wikiRepository, $compile) {
        Wiki.initScope($scope, $routeParams, $location);
        $scope.gridOptions = {
            data: 'children',
            displayFooter: false,
            columnDefs: [
                {
                    field: 'name',
                    displayName: 'Page Name',
                    cellTemplate: '<div class="ngCellText"><a href="{{childLink(row.entity)}}"><i class="{{row | fileIconClass}}"></i> {{row.getProperty(col.field)}}</a></div>',
                    cellFilter: ""
                }, 
                {
                    field: 'lastModified',
                    displayName: 'Modified',
                    cellFilter: "date:'EEE, MMM d, y : hh:mm:ss a'"
                }, 
                {
                    field: 'length',
                    displayName: 'Size',
                    cellFilter: "number"
                }
            ]
        };
        $scope.childLink = function (child) {
            var start = Wiki.startLink($scope.branch);
            var prefix = start + "/view";
            var postFix = "";
            var path = child.path;
            if(child.directory) {
                var formPath = path + ".form";
                var children = $scope.children;
                if(children) {
                    var formFile = children.find({
                        path: formPath
                    });
                    if(formFile) {
                        prefix = start + "/formTable";
                        postFix = "?form=" + formPath;
                    }
                }
            } else {
                var xmlNamespaces = child.xmlNamespaces;
                if(xmlNamespaces && xmlNamespaces.length) {
                    if(xmlNamespaces.any(function (ns) {
                        return Wiki.camelNamespaces.any(ns);
                    })) {
                        prefix = start + "/camel/canvas";
                    } else {
                        console.log("child " + path + " has namespaces " + xmlNamespaces);
                    }
                }
                if(child.path.endsWith(".form")) {
                    postFix = "?form=/";
                }
            }
            return Core.createHref($location, prefix + path + postFix, [
                "form"
            ]);
        };
        $scope.format = Wiki.fileFormat($scope.pageId, fileExtensionTypeRegistry);
        var options = {
            readOnly: true,
            mode: {
                name: $scope.format
            }
        };
        $scope.codeMirrorOptions = CodeEditor.createEditorSettings(options);
        $scope.editLink = function () {
            var pageName = ($scope.directory) ? $scope.readMePath : $scope.pageId;
            return (pageName) ? Wiki.editLink($scope.branch, pageName, $location) : null;
        };
        $scope.historyLink = "#/wiki/history/" + $scope.pageId;
        $scope.$watch('workspace.tree', function () {
            if(!$scope.git && Git.getGitMBean(workspace)) {
                setTimeout(updateView, 50);
            }
        });
        $scope.$on("$routeChangeSuccess", function (event, current, previous) {
            setTimeout(updateView, 50);
        });
        $scope.onSubmit = function (json, form) {
            notification("success", "Submitted form :" + form.get(0).name + " data: " + JSON.stringify(json));
        };
        $scope.onCancel = function (form) {
            notification("success", "Clicked cancel!");
        };
        updateView();
        function updateView() {
            var path = $location.path();
            if(path && path.startsWith("/wiki/diff")) {
                var baseObjectId = $routeParams["baseObjectId"];
                $scope.git = wikiRepository.diff($scope.objectId, baseObjectId, $scope.pageId, onFileDetails);
            } else {
                $scope.git = wikiRepository.getPage($scope.branch, $scope.pageId, $scope.objectId, onFileDetails);
            }
        }
        function viewContents(pageName, contents) {
            $scope.sourceView = null;
            if("markdown" === $scope.format) {
                $scope.html = contents ? marked(contents) : "";
                $scope.html = $compile($scope.html)($scope);
            } else {
                if($scope.format && $scope.format.startsWith("html")) {
                    $scope.html = contents;
                    $compile($scope.html)($scope);
                } else {
                    var form = null;
                    if($scope.format && $scope.format === "javascript") {
                        form = $location.search()["form"];
                    }
                    $scope.source = contents;
                    $scope.form = form;
                    if(form) {
                        $scope.sourceView = null;
                        if(form === "/") {
                            onFormSchema(_jsonSchema);
                        } else {
                            $scope.git = wikiRepository.getPage($scope.branch, form, $scope.objectId, function (details) {
                                onFormSchema(Wiki.parseJson(details.text));
                            });
                        }
                    } else {
                        $scope.sourceView = "app/wiki/html/sourceView.html";
                    }
                }
            }
            Core.$apply($scope);
        }
        function onFormSchema(json) {
            $scope.formDefinition = json;
            if($scope.source) {
                $scope.formEntity = Wiki.parseJson($scope.source);
            }
            $scope.sourceView = "app/wiki/html/formView.html";
            Core.$apply($scope);
        }
        function onFileDetails(details) {
            var contents = details.text;
            $scope.directory = details.directory;
            if(details && details.format) {
                $scope.format = details.format;
            } else {
                $scope.format = Wiki.fileFormat($scope.pageId, fileExtensionTypeRegistry);
            }
            $scope.codeMirrorOptions.mode.name = $scope.format;
            $scope.children = details.children;
            if(!details.directory) {
                $scope.childen = null;
            }
            $scope.html = null;
            $scope.source = null;
            $scope.readMePath = null;
            if($scope.children) {
                var item = $scope.children.find(function (info) {
                    var name = (info.name || "").toLowerCase();
                    var ext = Wiki.fileExtension(name);
                    return name && ext && (name.startsWith("readme.") || name === "readme");
                });
                if(item) {
                    var pageName = item.path;
                    $scope.readMePath = pageName;
                    wikiRepository.getPage($scope.branch, pageName, $scope.objectId, function (readmeDetails) {
                        viewContents(pageName, readmeDetails.text);
                    });
                }
            } else {
                var pageName = $scope.pageId;
                viewContents(pageName, contents);
            }
            Core.$apply($scope);
        }
    }
    Wiki.ViewController = ViewController;
})(Wiki || (Wiki = {}));
var Wiki;
(function (Wiki) {
    var pluginName = 'wiki';
    angular.module(pluginName, [
        'bootstrap', 
        'ui.bootstrap.dialog', 
        'ui.bootstrap.tabs', 
        'ngResource', 
        'hawtioCore', 
        'tree', 
        'camel'
    ]).config(function ($routeProvider) {
        angular.forEach([
            "", 
            "/branch/:branch"
        ], function (path) {
            $routeProvider.when('/wiki' + path + '/view/*page', {
                templateUrl: 'app/wiki/html/viewPage.html'
            }).when('/wiki' + path + '/create/*page', {
                templateUrl: 'app/wiki/html/createPage.html'
            }).when('/wiki' + path + '/edit/*page', {
                templateUrl: 'app/wiki/html/editPage.html'
            }).when('/wiki' + path + '/formTable/*page', {
                templateUrl: 'app/wiki/html/formTable.html'
            }).when('/wiki' + path + '/camel/diagram/*page', {
                templateUrl: 'app/wiki/html/camelDiagram.html'
            }).when('/wiki' + path + '/camel/canvas/*page', {
                templateUrl: 'app/wiki/html/camelCanvas.html'
            }).when('/wiki' + path + '/camel/properties/*page', {
                templateUrl: 'app/wiki/html/camelProperties.html'
            });
        });
        $routeProvider.when('/wiki/diff/*page/:objectId/:baseObjectId', {
            templateUrl: 'app/wiki/html/viewPage.html'
        }).when('/wiki/version/*page/:objectId', {
            templateUrl: 'app/wiki/html/viewPage.html'
        }).when('/wiki/history/*page', {
            templateUrl: 'app/wiki/html/history.html'
        });
    }).factory('wikiRepository', function (workspace, jolokia, localStorage) {
        return new Wiki.GitWikiRepository(function () {
            return Git.createGitRepository(workspace, jolokia, localStorage);
        });
    }).factory('fileExtensionTypeRegistry', function () {
        return {
            "markdown": [
                "md", 
                "markdown", 
                "mdown", 
                "mkdn", 
                "mkd"
            ],
            "htmlmixed": [
                "html", 
                "xhtml", 
                "htm"
            ],
            "text/x-java": [
                "java"
            ],
            "text/x-scala": [
                "scala"
            ],
            "javascript": [
                "js", 
                "json", 
                "javascript", 
                "jscript", 
                "ecmascript", 
                "form"
            ],
            "xml": [
                "xml"
            ],
            "properties": [
                "properties"
            ]
        };
    }).filter('fileIconClass', function () {
        return Wiki.iconClass;
    }).run(function ($location, workspace, viewRegistry, jolokia, localStorage, layoutFull) {
        viewRegistry["/wiki/(branch/.*/)?camel/canvas/"] = layoutFull;
        viewRegistry["/wiki/(branch/.*/)?camel/.*/"] = "app/wiki/html/layoutCamel.html";
        viewRegistry['wiki'] = layoutFull;
        workspace.topLevelTabs.push({
            content: "Wiki",
            title: "View and edit wiki pages",
            isValid: function (workspace) {
                return Git.createGitRepository(workspace, jolokia, localStorage) !== null;
            },
            href: function () {
                return "#/wiki/view/wiki";
            },
            isActive: function (workspace) {
                return workspace.isLinkActive("/wiki");
            }
        });
    });
    hawtioPluginLoader.addModule(pluginName);
})(Wiki || (Wiki = {}));
var Wiki;
(function (Wiki) {
    var GitWikiRepository = (function () {
        function GitWikiRepository(factoryMethod) {
            this.factoryMethod = factoryMethod;
            this.directoryPrefix = "";
        }
        GitWikiRepository.prototype.getPage = function (branch, path, objectId, fn) {
            var _this = this;
            var git = this.git();
            path = path || "/";
            if(git) {
                if(objectId) {
                    var blobPath = this.getLogPath(path);
                    git.getContent(objectId, blobPath, function (content) {
                        var details = {
                            text: content,
                            directory: false
                        };
                        fn(details);
                    });
                } else {
                    var fullPath = this.getPath(path);
                    git.read(branch, fullPath, function (details) {
                        var children = details.children;
                        angular.forEach(children, function (child) {
                            var path = child.path;
                            if(path) {
                                var directoryPrefix = "/" + _this.directoryPrefix;
                                if(path.startsWith(directoryPrefix)) {
                                    path = "/" + path.substring(directoryPrefix.length);
                                    child.path = path;
                                }
                            }
                        });
                        fn(details);
                    });
                }
            }
            return git;
        };
        GitWikiRepository.prototype.diff = function (objectId, baseObjectId, path, fn) {
            var fullPath = this.getLogPath(path);
            var git = this.git();
            if(git) {
                git.diff(objectId, baseObjectId, fullPath, function (content) {
                    var details = {
                        text: content,
                        format: "diff",
                        directory: false
                    };
                    fn(details);
                });
            }
            return git;
        };
        GitWikiRepository.prototype.putPage = function (branch, path, contents, commitMessage, fn) {
            var fullPath = this.getPath(path);
            this.git().write(branch, fullPath, commitMessage, contents, fn);
        };
        GitWikiRepository.prototype.revertTo = function (objectId, blobPath, commitMessage, fn) {
            var fullPath = this.getLogPath(blobPath);
            this.git().revertTo(objectId, fullPath, commitMessage, fn);
        };
        GitWikiRepository.prototype.deletePage = function (path, fn) {
            var fullPath = this.getPath(path);
            var commitMessage = "Removing wiki page " + path;
            this.git().remove(fullPath, commitMessage, fn);
        };
        GitWikiRepository.prototype.getPath = function (path) {
            var directoryPrefix = this.directoryPrefix;
            return (directoryPrefix) ? directoryPrefix + path : path;
        };
        GitWikiRepository.prototype.getLogPath = function (path) {
            return Core.trimLeading(this.getPath(path), "/");
        };
        GitWikiRepository.prototype.history = function (objectId, path, limit, fn) {
            var fullPath = this.getLogPath(path);
            var git = this.git();
            if(git) {
                git.history(objectId, fullPath, limit, fn);
            }
            return git;
        };
        GitWikiRepository.prototype.getContent = function (objectId, blobPath, fn) {
            var fullPath = this.getLogPath(blobPath);
            var git = this.git();
            if(git) {
                git.getContent(objectId, fullPath, fn);
            }
            return git;
        };
        GitWikiRepository.prototype.jsonChildContents = function (path, nameWildcard, search, fn) {
            var fullPath = this.getLogPath(path);
            var git = this.git();
            if(git) {
                git.readJsonChildContent(fullPath, nameWildcard, search, fn);
            }
            return git;
        };
        GitWikiRepository.prototype.git = function () {
            var repository = this.factoryMethod();
            if(!repository) {
                console.log("No repository yet! TODO we should use a local impl!");
            }
            return repository;
        };
        return GitWikiRepository;
    })();
    Wiki.GitWikiRepository = GitWikiRepository;    
})(Wiki || (Wiki = {}));
//@ sourceMappingURL=app.js.map
