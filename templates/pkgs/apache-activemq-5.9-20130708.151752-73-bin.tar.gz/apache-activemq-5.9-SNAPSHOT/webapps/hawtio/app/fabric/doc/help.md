### Fabric

This plugin works with [Fuse Fabric](http://fuse.fusesource.org/fabric/) to allow you to provision and configure clusters of [JBoss Fuse](http://www.jboss.org/jbossfuse) and introspect the running cluster.