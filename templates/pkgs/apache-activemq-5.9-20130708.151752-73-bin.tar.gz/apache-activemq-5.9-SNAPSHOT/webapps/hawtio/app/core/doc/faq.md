### Frequently Asked Questions

##### 1. Why does hawtio log a bunch of 404s to the javascript console at startup?

    The hawtio help registry tries to automatically discover help data for each registered plugin even if plugins haven't specifically registered a help file.


Also checkout the [hawtio](http://hawt.io) FAQ [here](http://hawt.io/faq/index.html)