package indirect::TestRequired4::b0;
sub get {
 eval 'require indirect::TestRequired4::c0';
}
1;
