package Factory;

use strict;

use Class::Factory::Util;

1;
