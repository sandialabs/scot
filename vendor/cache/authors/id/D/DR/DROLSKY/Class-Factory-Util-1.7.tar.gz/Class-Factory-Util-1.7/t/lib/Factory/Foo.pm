package Factory::Foo;

1;
