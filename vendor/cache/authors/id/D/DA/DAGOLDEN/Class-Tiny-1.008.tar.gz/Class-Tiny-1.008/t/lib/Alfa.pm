use 5.006;
use strict;
use warnings;

package Alfa;

use Class::Tiny qw/foo bar/;

1;
