use 5.006;
use strict;
use warnings;

package Baker;
use base 'Alfa';

use Class::Tiny qw/baz/;

1;
