package MojoliciousTest::Command::_test2_command;
use Mojo::Base 'Mojolicious::Command';

sub run {'works 2!'}

1;
