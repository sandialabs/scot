<?php
print_r(parse_ini_file('php-compat.ini', true));
