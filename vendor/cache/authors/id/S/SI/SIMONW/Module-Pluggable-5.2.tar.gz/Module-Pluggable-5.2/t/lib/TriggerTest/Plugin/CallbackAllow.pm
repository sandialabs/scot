package TriggerTest::Plugin::CallbackAllow;

sub exclude {
    return 0;
}
1;