package TriggerTest::Plugin::CallbackDeny;

sub exclude {
    return 1;
}
1;