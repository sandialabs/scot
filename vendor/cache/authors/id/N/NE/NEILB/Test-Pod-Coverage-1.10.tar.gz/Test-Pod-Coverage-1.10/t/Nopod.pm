package Nopod;

# Documentation is for wimps!
#
sub foo {}
sub bar {}
sub baz {}

1;
