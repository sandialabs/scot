     # This is a test #

     **This is bold**

     *This is italic*

     `This is teletype`

     - - -

       1.  One

       2.  Two

     This is a quote from Abraham Lincoln:
     > Four score and seven years ago our fathers 
     > brought forth on this continent, a new 
     > nation, conceived in Liberty, and dedicated 
     > to the proposition that all men are created 
     > equal. 


     In order to install and use this package you
     will need Perl version 5.004 or better. You
     will also need to have the HTML-Tree
     distribution (version 0.61 or better)
     installed. If you intend to use the PostScript
     formatter you need the Font-AFM distribution.
     All of these should be available from CPAN. In
     order to install and use this package you will
     need Perl version 5.004 or better. You will
     also need to have the HTML-Tree distribution
     (version 0.61 or better) installed. If you
     intend to use the PostScript formatter you
     need the Font-AFM distribution. All of these
     should be available from CPAN. In order to
     install and use this package you will need
     Perl version 5.004 or better. You will also
     need to have the HTML-Tree distribution
     (version 0.61 or better) installed. If you
     intend to use the PostScript formatter you
     need the Font-AFM distribution. All of these
     should be available from CPAN.

     In order to install and use this package you
     will need Perl version 5.004 or better.

       * You will also need to have the HTML-Tree
         distribution (version 0.61 or better)
         installed.

       * If you intend to use the PostScript
         formatter you need the Font-AFM
         distribution.

     All of these should be available from CPAN.

     In order to install and use this package you
     will need Perl version 5.004 or better. You
     will also need to have the HTML-Tree
     distribution (version 0.61 or better)
     installed. If you intend to use the PostScript
     formatter you need the Font-AFM distribution.
     All of these should be available from CPAN.

     ## Installation ##

     Just follow the usual procedure:

         perl Makefile.PL
         make
         make test
         make install

     In order to install and use this package you
     will need Perl version 5.004 or better. You
     will also need to have the HTML-Tree
     distribution (version 0.61 or better)
     installed. If you intend to use the PostScript
     formatter you need the Font-AFM distribution.
     All of these should be available from CPAN.

     [Byte me dot org](http://byte-me.org)
