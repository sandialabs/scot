     French: hétérogénéité, ça a beaucoup
     d'accents.

     Polish: welcome to sunny Łódź.

     Here's how you say "tax return" in Thai:
     คำร้องขอคืนเงินภาษีอากร

     This Mongolian person's twitter username
     character is not a soft-hyphen:
     ᠭ-ᠪᠢᠰᠢᠷᠡᠯ

     Let us all worship at the shrine of Emoji: how
     else could you throw a pile of poo at a
     snowman?
     💩→☃

     This sentence is full of non-breaking spaces
     but it'll be broken anyway.

     I put a hyphen in
     llanfairpwllgwyngyllgogerychwyrndrob
     wllllantysiliogogogoch and it ended up as a
     space.

