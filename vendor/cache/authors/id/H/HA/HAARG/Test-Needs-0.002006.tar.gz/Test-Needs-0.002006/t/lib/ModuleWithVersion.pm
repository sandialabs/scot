package ModuleWithVersion;

our $VERSION = 1;

1;
