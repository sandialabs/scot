package TrueModule;
our $LOADED;
$LOADED++;
1;
