package LWP::DebugFile;

our $VERSION = '6.53';

# legacy stub

1;
