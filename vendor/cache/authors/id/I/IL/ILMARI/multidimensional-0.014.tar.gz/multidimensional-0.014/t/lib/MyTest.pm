package MyTest;

my %a;

$a{1,2} if 0;

1;
