package t::Nest0;

{ use 5.006; }
use warnings;
use strict;
use t::Nested;

our $VERSION = 1;

"t::Nest0 return";
