#!/home/ben/software/install/bin/perl
use warnings;
use strict;
use HTML::Make;
my $tr = HTML::Make->new ('tr');
$tr->push ('li');
