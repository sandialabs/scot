# test-memory-cycle

Test::Memory::Cycle -- A Perl module to check for memory leaks and circular memory references.

It's a thin Test::More-compatible wrapper around Lincoln Stein's
Devel::Cycle module.
