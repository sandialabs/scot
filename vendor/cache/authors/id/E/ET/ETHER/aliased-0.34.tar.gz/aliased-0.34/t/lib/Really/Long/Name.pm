package Really::Long::Name;

sub thing { return $_[1] + 2 }

1;
