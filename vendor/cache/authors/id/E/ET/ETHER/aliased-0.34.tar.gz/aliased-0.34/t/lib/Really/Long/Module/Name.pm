package Really::Long::Module::Name;

sub new { bless {} => shift }

1;
