package NoSigDie;

use strict;
use warnings;

1;
