package CatalystLike::Controller;
use Moose;
use namespace::autoclean;
use MooseX::MethodAttributes;
with 'MooseX::MethodAttributes::Role::AttrContainer::Inheritable';

1;
