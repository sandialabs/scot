#!/usr/bin/env perl
package Class::Load::VersionCheck;
use strict;
use warnings;

our $VERSION = 42;

sub ok { 1 }

1;

