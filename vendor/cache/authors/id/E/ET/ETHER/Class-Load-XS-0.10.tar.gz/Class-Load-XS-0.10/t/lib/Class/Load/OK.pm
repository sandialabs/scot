#!/usr/bin/env perl
package Class::Load::OK;
use strict;
use warnings;

sub ok { 1 }

1;

