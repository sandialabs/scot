package PPI::Exception::ParserRejection;

use strict;
use PPI::Exception ();

our $VERSION = '1.270'; # VERSION

our @ISA = 'PPI::Exception';

1;
