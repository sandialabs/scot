#!/usr/bin/perl

if ( 1 ) {
	print "Hello World!\n";
}

#line 1000 moo.pl
print "Goodbye Blue Sky\n";

1;
