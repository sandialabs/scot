This is PSGI, Perl Web Server Gateway Interface -- ala Python's WSGI and Ruby's Rack.

[PSGI protocol specification](http://github.com/plack/psgi-specs/blob/master/PSGI.pod) is currently 1.0, and we're eworking on revising it to make version 1.1. See also [FAQ](http://github.com/plack/psgi-specs/blob/master/FAQ.pod)

See [PSGI/Plack website](http://plackperl.org/) for more links.
