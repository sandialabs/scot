IPC-Shareable
=============

Incorporation of patches provided by others to CPAN's IPC::Shareable, which I did not write and am only helping maintain.