use 5.010001;
use strict;
use warnings;

package PPSubclass;
use base qw/BSON::PP/;

1;

