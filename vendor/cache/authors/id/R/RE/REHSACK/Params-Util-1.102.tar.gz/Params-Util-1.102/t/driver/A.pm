package A;

# This is our driver class

use strict;

use vars qw{$VERSION};

BEGIN
{
    $VERSION = '0.01';
}

sub dummy { 1 }

1;
