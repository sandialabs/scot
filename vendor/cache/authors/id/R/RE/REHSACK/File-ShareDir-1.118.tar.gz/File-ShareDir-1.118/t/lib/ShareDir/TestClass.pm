package ShareDir::TestClass;

use strict;

use parent ("File::ShareDir");

our $VERSION = "1.118";

1;
