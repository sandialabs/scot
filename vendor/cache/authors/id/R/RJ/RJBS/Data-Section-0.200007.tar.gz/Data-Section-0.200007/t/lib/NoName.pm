use strict;
use warnings;
package NoName;
use Data::Section -setup => { default_name => 'a' };

1;
__DATA__
1
__[b]__
2
