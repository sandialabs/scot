use utf8;
package Unicode_pragma;
use Data::Section -setup;

1;
__DATA__
__[a]__
☺
