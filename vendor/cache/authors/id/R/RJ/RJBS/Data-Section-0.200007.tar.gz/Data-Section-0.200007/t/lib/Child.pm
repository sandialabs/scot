use strict;
use warnings;
package Child;
use Godfather;
use base qw(Mother Godfather);
1;
__DATA__
__[b]__
22
__[c]__
33
__[d]__
44
