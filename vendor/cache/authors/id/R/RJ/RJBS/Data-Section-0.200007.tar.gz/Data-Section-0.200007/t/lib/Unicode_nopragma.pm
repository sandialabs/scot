package Unicode_nopragma;
use Data::Section -setup;

1;
__DATA__
__[a]__
☺
