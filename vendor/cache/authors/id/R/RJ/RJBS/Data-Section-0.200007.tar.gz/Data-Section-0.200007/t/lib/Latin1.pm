# vim: fileencoding=latin1
package Latin1;
use Data::Section -setup => { encoding => "latin1" };

1;
__DATA__
__[a]__
Ricardo Juli�n Besteiro Signes
