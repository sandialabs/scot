package Relaxed;
use Data::Section -setup;

1;
__DATA__

__[a]__
1
__[b]__
2
