# This is a dummy class used only for testing RPC::XML::ParserFactory.

package BadParserClass;

1;
