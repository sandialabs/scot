package Some;

1;
__END__