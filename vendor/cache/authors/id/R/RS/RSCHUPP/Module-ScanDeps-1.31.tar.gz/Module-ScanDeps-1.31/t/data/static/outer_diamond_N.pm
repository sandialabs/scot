package outer_diamond_N;

use outer_diamond_E;
use outer_diamond_W;
use inner_diamond_N;

1;
__END__