package Sibling;
use Parent ();
use base 'Parent';

sub grandparent_method {
}

1;
__END__
