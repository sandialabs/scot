package Simple8;
1;

=item docs

=cut
