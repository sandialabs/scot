package GrandParent;

sub dummy {};

1;
__END__

=head1 NAME

GrandParent

=head2 grandparent_method

=cut
