package Simple9;

use Foo::Invalid;

=item docs

=cut
