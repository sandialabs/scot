package Devel::_NC_TEST_DashD;

use warnings;
use strict;

sub DB::DB { 1 }

1;

